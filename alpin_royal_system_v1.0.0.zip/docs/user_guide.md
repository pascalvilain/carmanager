# Alpin Royal Casino Management System - User Guide

## Introduction

Welcome to the Alpin Royal Casino Management System, a comprehensive solution designed to streamline and automate casino operations. This user guide provides detailed instructions on how to use the various modules and features of the system.

## Getting Started

### Logging In

1. Open your web browser and navigate to the application URL provided by your system administrator.
2. Enter your username and password on the login screen.
3. Click the "Login" button to access the system.

### Dashboard Overview

After logging in, you will be directed to the main dashboard, which provides an overview of key metrics and quick access to all modules:

- **Quick Stats**: View important metrics at a glance
- **Recent Activities**: See the latest activities across the system
- **Module Access**: Quick links to all enabled modules
- **Notifications**: System alerts and important messages
- **User Profile**: Access your profile and settings

### Navigation

The main navigation menu is located on the left side of the screen and provides access to all modules and features. You can collapse the menu by clicking the menu icon in the top-left corner.

## Player Tracking Module

The Player Tracking module allows you to manage guest information, track gaming activities, and monitor player behavior.

### Guest Management

#### Adding a New Guest

1. Navigate to the Player Tracking module.
2. Click on "Guests" in the sidebar.
3. Click the "Add New Guest" button.
4. Fill in the required information:
   - Personal details (name, date of birth, contact information)
   - ID information (ID type, number, expiration date)
   - Upload ID photo and reception photo
   - Additional notes
5. Click "Save" to create the guest profile.

#### Searching for Guests

1. Navigate to the Player Tracking module.
2. Use the search bar at the top of the Guests page.
3. Enter the guest's name, ID number, or guest ID.
4. Click the search icon or press Enter.
5. Click on a guest in the results to view their profile.

#### Editing Guest Information

1. Navigate to the guest's profile page.
2. Click the "Edit" button.
3. Update the necessary information.
4. Click "Save" to apply the changes.

### Gaming Session Tracking

#### Starting a Gaming Session

1. Navigate to the guest's profile page.
2. Click the "Start Session" button.
3. Select the gaming area (slots, tables, etc.).
4. Enter the initial buy-in amount if applicable.
5. Click "Start" to begin tracking the session.

#### Recording Table Play

1. Navigate to the active gaming session.
2. Click on "Add Table Activity".
3. Select the table number and game type.
4. Enter the buy-in amount, average bet, and duration.
5. Record chips in/out and any notes.
6. Click "Save" to record the activity.

#### Recording Slot Play

1. Navigate to the active gaming session.
2. Click on "Add Slot Activity".
3. Enter the slot machine number or scan the QR code.
4. Record the money in, ticket in/out, and jackpots if any.
5. Enter the duration of play and any notes.
6. Click "Save" to record the activity.

#### Ending a Gaming Session

1. Navigate to the active gaming session.
2. Click the "End Session" button.
3. Enter any final transactions or notes.
4. Click "Confirm" to end the session.

### Consumption Tracking

#### Recording Drinks and Food

1. Navigate to the active gaming session.
2. Click on "Add Consumption".
3. Select the item category (drinks, food, etc.).
4. Select the specific items and quantities.
5. Click "Save" to record the consumption.

#### Cigarette Tracking

1. Navigate to the active gaming session.
2. Click on "Add Cigarettes".
3. Select the cigarette brand and quantity.
4. Click "Save" to record the cigarette consumption.

### Financial Transactions

#### Recording Buy-ins and Cash-outs

1. Navigate to the active gaming session.
2. Click on "Add Transaction".
3. Select the transaction type (buy-in, cash-out).
4. Enter the amount and payment method.
5. Add any notes if necessary.
6. Click "Save" to record the transaction.

#### Recording Jackpots and Hand Pays

1. Navigate to the active gaming session.
2. Click on "Add Jackpot/Hand Pay".
3. Enter the amount, machine number, and game type.
4. Upload a photo of the win if required.
5. Enter any additional details.
6. Click "Save" to record the win.

### Cigarette Inventory Management

#### Checking Inventory

1. Navigate to the Player Tracking module.
2. Click on "Cigarette Inventory" in the sidebar.
3. View the current stock levels for all cigarette brands.

#### Adding Inventory

1. Navigate to the Cigarette Inventory page.
2. Click "Add Stock".
3. Select the cigarette brand and variant.
4. Enter the quantity to add.
5. Click "Save" to update the inventory.

#### Adjusting Inventory

1. Navigate to the Cigarette Inventory page.
2. Find the cigarette brand to adjust.
3. Click the "Adjust" button.
4. Enter the new quantity and reason for adjustment.
5. Click "Save" to update the inventory.

### Reports and Analytics

#### Generating Reports

1. Navigate to the Player Tracking module.
2. Click on "Reports" in the sidebar.
3. Select the report type:
   - Guest Activity Report
   - Gaming Session Report
   - Financial Transaction Report
   - Consumption Report
   - Cigarette Usage Report
4. Set the date range and any other filters.
5. Click "Generate Report".
6. View the report or export it as PDF, Excel, or CSV.

#### Dashboard Analytics

The Player Tracking dashboard provides real-time analytics including:

- Active gaming sessions
- Total drop (money in) for the day
- Total jackpots and hand pays
- Top players by activity
- Consumption trends
- Cigarette inventory alerts

## Network Design Module

The Network Design module allows you to create and manage network layouts, track devices, and visualize your casino's IT infrastructure.

### Floor Plan Management

#### Uploading a Floor Plan

1. Navigate to the Network Design module.
2. Click on "Floor Plans" in the sidebar.
3. Click the "Upload New Floor Plan" button.
4. Enter a name and description for the floor plan.
5. Select the floor plan image file to upload.
6. Set the scale of the floor plan if known.
7. Click "Upload" to save the floor plan.

#### Editing a Floor Plan

1. Navigate to the Floor Plans page.
2. Click on the floor plan you want to edit.
3. Click the "Edit" button.
4. Make the necessary changes.
5. Click "Save" to apply the changes.

### Device Management

#### Adding a Device

1. Navigate to the Network Design module.
2. Click on "Devices" in the sidebar.
3. Click the "Add New Device" button.
4. Select the device type (camera, switch, router, etc.).
5. Enter the device details:
   - Name and description
   - IP address and MAC address
   - Serial number
   - Manufacturer and model
   - Installation date
6. Click "Save" to add the device.

#### Placing Devices on Floor Plan

1. Navigate to the Floor Plans page.
2. Click on the floor plan where you want to place devices.
3. Click the "Edit Layout" button.
4. From the device palette, drag and drop device icons onto the floor plan.
5. For each device:
   - Select the actual device from the dropdown
   - Adjust position as needed
   - Set orientation and FOV for cameras
6. Click "Save Layout" when finished.

#### Connecting Devices

1. In the floor plan editor, click on a device.
2. Click the "Add Connection" button.
3. Click on another device to create a connection.
4. Enter the connection details:
   - Cable type
   - Cable length
   - Connection ports
5. Click "Save Connection".

### Cable and Patch Panel Management

#### Adding a Patch Panel

1. Navigate to the Network Design module.
2. Click on "Patch Panels" in the sidebar.
3. Click the "Add New Patch Panel" button.
4. Enter the patch panel details:
   - Name and location
   - Number of ports
   - Type and model
5. Click "Save" to add the patch panel.

#### Managing Cable Connections

1. Navigate to the Patch Panels page.
2. Click on a patch panel to view its details.
3. Click on a port to manage its connection.
4. Select the device and port to connect to.
5. Enter the cable number and type.
6. Click "Save Connection".

### Network Visualization

#### Viewing the Network Map

1. Navigate to the Network Design module.
2. Click on "Network Map" in the sidebar.
3. Select the floor plan to view.
4. Use the controls to:
   - Zoom in and out
   - Filter by device type
   - Show or hide connections
   - Show or hide labels

#### Viewing Device Details

1. In the Network Map view, click on any device.
2. View the device details in the side panel:
   - Basic information
   - Connection details
   - Status and alerts
   - Maintenance history

#### Tracing Connections

1. In the Network Map view, click on any device.
2. Click the "Trace Connections" button.
3. The system will highlight all connected devices and cables.
4. Follow the path from device to patch panel to switch.

## Inventory Management Module

The Inventory Management module allows you to track all casino assets, manage inventory levels, and monitor equipment deployment.

### Asset Management

#### Adding a New Asset

1. Navigate to the Inventory Management module.
2. Click on "Assets" in the sidebar.
3. Click the "Add New Asset" button.
4. Select the asset type.
5. Enter the asset details:
   - Name and description
   - Serial number
   - Manufacturer and model
   - Purchase date and cost
   - Warranty information
   - Additional specifications
6. Click "Save" to add the asset.

#### Searching for Assets

1. Navigate to the Assets page.
2. Use the search bar at the top of the page.
3. Enter the asset name, serial number, or asset tag.
4. Click the search icon or press Enter.
5. Click on an asset in the results to view its details.

#### Editing Asset Information

1. Navigate to the asset's detail page.
2. Click the "Edit" button.
3. Update the necessary information.
4. Click "Save" to apply the changes.

### Inventory Tracking

#### Checking Current Inventory

1. Navigate to the Inventory Management module.
2. Click on "Inventory" in the sidebar.
3. View the current inventory levels for all items.
4. Use filters to narrow down the view by category, location, etc.

#### Adding Inventory

1. Navigate to the Inventory page.
2. Click "Add Stock".
3. Select the item to add.
4. Enter the quantity and location.
5. Add any notes or reference numbers.
6. Click "Save" to update the inventory.

#### Transferring Inventory

1. Navigate to the Inventory page.
2. Find the item to transfer.
3. Click the "Transfer" button.
4. Select the source and destination locations.
5. Enter the quantity to transfer.
6. Click "Transfer" to move the inventory.

### Asset Deployment

#### Deploying Assets

1. Navigate to the asset's detail page.
2. Click the "Deploy" button.
3. Select the deployment location.
4. Enter the deployment date and responsible person.
5. Add any notes about the deployment.
6. Click "Deploy" to update the asset status.

#### Placing Assets on Floor Plan

1. Navigate to the Floor Plans page in the Inventory module.
2. Click on the floor plan where you want to place assets.
3. Click the "Edit Layout" button.
4. From the asset palette, drag and drop asset icons onto the floor plan.
5. For each asset:
   - Select the actual asset from the dropdown
   - Adjust position as needed
6. Click "Save Layout" when finished.

### Maintenance Management

#### Scheduling Maintenance

1. Navigate to the asset's detail page.
2. Click the "Schedule Maintenance" button.
3. Enter the maintenance details:
   - Type of maintenance
   - Scheduled date and time
   - Assigned technician
   - Estimated duration
   - Additional notes
4. Click "Save" to schedule the maintenance.

#### Recording Maintenance

1. Navigate to the Maintenance page.
2. Find the scheduled maintenance task.
3. Click the "Record" button.
4. Enter the maintenance results:
   - Actual completion date and time
   - Work performed
   - Parts replaced
   - Additional notes
5. Update the asset status if necessary.
6. Click "Save" to record the maintenance.

### Reports and Analytics

#### Generating Reports

1. Navigate to the Inventory Management module.
2. Click on "Reports" in the sidebar.
3. Select the report type:
   - Asset Inventory Report
   - Deployment Report
   - Maintenance History Report
   - Value and Depreciation Report
4. Set the date range and any other filters.
5. Click "Generate Report".
6. View the report or export it as PDF, Excel, or CSV.

#### Dashboard Analytics

The Inventory Management dashboard provides real-time analytics including:

- Total asset count and value
- Assets by category and location
- Deployment status
- Maintenance schedule
- Low inventory alerts
- Recent activities

## Ticket System Module

The Ticket System module allows you to create and manage support tickets for technical issues, maintenance requests, and other casino operations.

### Ticket Management

#### Creating a New Ticket

1. Navigate to the Ticket System module.
2. Click on "Tickets" in the sidebar.
3. Click the "Create New Ticket" button.
4. Enter the ticket details:
   - Title and description
   - Category and priority
   - Department
   - Location and floor plan position (if applicable)
   - Assigned person (if known)
   - Due date (if applicable)
   - Attachments (if any)
5. Click "Create Ticket" to submit.

#### Searching for Tickets

1. Navigate to the Tickets page.
2. Use the search bar at the top of the page.
3. Enter keywords, ticket number, or creator name.
4. Use filters to narrow down by status, priority, category, etc.
5. Click the search icon or press Enter.
6. Click on a ticket in the results to view its details.

#### Updating Ticket Status

1. Navigate to the ticket's detail page.
2. Click the "Update Status" button.
3. Select the new status from the dropdown.
4. Add a comment explaining the status change if necessary.
5. Click "Update" to save the changes.

### Ticket Communication

#### Adding Comments

1. Navigate to the ticket's detail page.
2. Scroll to the comments section.
3. Type your comment in the text box.
4. Check the "Internal Comment" box if the comment should only be visible to staff.
5. Add attachments if necessary.
6. Click "Add Comment" to post.

#### Adding Attachments

1. Navigate to the ticket's detail page.
2. Click the "Add Attachment" button.
3. Select the files to upload.
4. Add a description for each attachment if necessary.
5. Click "Upload" to add the attachments.

### Ticket Assignment

#### Assigning Tickets

1. Navigate to the ticket's detail page.
2. Click the "Assign" button.
3. Select the person to assign the ticket to.
4. Add a note about the assignment if necessary.
5. Click "Assign" to update the ticket.

#### Managing Assignments

1. Navigate to the Ticket System module.
2. Click on "My Assignments" in the sidebar.
3. View all tickets assigned to you.
4. Sort by priority, due date, or status.
5. Click on a ticket to view its details and take action.

### Floor Plan Integration

#### Viewing Tickets on Floor Plan

1. Navigate to the Ticket System module.
2. Click on "Floor Plan View" in the sidebar.
3. Select the floor plan to view.
4. Tickets associated with locations on the floor plan will be displayed as markers.
5. Click on a marker to view the ticket details.

#### Creating Location-Based Tickets

1. Navigate to the Floor Plan View.
2. Click on the location where the issue is occurring.
3. Click the "Create Ticket Here" button.
4. Fill in the ticket details.
5. The location coordinates will be automatically populated.
6. Click "Create Ticket" to submit.

### Reports and Analytics

#### Generating Reports

1. Navigate to the Ticket System module.
2. Click on "Reports" in the sidebar.
3. Select the report type:
   - Ticket Status Report
   - Resolution Time Report
   - Ticket by Category Report
   - Ticket by Department Report
   - Technician Performance Report
4. Set the date range and any other filters.
5. Click "Generate Report".
6. View the report or export it as PDF, Excel, or CSV.

#### Dashboard Analytics

The Ticket System dashboard provides real-time analytics including:

- Open tickets by status
- Tickets by priority and category
- Average resolution time
- Technician workload
- Overdue tickets
- Recent ticket activities

## Mobile Application

The Alpin Royal Casino Management System includes a mobile application for staff to use while moving around the casino floor.

### Installation

1. Download the Alpin Royal mobile app from the App Store (iOS) or Google Play Store (Android).
2. Install the app on your device.
3. Open the app and enter the server URL provided by your system administrator.
4. Log in with your username and password.

### Player Tracking on Mobile

#### Quick Guest Lookup

1. Tap the "Guests" icon on the mobile dashboard.
2. Use the search bar to find a guest by name or ID.
3. Tap on a guest to view their profile.

#### Recording Gaming Activity

1. Navigate to the guest's profile.
2. Tap "Add Activity".
3. Select the activity type (slot play, table play, etc.).
4. Enter the required information using the simplified mobile interface.
5. Tap "Save" to record the activity.

#### Recording Consumption

1. Navigate to the guest's profile.
2. Tap "Add Consumption".
3. Select items from the quick-access menu.
4. Adjust quantities as needed.
5. Tap "Save" to record the consumption.

### Ticket System on Mobile

#### Creating Tickets

1. Tap the "Tickets" icon on the mobile dashboard.
2. Tap the "+" button to create a new ticket.
3. Fill in the required information.
4. Take photos directly from the app if needed.
5. Tap "Submit" to create the ticket.

#### Managing Assigned Tickets

1. Tap the "My Tickets" icon on the mobile dashboard.
2. View all tickets assigned to you.
3. Tap on a ticket to view details and take action.
4. Update status, add comments, or upload photos as needed.

## System Administration

### User Management

#### Adding Users

1. Navigate to the Administration module.
2. Click on "Users" in the sidebar.
3. Click the "Add New User" button.
4. Enter the user details:
   - Username and password
   - Full name and contact information
   - Role and permissions
   - Department and position
5. Click "Create User" to add the user.

#### Managing Roles and Permissions

1. Navigate to the Administration module.
2. Click on "Roles & Permissions" in the sidebar.
3. To create a new role, click "Add New Role".
4. Enter the role name and description.
5. Set the permissions for each module and feature.
6. Click "Save" to create the role.

### Module Management

#### Enabling/Disabling Modules

1. Navigate to the Administration module.
2. Click on "Modules" in the sidebar.
3. View the list of available modules.
4. Toggle the switch next to a module to enable or disable it.
5. Configure module-specific settings if necessary.
6. Click "Save Changes" to apply.

### System Configuration

#### General Settings

1. Navigate to the Administration module.
2. Click on "Settings" in the sidebar.
3. Configure general settings:
   - Casino name and contact information
   - Regional settings (currency, date format, etc.)
   - System appearance and branding
   - Default values and behaviors
4. Click "Save Changes" to apply.

#### Backup and Restore

1. Navigate to the Administration module.
2. Click on "Backup & Restore" in the sidebar.
3. To create a backup, click "Create Backup".
4. Select what to include in the backup.
5. Click "Start Backup" to begin the process.
6. To restore from a backup, click "Restore".
7. Select the backup file to restore from.
8. Click "Start Restore" to begin the process.

## Troubleshooting

### Common Issues

#### Login Problems

- Ensure you are using the correct username and password.
- Check if your account is locked due to multiple failed login attempts.
- Contact your system administrator if you cannot reset your password.

#### Slow Performance

- Check your internet connection.
- Close unnecessary browser tabs and applications.
- Clear your browser cache and cookies.
- Try using a different browser.

#### Data Not Saving

- Ensure you have the necessary permissions.
- Check if all required fields are filled in.
- Try refreshing the page and entering the data again.
- Contact your system administrator if the problem persists.

### Getting Help

If you encounter any issues not covered in this guide:

1. Click the "Help" icon in the top-right corner of the application.
2. Search the knowledge base for solutions.
3. Click "Contact Support" to submit a support ticket.
4. Provide detailed information about the issue, including screenshots if possible.

## Appendix

### Keyboard Shortcuts

- **Ctrl+S**: Save current form
- **Ctrl+N**: Create new item
- **Ctrl+F**: Search
- **Ctrl+H**: Show help
- **Ctrl+D**: Go to dashboard
- **Esc**: Cancel/Close dialog

### Glossary

- **Drop**: Money inserted into a slot machine
- **Hand Pay**: A jackpot paid by hand by a casino employee
- **TITO**: Ticket In, Ticket Out system for slot machines
- **FOV**: Field of View for surveillance cameras
- **PTZ**: Pan-Tilt-Zoom camera functionality

### Contact Information

For additional support, contact:

- **Technical Support**: support@alpinroyal.com
- **Training**: training@alpinroyal.com
- **Sales**: sales@alpinroyal.com

© 2025 Alpin Royal. All rights reserved.
