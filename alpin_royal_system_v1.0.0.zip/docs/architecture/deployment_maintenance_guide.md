"""
Casino Management System - Deployment and Maintenance Guide
This document provides guidance for deploying and maintaining the casino management system.
"""

# Deployment and Maintenance Guide for Casino Management System

## Overview

This guide provides comprehensive instructions for deploying, configuring, and maintaining the Casino Management System. It covers deployment strategies, environment setup, backup procedures, monitoring, and routine maintenance tasks to ensure the system runs smoothly in a production environment.

## System Requirements

### Hardware Requirements

#### Production Server Requirements
- **Application Servers**: 
  - Minimum: 8 CPU cores, 16GB RAM, 100GB SSD
  - Recommended: 16 CPU cores, 32GB RAM, 250GB SSD
- **Database Servers**:
  - PostgreSQL: 8 CPU cores, 32GB RAM, 500GB SSD (RAID configuration recommended)
  - MongoDB: 8 CPU cores, 32GB RAM, 500GB SSD
  - Redis: 4 CPU cores, 16GB RAM, 100GB SSD
- **Storage Server**:
  - MinIO/S3: 4 CPU cores, 16GB RAM, 1TB+ storage (expandable)

#### Client Device Requirements
- **Desktop Workstations**:
  - Minimum: Quad-core CPU, 8GB RAM, modern web browser
  - Recommended: 6+ core CPU, 16GB RAM, dedicated graphics
- **Mobile Devices**:
  - Tablets: iPad (6th gen or newer), Samsung Galaxy Tab S6 or newer
  - Smartphones: iPhone X or newer, Samsung Galaxy S10 or newer
  - Minimum 4GB RAM, 32GB storage

### Software Requirements

#### Server Environment
- **Operating System**: Ubuntu Server 22.04 LTS or newer
- **Container Platform**: Docker 20.10+, Docker Compose 2.0+
- **Database Software**:
  - PostgreSQL 14+
  - MongoDB 5.0+
  - Redis 6.2+
- **Object Storage**: MinIO or AWS S3-compatible storage
- **Web Server**: Nginx 1.20+
- **SSL Certificate**: Valid SSL certificate for secure communication

#### Development Environment
- **Python**: 3.10+
- **Node.js**: 16.0+
- **Package Managers**: pip, npm
- **Version Control**: Git 2.30+
- **CI/CD**: Jenkins, GitHub Actions, or GitLab CI

## Deployment Architecture

### Single-Server Deployment

For smaller casinos with limited IT resources, a single-server deployment can be used:

```
                   ┌─────────────────────────────────────┐
                   │           Single Server             │
                   │                                     │
┌─────────┐        │  ┌─────────┐       ┌────────────┐  │
│         │        │  │         │       │            │  │
│ Clients ├────────┼──┤  Nginx  ├───────┤ API Server │  │
│         │        │  │         │       │            │  │
└─────────┘        │  └─────────┘       └──────┬─────┘  │
                   │                           │        │
                   │  ┌─────────┐       ┌──────▼─────┐  │
                   │  │         │       │            │  │
                   │  │  MinIO  │◄──────┤ Databases  │  │
                   │  │         │       │            │  │
                   │  └─────────┘       └────────────┘  │
                   │                                     │
                   └─────────────────────────────────────┘
```

### Multi-Server Deployment

For medium to large casinos, a multi-server deployment is recommended:

```
                                 ┌─────────────────┐
                                 │  Load Balancer  │
                                 └────────┬────────┘
                                          │
                 ┌────────────────────────┼────────────────────────┐
                 │                        │                        │
        ┌────────▼────────┐     ┌─────────▼─────────┐     ┌───────▼────────┐
        │                 │     │                   │     │                │
        │  API Server 1   │     │   API Server 2    │     │  API Server 3  │
        │                 │     │                   │     │                │
        └────────┬────────┘     └─────────┬─────────┘     └───────┬────────┘
                 │                        │                        │
                 └────────────────────────┼────────────────────────┘
                                          │
                 ┌────────────────────────┼────────────────────────┐
                 │                        │                        │
        ┌────────▼────────┐     ┌─────────▼─────────┐     ┌───────▼────────┐
        │                 │     │                   │     │                │
        │   PostgreSQL    │     │     MongoDB       │     │     Redis      │
        │                 │     │                   │     │                │
        └─────────────────┘     └───────────────────┘     └────────────────┘
                                          │
                                 ┌────────▼────────┐
                                 │                 │
                                 │  Storage (S3)   │
                                 │                 │
                                 └─────────────────┘
```

### Cloud Deployment

For maximum scalability and reliability, a cloud-based deployment can be used:

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Cloud Provider                              │
│                                                                     │
│  ┌─────────────────┐      ┌─────────────────┐                       │
│  │                 │      │                 │                       │
│  │  Load Balancer  │      │  API Cluster    │                       │
│  │                 │      │                 │                       │
│  └────────┬────────┘      └────────┬────────┘                       │
│           │                        │                                │
│           └────────────────────────┘                                │
│                        │                                            │
│  ┌─────────────────────┼─────────────────────┐                      │
│  │                     │                     │                      │
│  │  ┌─────────────┐    │    ┌─────────────┐  │   ┌─────────────┐   │
│  │  │             │    │    │             │  │   │             │   │
│  │  │ PostgreSQL  │    │    │  MongoDB    │  │   │    Redis    │   │
│  │  │   Cluster   │    │    │  Cluster    │  │   │   Cluster   │   │
│  │  │             │    │    │             │  │   │             │   │
│  │  └─────────────┘    │    └─────────────┘  │   └─────────────┘   │
│  │                     │                     │                      │
│  └─────────────────────┼─────────────────────┘                      │
│                        │                                            │
│                ┌───────▼────────┐                                   │
│                │                │                                   │
│                │  Object Storage│                                   │
│                │                │                                   │
│                └────────────────┘                                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## Deployment Process

### 1. Environment Setup

#### Docker-based Deployment

Create a `docker-compose.yml` file:

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:14
    environment:
      POSTGRES_USER: casino_user
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: casino_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U casino_user -d casino_db"]
      interval: 10s
      timeout: 5s
      retries: 5

  mongodb:
    image: mongo:5.0
    environment:
      MONGO_INITDB_ROOT_USERNAME: casino_user
      MONGO_INITDB_ROOT_PASSWORD: ${MONGO_PASSWORD}
    volumes:
      - mongo_data:/data/db
    ports:
      - "27017:27017"
    restart: unless-stopped
    healthcheck:
      test: echo 'db.runCommand("ping").ok' | mongosh localhost:27017/test --quiet
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:6.2
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  minio:
    image: minio/minio
    volumes:
      - minio_data:/data
    ports:
      - "9000:9000"
      - "9001:9001"
    environment:
      MINIO_ROOT_USER: ${MINIO_ACCESS_KEY}
      MINIO_ROOT_PASSWORD: ${MINIO_SECRET_KEY}
    command: server /data --console-address ":9001"
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 30s
      timeout: 20s
      retries: 3

  api:
    build:
      context: .
      dockerfile: Dockerfile
    environment:
      - POSTGRES_HOST=postgres
      - POSTGRES_PORT=5432
      - POSTGRES_USER=casino_user
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
      - POSTGRES_DB=casino_db
      - MONGO_HOST=mongodb
      - MONGO_PORT=27017
      - MONGO_USER=casino_user
      - MONGO_PASSWORD=${MONGO_PASSWORD}
      - REDIS_HOST=redis
      - REDIS_PORT=6379
      - REDIS_PASSWORD=${REDIS_PASSWORD}
      - MINIO_HOST=minio
      - MINIO_PORT=9000
      - MINIO_ACCESS_KEY=${MINIO_ACCESS_KEY}
      - MINIO_SECRET_KEY=${MINIO_SECRET_KEY}
      - JWT_SECRET=${JWT_SECRET}
    ports:
      - "8080:8080"
    depends_on:
      postgres:
        condition: service_healthy
      mongodb:
        condition: service_healthy
      redis:
        condition: service_healthy
      minio:
        condition: service_healthy
    restart: unless-stopped

  nginx:
    image: nginx:1.21
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/conf.d:/etc/nginx/conf.d
      - ./nginx/ssl:/etc/nginx/ssl
      - ./frontend/build:/usr/share/nginx/html
    depends_on:
      - api
    restart: unless-stopped

volumes:
  postgres_data:
  mongo_data:
  redis_data:
  minio_data:
```

Create a `.env` file for secrets:

```
POSTGRES_PASSWORD=secure_postgres_password
MONGO_PASSWORD=secure_mongo_password
REDIS_PASSWORD=secure_redis_password
MINIO_ACCESS_KEY=minio_access_key
MINIO_SECRET_KEY=secure_minio_secret
JWT_SECRET=secure_jwt_secret_key
```

Create a Dockerfile for the API:

```dockerfile
FROM python:3.10-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Expose port
EXPOSE 8080

# Run the application
CMD ["uvicorn", "base_layer.core.app:app", "--host", "0.0.0.0", "--port", "8080"]
```

### 2. Database Initialization

Create a script to initialize the databases:

```python
# init_db.py
import asyncio
import os
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import create_async_engine
from pymongo import MongoClient
import redis

async def init_postgres():
    # Create PostgreSQL tables
    from sqlalchemy.schema import CreateTable
    from modules.player_tracking.models.player import Player
    from modules.player_tracking.models.gaming_session import GamingSession
    from modules.player_tracking.models.financial import FinancialTransaction
    
    # Connect to PostgreSQL
    engine = create_engine(
        f"postgresql://{os.environ['POSTGRES_USER']}:{os.environ['POSTGRES_PASSWORD']}@"
        f"{os.environ['POSTGRES_HOST']}:{os.environ['POSTGRES_PORT']}/{os.environ['POSTGRES_DB']}"
    )
    
    # Create tables
    with engine.connect() as conn:
        conn.execute(CreateTable(Player.__table__))
        conn.execute(CreateTable(GamingSession.__table__))
        conn.execute(CreateTable(FinancialTransaction.__table__))
        conn.commit()
    
    print("PostgreSQL tables created successfully")

def init_mongodb():
    # Connect to MongoDB
    client = MongoClient(
        f"mongodb://{os.environ['MONGO_USER']}:{os.environ['MONGO_PASSWORD']}@"
        f"{os.environ['MONGO_HOST']}:{os.environ['MONGO_PORT']}"
    )
    
    # Create collections
    db = client.casino_db
    db.create_collection("player_events")
    db.create_collection("consumption_records")
    db.create_collection("ai_insights")
    
    print("MongoDB collections created successfully")

def init_redis():
    # Connect to Redis
    r = redis.Redis(
        host=os.environ['REDIS_HOST'],
        port=int(os.environ['REDIS_PORT']),
        password=os.environ['REDIS_PASSWORD']
    )
    
    # Set initial keys
    r.set("system:status", "initialized")
    r.set("system:version", "1.0.0")
    
    print("Redis initialized successfully")

async def main():
    await init_postgres()
    init_mongodb()
    init_redis()
    print("Database initialization complete")

if __name__ == "__main__":
    asyncio.run(main())
```

### 3. Deployment Steps

1. **Prepare the environment**:
   ```bash
   # Clone the repository
   git clone https://github.com/your-org/casino-management-system.git
   cd casino-management-system
   
   # Create .env file with secrets
   cp .env.example .env
   # Edit .env with secure passwords
   ```

2. **Build and start the containers**:
   ```bash
   docker-compose build
   docker-compose up -d
   ```

3. **Initialize the databases**:
   ```bash
   docker-compose exec api python init_db.py
   ```

4. **Create an admin user**:
   ```bash
   docker-compose exec api python create_admin.py
   ```

5. **Verify deployment**:
   ```bash
   # Check if all services are running
   docker-compose ps
   
   # Check API health
   curl http://localhost:8080/health
   ```

## Backup and Recovery

### Database Backup

#### PostgreSQL Backup

Create a script for automated PostgreSQL backups:

```bash
#!/bin/bash
# postgres_backup.sh

# Configuration
BACKUP_DIR="/backups/postgres"
POSTGRES_CONTAINER="casino-management-system_postgres_1"
POSTGRES_USER="casino_user"
POSTGRES_DB="casino_db"
RETENTION_DAYS=7

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Generate filename with timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/postgres_$TIMESTAMP.sql.gz"

# Perform backup
docker exec $POSTGRES_CONTAINER pg_dump -U $POSTGRES_USER $POSTGRES_DB | gzip > $BACKUP_FILE

# Check if backup was successful
if [ $? -eq 0 ]; then
    echo "PostgreSQL backup completed successfully: $BACKUP_FILE"
else
    echo "PostgreSQL backup failed!"
    exit 1
fi

# Remove old backups
find $BACKUP_DIR -name "postgres_*.sql.gz" -type f -mtime +$RETENTION_DAYS -delete
```

#### MongoDB Backup

Create a script for automated MongoDB backups:

```bash
#!/bin/bash
# mongodb_backup.sh

# Configuration
BACKUP_DIR="/backups/mongodb"
MONGODB_CONTAINER="casino-management-system_mongodb_1"
MONGO_USER="casino_user"
MONGO_PASSWORD="your_password"
RETENTION_DAYS=7

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Generate filename with timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/mongodb_$TIMESTAMP"

# Perform backup
docker exec $MONGODB_CONTAINER mongodump --username $MONGO_USER --password $MONGO_PASSWORD --authenticationDatabase admin --out /tmp/mongodb_backup
docker cp $MONGODB_CONTAINER:/tmp/mongodb_backup $BACKUP_FILE
docker exec $MONGODB_CONTAINER rm -rf /tmp/mongodb_backup

# Compress backup
tar -czf $BACKUP_FILE.tar.gz -C $BACKUP_DIR $(basename $BACKUP_FILE)
rm -rf $BACKUP_FILE

# Check if backup was successful
if [ $? -eq 0 ]; then
    echo "MongoDB backup completed successfully: $BACKUP_FILE.tar.gz"
else
    echo "MongoDB backup failed!"
    exit 1
fi

# Remove old backups
find $BACKUP_DIR -name "mongodb_*.tar.gz" -type f -mtime +$RETENTION_DAYS -delete
```

### Backup Automation

Set up cron jobs to automate backups:

```bash
# Edit crontab
crontab -e
<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>