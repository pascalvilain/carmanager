# Casino Management System - Entity Relationship Diagram

## Player Tracking Module ERD

```
+----------------+       +-------------------+       +----------------+
|    Players     |       |  GamingSessions   |       | PlayerPhotos   |
+----------------+       +-------------------+       +----------------+
| PK player_id   |<----->| PK session_id     |       | PK photo_id    |
|    casino_id   |       | FK player_id      |       | FK player_id   |
|    first_name  |       |    start_time     |       |    photo_type  |
|    last_name   |       |    end_time       |       |    storage_path|
|    dob         |       |    duration       |       |    upload_date |
|    ...         |       |    status         |       |    notes       |
+----------------+       |    notes          |       +----------------+
        |                +-------------------+
        |                        |
        |                        |
+----------------+       +-------v-----------+
| CigaretteInv   |       |                   |
+----------------+       |                   |
| PK inventory_id|       |                   |
|    brand       |       |                   |
|    variant     |<------+                   |
|    pack_size   |       |                   |
|    stock       |       |                   |
+----------------+       |                   |
        ^                |                   |
        |                |                   |
+-------+---------+      |                   |
| CigaretteInvTxn |      |                   |
+----------------+       |                   |
| PK txn_id      |       |                   |
| FK inventory_id|       |                   |
| FK player_id   |       |                   |
|    txn_type    |       |                   |
|    quantity    |       |                   |
+----------------+       |                   |
                         |                   |
+----------------+       |                   |       +----------------+
| ConsumptionItems|      |                   |       | TableGames     |
+----------------+       |                   |       +----------------+
| PK item_id     |       |                   |       | PK table_id    |
|    item_name   |       |                   |       |    table_number|
|    item_type   |       |                   |       |    game_type   |
|    category    |       |                   |       |    min_bet     |
|    price       |       |                   |       |    max_bet     |
+----------------+       |                   |       |    location    |
        ^                |                   |       +----------------+
        |                |                   |               ^
+-------+---------+      |                   |               |
| PlayerConsumption|     |                   |       +-------+---------+
+----------------+       |                   |       | TableGameAct    |
| PK consumption_id|     |                   |       +----------------+
| FK player_id   |<------+                   |<------| PK activity_id  |
| FK session_id  |       |                   |       | FK session_id   |
| FK item_id     |       |                   |       | FK table_id     |
|    quantity    |       |                   |       |    start_time   |
|    time        |       |                   |       |    end_time     |
+----------------+       |                   |       |    avg_bet      |
                         |                   |       |    buy_in       |
+----------------+       |                   |       |    cash_out     |
| FinancialTxn   |       |                   |       +----------------+
+----------------+       |                   |
| PK txn_id      |       |                   |       +----------------+
| FK player_id   |<------+                   |       | SlotMachines   |
| FK session_id  |       |                   |       +----------------+
|    txn_type    |       |                   |       | PK machine_id  |
|    amount      |       |                   |       |    machine_num |
|    time        |       |                   |       |    game_title  |
+----------------+       |                   |       |    manufacturer|
                         |                   |       |    denomination|
+----------------+       |                   |       +----------------+
| JackpotsHandPays|      |                   |               ^
+----------------+       |                   |               |
| PK jackpot_id  |       |                   |       +-------+---------+
| FK player_id   |<------+                   |       | SlotMachineAct  |
| FK session_id  |       |                   |       +----------------+
| FK machine_id  |       |                   |<------| PK activity_id  |
| FK table_id    |       |                   |       | FK session_id   |
|    amount      |       |                   |       | FK machine_id   |
|    time        |       |                   |       |    start_time   |
|    type        |       |                   |       |    end_time     |
+----------------+       |                   |       |    money_in     |
                         |                   |       |    ticket_in    |
                         |                   |       |    ticket_out   |
                         |                   |       |    hand_pay     |
                         |                   |       |    jackpot      |
                         |                   |       +----------------+
                         |                   |
                         |                   |
                         |                   |
                         |                   |
                         +-------------------+
```

## Database Relationships

### One-to-Many Relationships
- Player to GamingSessions (one player can have many gaming sessions)
- Player to PlayerPhotos (one player can have many photos)
- Player to FinancialTransactions (one player can have many transactions)
- Player to JackpotsAndHandPays (one player can have many jackpots)
- Player to PlayerConsumption (one player can have many consumption records)
- GamingSession to TableGameActivities (one session can have many table game activities)
- GamingSession to SlotMachineActivities (one session can have many slot machine activities)
- TableGame to TableGameActivities (one table can have many activities)
- SlotMachine to SlotMachineActivities (one machine can have many activities)
- ConsumptionItem to PlayerConsumption (one item can be consumed many times)
- CigaretteInventory to CigaretteInventoryTransactions (one inventory item can have many transactions)

### Many-to-One Relationships
- PlayerConsumption to GamingSession (many consumption records can belong to one session)
- FinancialTransaction to GamingSession (many transactions can belong to one session)
- TableGameActivity to GamingSession (many table activities can belong to one session)
- SlotMachineActivity to GamingSession (many slot activities can belong to one session)
- JackpotsAndHandPays to GamingSession (many jackpots can belong to one session)

### Optional Relationships
- JackpotsAndHandPays to SlotMachine (jackpot may be from a slot machine)
- JackpotsAndHandPays to TableGame (jackpot may be from a table game)
- JackpotsAndHandPays to PlayerPhotos (jackpot may have an associated photo)
- CigaretteInventoryTransaction to Player (transaction may be associated with a player)

## Data Flow Diagrams

### Player Registration Flow
```
+-------------+     +-------------+     +-------------+
|  Reception  |---->|  Player     |---->|  Database   |
|  Staff      |     |  Profile    |     |  Storage    |
+-------------+     +-------------+     +-------------+
       |                  |                   ^
       |                  v                   |
       |            +-------------+           |
       +----------->|  Photo      |------------
                    |  Capture    |
                    +-------------+
```

### Real-time Activity Tracking Flow
```
+-------------+     +-------------+     +-------------+
|  Slot       |---->|  Mobile     |---->|  API        |
|  Attendant  |     |  App        |     |  Gateway    |
+-------------+     +-------------+     +-------------+
                                              |
                                              v
+-------------+     +-------------+     +-------------+
|  Real-time  |<----|  Event      |<----|  Database   |
|  Dashboard  |     |  Processing |     |  Storage    |
+-------------+     +-------------+     +-------------+
```

### Jackpot Processing Flow
```
+-------------+     +-------------+     +-------------+
|  Slot       |---->|  Jackpot    |---->|  Photo      |
|  Attendant  |     |  Verification|     |  Capture   |
+-------------+     +-------------+     +-------------+
                          |                   |
                          v                   v
                    +-------------+     +-------------+
                    |  Payment    |---->|  Database   |
                    |  Processing |     |  Storage    |
                    +-------------+     +-------------+
                          |
                          v
                    +-------------+
                    |  Player     |
                    |  Notification|
                    +-------------+
```

### Cigarette Inventory Flow
```
+-------------+     +-------------+     +-------------+
|  Player     |---->|  Cigarette  |---->|  Inventory  |
|  Request    |     |  Dispensing |     |  Update     |
+-------------+     +-------------+     +-------------+
                                              |
                                              v
+-------------+     +-------------+     +-------------+
|  Reorder    |<----|  Inventory  |<----|  Threshold  |
|  Alert      |     |  Check      |     |  Monitoring |
+-------------+     +-------------+     +-------------+
```

## Data Migration and Synchronization

### Data Flow Between Databases
```
+----------------+     +----------------+     +----------------+
| PostgreSQL     |---->| Event Stream   |---->| MongoDB        |
| (Structured    |     | Processing     |     | (Document      |
|  Data)         |     |                |     |  Storage)      |
+----------------+     +----------------+     +----------------+
       |                      ^                      |
       |                      |                      |
       v                      |                      v
+----------------+     +----------------+     +----------------+
| Redis          |<--->| API Services   |<--->| MinIO/S3       |
| (Cache &       |     | (Application   |     | (File          |
|  Real-time)    |     |  Logic)        |     |  Storage)      |
+----------------+     +----------------+     +----------------+
```

### Backup and Recovery Flow
```
+----------------+     +----------------+     +----------------+
| Database       |---->| Scheduled      |---->| Backup         |
| Systems        |     | Backup Jobs    |     | Storage        |
+----------------+     +----------------+     +----------------+
       ^                                             |
       |                                             |
       |                                             v
+----------------+     +----------------+     +----------------+
| Restored       |<----| Recovery       |<----| Backup         |
| Systems        |     | Process        |     | Selection      |
+----------------+     +----------------+     +----------------+
```

## Search and Analytics Flow

### Player Search Flow
```
+----------------+     +----------------+     +----------------+
| User           |---->| Search         |---->| Search         |
| Interface      |     | Query          |     | Index          |
+----------------+     +----------------+     +----------------+
                                                     |
                                                     v
+----------------+     +----------------+     +----------------+
| Results        |<----| Result         |<----| Database       |
| Display        |     | Processing     |     | Query          |
+----------------+     +----------------+     +----------------+
```

### Analytics Processing Flow
```
+----------------+     +----------------+     +----------------+
| Raw            |---->| ETL            |---->| Analytics      |
| Data           |     | Processing     |     | Database       |
+----------------+     +----------------+     +----------------+
                                                     |
                                                     v
+----------------+     +----------------+     +----------------+
| Visualization  |<----| Analytics      |<----| AI/ML          |
| Dashboard      |     | API            |     | Processing     |
+----------------+     +----------------+     +----------------+
```
