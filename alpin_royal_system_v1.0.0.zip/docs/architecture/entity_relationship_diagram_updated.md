# Casino Management System - Entity Relationship Diagram

## Player Tracking Module ERD

```
+----------------+       +-------------------+       +----------------+
|    Players     |       |  GamingSessions   |       | PlayerPhotos   |
+----------------+       +-------------------+       +----------------+
| PK player_id   |<----->| PK session_id     |       | PK photo_id    |
|    casino_id   |       | FK player_id      |       | FK player_id   |
|    first_name  |       |    start_time     |       |    photo_type  |
|    last_name   |       |    end_time       |       |    storage_path|
|    dob         |       |    duration       |       |    upload_date |
|    ...         |       |    status         |       |    notes       |
+----------------+       |    notes          |       +----------------+
        |                +-------------------+
        |                        |
        |                        |
+----------------+       +-------v-----------+
| CigaretteInv   |       |                   |
+----------------+       |                   |
| PK inventory_id|       |                   |
|    brand       |       |                   |
|    variant     |<------+                   |
|    pack_size   |       |                   |
|    stock       |       |                   |
+----------------+       |                   |
        ^                |                   |
        |                |                   |
+-------+---------+      |                   |
| CigaretteInvTxn |      |                   |
+----------------+       |                   |
| PK txn_id      |       |                   |
| FK inventory_id|       |                   |
| FK player_id   |       |                   |
|    txn_type    |       |                   |
|    quantity    |       |                   |
+----------------+       |                   |
                         |                   |
+----------------+       |                   |       +----------------+
| ConsumptionItems|      |                   |       | TableGames     |
+----------------+       |                   |       +----------------+
| PK item_id     |       |                   |       | PK table_id    |
|    item_name   |       |                   |       |    table_number|
|    item_type   |       |                   |       |    game_type   |
|    category    |       |                   |       |    min_bet     |
|    price       |       |                   |       |    max_bet     |
+----------------+       |                   |       |    location    |
        ^                |                   |       +----------------+
        |                |                   |               ^
+-------+---------+      |                   |               |
| PlayerConsumption|     |                   |       +-------+---------+
+----------------+       |                   |       | TableGameAct    |
| PK consumption_id|     |                   |       +----------------+
| FK player_id   |<------+                   |<------| PK activity_id  |
| FK session_id  |       |                   |       | FK session_id   |
| FK item_id     |       |                   |       | FK table_id     |
|    quantity    |       |                   |       |    start_time   |
|    time        |       |                   |       |    end_time     |
+----------------+       |                   |       |    avg_bet      |
                         |                   |       |    buy_in       |
+----------------+       |                   |       |    cash_out     |
| FinancialTxn   |       |                   |       +----------------+
+----------------+       |                   |
| PK txn_id      |       |                   |       +----------------+
| FK player_id   |<------+                   |       | SlotMachines   |
| FK session_id  |       |                   |       +----------------+
|    txn_type    |       |                   |       | PK machine_id  |
|    amount      |       |                   |       |    machine_num |
|    time        |       |                   |       |    game_title  |
+----------------+       |                   |       |    manufacturer|
                         |                   |       |    denomination|
+----------------+       |                   |       +----------------+
| JackpotsHandPays|      |                   |               ^
+----------------+       |                   |               |
| PK jackpot_id  |       |                   |       +-------+---------+
| FK player_id   |<------+                   |       | SlotMachineAct  |
| FK session_id  |       |                   |       +----------------+
| FK machine_id  |       |                   |<------| PK activity_id  |
| FK table_id    |       |                   |       | FK session_id   |
|    amount      |       |                   |       | FK machine_id   |
|    time        |       |                   |       |    start_time   |
|    type        |       |                   |       |    end_time     |
+----------------+       |                   |       |    money_in     |
                         |                   |       |    ticket_in    |
                         |                   |       |    ticket_out   |
                         |                   |       |    hand_pay     |
                         |                   |       |    jackpot      |
                         |                   |       +----------------+
                         |                   |
                         |                   |
                         |                   |
                         |                   |
                         +-------------------+
```

## Network Design and Planning Module ERD

```
+----------------+       +-------------------+       +----------------+
|   FloorPlans   |       |   NetworkDevices  |       |    Cameras     |
+----------------+       +-------------------+       +----------------+
| PK plan_id     |<----->| PK device_id      |<----->| PK camera_id   |
|    name        |       | FK plan_id        |       | FK device_id   |
|    description |       |    device_type    |       |    camera_type |
|    image_path  |       |    name           |       |    model       |
|    scale       |       |    model          |       |    fov_angle   |
|    created_at  |       |    manufacturer   |       |    direction   |
|    updated_at  |       |    x_position     |       |    resolution  |
+----------------+       |    y_position     |       |    status      |
        |                |    status         |       +----------------+
        |                +-------------------+               |
        |                        |                           |
        |                        |                           |
+----------------+       +-------v-----------+       +-------v---------+
|   Locations    |       |    IPAddresses    |       |  CameraViews    |
+----------------+       +-------------------+       +----------------+
| PK location_id |       | PK ip_id          |       | PK view_id     |
| FK plan_id     |       | FK device_id      |       | FK camera_id   |
|    name        |       |    ip_address     |       |    start_angle |
|    type        |       |    subnet_mask    |       |    end_angle   |
|    x_position  |       |    gateway        |       |    distance    |
|    y_position  |       |    mac_address    |       |    view_image  |
|    width       |       |    assigned_at    |       |    created_at  |
|    height      |       |    status         |       +----------------+
+----------------+       +-------------------+
        |                        |
        |                        |
+-------v--------+       +-------v-----------+       +----------------+
|   PatchPanels  |       |     Switches      |       |     Ports      |
+----------------+       +-------------------+       +----------------+
| PK panel_id    |       | PK switch_id      |<----->| PK port_id     |
| FK location_id |       | FK device_id      |       | FK switch_id   |
|    name        |       |    num_ports      |       |    port_number |
|    num_ports   |       |    model          |       |    port_type   |
|    panel_type  |       |    ip_address     |       |    status      |
|    status      |       |    status         |       |    vlan        |
+----------------+       +-------------------+       +----------------+
        |                                                    |
        |                                                    |
+-------v--------+       +-------------------+       +-------v---------+
|  PanelPorts    |       |     Cables        |       |   Connections   |
+----------------+       +-------------------+       +----------------+
| PK port_id     |<----->| PK cable_id       |<----->| PK connection_id|
| FK panel_id    |       |    cable_type     |       | FK port_id     |
|    port_number |       |    length         |       | FK panel_port_id|
|    label       |       |    color          |       | FK cable_id    |
|    status      |       |    identifier     |       |    created_at  |
+----------------+       +-------------------+       +----------------+
```

## Inventory Management Module ERD

```
+----------------+       +-------------------+       +----------------+
| AssetCategories|       |      Assets       |       | AssetLocations |
+----------------+       +-------------------+       +----------------+
| PK category_id |<----->| PK asset_id       |<----->| PK location_id |
|    name        |       | FK category_id    |       | FK asset_id    |
|    description |       | FK vendor_id      |       | FK plan_id     |
|    parent_id   |       |    name           |       |    x_position  |
|    attributes  |       |    model          |       |    y_position  |
|    icon        |       |    serial_number  |       |    floor       |
+----------------+       |    purchase_date  |       |    room        |
                         |    purchase_cost  |       |    status      |
                         |    status         |       |    updated_at  |
                         |    notes          |       +----------------+
                         +-------------------+
                                  |
                                  |
+----------------+       +--------v----------+       +----------------+
|    Vendors     |       |  AssetAssignments |       | MaintenanceRecs|
+----------------+       +-------------------+       +----------------+
| PK vendor_id   |       | PK assignment_id  |       | PK maint_id    |
|    name        |       | FK asset_id       |       | FK asset_id    |
|    contact     |       | FK employee_id    |       |    type        |
|    phone       |       |    assigned_date  |       |    description |
|    email       |       |    return_date    |       |    date        |
|    website     |       |    status         |       |    cost        |
|    notes       |       |    notes          |       |    technician  |
+----------------+       +-------------------+       |    status      |
                                                     +----------------+
                                                             |
                                                             |
+----------------+       +-------------------+       +-------v---------+
| WarrantyInfo   |       |  AssetAttributes  |       |  AssetHistory   |
+----------------+       +-------------------+       +----------------+
| PK warranty_id |       | PK attribute_id   |       | PK history_id  |
| FK asset_id    |       | FK asset_id       |       | FK asset_id    |
|    start_date  |       | FK attribute_def_id|      |    action      |
|    end_date    |       |    value          |       |    date        |
|    provider    |       |    updated_at     |       |    user_id     |
|    terms       |       +-------------------+       |    notes       |
|    contact     |                                   +----------------+
+----------------+
```

## Ticket System Module ERD

```
+----------------+       +-------------------+       +----------------+
|    Tickets     |       |   TicketComments  |       |  Attachments   |
+----------------+       +-------------------+       +----------------+
| PK ticket_id   |<----->| PK comment_id     |       | PK attach_id   |
| FK category_id |       | FK ticket_id      |       | FK ticket_id   |
| FK priority_id |       | FK user_id        |       |    filename    |
| FK status_id   |       |    comment_text   |       |    file_path   |
| FK department_id|      |    created_at     |       |    file_type   |
| FK assigned_to |       |    is_internal    |       |    file_size   |
|    subject     |       +-------------------+       |    uploaded_at |
|    description |                                   +----------------+
|    created_by  |
|    created_at  |
|    updated_at  |
|    due_date    |
+----------------+
        |
        |
+-------v--------+       +-------------------+       +----------------+
| TicketCategories|      |  TicketPriorities |       | TicketStatuses |
+----------------+       +-------------------+       +----------------+
| PK category_id |       | PK priority_id    |       | PK status_id   |
|    name        |       |    name           |       |    name        |
|    description |       |    description    |       |    description |
|    parent_id   |       |    color          |       |    is_closed   |
|    sla_hours   |       |    response_time  |       |    color       |
+----------------+       +-------------------+       +----------------+
        |                        |                           |
        |                        |                           |
+-------v--------+       +-------v-----------+       +-------v---------+
|  Departments   |       |  ServiceLevelAgr  |       | EscalationRules |
+----------------+       +-------------------+       +----------------+
| PK dept_id     |       | PK sla_id         |       | PK rule_id     |
|    name        |       | FK category_id    |       | FK sla_id      |
|    description |       | FK priority_id    |       |    condition   |
|    manager_id  |       |    response_time  |       |    threshold   |
|    email       |       |    resolution_time|       |    action      |
+----------------+       |    business_hours |       |    notify_users|
        |                +-------------------+       +----------------+
        |
+-------v--------+
|  Technicians   |
+----------------+
| PK tech_id     |
| FK dept_id     |
| FK user_id     |
|    skills      |
|    availability|
|    status      |
+----------------+
```

## Database Relationships

### One-to-Many Relationships (Player Tracking)
- Player to GamingSessions (one player can have many gaming sessions)
- Player to PlayerPhotos (one player can have many photos)
- Player to FinancialTransactions (one player can have many transactions)
- Player to JackpotsAndHandPays (one player can have many jackpots)
- Player to PlayerConsumption (one player can have many consumption records)
- GamingSession to TableGameActivities (one session can have many table game activities)
- GamingSession to SlotMachineActivities (one session can have many slot machine activities)
- TableGame to TableGameActivities (one table can have many activities)
- SlotMachine to SlotMachineActivities (one machine can have many activities)
- ConsumptionItem to PlayerConsumption (one item can be consumed many times)
- CigaretteInventory to CigaretteInventoryTransactions (one inventory item can have many transactions)

### One-to-Many Relationships (Network Design)
- FloorPlan to NetworkDevices (one floor plan can have many network devices)
- FloorPlan to Locations (one floor plan can have many locations)
- NetworkDevice to IPAddresses (one device can have multiple IP addresses)
- NetworkDevice to Cameras (one device can be associated with one camera)
- Camera to CameraViews (one camera can have multiple views)
- Location to PatchPanels (one location can have multiple patch panels)
- PatchPanel to PanelPorts (one patch panel can have multiple ports)
- Switch to Ports (one switch can have multiple ports)
- Cable to Connections (one cable can be used in multiple connections)

### One-to-Many Relationships (Inventory Management)
- AssetCategory to Assets (one category can have many assets)
- Vendor to Assets (one vendor can supply many assets)
- Asset to AssetLocations (one asset can have location history)
- Asset to AssetAssignments (one asset can have multiple assignments)
- Asset to MaintenanceRecords (one asset can have many maintenance records)
- Asset to WarrantyInfo (one asset can have warranty information)
- Asset to AssetAttributes (one asset can have many attributes)
- Asset to AssetHistory (one asset can have many history records)

### One-to-Many Relationships (Ticket System)
- Ticket to TicketComments (one ticket can have many comments)
- Ticket to Attachments (one ticket can have many attachments)
- TicketCategory to Tickets (one category can have many tickets)
- TicketPriority to Tickets (one priority can have many tickets)
- TicketStatus to Tickets (one status can have many tickets)
- Department to Tickets (one department can have many tickets)
- Department to Technicians (one department can have many technicians)
- ServiceLevelAgreement to EscalationRules (one SLA can have many escalation rules)

### Many-to-One Relationships
- PlayerConsumption to GamingSession (many consumption records can belong to one session)
- FinancialTransaction to GamingSession (many transactions can belong to one session)
- TableGameActivity to GamingSession (many table activities can belong to one session)
- SlotMachineActivity to GamingSession (many slot activities can belong to one session)
- JackpotsAndHandPays to GamingSession (many jackpots can belong to one session)
- PanelPort to Connection (many panel ports can be part of connections)
- Port to Connection (many switch ports can be part of connections)
- AssetAssignment to Employee (many assets can be assigned to one employee)

### Optional Relationships
- JackpotsAndHandPays to SlotMachine (jackpot may be from a slot machine)
- JackpotsAndHandPays to TableGame (jackpot may be from a table game)
- JackpotsAndHandPays to PlayerPhotos (jackpot may have an associated photo)
- CigaretteInventoryTransaction to Player (transaction may be associated with a player)
- Ticket to Technician (ticket may be assigned to a technician)

## Data Flow Diagrams

### Network Device Placement Flow
```
+-------------+     +-------------+     +-------------+
|  Admin      |---->|  Floor Plan |---->|  Database   |
|  User       |     |  Editor     |     |  Storage    |
+-------------+     +-------------+     +-------------+
       |                  |                   ^
       |                  v                   |
       |            +-------------+           |
       +----------->|  Device     |------------
                    |  Properties |
                    +-------------+
```

### Asset Inventory Flow
```
+-------------+     +-------------+     +-------------+
|  Inventory  |---->|  Asset      |---->|  Database   |
|  Manager    |     |  Entry Form |     |  Storage    |
+-------------+     +-------------+     +-------------+
       |                  |                   ^
       |                  v                   |
       |            +-------------+           |
       +----------->|  Floor Plan |------------
                    |  Placement  |
                    +-------------+
```

### Ticket Management Flow
```
+-------------+     +-------------+     +-------------+
|  User       |---->|  Ticket     |---->|  Routing    |
|  Request    |     |  Creation   |     |  Engine     |
+-------------+     +-------------+     +-------------+
                                              |
                                              v
+-------------+     +-------------+     +-------------+
|  Resolution |<----|  Technician |<----|  Assignment |
|  Confirmation|     |  Updates   |     |  System     |
+-------------+     +-------------+     +-------------+
```

### Camera Field of View Flow
```
+-------------+     +-------------+     +-------------+
|  Security   |---->|  Camera     |---->|  FOV        |
|  Admin      |     |  Placement  |     |  Calculation|
+-------------+     +-------------+     +-------------+
                                              |
                                              v
+-------------+     +-------------+     +-------------+
|  Coverage   |<----|  Overlap    |<----|  Visualization|
|  Report     |     |  Analysis   |     |  Engine     |
+-------------+     +-------------+     +-------------+
```

## Data Migration and Synchronization

### Data Flow Between Databases
```
+----------------+     +----------------+     +----------------+
| PostgreSQL     |---->| Event Stream   |---->| MongoDB        |
| (Structured    |     | Processing     |     | (Document      |
|  Data)         |     |                |     |  Storage)      |
+----------------+     +----------------+     +----------------+
       |                      ^                      |
       |                      |                      |
       v                      |                      v
+----------------+     +----------------+     +----------------+
| Redis          |<--->| API Services   |<--->| MinIO/S3       |
| (Cache &       |     | (Application   |     | (File          |
|  Real-time)    |     |  Logic)        |     |  Storage)      |
+----------------+     +----------------+     +----------------+
```

### Backup and Recovery Flow
```
+----------------+     +----------------+     +----------------+
| Database       |---->| Scheduled      |---->| Backup         |
| Systems        |     | Backup Jobs    |     | Storage        |
+----------------+     +----------------+     +----------------+
       ^                                             |
       |                                             |
       |                                             v
+----------------+     +----------------+     +----------------+
| Restored       |<----| Recovery       |<----| Backup         |
| Systems        |     | Process        |     | Selection      |
+----------------+     +----------------+     +----------------+
```

## Search and Analytics Flow

### Asset Search Flow
```
+----------------+     +----------------+     +----------------+
| User           |---->| Search         |---->| Search         |
| Interface      |     | Query          |     | Index          |
+----------------+     +----------------+     +----------------+
                                                     |
                                                     v
+----------------+     +----------------+     +----------------+
| Results        |<----| Result         |<----| Database       |
| Display        |     | Processing     |     | Query          |
+----------------+     +----------------+     +----------------+
```

### Network Analytics Flow
```
+----------------+     +----------------+     +----------------+
| Network        |---->| Topology       |---->| Analytics      |
| Data           |     | Processing     |     | Engine         |
+----------------+     +----------------+     +----------------+
                                                     |
                                                     v
+----------------+     +----------------+     +----------------+
| Visualization  |<----| Optimization   |<----| AI/ML          |
| Dashboard      |     | Recommendations|     | Processing     |
+----------------+     +----------------+     +----------------+
```

### Ticket Analytics Flow
```
+----------------+     +----------------+     +----------------+
| Ticket         |---->| ETL            |---->| Analytics      |
| Data           |     | Processing     |     | Database       |
+----------------+     +----------------+     +----------------+
                                                     |
                                                     v
+----------------+     +----------------+     +----------------+
| Performance    |<----| Trend          |<----| AI/ML          |
| Dashboard      |     | Analysis       |     | Processing     |
+----------------+     +----------------+     +----------------+
```
