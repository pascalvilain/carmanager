# Casino Management System - Player Tracking Database Schema

## Overview
This document defines the database schema for the Player Tracking module of the Casino Management System. The schema uses a mixed database approach with:

1. PostgreSQL for structured relational data
2. MongoDB for flexible schema and document-oriented data
3. Redis for caching and real-time operations
4. MinIO/S3 for file storage (photos)

## Relational Database Schema (PostgreSQL)

### Players Table
```sql
CREATE TABLE players (
    player_id SERIAL PRIMARY KEY,
    casino_guest_id VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(20),
    nationality VARCHAR(50),
    id_type VARCHAR(50),
    id_number VARCHAR(100),
    address_line1 VARCHAR(200),
    address_line2 VARCHAR(200),
    city VARCHAR(100),
    state_province VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(100),
    phone_number VARCHAR(50),
    email VARCHAR(200),
    preferred_language VARCHAR(50),
    vip_status VARCHAR(50),
    registration_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_visit_date TIMESTAMP,
    notes TEXT,
    preferred_cigarette_brand VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_players_casino_guest_id ON players(casino_guest_id);
CREATE INDEX idx_players_last_name ON players(last_name);
CREATE INDEX idx_players_registration_date ON players(registration_date);
CREATE INDEX idx_players_last_visit_date ON players(last_visit_date);
```

### PlayerPhotos Table
```sql
CREATE TABLE player_photos (
    photo_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    photo_type VARCHAR(50) NOT NULL, -- 'id', 'reception', 'jackpot', 'handpay'
    storage_path VARCHAR(500) NOT NULL,
    upload_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_player_photos_player_id ON player_photos(player_id);
```

### GamingSessions Table
```sql
CREATE TABLE gaming_sessions (
    session_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_minutes INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'completed', 'interrupted'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_gaming_sessions_player_id ON gaming_sessions(player_id);
CREATE INDEX idx_gaming_sessions_start_time ON gaming_sessions(start_time);
CREATE INDEX idx_gaming_sessions_status ON gaming_sessions(status);
```

### TableGames Table
```sql
CREATE TABLE table_games (
    table_id SERIAL PRIMARY KEY,
    table_number VARCHAR(20) NOT NULL,
    game_type VARCHAR(100) NOT NULL, -- 'blackjack', 'roulette', 'poker', etc.
    min_bet DECIMAL(12,2),
    max_bet DECIMAL(12,2),
    location VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_table_games_table_number ON table_games(table_number);
CREATE INDEX idx_table_games_game_type ON table_games(game_type);
```

### SlotMachines Table
```sql
CREATE TABLE slot_machines (
    machine_id SERIAL PRIMARY KEY,
    machine_number VARCHAR(20) NOT NULL,
    game_title VARCHAR(100) NOT NULL,
    manufacturer VARCHAR(100),
    denomination DECIMAL(12,2),
    location VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_slot_machines_machine_number ON slot_machines(machine_number);
CREATE INDEX idx_slot_machines_game_title ON slot_machines(game_title);
```

### TableGameActivities Table
```sql
CREATE TABLE table_game_activities (
    activity_id SERIAL PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES gaming_sessions(session_id),
    table_id INTEGER NOT NULL REFERENCES table_games(table_id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_minutes INTEGER,
    avg_bet DECIMAL(12,2),
    buy_in DECIMAL(12,2),
    cash_out DECIMAL(12,2),
    chips_in DECIMAL(12,2),
    chips_out DECIMAL(12,2),
    win_loss DECIMAL(12,2),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_table_game_activities_session_id ON table_game_activities(session_id);
CREATE INDEX idx_table_game_activities_table_id ON table_game_activities(table_id);
CREATE INDEX idx_table_game_activities_start_time ON table_game_activities(start_time);
```

### SlotMachineActivities Table
```sql
CREATE TABLE slot_machine_activities (
    activity_id SERIAL PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES gaming_sessions(session_id),
    machine_id INTEGER NOT NULL REFERENCES slot_machines(machine_id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_minutes INTEGER,
    money_in DECIMAL(12,2),
    ticket_in DECIMAL(12,2),
    ticket_out DECIMAL(12,2),
    hand_pay DECIMAL(12,2),
    jackpot DECIMAL(12,2),
    win_loss DECIMAL(12,2),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_slot_machine_activities_session_id ON slot_machine_activities(session_id);
CREATE INDEX idx_slot_machine_activities_machine_id ON slot_machine_activities(machine_id);
CREATE INDEX idx_slot_machine_activities_start_time ON slot_machine_activities(start_time);
```

### FinancialTransactions Table
```sql
CREATE TABLE financial_transactions (
    transaction_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    session_id INTEGER REFERENCES gaming_sessions(session_id),
    transaction_type VARCHAR(50) NOT NULL, -- 'buy_in', 'cash_out', 'comp', 'credit', etc.
    amount DECIMAL(12,2) NOT NULL,
    transaction_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    location VARCHAR(100),
    payment_method VARCHAR(50),
    reference_number VARCHAR(100),
    staff_id INTEGER,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_financial_transactions_player_id ON financial_transactions(player_id);
CREATE INDEX idx_financial_transactions_session_id ON financial_transactions(session_id);
CREATE INDEX idx_financial_transactions_transaction_time ON financial_transactions(transaction_time);
CREATE INDEX idx_financial_transactions_transaction_type ON financial_transactions(transaction_type);
```

### JackpotsAndHandPays Table
```sql
CREATE TABLE jackpots_and_hand_pays (
    jackpot_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    session_id INTEGER REFERENCES gaming_sessions(session_id),
    machine_id INTEGER REFERENCES slot_machines(machine_id),
    table_id INTEGER REFERENCES table_games(table_id),
    amount DECIMAL(12,2) NOT NULL,
    jackpot_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    jackpot_type VARCHAR(50) NOT NULL, -- 'progressive', 'hand_pay', 'bonus', etc.
    game_outcome VARCHAR(200),
    staff_id INTEGER,
    photo_id INTEGER REFERENCES player_photos(photo_id),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jackpots_and_hand_pays_player_id ON jackpots_and_hand_pays(player_id);
CREATE INDEX idx_jackpots_and_hand_pays_session_id ON jackpots_and_hand_pays(session_id);
CREATE INDEX idx_jackpots_and_hand_pays_jackpot_time ON jackpots_and_hand_pays(jackpot_time);
```

### ConsumptionItems Table
```sql
CREATE TABLE consumption_items (
    item_id SERIAL PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'food', 'beverage', 'cigarette', 'other'
    category VARCHAR(50),
    price DECIMAL(12,2),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_consumption_items_item_type ON consumption_items(item_type);
CREATE INDEX idx_consumption_items_category ON consumption_items(category);
```

### PlayerConsumption Table
```sql
CREATE TABLE player_consumption (
    consumption_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    session_id INTEGER REFERENCES gaming_sessions(session_id),
    item_id INTEGER NOT NULL REFERENCES consumption_items(item_id),
    quantity INTEGER NOT NULL DEFAULT 1,
    consumption_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    location VARCHAR(100),
    staff_id INTEGER,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_player_consumption_player_id ON player_consumption(player_id);
CREATE INDEX idx_player_consumption_session_id ON player_consumption(session_id);
CREATE INDEX idx_player_consumption_item_id ON player_consumption(item_id);
CREATE INDEX idx_player_consumption_consumption_time ON player_consumption(consumption_time);
```

### CigaretteInventory Table
```sql
CREATE TABLE cigarette_inventory (
    inventory_id SERIAL PRIMARY KEY,
    brand VARCHAR(100) NOT NULL,
    variant VARCHAR(100),
    pack_size INTEGER NOT NULL DEFAULT 20,
    current_stock INTEGER NOT NULL DEFAULT 0,
    reorder_level INTEGER NOT NULL DEFAULT 10,
    last_restock_date TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cigarette_inventory_brand ON cigarette_inventory(brand);
```

### CigaretteInventoryTransactions Table
```sql
CREATE TABLE cigarette_inventory_transactions (
    transaction_id SERIAL PRIMARY KEY,
    inventory_id INTEGER NOT NULL REFERENCES cigarette_inventory(inventory_id),
    transaction_type VARCHAR(50) NOT NULL, -- 'restock', 'consumption', 'adjustment'
    quantity INTEGER NOT NULL,
    transaction_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    player_id INTEGER REFERENCES players(player_id),
    staff_id INTEGER,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cigarette_inventory_transactions_inventory_id ON cigarette_inventory_transactions(inventory_id);
CREATE INDEX idx_cigarette_inventory_transactions_transaction_time ON cigarette_inventory_transactions(transaction_time);
CREATE INDEX idx_cigarette_inventory_transactions_player_id ON cigarette_inventory_transactions(player_id);
```

### Staff Table
```sql
CREATE TABLE staff (
    staff_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    position VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_staff_employee_id ON staff(employee_id);
CREATE INDEX idx_staff_department ON staff(department);
```

## NoSQL Database Schema (MongoDB)

### PlayerEvents Collection
```json
{
  "_id": "ObjectId",
  "player_id": "Integer",
  "casino_guest_id": "String",
  "event_type": "String",  // "login", "game_start", "game_end", "order", "jackpot", etc.
  "event_time": "ISODate",
  "location": "String",
  "device_id": "String",
  "staff_id": "Integer",
  "details": {
    // Flexible schema for different event types
    // For game events:
    "game_type": "String",
    "game_id": "String",
    "bet_amount": "Number",
    "outcome": "String",
    
    // For consumption events:
    "item_id": "Integer",
    "item_name": "String",
    "quantity": "Integer",
    "price": "Number",
    
    // For jackpot events:
    "jackpot_amount": "Number",
    "jackpot_type": "String",
    
    // Other event-specific details
  },
  "created_at": "ISODate"
}

// Indexes
db.PlayerEvents.createIndex({ "player_id": 1 })
db.PlayerEvents.createIndex({ "casino_guest_id": 1 })
db.PlayerEvents.createIndex({ "event_time": 1 })
db.PlayerEvents.createIndex({ "event_type": 1 })
db.PlayerEvents.createIndex({ "event_time": -1, "player_id": 1 })
```

### PlayerAnalytics Collection
```json
{
  "_id": "ObjectId",
  "player_id": "Integer",
  "casino_guest_id": "String",
  "analysis_date": "ISODate",
  "lifetime_stats": {
    "total_visits": "Integer",
    "total_play_time_minutes": "Integer",
    "total_spend": "Number",
    "total_winnings": "Number",
    "net_value": "Number",
    "avg_bet": "Number",
    "favorite_games": ["String"],
    "favorite_machines": ["String"],
    "preferred_play_times": ["String"],
    "preferred_days": ["String"]
  },
  "recent_trends": {
    "visit_frequency_change": "Number",
    "spend_change": "Number",
    "win_rate_change": "Number",
    "play_time_change": "Number"
  },
  "preferences": {
    "game_preferences": [
      {
        "game_type": "String",
        "preference_score": "Number"
      }
    ],
    "food_preferences": [
      {
        "item_category": "String",
        "preference_score": "Number"
      }
    ],
    "beverage_preferences": [
      {
        "item_category": "String",
        "preference_score": "Number"
      }
    ],
    "cigarette_preferences": {
      "brand": "String",
      "variant": "String",
      "consumption_rate": "Number"
    }
  },
  "ai_insights": {
    "player_value_score": "Number",
    "churn_risk": "Number",
    "upsell_opportunities": ["String"],
    "recommended_offers": ["String"],
    "anomaly_flags": ["String"]
  },
  "updated_at": "ISODate"
}

// Indexes
db.PlayerAnalytics.createIndex({ "player_id": 1 })
db.PlayerAnalytics.createIndex({ "casino_guest_id": 1 })
db.PlayerAnalytics.createIndex({ "analysis_date": 1 })
db.PlayerAnalytics.createIndex({ "ai_insights.player_value_score": -1 })
db.PlayerAnalytics.createIndex({ "ai_insights.churn_risk": -1 })
```

### RealTimePlayerStatus Collection
```json
{
  "_id": "ObjectId",
  "player_id": "Integer",
  "casino_guest_id": "String",
  "status": "String",  // "active", "inactive", "left"
  "current_location": "String",
  "current_activity": "String",
  "current_game": {
    "type": "String",  // "table", "slot"
    "id": "Integer",
    "name": "String",
    "start_time": "ISODate",
    "duration_minutes": "Integer"
  },
  "current_session": {
    "session_id": "Integer",
    "start_time": "ISODate",
    "duration_minutes": "Integer"
  },
  "recent_consumption": [
    {
      "item_name": "String",
      "item_type": "String",
      "quantity": "Integer",
      "time": "ISODate"
    }
  ],
  "recent_transactions": [
    {
      "type": "String",
      "amount": "Number",
      "time": "ISODate"
    }
  ],
  "last_updated": "ISODate"
}

// Indexes
db.RealTimePlayerStatus.createIndex({ "player_id": 1 })
db.RealTimePlayerStatus.createIndex({ "casino_guest_id": 1 })
db.RealTimePlayerStatus.createIndex({ "status": 1 })
db.RealTimePlayerStatus.createIndex({ "current_location": 1 })
db.RealTimePlayerStatus.createIndex({ "last_updated": 1 })
```

## Redis Schema (Caching and Real-time)

### Player Cache
```
// Player basic info cache (Hash)
player:{player_id}:info
  casino_guest_id -> "String"
  first_name -> "String"
  last<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>