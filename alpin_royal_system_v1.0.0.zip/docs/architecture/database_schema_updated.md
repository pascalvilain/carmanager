# Casino Management System - Database Schema

## Overview
This document defines the database schema for the Casino Management System. The schema uses a mixed database approach with:

1. PostgreSQL for structured relational data
2. MongoDB for flexible schema and document-oriented data
3. Redis for caching and real-time operations
4. MinIO/S3 for file storage (photos, floor plans, documents)

## Relational Database Schema (PostgreSQL)

### Player Tracking Module

#### Players Table
```sql
CREATE TABLE players (
    player_id SERIAL PRIMARY KEY,
    casino_guest_id VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(20),
    nationality VARCHAR(50),
    id_type VARCHAR(50),
    id_number VARCHAR(100),
    address_line1 VARCHAR(200),
    address_line2 VARCHAR(200),
    city VARCHAR(100),
    state_province VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(100),
    phone_number VARCHAR(50),
    email VARCHAR(200),
    preferred_language VARCHAR(50),
    vip_status VARCHAR(50),
    registration_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_visit_date TIMESTAMP,
    notes TEXT,
    preferred_cigarette_brand VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_players_casino_guest_id ON players(casino_guest_id);
CREATE INDEX idx_players_last_name ON players(last_name);
CREATE INDEX idx_players_registration_date ON players(registration_date);
CREATE INDEX idx_players_last_visit_date ON players(last_visit_date);
```

#### PlayerPhotos Table
```sql
CREATE TABLE player_photos (
    photo_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    photo_type VARCHAR(50) NOT NULL, -- 'id', 'reception', 'jackpot', 'handpay'
    storage_path VARCHAR(500) NOT NULL,
    upload_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_player_photos_player_id ON player_photos(player_id);
```

#### GamingSessions Table
```sql
CREATE TABLE gaming_sessions (
    session_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_minutes INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'completed', 'interrupted'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_gaming_sessions_player_id ON gaming_sessions(player_id);
CREATE INDEX idx_gaming_sessions_start_time ON gaming_sessions(start_time);
CREATE INDEX idx_gaming_sessions_status ON gaming_sessions(status);
```

#### TableGames Table
```sql
CREATE TABLE table_games (
    table_id SERIAL PRIMARY KEY,
    table_number VARCHAR(20) NOT NULL,
    game_type VARCHAR(100) NOT NULL, -- 'blackjack', 'roulette', 'poker', etc.
    min_bet DECIMAL(12,2),
    max_bet DECIMAL(12,2),
    location VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_table_games_table_number ON table_games(table_number);
CREATE INDEX idx_table_games_game_type ON table_games(game_type);
```

#### SlotMachines Table
```sql
CREATE TABLE slot_machines (
    machine_id SERIAL PRIMARY KEY,
    machine_number VARCHAR(20) NOT NULL,
    game_title VARCHAR(100) NOT NULL,
    manufacturer VARCHAR(100),
    denomination DECIMAL(12,2),
    location VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_slot_machines_machine_number ON slot_machines(machine_number);
CREATE INDEX idx_slot_machines_game_title ON slot_machines(game_title);
```

#### TableGameActivities Table
```sql
CREATE TABLE table_game_activities (
    activity_id SERIAL PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES gaming_sessions(session_id),
    table_id INTEGER NOT NULL REFERENCES table_games(table_id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_minutes INTEGER,
    avg_bet DECIMAL(12,2),
    buy_in DECIMAL(12,2),
    cash_out DECIMAL(12,2),
    chips_in DECIMAL(12,2),
    chips_out DECIMAL(12,2),
    win_loss DECIMAL(12,2),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_table_game_activities_session_id ON table_game_activities(session_id);
CREATE INDEX idx_table_game_activities_table_id ON table_game_activities(table_id);
CREATE INDEX idx_table_game_activities_start_time ON table_game_activities(start_time);
```

#### SlotMachineActivities Table
```sql
CREATE TABLE slot_machine_activities (
    activity_id SERIAL PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES gaming_sessions(session_id),
    machine_id INTEGER NOT NULL REFERENCES slot_machines(machine_id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_minutes INTEGER,
    money_in DECIMAL(12,2),
    ticket_in DECIMAL(12,2),
    ticket_out DECIMAL(12,2),
    hand_pay DECIMAL(12,2),
    jackpot DECIMAL(12,2),
    win_loss DECIMAL(12,2),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_slot_machine_activities_session_id ON slot_machine_activities(session_id);
CREATE INDEX idx_slot_machine_activities_machine_id ON slot_machine_activities(machine_id);
CREATE INDEX idx_slot_machine_activities_start_time ON slot_machine_activities(start_time);
```

#### FinancialTransactions Table
```sql
CREATE TABLE financial_transactions (
    transaction_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    session_id INTEGER REFERENCES gaming_sessions(session_id),
    transaction_type VARCHAR(50) NOT NULL, -- 'buy_in', 'cash_out', 'comp', 'credit', etc.
    amount DECIMAL(12,2) NOT NULL,
    transaction_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    location VARCHAR(100),
    payment_method VARCHAR(50),
    reference_number VARCHAR(100),
    staff_id INTEGER,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_financial_transactions_player_id ON financial_transactions(player_id);
CREATE INDEX idx_financial_transactions_session_id ON financial_transactions(session_id);
CREATE INDEX idx_financial_transactions_transaction_time ON financial_transactions(transaction_time);
CREATE INDEX idx_financial_transactions_transaction_type ON financial_transactions(transaction_type);
```

#### JackpotsAndHandPays Table
```sql
CREATE TABLE jackpots_and_hand_pays (
    jackpot_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    session_id INTEGER REFERENCES gaming_sessions(session_id),
    machine_id INTEGER REFERENCES slot_machines(machine_id),
    table_id INTEGER REFERENCES table_games(table_id),
    amount DECIMAL(12,2) NOT NULL,
    jackpot_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    jackpot_type VARCHAR(50) NOT NULL, -- 'progressive', 'hand_pay', 'bonus', etc.
    game_outcome VARCHAR(200),
    staff_id INTEGER,
    photo_id INTEGER REFERENCES player_photos(photo_id),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jackpots_and_hand_pays_player_id ON jackpots_and_hand_pays(player_id);
CREATE INDEX idx_jackpots_and_hand_pays_session_id ON jackpots_and_hand_pays(session_id);
CREATE INDEX idx_jackpots_and_hand_pays_jackpot_time ON jackpots_and_hand_pays(jackpot_time);
```

#### ConsumptionItems Table
```sql
CREATE TABLE consumption_items (
    item_id SERIAL PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    item_type VARCHAR(50) NOT NULL, -- 'food', 'beverage', 'cigarette', 'other'
    category VARCHAR(50),
    price DECIMAL(12,2),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_consumption_items_item_type ON consumption_items(item_type);
CREATE INDEX idx_consumption_items_category ON consumption_items(category);
```

#### PlayerConsumption Table
```sql
CREATE TABLE player_consumption (
    consumption_id SERIAL PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(player_id),
    session_id INTEGER REFERENCES gaming_sessions(session_id),
    item_id INTEGER NOT NULL REFERENCES consumption_items(item_id),
    quantity INTEGER NOT NULL DEFAULT 1,
    consumption_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    location VARCHAR(100),
    staff_id INTEGER,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_player_consumption_player_id ON player_consumption(player_id);
CREATE INDEX idx_player_consumption_session_id ON player_consumption(session_id);
CREATE INDEX idx_player_consumption_item_id ON player_consumption(item_id);
CREATE INDEX idx_player_consumption_consumption_time ON player_consumption(consumption_time);
```

#### CigaretteInventory Table
```sql
CREATE TABLE cigarette_inventory (
    inventory_id SERIAL PRIMARY KEY,
    brand VARCHAR(100) NOT NULL,
    variant VARCHAR(100),
    pack_size INTEGER NOT NULL DEFAULT 20,
    current_stock INTEGER NOT NULL DEFAULT 0,
    reorder_level INTEGER NOT NULL DEFAULT 10,
    last_restock_date TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cigarette_inventory_brand ON cigarette_inventory(brand);
```

#### CigaretteInventoryTransactions Table
```sql
CREATE TABLE cigarette_inventory_transactions (
    transaction_id SERIAL PRIMARY KEY,
    inventory_id INTEGER NOT NULL REFERENCES cigarette_inventory(inventory_id),
    transaction_type VARCHAR(50) NOT NULL, -- 'restock', 'consumption', 'adjustment'
    quantity INTEGER NOT NULL,
    transaction_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    player_id INTEGER REFERENCES players(player_id),
    staff_id INTEGER,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cigarette_inventory_transactions_inventory_id ON cigarette_inventory_transactions(inventory_id);
CREATE INDEX idx_cigarette_inventory_transactions_transaction_time ON cigarette_inventory_transactions(transaction_time);
CREATE INDEX idx_cigarette_inventory_transactions_player_id ON cigarette_inventory_transactions(player_id);
```

#### Staff Table
```sql
CREATE TABLE staff (
    staff_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    position VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(200),
    phone VARCHAR(50),
    hire_date DATE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_staff_employee_id ON staff(employee_id);
CREATE INDEX idx_staff_department ON staff(department);
```

### Network Design and Planning Module

#### FloorPlans Table
```sql
CREATE TABLE floor_plans (
    plan_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    image_path VARCHAR(500) NOT NULL,
    scale DECIMAL(10,5), -- scale in pixels per meter
    width INTEGER NOT NULL,
    height INTEGER NOT NULL,
    floor_number INTEGER,
    building VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES staff(staff_id),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_floor_plans_name ON floor_plans(name);
CREATE INDEX idx_floor_plans_floor_number ON floor_plans(floor_number);
```

#### Locations Table
```sql
CREATE TABLE locations (
    location_id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES floor_plans(plan_id),
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'room', 'area', 'rack', 'wall', etc.
    x_position INTEGER NOT NULL,
    y_position INTEGER NOT NULL,
    width INTEGER,
    height INTEGER,
    rotation INTEGER DEFAULT 0,
    color VARCHAR(20),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_locations_plan_id ON locations(plan_id);
CREATE INDEX idx_locations_type ON locations(type);
```

#### NetworkDevices Table
```sql
CREATE TABLE network_devices (
    device_id SERIAL PRIMARY KEY,
    plan_id INTEGER NOT NULL REFERENCES floor_plans(plan_id),
    device_type VARCHAR(50) NOT NULL, -- 'switch', 'router', 'access_point', 'camera', 'tv', 'computer', 'raspberry_pi', 'slot', 'kiosk', etc.
    name VARCHAR(100) NOT NULL,
    model VARCHAR(100),
    manufacturer VARCHAR(100),
    serial_number VARCHAR(100),
    x_position INTEGER NOT NULL,
    y_position INTEGER NOT NULL,
    rotation INTEGER DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    installation_date DATE,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_network_devices_plan_id ON network_devices(plan_id);
CREATE INDEX idx_network_devices_device_type ON network_devices(device_type);
CREATE INDEX idx_network_devices_status ON network_devices(status);
```

#### IPAddresses Table
```sql
CREATE TABLE ip_addresses (
    ip_id SERIAL PRIMARY KEY,
    device_id INTEGER NOT NULL REFERENCES network_devices(device_id),
    ip_address VARCHAR(45) NOT NULL, -- IPv4 or IPv6
    subnet_mask VARCHAR(45),
    gateway VARCHAR(45),
    mac_address VARCHAR(17),
    dns_servers VARCHAR(200),
    is_dhcp BOOLEAN DEFAULT FALSE,
    vlan INTEGER,
    assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'reserved', 'inactive'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ip_addresses_device_id ON ip_addresses(device_id);
CREATE INDEX idx_ip_addresses_ip_address ON ip_addresses(ip_address);
CREATE INDEX idx_ip_addresses_mac_address ON ip_addresses(mac_address);
```

#### Cameras Table
```sql
CREATE TABLE cameras (
    camera_id SERIAL PRIMARY KEY,
    device_id INTEGER NOT NULL REFERENCES network_devices(device_id),
    camera_type VARCHAR(50) NOT NULL, -- 'fixed', 'ptz', 'dome', etc.
    model VARCHAR(100),
    resolution VARCHAR(20),
    fov_angle INTEGER, -- field of view angle in degrees
    direction INTEGER, -- direction in degrees (0-359)
    ptz_capable BOOLEAN DEFAULT FALSE,
    recording_enabled BOOLEAN DEFAULT TRUE,
    stream_url VARCHAR(500),
    username VARCHAR(100),
    password VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cameras_device_id ON cameras(device_id);
```

#### CameraViews Table
```sql
CREATE TABLE camera_views (
    view_id SERIAL PRIMARY KEY,
    camera_id INTEGER NOT NULL REFERENCES cameras(camera_id),
    start_angle INTEGER, -- start angle of view in degrees
    end_angle INTEGER, -- end angle of view in degrees
    distance INTEGER, -- view distance in meters
    view_image VARCHAR(500), -- path to image showing the view
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_camera_views_camera_id ON camera_views(camera_id);
```

#### PatchPanels Table
```sql
CREATE TABLE patch_panels (
    panel_id SERIAL PRIMARY KEY,
    location_id INTEGER NOT NULL REFERENCES locations(location_id),
    name VARCHAR(100) NOT NULL,
    num_ports INTEGER NOT NULL,
    panel_type VARCHAR(50), -- 'cat6', 'fiber', etc.
    rack_position VARCHAR(20),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_patch_panels_location_id ON patch_panels(location_id);
```

#### PanelPorts Table
```sql
CREATE TABLE panel_ports (
    port_id SERIAL PRIMARY KEY,
    panel_id INTEGER NOT NULL REFERENCES patch_panels(panel_id),
    port_number INTEGER NOT NULL,
    label VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'available', -- 'available', 'connected', 'faulty'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (panel_id, port_number)
);

CREATE INDEX idx_panel_ports_panel_id ON panel_ports(panel_id);
```

#### Switches Table
```sql
CREATE TABLE switches (
    switch_id SERIAL PRIMARY KEY,
    device_id INTEGER NOT NULL REFERENCES network_devices(device_id),
    num_ports INTEGER NOT NULL,
    model VARCHAR(100),
    firmware_version VARCHAR(50),
    management_ip VARCHAR(45),
    username VARCHAR(100),
    password VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_switches_device_id ON switches(device_id);
```

#### SwitchPorts Table
```sql
CREATE TABLE switch_ports (
    port_id SERIAL PRIMARY KEY,
    switch_id INTEGER NOT NULL REFERENCES switches(switch_id),
    port_number INTEGER NOT NULL,
    port_type VARCHAR(50), -- 'ethernet', 'fiber', etc.
    speed VARCHAR(20), -- '100M', '1G', '10G', etc.
    vlan INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'available', -- 'available', 'connected', 'faulty'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (switch_id, port_number)
);

CREATE INDEX idx_switch_ports_switch_id ON switch_ports(switch_id);
```

#### Cables Table
```sql
CREATE TABLE cables (
    cable_id SERIAL PRIMARY KEY,
    cable_type VARCHAR(50) NOT NULL, -- 'cat6', 'fiber', 'hdmi', etc.
    length INTEGER, -- length in meters
    color VARCHAR(20),
    identifier VARCHAR(50), -- cable identifier or label
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cables_cable_type ON cables(cable_type);
```

#### Connections Table
```sql
CREATE TABLE connections (
    connection_id SERIAL PRIMARY KEY,
    cable_id INTEGER REFERENCES cables(cable_id),
    source_type VARCHAR(50) NOT NULL, -- 'panel_port', 'switch_port', 'device'
    source_id INTEGER NOT NULL, -- ID of the source (panel_port_id, switch_port_id, device_id)
    destination_type VARCHAR(50) NOT NULL, -- 'panel_port', 'switch_port', 'device'
    destination_id INTEGER NOT NULL, -- ID of the destination
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'planned', 'faulty'
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_connections_cable_id ON connections(cable_id);
CREATE INDEX idx_connections_source ON connections(source_type, source_id);
CREATE INDEX idx_connections_destination ON connections(destination_type, destination_id);
```

### Inventory Management Module

#### AssetCategories Table
```sql
CREATE TABLE asset_categories (
    category_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_id INTEGER REFERENCES asset_categories(category_id),
    attributes JSONB, -- JSON array of attribute definitions
    icon VARCHAR(200), -- path to category icon
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_asset_categories_parent_id ON asset_categories(parent_id);
```

#### Vendors Table
```sql
CREATE TABLE vendors (
    vendor_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(50),
    email VARCHAR(200),
    website VARCHAR(200),
    address TEXT,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_vendors_name ON vendors(name);
```

#### Assets Table
```sql
CREATE TABLE assets (
    asset_id SERIAL PRIMARY KEY,
    category_id INTEGER NOT NULL REFERENCES asset_categories(category_id),
    vendor_id INTEGER REFERENCES vendors(vendor_id),
    name VARCHAR(100) NOT NULL,
    model VARCHAR(100),
    serial_number VARCHAR(100),
    asset_tag VARCHAR(50),
    purchase_date DATE,
    purchase_cost DECIMAL(12,2),
    warranty_end_date DATE,
    expected_lifetime INTEGER, -- in months
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'maintenance', 'retired'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_assets_category_id ON assets(category_id);
CREATE INDEX idx_assets_vendor_id ON assets(vendor_id);
CREATE INDEX idx_assets_serial_number ON assets(serial_number);
CREATE INDEX idx_assets_asset_tag ON assets(asset_tag);
CREATE INDEX idx_assets_status ON assets(status);
```

#### AssetLocations Table
```sql
CREATE TABLE asset_locations (
    location_id SERIAL PRIMARY KEY,
    asset_id INTEGER NOT NULL REFERENCES assets(asset_id),
    plan_id INTEGER REFERENCES floor_plans(plan_id),
    x_position INTEGER,
    y_position INTEGER,
    floor VARCHAR(50),
    room VARCHAR(100),
    rack VARCHAR(50),
    rack_position VARCHAR(20),
    status VARCHAR(20) NOT NULL DEFAULT 'current', -- 'current', 'previous', 'planned'
    moved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    moved_by INTEGER REFERENCES staff(staff_id),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_asset_locations_asset_id ON asset_locations(asset_id);
CREATE INDEX idx_asset_locations_plan_id ON asset_locations(plan_id);
CREATE INDEX idx_asset_locations_status ON asset_locations(status);
```

#### AssetAssignments Table
```sql
CREATE TABLE asset_assignments (
    assignment_id SERIAL PRIMARY KEY,
    asset_id INTEGER NOT NULL REFERENCES assets(asset_id),
    employee_id INTEGER REFERENCES staff(staff_id),
    assigned_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    return_date TIMESTAMP,
    assigned_by INTEGER REFERENCES staff(staff_id),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'returned', 'lost'
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_asset_assignments_asset_id ON asset_assignments(asset_id);
CREATE INDEX idx_asset_assignments_employee_id ON asset_assignments(employee_id);
CREATE INDEX idx_asset_assignments_status ON asset_assignments(status);
```

#### MaintenanceRecords Table
```sql
CREATE TABLE maintenance_records (
    maintenance_id SERIAL PRIMARY KEY,
    asset_id INTEGER NOT NULL REFERENCES assets(asset_id),
    maintenance_type VARCHAR(50) NOT NULL, -- 'preventive', 'corrective', 'inspection'
    description TEXT,
    maintenance_date TIMESTAMP NOT NULL,
    cost DECIMAL(12,2),
    performed_by VARCHAR(100),
    technician_id INTEGER REFERENCES staff(staff_id),
    status VARCHAR(20) NOT NULL DEFAULT 'completed', -- 'scheduled', 'in_progress', 'completed', 'cancelled'
    next_maintenance_date DATE,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_maintenance_records_asset_id ON maintenance_records(asset_id);
CREATE INDEX idx_maintenance_records_maintenance_date ON maintenance_records(maintenance_date);
CREATE INDEX idx_maintenance_records_status ON maintenance_records(status);
```

#### WarrantyInfo Table
```sql
CREATE TABLE warranty_info (
    warranty_id SERIAL PRIMARY KEY,
    asset_id INTEGER NOT NULL REFERENCES assets(asset_id),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    provider VARCHAR(100),
    warranty_type VARCHAR(50), -- 'standard', 'extended', 'premium'
    terms TEXT,
    contact_info TEXT,
    documentation_path VARCHAR(500),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_warranty_info_asset_id ON warranty_info(asset_id);
CREATE INDEX idx_warranty_info_end_date ON warranty_info(end_date);
```

#### AssetAttributes Table
```sql
CREATE TABLE asset_attributes (
    attribute_id SERIAL PRIMARY KEY,
    asset_id INTEGER NOT NULL REFERENCES assets(asset_id),
    attribute_name VARCHAR(100) NOT NULL,
    attribute_value TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_asset_attributes_asset_id ON asset_attributes(asset_id);
CREATE INDEX idx_asset_attributes_name ON asset_attributes(attribute_name);
```

#### AssetHistory Table
```sql
CREATE TABLE asset_history (
    history_id SERIAL PRIMARY KEY,
    asset_id INTEGER NOT NULL REFERENCES assets(asset_id),
    action VARCHAR(50) NOT NULL, -- 'created', 'updated', 'moved', 'assigned', 'maintained', 'retired'
    action_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER REFERENCES staff(staff_id),
    details JSONB, -- JSON object with action-specific details
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_asset_history_asset_id ON asset_history(asset_id);
CREATE INDEX idx_asset_history_action_date ON asset_history(action_date);
```

### Ticket System Module

#### Departments Table
```sql
CREATE TABLE departments (
    department_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    manager_id INTEGER REFERENCES staff(staff_id),
    email VARCHAR(200),
    phone VARCHAR(50),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_departments_name ON departments(name);
```

#### Technicians Table
```sql
CREATE TABLE technicians (
    technician_id SERIAL PRIMARY KEY,
    staff_id INTEGER NOT NULL REFERENCES staff(staff_id),
    department_id INTEGER NOT NULL REFERENCES departments(department_id),
    skills TEXT[], -- array of skills
    availability VARCHAR(20) DEFAULT 'available', -- 'available', 'busy', 'off_duty'
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active', 'inactive', 'on_leave'
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_technicians_staff_id ON technicians(staff_id);
CREATE INDEX idx_technicians_department_id ON technicians(department_id);
CREATE INDEX idx_technicians_availability ON technicians(availability);
```

#### TicketCategories Table
```sql
CREATE TABLE ticket_categories (
    category_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_id INTEGER REFERENCES ticket_categories(category_id),
    department_id INTEGER REFERENCES departments(department_id),
    sla_hours INTEGER, -- default SLA response time in hours
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ticket_categories_parent_id ON ticket_categories(parent_id);
CREATE INDEX idx_ticket_categories_department_id ON ticket_categories(department_id);
```

#### TicketPriorities Table
```sql
CREATE TABLE ticket_priorities (
    priority_id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL, -- 'low', 'medium', 'high', 'critical'
    description TEXT,
    color VARCHAR(20),
    response_time INTEGER, -- target response time in hours
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ticket_priorities_name ON ticket_priorities(name);
```

#### TicketStatuses Table
```sql
CREATE TABLE ticket_statuses (
    status_id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL, -- 'new', 'assigned', 'in_progress', 'on_hold', 'resolved', 'closed'
    description TEXT,
    is_closed BOOLEAN DEFAULT FALSE,
    color VARCHAR(20),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ticket_statuses_name ON ticket_statuses(name);
CREATE INDEX idx_ticket_statuses_is_closed ON ticket_statuses(is_closed);
```

#### Tickets Table
```sql
CREATE TABLE tickets (
    ticket_id SERIAL PRIMARY KEY,
    category_id INTEGER NOT NULL REFERENCES ticket_categories(category_id),
    priority_id INTEGER NOT NULL REFERENCES ticket_priorities(priority_id),
    status_id INTEGER NOT NULL REFERENCES ticket_statuses(status_id),
    department_id INTEGER NOT NULL REFERENCES departments(department_id),
    assigned_to INTEGER REFERENCES technicians(technician_id),
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    created_by INTEGER NOT NULL REFERENCES staff(staff_id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    due_date TIMESTAMP,
    resolution_date TIMESTAMP,
    resolution TEXT,
    asset_id INTEGER REFERENCES assets(asset_id),
    location_id INTEGER REFERENCES locations(location_id),
    is_internal BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_tickets_category_id ON tickets(category_id);
CREATE INDEX idx_tickets_priority_id ON tickets(priority_id);
CREATE INDEX idx_tickets_status_id ON tickets(status_id);
CREATE INDEX idx_tickets_department_id ON tickets(department_id);
CREATE INDEX idx_tickets_assigned_to ON tickets(assigned_to);
CREATE INDEX idx_tickets_created_at ON tickets(created_at);
CREATE INDEX idx_tickets_due_date ON tickets(due_date);
CREATE INDEX idx_tickets_asset_id ON tickets(asset_id);
```

#### TicketComments Table
```sql
CREATE TABLE ticket_comments (
    comment_id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(ticket_id),
    user_id INTEGER NOT NULL REFERENCES staff(staff_id),
    comment_text TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_internal BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_ticket_comments_ticket_id ON ticket_comments(ticket_id);
CREATE INDEX idx_ticket_comments_created_at ON ticket_comments(created_at);
```

#### TicketAttachments Table
```sql
CREATE TABLE ticket_attachments (
    attachment_id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(ticket_id),
    comment_id INTEGER REFERENCES ticket_comments(comment_id),
    filename VARCHAR(200) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    file_size INTEGER,
    uploaded_by INTEGER NOT NULL REFERENCES staff(staff_id),
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ticket_attachments_ticket_id ON ticket_attachments(ticket_id);
CREATE INDEX idx_ticket_attachments_comment_id ON ticket_attachments(comment_id);
```

#### ServiceLevelAgreements Table
```sql
CREATE TABLE service_level_agreements (
    sla_id SERIAL PRIMARY KEY,
    category_id INTEGER REFERENCES ticket_categories(category_id),
    priority_id INTEGER REFERENCES ticket_priorities(priority_id),
    response_time INTEGER NOT NULL, -- in hours
    resolution_time INTEGER NOT NULL, -- in hours
    business_hours BOOLEAN DEFAULT TRUE, -- true if SLA is for business hours only
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_service_level_agreements_category_id ON service_level_agreements(category_id);
CREATE INDEX idx_service_level_agreements_priority_id ON service_level_agreements(priority_id);
```

#### EscalationRules Table
```sql
CREATE TABLE escalation_rules (
    rule_id SERIAL PRIMARY KEY,
    sla_id INTEGER NOT NULL REFERENCES service_level_agreements(sla_id),
    condition VARCHAR(50) NOT NULL, -- 'response_time', 'resolution_time'
    threshold INTEGER NOT NULL, -- percentage of SLA time
    action VARCHAR(50) NOT NULL, -- 'notify', 'reassign', 'escalate'
    notify_users INTEGER[], -- array of staff_id to notify
    escalate_to INTEGER REFERENCES staff(staff_id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_escalation_rules_sla_id ON escalation_rules(sla_id);
```

#### TicketHistory Table
```sql
CREATE TABLE ticket_history (
    history_id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(ticket_id),
    action VARCHAR(50) NOT NULL, -- 'created', 'updated', 'assigned', 'status_changed', 'commented', 'resolved', 'closed'
    action_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER REFERENCES staff(staff_id),
    details JSONB, -- JSON object with action-specific details
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ticket_history_ticket_id ON ticket_history(ticket_id);
CREATE INDEX idx_ticket_history_action_date ON ticket_history(action_date);
```

## NoSQL Database Schema (MongoDB)

### Player Tracking Collections

#### players_events
```json
{
  "_id": "ObjectId",
  "player_id": "Integer",
  "event_type": "String", // "login", "game_start", "game_end", "transaction", "consumption", "jackpot", etc.
  "event_time": "ISODate",
  "location": "String",
  "device_id": "String",
  "details": {
    // Event-specific details
  },
  "created_at": "ISODate"
}
```

#### player_analytics
```json
{
  "_id": "ObjectId",
  "player_id": "Integer",
  "date": "ISODate",
  "visit_count": "Integer",
  "total_play_time": "Integer", // in minutes
  "total_spend": "Decimal",
  "total_win": "Decimal",
  "net_win_loss": "Decimal",
  "game_preferences": [
    {
      "game_type": "String",
      "play_time": "Integer",
      "frequency": "Integer"
    }
  ],
  "consumption_preferences": [
    {
      "item_type": "String",
      "quantity": "Integer",
      "frequency": "Integer"
    }
  ],
  "ai_segments": [
    {
      "segment_type": "String",
      "confidence": "Decimal",
      "assigned_at": "ISODate"
    }
  ],
  "updated_at": "ISODate"
}
```

### Network Design Collections

#### network_topology
```json
{
  "_id": "ObjectId",
  "plan_id": "Integer",
  "name": "String",
  "description": "String",
  "nodes": [
    {
      "node_id": "String",
      "device_id": "Integer",
      "device_type": "String",
      "name": "String",
      "ip_addresses": ["String"],
      "position": {
        "x": "Integer",
        "y": "Integer"
      },
      "status": "String"
    }
  ],
  "edges": [
    {
      "edge_id": "String",
      "source_node_id": "String",
      "target_node_id": "String",
      "connection_id": "Integer",
      "cable_id": "Integer",
      "status": "String"
    }
  ],
  "created_at": "ISODate",
  "updated_at": "ISODate"
}
```

#### camera_coverage
```json
{
  "_id": "ObjectId",
  "plan_id": "Integer",
  "coverage_map": "String", // path to coverage heatmap image
  "cameras": [
    {
      "camera_id": "Integer",
      "position": {
        "x": "Integer",
        "y": "Integer"
      },
      "fov": {
        "angle": "Integer",
        "direction": "Integer",
        "distance": "Integer"
      },
      "coverage_area": [
        // Array of polygon points defining coverage area
        {"x": "Integer", "y": "Integer"}
      ]
    }
  ],
  "blind_spots": [
    // Array of polygon points defining blind spots
    {"x": "Integer", "y": "Integer"}
  ],
  "created_at": "ISODate",
  "updated_at": "ISODate"
}
```

### Inventory Management Collections

#### asset_snapshots
```json
{
  "_id": "ObjectId",
  "snapshot_date": "ISODate",
  "total_assets": "Integer",
  "assets_by_category": [
    {
      "category_id": "Integer",
      "category_name": "String",
      "count": "Integer",
      "total_value": "Decimal"
    }
  ],
  "assets_by_status": [
    {
      "status": "String",
      "count": "Integer"
    }
  ],
  "assets_by_location": [
    {
      "location": "String",
      "count": "Integer"
    }
  ],
  "maintenance_due": "Integer",
  "warranty_expiring": "Integer",
  "created_at": "ISODate"
}
```

#### asset_audit_logs
```json
{
  "_id": "ObjectId",
  "audit_date": "ISODate",
  "auditor_id": "Integer",
  "audit_type": "String", // "scheduled", "random", "annual"
  "assets_checked": [
    {
      "asset_id": "Integer",
      "expected_location": "String",
      "actual_location": "String",
      "status": "String", // "found", "missing", "wrong_location"
      "condition": "String",
      "notes": "String"
    }
  ],
  "discrepancies": "Integer",
  "resolution_status": "String",
  "created_at": "ISODate",
  "updated_at": "ISODate"
}
```

### Ticket System Collections

#### ticket_analytics
```json
{
  "_id": "ObjectId",
  "period": "String", // "daily", "weekly", "monthly"
  "date": "ISODate",
  "tickets_opened": "Integer",
  "tickets_closed": "Integer",
  "average_resolution_time": "Decimal", // in hours
  "sla_compliance": "Decimal", // percentage
  "by_department": [
    {
      "department_id": "Integer",
      "department_name": "String",
      "tickets_opened": "Integer",
      "tickets_closed": "Integer",
      "average_resolution_time": "Decimal"
    }
  ],
  "by_category": [
    {
      "category_id": "Integer",
      "category_name": "String",
      "count": "Integer",
      "average_resolution_time": "Decimal"
    }
  ],
  "by_priority": [
    {
      "priority_id": "Integer",
      "priority_name": "String",
      "count": "Integer",
      "average_resolution_time": "Decimal"
    }
  ],
  "by_technician": [
    {
      "technician_id": "Integer",
      "name": "String",
      "tickets_assigned": "Integer",
      "tickets_resolved": "Integer",
      "average_resolution_time": "Decimal"
    }
  ],
  "created_at": "ISODate"
}
```

#### knowledge_base
```json
{
  "_id": "ObjectId",
  "title": "String",
  "category_id": "Integer",
  "content": "String",
  "tags": ["String"],
  "related_ticket_ids": ["Integer"],
  "attachments": [
    {
      "filename": "String",
      "file_path": "String",
      "file_type": "String"
    }
  ],
  "created_by": "Integer",
  "created_at": "ISODate",
  "updated_at": "ISODate",
  "view_count": "Integer",
  "helpful_count": "Integer"
}
```

## Redis Schema

### Caching Keys

#### Player Data
- `player:{player_id}:profile` - Player profile data
- `player:{player_id}:current_session` - Current gaming session data
- `player:{player_id}:recent_activities` - List of recent activities
- `player:{player_id}:preferences` - Player preferences

#### Network Status
- `network:device:{device_id}:status` - Current status of network device
- `network:camera:{camera_id}:status` - Current status of camera
- `network:switch:{switch_id}:port_status` - Hash of port statuses for a switch

#### Asset Tracking
- `asset:{asset_id}:status` - Current status of asset
- `asset:{asset_id}:location` - Current location of asset
- `asset:search:index` - Search index for assets

#### Ticket System
- `ticket:{ticket_id}:status` - Current status of ticket
- `ticket:technician:{technician_id}:assigned` - List of assigned tickets
- `ticket:department:{department_id}:open` - List of open tickets for department

### Pub/Sub Channels

- `events:player_activity` - Real-time player activity events
- `events:network_status` - Network device status changes
- `events:asset_movement` - Asset location changes
- `events:ticket_updates` - Ticket status updates

## File Storage (MinIO/S3)

### Buckets and Paths

#### Player Photos
- `player-photos/{player_id}/{photo_id}.jpg` - Player identification photos
- `player-photos/jackpots/{jackpot_id}.jpg` - Jackpot photos

#### Floor Plans
- `floor-plans/{plan_id}/original.jpg` - Original floor plan images
- `floor-plans/{plan_id}/rendered.jpg` - Rendered floor plan with devices

#### Network Documentation
- `network-docs/{device_id}/manuals/` - Device manuals
- `network-docs/topology/{plan_id}.svg` - Network topology diagrams
- `network-docs/coverage/{plan_id}.jpg` - Camera coverage maps

#### Asset Documentation
- `asset-docs/{asset_id}/manuals/` - Asset manuals
- `asset-docs/{asset_id}/photos/` - Asset photos
- `asset-docs/{asset_id}/warranty/` - Warranty documentation

#### Ticket Attachments
- `ticket-attachments/{ticket_id}/{attachment_id}` - Ticket attachments
- `knowledge-base/{article_id}/attachments/` - Knowledge base attachments

## Data Migration and Backup Strategies

### Backup Schedule
- Full database backup: Daily
- Incremental backups: Every 6 hours
- Transaction log backups: Every 15 minutes
- File storage backup: Daily

### Retention Policy
- Daily backups: 30 days
- Weekly backups: 3 months
- Monthly backups: 1 year
- Yearly backups: 7 years

### Disaster Recovery
- Point-in-time recovery capability
- Offsite backup storage
- Automated recovery testing monthly
- Recovery time objective (RTO): 4 hours
- Recovery point objective (RPO): 15 minutes

## Performance Optimization

### Indexing Strategy
- Primary keys and foreign keys indexed
- Frequently queried fields indexed
- Composite indexes for common query patterns
- Regular index maintenance and optimization

### Partitioning
- Time-based partitioning for historical data
- Location-based partitioning for multi-site deployments
- Category-based partitioning for large asset collections

### Caching
- Frequently accessed data cached in Redis
- Cache invalidation on data updates
- Tiered caching strategy for different data types

### Query Optimization
- Prepared statements for common queries
- Query plan analysis and optimization
- Pagination for large result sets
- Asynchronous processing for reports and analytics
