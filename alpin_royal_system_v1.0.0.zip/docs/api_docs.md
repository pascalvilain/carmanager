# Alpin Royal Casino Management System - API Documentation

## Introduction

This document provides comprehensive documentation for the Alpin Royal Casino Management System API. The API follows RESTful principles and uses JSON for data exchange. All endpoints require authentication unless explicitly stated otherwise.

## Base URL

```
https://your-server-domain/api/v1
```

## Authentication

### Obtaining an Access Token

```
POST /auth/token
```

**Request Body:**

```json
{
  "username": "your_username",
  "password": "your_password"
}
```

**Response:**

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 86400
}
```

### Using the Access Token

Include the access token in the Authorization header for all API requests:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## Common Response Formats

### Success Response

```json
{
  "status": "success",
  "data": {
    // Response data here
  }
}
```

### Error Response

```json
{
  "status": "error",
  "error": {
    "code": "ERROR_CODE",
    "message": "Error message description"
  }
}
```

## Player Tracking API

### Guests

#### List Guests

```
GET /player-tracking/guests
```

**Query Parameters:**

| Parameter | Type   | Description                                      |
|-----------|--------|--------------------------------------------------|
| page      | int    | Page number (default: 1)                         |
| limit     | int    | Number of results per page (default: 20, max: 100) |
| search    | string | Search term for name, ID, or guest ID            |
| sort      | string | Field to sort by (e.g., "name", "created_at")    |
| order     | string | Sort order ("asc" or "desc")                     |

**Response:**

```json
{
  "status": "success",
  "data": {
    "guests": [
      {
        "id": "g12345",
        "guest_id": "AR-10001",
        "first_name": "John",
        "last_name": "Doe",
        "date_of_birth": "1980-01-15",
        "nationality": "Switzerland",
        "id_type": "passport",
        "id_number": "X123456",
        "contact_info": {
          "email": "john.doe@example.com",
          "phone": "+41 123 456 789",
          "address": {
            "street": "Bahnhofstrasse 123",
            "city": "Zurich",
            "postal_code": "8001",
            "country": "Switzerland"
          }
        },
        "photos": {
          "id_photo": "/storage/photos/id/g12345.jpg",
          "profile_photo": "/storage/photos/profile/g12345.jpg"
        },
        "created_at": "2025-01-10T14:30:00Z",
        "updated_at": "2025-03-15T09:45:00Z"
      },
      // More guests...
    ],
    "pagination": {
      "total": 1000,
      "page": 1,
      "limit": 20,
      "pages": 50
    }
  }
}
```

#### Get Guest Details

```
GET /player-tracking/guests/{guest_id}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "guest": {
      "id": "g12345",
      "guest_id": "AR-10001",
      "first_name": "John",
      "last_name": "Doe",
      "date_of_birth": "1980-01-15",
      "nationality": "Switzerland",
      "id_type": "passport",
      "id_number": "X123456",
      "contact_info": {
        "email": "john.doe@example.com",
        "phone": "+41 123 456 789",
        "address": {
          "street": "Bahnhofstrasse 123",
          "city": "Zurich",
          "postal_code": "8001",
          "country": "Switzerland"
        }
      },
      "photos": {
        "id_photo": "/storage/photos/id/g12345.jpg",
        "profile_photo": "/storage/photos/profile/g12345.jpg"
      },
      "preferences": {
        "favorite_games": ["roulette", "blackjack"],
        "preferred_drink": "whiskey",
        "smoking": true,
        "preferred_cigarette": "Marlboro Gold"
      },
      "statistics": {
        "total_visits": 25,
        "total_play_time": 75.5, // hours
        "average_bet": 150.0, // CHF
        "total_drop": 45000.0, // CHF
        "total_jackpots": 3,
        "jackpot_amount": 12500.0 // CHF
      },
      "notes": "VIP guest, prefers quiet areas",
      "created_at": "2025-01-10T14:30:00Z",
      "updated_at": "2025-03-15T09:45:00Z"
    }
  }
}
```

#### Create Guest

```
POST /player-tracking/guests
```

**Request Body:**

```json
{
  "first_name": "Jane",
  "last_name": "Smith",
  "date_of_birth": "1985-05-20",
  "nationality": "Germany",
  "id_type": "id_card",
  "id_number": "DE987654321",
  "contact_info": {
    "email": "jane.smith@example.com",
    "phone": "+49 987 654 321",
    "address": {
      "street": "Hauptstrasse 45",
      "city": "Berlin",
      "postal_code": "10115",
      "country": "Germany"
    }
  },
  "notes": "First time visitor"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "guest": {
      "id": "g12346",
      "guest_id": "AR-10002",
      "first_name": "Jane",
      "last_name": "Smith",
      // Other guest details...
      "created_at": "2025-03-26T11:30:00Z",
      "updated_at": "2025-03-26T11:30:00Z"
    }
  }
}
```

#### Update Guest

```
PUT /player-tracking/guests/{guest_id}
```

**Request Body:**

```json
{
  "contact_info": {
    "email": "jane.updated@example.com",
    "phone": "+49 987 654 321"
  },
  "notes": "Updated guest information"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "guest": {
      "id": "g12346",
      "guest_id": "AR-10002",
      // Updated guest details...
      "updated_at": "2025-03-26T12:15:00Z"
    }
  }
}
```

#### Upload Guest Photo

```
POST /player-tracking/guests/{guest_id}/photos
```

**Request Body (multipart/form-data):**

| Parameter | Type | Description                                |
|-----------|------|--------------------------------------------|
| photo_type | string | Type of photo ("id" or "profile")        |
| photo     | file  | The image file to upload                  |

**Response:**

```json
{
  "status": "success",
  "data": {
    "photo_url": "/storage/photos/profile/g12346.jpg"
  }
}
```

### Gaming Sessions

#### List Guest Sessions

```
GET /player-tracking/guests/{guest_id}/sessions
```

**Query Parameters:**

| Parameter | Type   | Description                                      |
|-----------|--------|--------------------------------------------------|
| page      | int    | Page number (default: 1)                         |
| limit     | int    | Number of results per page (default: 20, max: 100) |
| start_date | string | Filter by start date (ISO format)               |
| end_date  | string | Filter by end date (ISO format)                  |
| status    | string | Filter by status ("active", "completed")         |

**Response:**

```json
{
  "status": "success",
  "data": {
    "sessions": [
      {
        "id": "s78901",
        "guest_id": "g12345",
        "start_time": "2025-03-20T19:30:00Z",
        "end_time": "2025-03-21T01:45:00Z",
        "duration": 6.25, // hours
        "status": "completed",
        "activities": {
          "tables": 2,
          "slots": 1
        },
        "financial": {
          "total_buy_in": 5000.0,
          "total_cash_out": 6200.0,
          "net_result": 1200.0
        },
        "consumption": {
          "drinks": 4,
          "food": 1,
          "cigarettes": 2
        },
        "created_at": "2025-03-20T19:30:00Z",
        "updated_at": "2025-03-21T01:45:00Z"
      },
      // More sessions...
    ],
    "pagination": {
      "total": 25,
      "page": 1,
      "limit": 20,
      "pages": 2
    }
  }
}
```

#### Get Session Details

```
GET /player-tracking/sessions/{session_id}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "session": {
      "id": "s78901",
      "guest_id": "g12345",
      "guest": {
        "id": "g12345",
        "guest_id": "AR-10001",
        "first_name": "John",
        "last_name": "Doe"
      },
      "start_time": "2025-03-20T19:30:00Z",
      "end_time": "2025-03-21T01:45:00Z",
      "duration": 6.25, // hours
      "status": "completed",
      "table_activities": [
        {
          "id": "ta12345",
          "table_id": "t001",
          "game_type": "roulette",
          "start_time": "2025-03-20T19:45:00Z",
          "end_time": "2025-03-20T21:30:00Z",
          "duration": 1.75, // hours
          "buy_in": 2000.0,
          "cash_out": 2500.0,
          "average_bet": 100.0,
          "notes": "Played mostly on red/black"
        },
        {
          "id": "ta12346",
          "table_id": "t003",
          "game_type": "blackjack",
          "start_time": "2025-03-20T22:00:00Z",
          "end_time": "2025-03-20T23:45:00Z",
          "duration": 1.75, // hours
          "buy_in": 1500.0,
          "cash_out": 2200.0,
          "average_bet": 150.0,
          "notes": "Split pairs frequently"
        }
      ],
      "slot_activities": [
        {
          "id": "sa12345",
          "machine_id": "s150",
          "start_time": "2025-03-21T00:00:00Z",
          "end_time": "2025-03-21T01:30:00Z",
          "duration": 1.5, // hours
          "money_in": 1500.0,
          "ticket_in": 0.0,
          "ticket_out": 1500.0,
          "jackpots": [
            {
              "amount": 1000.0,
              "time": "2025-03-21T01:15:00Z",
              "photo": "/storage/photos/jackpots/j12345.jpg"
            }
          ],
          "hand_pays": [],
          "notes": "Played max bet consistently"
        }
      ],
      "financial_transactions": [
        {
          "id": "ft12345",
          "type": "buy_in",
          "amount": 2000.0,
          "payment_method": "cash",
          "time": "2025-03-20T19:40:00Z",
          "location": "cashdesk",
          "notes": "Initial buy-in"
        },
        {
          "id": "ft12346",
          "type": "buy_in",
          "amount": 3000.0,
          "payment_method": "card",
          "time": "2025-03-20T21:45:00Z",
          "location": "cashdesk",
          "notes": "Additional buy-in"
        },
        {
          "id": "ft12347",
          "type": "cash_out",
          "amount": 6200.0,
          "payment_method": "cash",
          "time": "2025-03-21T01:40:00Z",
          "location": "cashdesk",
          "notes": "Final cash out"
        }
      ],
      "consumption_records": [
        {
          "id": "cr12345",
          "type": "drink",
          "item": "Whiskey",
          "quantity": 2,
          "time": "2025-03-20T20:15:00Z",
          "notes": "Macallan 12"
        },
        {
          "id": "cr12346",
          "type": "food",
          "item": "Steak",
          "quantity": 1,
          "time": "2025-03-20T21:00:00Z",
          "notes": "Medium rare"
        },
        {
          "id": "cr12347",
          "type": "drink",
          "item": "Water",
          "quantity": 2,
          "time": "2025-03-20T22:30:00Z",
          "notes": "Sparkling"
        },
        {
          "id": "cr12348",
          "type": "cigarette",
          "item": "Marlboro Gold",
          "quantity": 2,
          "time": "2025-03-20T23:00:00Z",
          "notes": ""
        }
      ],
      "created_at": "2025-03-20T19:30:00Z",
      "updated_at": "2025-03-21T01:45:00Z"
    }
  }
}
```

#### Start Session

```
POST /player-tracking/guests/{guest_id}/sessions
```

**Request Body:**

```json
{
  "initial_buy_in": 1000.0,
  "payment_method": "cash",
  "notes": "Weekend visit"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "session": {
      "id": "s78902",
      "guest_id": "g12345",
      "start_time": "2025-03-26T14:00:00Z",
      "status": "active",
      "financial": {
        "total_buy_in": 1000.0,
        "total_cash_out": 0.0,
        "net_result": -1000.0
      },
      "created_at": "2025-03-26T14:00:00Z",
      "updated_at": "2025-03-26T14:00:00Z"
    }
  }
}
```

#### End Session

```
PUT /player-tracking/sessions/{session_id}/end
```

**Request Body:**

```json
{
  "final_cash_out": 1500.0,
  "payment_method": "cash",
  "notes": "Guest satisfied with experience"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "session": {
      "id": "s78902",
      "guest_id": "g12345",
      "start_time": "2025-03-26T14:00:00Z",
      "end_time": "2025-03-26T18:30:00Z",
      "duration": 4.5, // hours
      "status": "completed",
      "financial": {
        "total_buy_in": 1000.0,
        "total_cash_out": 1500.0,
        "net_result": 500.0
      },
      "created_at": "2025-03-26T14:00:00Z",
      "updated_at": "2025-03-26T18:30:00Z"
    }
  }
}
```

### Table Activities

#### Add Table Activity

```
POST /player-tracking/sessions/{session_id}/table-activities
```

**Request Body:**

```json
{
  "table_id": "t002",
  "game_type": "roulette",
  "start_time": "2025-03-26T14:15:00Z",
  "end_time": "2025-03-26T15:45:00Z",
  "buy_in": 500.0,
  "cash_out": 750.0,
  "average_bet": 50.0,
  "notes": "Played mostly on numbers"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "table_activity": {
      "id": "ta12347",
      "session_id": "s78902",
      "table_id": "t002",
      "game_type": "roulette",
      "start_time": "2025-03-26T14:15:00Z",
      "end_time": "2025-03-26T15:45:00Z",
      "duration": 1.5, // hours
      "buy_in": 500.0,
      "cash_out": 750.0,
      "average_bet": 50.0,
      "notes": "Played mostly on numbers",
      "created_at": "2025-03-26T15:45:00Z",
      "updated_at": "2025-03-26T15:45:00Z"
    }
  }
}
```

#### Update Table Activity

```
PUT /player-tracking/table-activities/{activity_id}
```

**Request Body:**

```json
{
  "end_time": "2025-03-26T16:00:00Z",
  "cash_out": 800.0,
  "notes": "Extended play time, won on final spins"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "table_activity": {
      "id": "ta12347",
      "session_id": "s78902",
      "table_id": "t002",
      "game_type": "roulette",
      "start_time": "2025-03-26T14:15:00Z",
      "end_time": "2025-03-26T16:00:00Z",
      "duration": 1.75, // hours
      "buy_in": 500.0,
      "cash_out": 800.0,
      "average_bet": 50.0,
      "notes": "Extended play time, won on final spins",
      "created_at": "2025-03-26T15:45:00Z",
      "updated_at": "2025-03-26T16:00:00Z"
    }
  }
}
```

### Slot Activities

#### Add Slot Activity

```
POST /player-tracking/sessions/{session_id}/slot-activities
```

**Request Body:**

```json
{
  "machine_id": "s075",
  "start_time": "2025-03-26T16:15:00Z",
  "end_time": "2025-03-26T17:30:00Z",
  "money_in": 300.0,
  "ticket_in": 0.0,
  "ticket_out": 450.0,
  "jackpots": [
    {
      "amount": 200.0,
      "time": "2025-03-26T17:15:00Z"
    }
  ],
  "notes": "Played bonus rounds frequently"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "slot_activity": {
      "id": "sa12346",
      "session_id": "s78902",
      "machine_id": "s075",
      "start_time": "2025-03-26T16:15:00Z",
      "end_time": "2025-03-26T17:30:00Z",
      "duration": 1.25, // hours
      "money_in": 300.0,
      "ticket_in": 0.0,
      "ticket_out": 450.0,
      "jackpots": [
        {
          "id": "j12346",
          "amount": 200.0,
          "time": "2025-03-26T17:15:00Z"
        }
      ],
      "hand_pays": [],
      "notes": "Played bonus rounds frequently",
      "created_at": "2025-03-26T17:30:00Z",
      "updated_at": "2025-03-26T17:30:00Z"
    }
  }
}
```

#### Upload Jackpot Photo

```
POST /player-tracking/jackpots/{jackpot_id}/photo
```

**Request Body (multipart/form-data):**

| Parameter | Type | Description                                |
|-----------|------|--------------------------------------------|
| photo     | file | The image file to upload                   |

**Response:**

```json
{
  "status": "success",
  "data": {
    "photo_url": "/storage/photos/jackpots/j12346.jpg"
  }
}
```

### Financial Transactions

#### Add Financial Transaction

```
POST /player-tracking/sessions/{session_id}/transactions
```

**Request Body:**

```json
{
  "type": "buy_in",
  "amount": 500.0,
  "payment_method": "cash",
  "time": "2025-03-26T16:10:00Z",
  "location": "cashdesk",
  "notes": "Additional buy-in for slots"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "transaction": {
      "id": "ft12348",
      "session_id": "s78902",
      "type": "buy_in",
      "amount": 500.0,
      "payment_method": "cash",
      "time": "2025-03-26T16:10:00Z",
      "location": "cashdesk",
      "notes": "Additional buy-in for slots",
      "created_at": "2025-03-26T16:10:00Z",
      "updated_at": "2025-03-26T16:10:00Z"
    }
  }
}
```

### Consumption Records

#### Add Consumption Record

```
POST /player-tracking/sessions/{session_id}/consumption
```

**Request Body:**

```json
{
  "type": "drink",
  "item": "Beer",
  "quantity": 1,
  "time": "2025-03-26T15:00:00Z",
  "notes": "Heineken"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "consumption": {
      "id": "cr12349",
      "session_id": "s78902",
      "type": "drink",
      "item": "Beer",
      "quantity": 1,
      "time": "2025-03-26T15:00:00Z",
      "notes": "Heineken",
      "created_at": "2025-03-26T15:00:00Z",
      "updated_at": "2025-03-26T15:00:00Z"
    }
  }
}
```

### Cigarette Inventory

#### List Cigarette Inventory

```
GET /player-tracking/cigarette-inventory
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "inventory": [
      {
        "id": "ci12345",
        "brand": "Marlboro",
        "variant": "Red",
        "quantity": 45,
        "threshold": 10,
        "last_updated": "2025-03-25T10:30:00Z"
      },
      {
        "id": "ci12346",
        "brand": "Marlboro",
        "variant": "Gold",
        "quantity": 32,
        "threshold": 10,
        "last_updated": "2025-03-25T10:30:00Z"
      },
      // More inventory items...
    ]
  }
}
```

#### Update Cigarette Inventory

```
PUT /player-tracking/cigarette-inventory/{inventory_id}
```

**Request Body:**

```json
{
  "quantity": 50,
  "threshold": 15,
  "notes": "Restocked"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "inventory": {
      "id": "ci12345",
      "brand": "Marlboro",
      "variant": "Red",
      "quantity": 50,
      "threshold": 15,
      "last_updated": "2025-03-26T14:45:00Z",
      "notes": "Restocked"
    }
  }
}
```

### Reports

#### Generate Player Activity Report

```
GET /player-tracking/reports/player-activity
```

**Query Parameters:**

| Parameter | Type   | Description                                      |
|-----------|--------|--------------------------------------------------|
| start_date | string | Start date for report (ISO format)              |
| end_date  | string | End date for report (ISO format)                 |
| guest_id  | string | (Optional) Filter by specific guest              |
| format    | string | Report format ("json", "csv", "pdf", "excel")    |

**Response (for JSON format):**

```json
{
  "status": "success",
  "data": {
    "report": {
      "title": "Player Activity Report",
      "period": {
        "start": "2025-03-01T00:00:00Z",
        "end": "2025-03-26T23:59:59Z"
      },
      "summary": {
        "total_guests": 245,
        "total_sessions": 412,
        "total_play_time": 1560.5, // hours
        "total_drop": 1250000.0, // CHF
        "total_jackpots": 87,
        "jackpot_amount": 325000.0 // CHF
      },
      "guests": [
        {
          "id": "g12345",
          "guest_id": "AR-10001",
          "name": "John Doe",
          "sessions": 5,
          "play_time": 25.75, // hours
          "drop": 15000.0, // CHF
          "jackpots": 2,
          "jackpot_amount": 3500.0, // CHF
          "net_result": 2200.0 // CHF
        },
        // More guests...
      ]
    }
  }
}
```

For other formats (CSV, PDF, Excel), the response will be a file download.

## Network Design API

### Floor Plans

#### List Floor Plans

```
GET /network-design/floor-plans
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "floor_plans": [
      {
        "id": "fp12345",
        "name": "Main Casino Floor",
        "description": "Ground floor gaming area",
        "image_url": "/storage/floor-plans/fp12345.jpg",
        "scale": 1.5, // meters per 100 pixels
        "dimensions": {
          "width": 2400,
          "height": 1800
        },
        "created_at": "2025-02-15T10:00:00Z",
        "updated_at": "2025-02-15T10:00:00Z"
      },
      // More floor plans...
    ]
  }
}
```

#### Get Floor Plan Details

```
GET /network-design/floor-plans/{floor_plan_id}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "floor_plan": {
      "id": "fp12345",
      "name": "Main Casino Floor",
      "description": "Ground floor gaming area",
      "image_url": "/storage/floor-plans/fp12345.jpg",
      "scale": 1.5, // meters per 100 pixels
      "dimensions": {
        "width": 2400,
        "height": 1800
      },
      "devices": [
        {
          "id": "d12345",
          "type": "camera",
          "subtype": "fixed",
          "name": "Cam-101",
          "position": {
            "x": 450,
            "y": 320
          },
          "rotation": 45, // degrees
          "fov": 90, // degrees
          "properties": {
            "ip_address": "192.168.1.101",
            "mac_address": "00:11:22:33:44:55"
          }
        },
        // More devices...
      ],
      "created_at": "2025-02-15T10:00:00Z",
      "updated_at": "2025-03-10T14:30:00Z"
    }
  }
}
```

#### Upload Floor Plan

```
POST /network-design/floor-plans
```

**Request Body (multipart/form-data):**

| Parameter  | Type   | Description                                |
|------------|--------|--------------------------------------------|
| name       | string | Name of the floor plan                     |
| description | string | Description of the floor plan              |
| scale      | number | Scale in meters per 100 pixels             |
| image      | file   | The floor plan image file                  |

**Response:**

```json
{
  "status": "success",
  "data": {
    "floor_plan": {
      "id": "fp12346",
      "name": "VIP Area",
      "description": "Private gaming area for VIP guests",
      "image_url": "/storage/floor-plans/fp12346.jpg",
      "scale": 1.2,
      "dimensions": {
        "width": 1800,
        "height": 1200
      },
      "created_at": "2025-03-26T15:00:00Z",
      "updated_at": "2025-03-26T15:00:00Z"
    }
  }
}
```

### Devices

#### List Devices

```
GET /network-design/devices
```

**Query Parameters:**

| Parameter | Type   | Description                                      |
|-----------|--------|--------------------------------------------------|
| page      | int    | Page number (default: 1)                         |
| limit     | int    | Number of results per page (default: 20, max: 100) |
| type      | string | Filter by device type                            |
| search    | string | Search term for name or IP address               |

**Response:**

```json
{
  "status": "success",
  "data": {
    "devices": [
      {
        "id": "d12345",
        "type": "camera",
        "subtype": "fixed",
        "name": "Cam-101",
        "description": "Main entrance camera",
        "properties": {
          "ip_address": "192.168.1.101",
          "mac_address": "00:11:22:33:44:55",
          "manufacturer": "Axis",
          "model": "P3245-LV",
          "serial_number": "ACCC12345",
          "firmware": "10.2.1"
        },
        "location": {
          "floor_plan_id": "fp12345",
          "position": {
            "x": 450,
            "y": 320
          }
        },
        "created_at": "2025-02-20T09:30:00Z",
        "updated_at": "2025-02-20T09:30:00Z"
      },
      // More devices...
    ],
    "pagination": {
      "total": 150,
      "page": 1,
      "limit": 20,
      "pages": 8
    }
  }
}
```

#### Get Device Details

```
GET /network-design/devices/{device_id}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "device": {
      "id": "d12345",
      "type": "camera",
      "subtype": "fixed",
      "name": "Cam-101",
      "description": "Main entrance camera",
      "properties": {
        "ip_address": "192.168.1.101",
        "mac_address": "00:11:22:33:44:55",
        "manufacturer": "Axis",
        "model": "P3245-LV",
        "serial_number": "ACCC12345",
        "firmware": "10.2.1",
        "resolution": "4MP",
        "power_type": "PoE"
      },
      "location": {
        "floor_plan_id": "fp12345",
        "floor_plan_name": "Main Casino Floor",
        "position": {
          "x": 450,
          "y": 320
        },
        "rotation": 45,
        "fov": 90
      },
      "connections": [
        {
          "id": "c12345",
          "target_device_id": "d12350",
          "target_device_name": "Switch-01",
          "cable_id": "cab12345",
          "cable_type": "Cat6",
          "cable_length": 15.5, // meters
          "source_port": "Network",
          "target_port": "Port 12"
        }
      ],
      "maintenance": [
        {
          "id": "m12345",
          "type": "installation",
          "date": "2025-02-20T09:00:00Z",
          "technician": "John Smith",
          "notes": "Initial installation"
        },
        {
          "id": "m12346",
          "type": "firmware_update",
          "date": "2025-03-15T14:00:00Z",
          "technician": "Jane Doe",
          "notes": "Updated firmware to 10.2.1"
        }
      ],
      "created_at": "2025-02-20T09:30:00Z",
      "updated_at": "2025-03-15T14:00:00Z"
    }
  }
}
```

#### Create Device

```
POST /network-design/devices
```

**Request Body:**

```json
{
  "type": "switch",
  "subtype": "managed",
  "name": "Switch-02",
  "description": "VIP area network switch",
  "properties": {
    "ip_address": "192.168.1.2",
    "mac_address": "AA:BB:CC:DD:EE:FF",
    "manufacturer": "Cisco",
    "model": "Catalyst 2960",
    "serial_number": "CSC987654",
    "ports": 24,
    "port_speed": "1Gbps"
  },
  "location": {
    "floor_plan_id": "fp12346",
    "position": {
      "x": 600,
      "y": 400
    }
  }
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "device": {
      "id": "d12351",
      "type": "switch",
      "subtype": "managed",
      "name": "Switch-02",
      // Other device details...
      "created_at": "2025-03-26T15:30:00Z",
      "updated_at": "2025-03-26T15:30:00Z"
    }
  }
}
```

#### Update Device Position

```
PUT /network-design/devices/{device_id}/position
```

**Request Body:**

```json
{
  "floor_plan_id": "fp12346",
  "position": {
    "x": 650,
    "y": 420
  },
  "rotation": 0
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "device": {
      "id": "d12351",
      "location": {
        "floor_plan_id": "fp12346",
        "position": {
          "x": 650,
          "y": 420
        },
        "rotation": 0
      },
      "updated_at": "2025-03-26T15:45:00Z"
    }
  }
}
```

### Connections

#### Create Connection

```
POST /network-design/connections
```

**Request Body:**

```json
{
  "source_device_id": "d12345",
  "target_device_id": "d12351",
  "cable_type": "Cat6",
  "cable_length": 25.0,
  "source_port": "Network",
  "target_port": "Port 1",
  "notes": "Main camera connection"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "connection": {
      "id": "c12346",
      "source_device_id": "d12345",
      "source_device_name": "Cam-101",
      "target_device_id": "d12351",
      "target_device_name": "Switch-02",
      "cable_id": "cab12346",
      "cable_type": "Cat6",
      "cable_length": 25.0,
      "source_port": "Network",
      "target_port": "Port 1",
      "notes": "Main camera connection",
      "created_at": "2025-03-26T16:00:00Z",
      "updated_at": "2025-03-26T16:00:00Z"
    }
  }
}
```

## Inventory Management API

### Assets

#### List Assets

```
GET /inventory/assets
```

**Query Parameters:**

| Parameter | Type   | Description                                      |
|-----------|--------|--------------------------------------------------|
| page      | int    | Page number (default: 1)                         |
| limit     | int    | Number of results per page (default: 20, max: 100) |
| category  | string | Filter by asset category                         |
| status    | string | Filter by status ("in_stock", "deployed", "maintenance") |
| search    | string | Search term for name or serial number            |

**Response:**

```json
{
  "status": "success",
  "data": {
    "assets": [
      {
        "id": "a12345",
        "name": "Dell OptiPlex 7090",
        "category": "computer",
        "status": "deployed",
        "serial_number": "DELL123456",
        "asset_tag": "IT-PC-001",
        "purchase_date": "2025-01-15",
        "purchase_cost": 1200.0,
        "location": {
          "floor_plan_id": "fp12345",
          "area": "Reception"
        },
        "created_at": "2025-01-20T10:00:00Z",
        "updated_at": "2025-01-25T14:30:00Z"
      },
      // More assets...
    ],
    "pagination": {
      "total": 350,
      "page": 1,
      "limit": 20,
      "pages": 18
    }
  }
}
```

#### Get Asset Details

```
GET /inventory/assets/{asset_id}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "asset": {
      "id": "a12345",
      "name": "Dell OptiPlex 7090",
      "category": "computer",
      "status": "deployed",
      "serial_number": "DELL123456",
      "asset_tag": "IT-PC-001",
      "manufacturer": "Dell",
      "model": "OptiPlex 7090",
      "purchase_date": "2025-01-15",
      "purchase_cost": 1200.0,
      "warranty_expiry": "2028-01-15",
      "specifications": {
        "cpu": "Intel Core i7-11700",
        "ram": "16GB",
        "storage": "512GB SSD",
        "os": "Windows 11 Pro"
      },
      "location": {
        "floor_plan_id": "fp12345",
        "floor_plan_name": "Main Casino Floor",
        "area": "Reception",
        "position": {
          "x": 150,
          "y": 100
        }
      },
      "assigned_to": {
        "employee_id": "e12345",
        "name": "Jane Smith",
        "department": "Reception"
      },
      "maintenance_history": [
        {
          "id": "am12345",
          "type": "installation",
          "date": "2025-01-25T10:00:00Z",
          "technician": "John Doe",
          "notes": "Initial setup and installation"
        },
        {
          "id": "am12346",
          "type": "software_update",
          "date": "2025-03-10T15:00:00Z",
          "technician": "John Doe",
          "notes": "Windows updates and security patches"
        }
      ],
      "attachments": [
        {
          "id": "att12345",
          "name": "Invoice",
          "file_url": "/storage/attachments/a12345/invoice.pdf",
          "uploaded_at": "2025-01-20T10:00:00Z"
        },
        {
          "id": "att12346",
          "name": "Warranty",
          "file_url": "/storage/attachments/a12345/warranty.pdf",
          "uploaded_at": "2025-01-20T10:00:00Z"
        }
      ],
      "notes": "Primary reception computer",
      "created_at": "2025-01-20T10:00:00Z",
      "updated_at": "2025-03-10T15:00:00Z"
    }
  }
}
```

#### Create Asset

```
POST /inventory/assets
```

**Request Body:**

```json
{
  "name": "Samsung Smart TV",
  "category": "tv",
  "serial_number": "SMSNG987654",
  "asset_tag": "IT-TV-015",
  "manufacturer": "Samsung",
  "model": "QN90B",
  "purchase_date": "2025-03-20",
  "purchase_cost": 2500.0,
  "warranty_expiry": "2028-03-20",
  "specifications": {
    "size": "65 inch",
    "resolution": "4K",
    "smart_features": true
  },
  "location": {
    "floor_plan_id": "fp12345",
    "area": "Bar Area"
  },
  "notes": "Main bar display"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "asset": {
      "id": "a12346",
      "name": "Samsung Smart TV",
      // Other asset details...
      "created_at": "2025-03-26T16:30:00Z",
      "updated_at": "2025-03-26T16:30:00Z"
    }
  }
}
```

#### Update Asset Status

```
PUT /inventory/assets/{asset_id}/status
```

**Request Body:**

```json
{
  "status": "deployed",
  "location": {
    "floor_plan_id": "fp12345",
    "area": "Bar Area",
    "position": {
      "x": 800,
      "y": 350
    }
  },
  "notes": "Installed and configured"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "asset": {
      "id": "a12346",
      "status": "deployed",
      "location": {
        "floor_plan_id": "fp12345",
        "area": "Bar Area",
        "position": {
          "x": 800,
          "y": 350
        }
      },
      "updated_at": "2025-03-26T17:00:00Z"
    }
  }
}
```

### Inventory Items

#### List Inventory Items

```
GET /inventory/items
```

**Query Parameters:**

| Parameter | Type   | Description                                      |
|-----------|--------|--------------------------------------------------|
| page      | int    | Page number (default: 1)                         |
| limit     | int    | Number of results per page (default: 20, max: 100) |
| category  | string | Filter by item category                          |
| search    | string | Search term for name                             |

**Response:**

```json
{
  "status": "success",
  "data": {
    "items": [
      {
        "id": "i12345",
        "name": "HDMI Cable 2m",
        "category": "cables",
        "sku": "CBL-HDMI-2M",
        "total_quantity": 50,
        "available_quantity": 32,
        "deployed_quantity": 18,
        "reorder_threshold": 10,
        "created_at": "2025-01-10T09:00:00Z",
        "updated_at": "2025-03-15T11:30:00Z"
      },
      // More items...
    ],
    "pagination": {
      "total": 120,
      "page": 1,
      "limit": 20,
      "pages": 6
    }
  }
}
```

#### Get Inventory Item Details

```
GET /inventory/items/{item_id}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "item": {
      "id": "i12345",
      "name": "HDMI Cable 2m",
      "category": "cables",
      "sku": "CBL-HDMI-2M",
      "description": "High-speed HDMI cable, 2 meters length",
      "manufacturer": "Generic",
      "total_quantity": 50,
      "available_quantity": 32,
      "deployed_quantity": 18,
      "reorder_threshold": 10,
      "unit_cost": 15.0,
      "locations": [
        {
          "location_name": "Main Storage",
          "quantity": 30
        },
        {
          "location_name": "IT Office",
          "quantity": 2
        }
      ],
      "deployments": [
        {
          "asset_id": "a12345",
          "asset_name": "Dell OptiPlex 7090",
          "quantity": 1,
          "date": "2025-01-25T10:00:00Z"
        },
        // More deployments...
      ],
      "transactions": [
        {
          "id": "it12345",
          "type": "purchase",
          "quantity": 50,
          "date": "2025-01-10T09:00:00Z",
          "notes": "Initial stock purchase"
        },
        {
          "id": "it12346",
          "type": "deployment",
          "quantity": 1,
          "date": "2025-01-25T10:00:00Z",
          "notes": "Deployed to Reception PC"
        }
      ],
      "created_at": "2025-01-10T09:00:00Z",
      "updated_at": "2025-03-15T11:30:00Z"
    }
  }
}
```

#### Create Inventory Item

```
POST /inventory/items
```

**Request Body:**

```json
{
  "name": "DisplayPort Cable 2m",
  "category": "cables",
  "sku": "CBL-DP-2M",
  "description": "DisplayPort 1.4 cable, 2 meters length",
  "manufacturer": "Generic",
  "total_quantity": 25,
  "reorder_threshold": 5,
  "unit_cost": 20.0,
  "locations": [
    {
      "location_name": "Main Storage",
      "quantity": 25
    }
  ],
  "notes": "For connecting high-resolution displays"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "item": {
      "id": "i12346",
      "name": "DisplayPort Cable 2m",
      // Other item details...
      "created_at": "2025-03-26T17:30:00Z",
      "updated_at": "2025-03-26T17:30:00Z"
    }
  }
}
```

#### Update Inventory Quantity

```
PUT /inventory/items/{item_id}/quantity
```

**Request Body:**

```json
{
  "transaction_type": "purchase",
  "quantity": 10,
  "location_name": "Main Storage",
  "notes": "Restocking"
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "item": {
      "id": "i12346",
      "total_quantity": 35,
      "available_quantity": 35,
      "locations": [
        {
          "location_name": "Main Storage",
          "quantity": 35
        }
      ],
      "transactions": [
        // Previous transactions...
        {
          "id": "it12347",
          "type": "purchase",
          "quantity": 10,
          "date": "2025-03-26T17:45:00Z",
          "notes": "Restocking"
        }
      ],
      "updated_at": "2025-03-26T17:45:00Z"
    }
  }
}
```

## Ticket System API

### Tickets

#### List Tickets

```
GET /tickets
```

**Query Parameters:**

| Parameter | Type   | Description                                      |
|-----------|--------|--------------------------------------------------|
| page      | int    | Page number (default: 1)                         |
| limit     | int    | Number of results per page (default: 20, max: 100) |
| status    | string | Filter by status ("open", "in_progress", "resolved", "closed") |
| priority  | string | Filter by priority ("low", "medium", "high", "critical") |
| category  | string | Filter by category                               |
| department | string | Filter by department                            |
| assigned_to | string | Filter by assigned user ID                     |
| search    | string | Search term for title or description             |

**Response:**

```json
{
  "status": "success",
  "data": {
    "tickets": [
      {
        "id": "t12345",
        "title": "Slot machine display not working",
        "status": "in_progress",
        "priority": "high",
        "category": "hardware",
        "department": "technical",
        "created_by": {
          "id": "e12345",
          "name": "Jane Smith"
        },
        "assigned_to": {
          "id": "e12346",
          "name": "John Doe"
        },
        "location": {
          "floor_plan_id": "fp12345",
          "area": "Slot Area"
        },
        "created_at": "2025-03-25T15:30:00Z",
        "updated_at": "2025-03-25T16:00:00Z"
      },
      // More tickets...
    ],
    "pagination": {
      "total": 85,
      "page": 1,
      "limit": 20,
      "pages": 5
    }
  }
}
```

#### Get Ticket Details

```
GET /tickets/{ticket_id}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "ticket": {
      "id": "t12345",
      "title": "Slot machine display not working",
      "description": "The main display on slot machine S075 is showing distorted images and occasionally goes blank.",
      "status": "in_progress",
      "priority": "high",
      "category": "hardware",
      "department": "technical",
      "created_by": {
        "id": "e12345",
        "name": "Jane Smith",
        "department": "slot_operations",
        "email": "jane.smith@alpinroyal.com"
      },
      "assigned_to": {
        "id": "e12346",
        "name": "John Doe",
        "department": "technical",
        "email": "john.doe@alpinroyal.com"
      },
      "location": {
        "floor_plan_id": "fp12345",
        "floor_plan_name": "Main Casino Floor",
        "area": "Slot Area",
        "position": {
          "x": 550,
          "y": 420
        }
      },
      "related_asset": {
        "id": "a12347",
        "name": "Slot Machine S075",
        "asset_tag": "SM-075"
      },
      "due_date": "2025-03-26T17:00:00Z",
      "comments": [
        {
          "id": "tc12345",
          "user": {
            "id": "e12346",
            "name": "John Doe"
          },
          "content": "Inspected the machine. The display cable appears to be loose. Will replace it.",
          "internal": false,
          "created_at": "2025-03-25T16:30:00Z"
        },
        {
          "id": "tc12346",
          "user": {
            "id": "e12346",
            "name": "John Doe"
          },
          "content": "Ordered replacement cable from inventory.",
          "internal": true,
          "created_at": "2025-03-25T16:35:00Z"
        }
      ],
      "attachments": [
        {
          "id": "ta12345",
          "name": "Issue Photo",
          "file_url": "/storage/attachments/t12345/issue_photo.jpg",
          "uploaded_by": "e12345",
          "uploaded_at": "2025-03-25T15:30:00Z"
        }
      ],
      "history": [
        {
          "action": "created",
          "user": {
            "id": "e12345",
            "name": "Jane Smith"
          },
          "timestamp": "2025-03-25T15:30:00Z"
        },
        {
          "action": "assigned",
          "user": {
            "id": "e12350",
            "name": "Robert Johnson"
          },
          "assigned_to": {
            "id": "e12346",
            "name": "John Doe"
          },
          "timestamp": "2025-03-25T15:45:00Z"
        },
        {
          "action": "status_changed",
          "user": {
            "id": "e12346",
            "name": "John Doe"
          },
          "from_status": "open",
          "to_status": "in_progress",
          "timestamp": "2025-03-25T16:00:00Z"
        }
      ],
      "created_at": "2025-03-25T15:30:00Z",
      "updated_at": "2025-03-25T16:35:00Z"
    }
  }
}
```

#### Create Ticket

```
POST /tickets
```

**Request Body:**

```json
{
  "title": "Surveillance camera offline",
  "description": "The surveillance camera in the VIP area (Cam-105) is not responding to commands and shows offline in the monitoring system.",
  "priority": "high",
  "category": "hardware",
  "department": "technical",
  "location": {
    "floor_plan_id": "fp12346",
    "area": "VIP Area",
    "position": {
      "x": 300,
      "y": 250
    }
  },
  "related_asset_id": "d12355",
  "due_date": "2025-03-27T12:00:00Z",
  "attachments": []
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "ticket": {
      "id": "t12346",
      "title": "Surveillance camera offline",
      // Other ticket details...
      "status": "open",
      "created_by": {
        "id": "e12345",
        "name": "Jane Smith"
      },
      "created_at": "2025-03-26T18:00:00Z",
      "updated_at": "2025-03-26T18:00:00Z"
    }
  }
}
```

#### Update Ticket Status

```
PUT /tickets/{ticket_id}/status
```

**Request Body:**

```json
{
  "status": "resolved",
  "comment": "Replaced the display cable and tested the machine. Display is now working correctly."
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "ticket": {
      "id": "t12345",
      "status": "resolved",
      "comments": [
        // Previous comments...
        {
          "id": "tc12347",
          "user": {
            "id": "e12346",
            "name": "John Doe"
          },
          "content": "Replaced the display cable and tested the machine. Display is now working correctly.",
          "internal": false,
          "created_at": "2025-03-26T16:00:00Z"
        }
      ],
      "history": [
        // Previous history...
        {
          "action": "status_changed",
          "user": {
            "id": "e12346",
            "name": "John Doe"
          },
          "from_status": "in_progress",
          "to_status": "resolved",
          "timestamp": "2025-03-26T16:00:00Z"
        }
      ],
      "updated_at": "2025-03-26T16:00:00Z"
    }
  }
}
```

#### Assign Ticket

```
PUT /tickets/{ticket_id}/assign
```

**Request Body:**

```json
{
  "assigned_to": "e12347",
  "comment": "Assigning to network specialist to check camera connectivity issues."
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "ticket": {
      "id": "t12346",
      "assigned_to": {
        "id": "e12347",
        "name": "Sarah Williams"
      },
      "comments": [
        {
          "id": "tc12348",
          "user": {
            "id": "e12346",
            "name": "John Doe"
          },
          "content": "Assigning to network specialist to check camera connectivity issues.",
          "internal": true,
          "created_at": "2025-03-26T18:15:00Z"
        }
      ],
      "history": [
        // Previous history...
        {
          "action": "assigned",
          "user": {
            "id": "e12346",
            "name": "John Doe"
          },
          "assigned_to": {
            "id": "e12347",
            "name": "Sarah Williams"
          },
          "timestamp": "2025-03-26T18:15:00Z"
        }
      ],
      "updated_at": "2025-03-26T18:15:00Z"
    }
  }
}
```

#### Add Comment to Ticket

```
POST /tickets/{ticket_id}/comments
```

**Request Body:**

```json
{
  "content": "Checked the network switch and found that the port is disabled. Enabling the port and monitoring.",
  "internal": false,
  "attachments": []
}
```

**Response:**

```json
{
  "status": "success",
  "data": {
    "comment": {
      "id": "tc12349",
      "user": {
        "id": "e12347",
        "name": "Sarah Williams"
      },
      "content": "Checked the network switch and found that the port is disabled. Enabling the port and monitoring.",
      "internal": false,
      "created_at": "2025-03-26T18:30:00Z"
    }
  }
}
```

#### Upload Attachment to Ticket

```
POST /tickets/{ticket_id}/attachments
```

**Request Body (multipart/form-data):**

| Parameter | Type   | Description                                |
|-----------|--------|--------------------------------------------|
| name      | string | Name of the attachment                     |
| file      | file   | The file to upload                         |
| comment   | string | Optional comment about the attachment      |

**Response:**

```json
{
  "status": "success",
  "data": {
    "attachment": {
      "id": "ta12346",
      "name": "Network Logs",
      "file_url": "/storage/attachments/t12346/network_logs.txt",
      "uploaded_by": "e12347",
      "uploaded_at": "2025-03-26T18:45:00Z"
    }
  }
}
```

## Error Codes

| Code               | Description                                      |
|--------------------|--------------------------------------------------|
| UNAUTHORIZED       | Authentication required or token invalid         |
| FORBIDDEN          | User does not have permission for this action    |
| NOT_FOUND          | Requested resource not found                     |
| VALIDATION_ERROR   | Request validation failed                        |
| INTERNAL_ERROR     | Internal server error                            |
| DUPLICATE_ENTRY    | Resource already exists                          |
| INVALID_STATUS     | Invalid status transition                        |
| RESOURCE_LOCKED    | Resource is locked by another operation          |

## Rate Limiting

The API implements rate limiting to prevent abuse. The current limits are:

- 100 requests per minute per user
- 1000 requests per hour per user

When a rate limit is exceeded, the API will respond with a 429 Too Many Requests status code.

## Versioning

The API uses URL versioning (e.g., `/api/v1/`). When breaking changes are introduced, a new version will be released.

## Changelog

### v1.0.0 (2025-03-01)
- Initial release of the Alpin Royal Casino Management System API

### v1.0.1 (2025-03-15)
- Added cigarette inventory endpoints
- Improved search functionality
- Fixed bugs in ticket assignment

## Support

For API support, please contact:

- Email: api-support@alpinroyal.com
- Phone: +41 123 456 789

## License

This API and its documentation are proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

© 2025 Alpin Royal. All rights reserved.
