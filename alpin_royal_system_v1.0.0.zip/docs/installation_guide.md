# Alpin Royal Casino Management System - Installation and Setup Guide

This guide provides step-by-step instructions for setting up and running the Alpin Royal Casino Management System.

## System Requirements

### Hardware Requirements
- **CPU**: 4+ cores recommended
- **RAM**: 8GB minimum, 16GB+ recommended
- **Storage**: 50GB+ of free disk space
- **Network**: Stable internet connection

### Software Requirements
- **Operating System**: Ubuntu 22.04 LTS or later
- **Docker**: 20.10.x or later
- **Docker Compose**: 2.x or later
- **Git**: 2.x or later

## Installation Steps

### 1. Install Required Software

First, ensure your system is up to date:

```bash
sudo apt update
sudo apt upgrade -y
```

Install Docker and Docker Compose:

```bash
# Install Docker
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.15.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Add your user to the docker group to run docker without sudo
sudo usermod -aG docker $USER
```

Install Git:

```bash
sudo apt install -y git
```

### 2. Clone the Repository

```bash
git clone https://github.com/your-organization/alpin-royal-system.git
cd alpin-royal-system
```

### 3. Configure Environment Variables

Create a `.env` file in the root directory:

```bash
cp .env.example .env
```

Edit the `.env` file to configure your environment variables:

```bash
# Database configurations
POSTGRES_USER=alpin_royal
POSTGRES_PASSWORD=your_secure_password
POSTGRES_DB=alpin_royal_db
POSTGRES_HOST=postgres
POSTGRES_PORT=5432

# MongoDB configurations
MONGO_INITDB_ROOT_USERNAME=alpin_royal
MONGO_INITDB_ROOT_PASSWORD=your_secure_password
MONGO_DB=alpin_royal_db
MONGO_HOST=mongodb
MONGO_PORT=27017

# Redis configurations
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=your_secure_password

# Elasticsearch configurations
ELASTIC_HOST=elasticsearch
ELASTIC_PORT=9200
ELASTIC_USERNAME=elastic
ELASTIC_PASSWORD=your_secure_password

# MinIO configurations
MINIO_ROOT_USER=alpin_royal
MINIO_ROOT_PASSWORD=your_secure_password
MINIO_HOST=minio
MINIO_PORT=9000

# JWT Secret
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRATION=86400

# Application configurations
APP_PORT=8000
APP_ENV=production
APP_DEBUG=false
APP_URL=http://localhost:8000
```

### 4. Build and Start the Services

```bash
# Build the Docker images
docker-compose build

# Start the services
docker-compose up -d
```

### 5. Initialize the Database

```bash
# Run database migrations
docker-compose exec app python -m scripts.database.init_db

# Load test data (optional)
docker-compose exec app python -m scripts.test_data.load_test_data
```

### 6. Access the Application

Once all services are up and running, you can access the application at:

- **Web Interface**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs

Default admin credentials:
- **Username**: admin
- **Password**: admin123

**Important**: Change the default admin password immediately after the first login.

## Module Configuration

### Player Tracking Module

The Player Tracking module is enabled by default. No additional configuration is required.

### Network Design Module

To enable the Network Design module:

1. Access the admin panel at http://localhost:8000/admin
2. Navigate to "Module Management"
3. Enable the "Network Design" module

### Inventory Management Module

To enable the Inventory Management module:

1. Access the admin panel at http://localhost:8000/admin
2. Navigate to "Module Management"
3. Enable the "Inventory Management" module

### Ticket System Module

To enable the Ticket System module:

1. Access the admin panel at http://localhost:8000/admin
2. Navigate to "Module Management"
3. Enable the "Ticket System" module

## Backup and Restore

### Creating a Backup

```bash
# Backup PostgreSQL database
docker-compose exec postgres pg_dump -U alpin_royal alpin_royal_db > backup_postgres_$(date +%Y%m%d).sql

# Backup MongoDB database
docker-compose exec mongodb mongodump --username alpin_royal --password your_secure_password --db alpin_royal_db --out /backup
docker cp $(docker-compose ps -q mongodb):/backup ./backup_mongo_$(date +%Y%m%d)

# Backup MinIO data
docker-compose exec minio mc cp --recursive /data backup/
```

### Restoring from a Backup

```bash
# Restore PostgreSQL database
cat backup_postgres_YYYYMMDD.sql | docker-compose exec -T postgres psql -U alpin_royal alpin_royal_db

# Restore MongoDB database
docker cp ./backup_mongo_YYYYMMDD $(docker-compose ps -q mongodb):/backup
docker-compose exec mongodb mongorestore --username alpin_royal --password your_secure_password --db alpin_royal_db /backup/alpin_royal_db

# Restore MinIO data
docker-compose exec minio mc cp --recursive backup/ /data/
```

## Troubleshooting

### Common Issues

#### Services Not Starting

If some services fail to start, check the logs:

```bash
docker-compose logs [service_name]
```

#### Database Connection Issues

Ensure the database credentials in the `.env` file are correct:

```bash
docker-compose logs postgres
docker-compose logs mongodb
```

#### Permission Issues

If you encounter permission issues, ensure your user is in the docker group:

```bash
sudo usermod -aG docker $USER
newgrp docker
```

#### Port Conflicts

If there are port conflicts, modify the exposed ports in the `docker-compose.yml` file.

### Getting Help

If you encounter any issues not covered in this guide, please:

1. Check the detailed logs: `docker-compose logs`
2. Refer to the documentation in the `docs` directory
3. Contact support at support@alpinroyal.com

## Updating the System

To update the system to the latest version:

```bash
# Pull the latest changes
git pull

# Rebuild the Docker images
docker-compose build

# Restart the services
docker-compose down
docker-compose up -d

# Run database migrations if needed
docker-compose exec app python -m scripts.database.migrate
```

## Security Considerations

- Change all default passwords immediately
- Regularly update the system with security patches
- Set up a firewall to restrict access to the application
- Use HTTPS in production environments
- Implement regular backups
- Monitor system logs for suspicious activities

## Production Deployment

For production deployment, additional steps are recommended:

1. Set up HTTPS using a reverse proxy (Nginx or Traefik)
2. Configure proper monitoring and alerting
3. Set up automated backups
4. Implement high availability for critical services
5. Use a dedicated database server with proper replication

## License

This software is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

© 2025 Alpin Royal. All rights reserved.
