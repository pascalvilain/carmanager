import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Grid, 
  Button, 
  TextField, 
  Select, 
  MenuItem, 
  FormControl, 
  InputLabel,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  Tooltip,
  CircularProgress,
  Snackbar,
  Alert,
  Card,
  CardContent,
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Autocomplete
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Upload as UploadIcon,
  Download as DownloadIcon,
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Inventory as InventoryIcon,
  Category as CategoryIcon,
  LocalShipping as ShippingIcon,
  LocationOn as LocationIcon,
  Label as TagIcon,
  History as HistoryIcon,
  Assessment as ReportIcon,
  Dashboard as DashboardIcon,
  PhotoCamera as CameraIcon,
  ZoomIn as ZoomInIcon,
  ZoomOut as ZoomOutIcon,
  PanTool as PanIcon,
  Computer as ComputerIcon,
  Router as RouterIcon,
  Videocam as CameraDeviceIcon,
  Storage as ServerIcon,
  Tv as TvIcon,
  Casino as GamingIcon,
  ConfirmationNumber as TicketIcon
} from '@mui/icons-material';
import { Stage, Layer, Image, Rect, Group, Text, Transformer } from 'react-konva';

// Inventory Dashboard Component
export const InventoryDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch dashboard data from API
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        // In a real implementation, this would be an API call
        // const response = await fetch('/api/inventory/dashboard');
        // const data = await response.json();
        
        // Mock data for demonstration
        const mockData = {
          total_items: 1245,
          items_by_category: {
            NETWORK: 320,
            COMPUTER: 180,
            PERIPHERAL: 95,
            GAMING: 350,
            SURVEILLANCE: 120,
            FURNITURE: 80,
            OFFICE: 60,
            CONSUMABLE: 40
          },
          items_by_status: {
            AVAILABLE: 320,
            DEPLOYED: 850,
            MAINTENANCE: 35,
            RESERVED: 15,
            DAMAGED: 20,
            RETIRED: 5
          },
          items_by_location: {
            "Main Casino Floor": 450,
            "Server Room": 120,
            "Security Office": 85,
            "Storage Room": 210,
            "Administrative Office": 75,
            "Gaming Pit": 305
          },
          recent_transactions: [
            {
              transaction_id: 1,
              item_name: "Gaming Server #3",
              transaction_type: "DEPLOYMENT",
              source_location: "Storage Room",
              destination_location: "Server Room",
              timestamp: "2025-03-25T14:32:15"
            },
            {
              transaction_id: 2,
              item_name: "Surveillance Camera PTZ-12",
              transaction_type: "MAINTENANCE",
              source_location: "Main Casino Floor",
              destination_location: "Security Office",
              timestamp: "2025-03-25T11:15:42"
            },
            {
              transaction_id: 3,
              item_name: "Slot Machine #145",
              transaction_type: "DEPLOYMENT",
              source_location: "Storage Room",
              destination_location: "Gaming Pit",
              timestamp: "2025-03-24T16:45:30"
            }
          ],
          value_by_category: {
            NETWORK: 125000,
            COMPUTER: 85000,
            PERIPHERAL: 15000,
            GAMING: 750000,
            SURVEILLANCE: 95000,
            FURNITURE: 45000,
            OFFICE: 25000,
            CONSUMABLE: 5000
          },
          expiring_warranties: [
            {
              item_id: 1,
              name: "Core Switch",
              warranty_expiry: "2025-04-15T00:00:00",
              days_remaining: 20
            },
            {
              item_id: 2,
              name: "Gaming Server #2",
              warranty_expiry: "2025-04-22T00:00:00",
              days_remaining: 27
            },
            {
              item_id: 3,
              name: "Surveillance NVR",
              warranty_expiry: "2025-05-10T00:00:00",
              days_remaining: 45
            }
          ]
        };
        
        setDashboardData(mockData);
        setLoading(false);
      } catch (err) {
        setError('Failed to load dashboard data');
        setLoading(false);
        console.error(err);
      }
    };

    fetchDashboardData();
  }, []);

  // Helper function to get icon for category
  const getCategoryIcon = (category) => {
    switch (category) {
      case 'NETWORK':
        return <RouterIcon />;
      case 'COMPUTER':
        return <ComputerIcon />;
      case 'PERIPHERAL':
        return <DevicesIcon />;
      case 'GAMING':
        return <GamingIcon />;
      case 'SURVEILLANCE':
        return <CameraDeviceIcon />;
      case 'FURNITURE':
        return <ChairIcon />;
      case 'OFFICE':
        return <BusinessCenterIcon />;
      case 'CONSUMABLE':
        return <ShoppingCartIcon />;
      default:
        return <InventoryIcon />;
    }
  };

  // Helper function to format currency
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'CHF'
    }).format(value);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Inventory Management Dashboard
      </Typography>
      
      <Grid container spacing={3}>
        {/* Summary Cards */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="primary">Total Items</Typography>
              <Typography variant="h3">{dashboardData.total_items}</Typography>
              <Box sx={{ mt: 1, display: 'flex', alignItems: 'center' }}>
                <Chip 
                  label={`Deployed: ${dashboardData.items_by_status.DEPLOYED || 0}`} 
                  color="success" 
                  size="small" 
                  sx={{ mr: 1 }} 
                />
                <Chip 
                  label={`Available: ${dashboardData.items_by_status.AVAILABLE || 0}`} 
                  color="primary" 
                  size="small" 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="primary">Total Value</Typography>
              <Typography variant="h3">
                {formatCurrency(Object.values(dashboardData.value_by_category).reduce((a, b) => a + b, 0))}
              </Typography>
              <Box sx={{ mt: 1 }}>
                <Chip 
                  label={`Gaming: ${formatCurrency(dashboardData.value_by_category.GAMING || 0)}`} 
                  color="secondary" 
                  size="small" 
                  sx={{ mr: 1 }} 
                />
                <Chip 
                  label={`Network: ${formatCurrency(dashboardData.value_by_category.NETWORK || 0)}`} 
                  color="info" 
                  size="small" 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="primary">Expiring Warranties</Typography>
              <List dense>
                {dashboardData.expiring_warranties.map((item) => (
                  <ListItem key={item.item_id}>
                    <ListItemIcon>
                      <WarningIcon color={item.days_remaining < 30 ? "error" : "warning"} />
                    </ListItemIcon>
                    <ListItemText 
                      primary={item.name} 
                      secondary={`Expires: ${new Date(item.warranty_expiry).toLocaleDateString()} (${item.days_remaining} days)`} 
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Recent Transactions */}
        <Grid item xs={12}>
          <Card>
            <CardHeader title="Recent Transactions" />
            <CardContent>
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Item</TableCell>
                      <TableCell>Transaction Type</TableCell>
                      <TableCell>Source</TableCell>
                      <TableCell>Destination</TableCell>
                      <TableCell>Date & Time</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {dashboardData.recent_transactions.map((transaction) => (
                      <TableRow key={transaction.transaction_id}>
                        <TableCell>{transaction.item_name}</TableCell>
                        <TableCell>
                          <Chip 
                            label={transaction.transaction_type} 
                            color={
                              transaction.transaction_type === "DEPLOYMENT" ? "success" :
                              transaction.transaction_type === "MAINTENANCE" ? "warning" :
                              transaction.transaction_type === "RETURN" ? "info" :
                              "default"
                            } 
                            size="small" 
                          />
                        </TableCell>
                        <TableCell>{transaction.source_location || "—"}</TableCell>
                        <TableCell>{transaction.destination_location || "—"}</TableCell>
                        <TableCell>{new Date(transaction.timestamp).toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Item Distribution by Category */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title="Items by Category" />
            <CardContent>
              <Box sx={{ height: 300, overflowY: 'auto' }}>
                {Object.entries(dashboardData.items_by_category).map(([category, count]) => (
                  <Box key={category} sx={{ mb: 1, display: 'flex', alignItems: 'center' }}>
                    <Box sx={{ mr: 2, width: 30 }}>{getCategoryIcon(category)}</Box>
                    <Box sx={{ flexGrow: 1 }}>
                      <Typography variant="body2">{category}</Typography>
                      <Box sx={{ width: '100%', bgcolor: 'background.paper', borderRadius: 1 }}>
                        <Box 
                          sx={{ 
                            height: 10, 
                            bgcolor: 'primary.main', 
                            borderRadius: 1,
                            width: `${(count / dashboardData.total_items) * 100}%`
                          }} 
                        />
                      </Box>
                    </Box>
                    <Typography variant="body2" sx={{ ml: 2, minWidth: 30 }}>{count}</Typography>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Item Distribution by Location */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title="Items by Location" />
            <CardContent>
              <Box sx={{ height: 300, overflowY: 'auto' }}>
                {Object.entries(dashboardData.items_by_location).map(([location, count]) => (
                  <Box key={location} sx={{ mb: 1 }}>
                    <Typography variant="body2">{location}</Typography>
                    <Box sx={{ width: '100%', bgcolor: 'background.paper', borderRadius: 1 }}>
                      <Box 
                        sx={{ 
                          height: 10, 
                          bgcolor: 'secondary.main', 
                          borderRadius: 1,
                          width: `${(count / dashboardData.total_items) * 100}%`
                        }} 
                      />
                    </Box>
                    <Typography variant="body2" align="right">{count}</Typography>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Action Buttons */}
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
            <Button 
              variant="contained" 
              startIcon={<AddIcon />} 
              sx={{ mr: 1 }}
              onClick={() => window.location.href = '/inventory/items/new'}
            >
              New Item
            </Button>
            <Button 
              variant="outlined" 
              startIcon={<SearchIcon />}
              sx={{ mr: 1 }}
              onClick={() => window.location.href = '/inventory/items/search'}
            >
              Search Items
            </Button>
            <Button 
              variant="outlined" 
              startIcon={<ReportIcon />}
              onClick={() => window.location.href = '/inventory/reports'}
            >
              Generate Report
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

// Inventory Item List Component
export const InventoryItemList = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [searchParams, setSearchParams] = useState({
    name: '',
    category: '',
    status: '',
    location_id: null
  });
  const [locations, setLocations] = useState([]);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });

  useEffect(() => {
    // Fetch inventory items from API
    const fetchItems = async () => {
      try {
        setLoading(true);
        // In a real implementation, this would be an API call
        // const response = await fetch('/api/inventory/items');
        // const data = await response.json();
        
        // Mock data for demonstration
        const mockItems = Array.from({ length: 50 }, (_, i) => ({
          item_id: i + 1,
          name: `Item ${i + 1}`,
          category: ['NETWORK', 'COMPUTER', 'PERIPHERAL', 'GAMING', 'SURVEILLANCE', 'FURNITURE', 'OFFICE', 'CONSUMABLE'][Math.floor(Math.random() * 8)],
          status: ['AVAILABLE', 'DEPLOYED', 'MAINTENANCE', 'RESERVED', 'DAMAGED', 'RETIRED'][Math.floor(Math.random() * 6)],
          manufacturer: `Manufacturer ${Math.floor(i / 10) + 1}`,
          model: `Model ${String.fromCharCode(65 + Math.floor(i / 5))}-${i % 5 + 1}`,
          serial_number: `SN-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
          asset_tag: `AT-${(i + 1).toString().padStart(4, '0')}`,
          purchase_date: new Date(2023, Math.floor(i / 10), (i % 28) + 1).toISOString(),
          purchase_price: Math.floor(Math.random() * 10000) + 100,
          location: {
            location_id: Math.floor(i / 8) + 1,
            name: [`Main Casino Floor`, `Server Room`, `Security Office`, `Storage Room`, `Administrative Office`, `Gaming Pit`][Math.floor(i / 8) % 6]
          }
        }));
        
        // Mock locations
        const mockLocations = [
          { location_id: 1, name: 'Main Casino Floor' },
          { location_id: 2, name: 'Server Room' },
          { location_id: 3, name: 'Security Office' },
          { location_id: 4, name: 'Storage Room' },
          { location_id: 5, name: 'Administrative Office' },
          { location_id: 6, name: 'Gaming Pit' }
        ];
        
        setItems(mockItems);
        setLocations(mockLocations);
        setLoading(false);
      } catch (err) {
        setError('Failed to load inventory items');
        setLoading(false);
        console.error(err);
      }
    };

    fetchItems();
  }, []);

  // Handle page change
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  // Handle rows per page change
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Handle search
  const handleSearch = () => {
    // In a real implementation, this would be an API call with search parameters
    setShowSearchDialog(false);
    
    // Mock search implementation
    setLoading(true);
    setTimeout(() => {
      const filteredItems = items.filter(item => {
        let matches = true;
        
        if (searchParams.name && !item.name.toLowerCase().includes(searchParams.name.toLowerCase())) {
          matches = false;
        }
        
        if (searchParams.category && item.category !== searchParams.category) {
          matches = false;
        }
        
        if (searchParams.status && item.status !== searchParams.status) {
          matches = false;
        }
        
        if (searchParams.location_id && item.location.location_id !== searchParams.location_id) {
          matches = false;
        }
        
        return matches;
      });
      
      setItems(filteredItems);
      setLoading(false);
      
      setNotification({
        open: true,
        message: `Found ${filteredItems.length} items matching your criteria`,
        severity: 'info'
      });
    }, 500);
  };

  // Handle reset search
  const handleResetSearch = () => {
    setSearchParams({
      name: '',
      category: '',
      status: '',
      location_id: null
    });
    
    // Reload all items
    setLoading(true);
    // In a real implementation, this would be an API call
    setTimeout(() => {
      // Reload mock data
      const mockItems = Array.from({ length: 50 }, (_, i) => ({
        item_id: i + 1,
        name: `Item ${i + 1}`,
        category: ['NETWORK', 'COMPUTER', 'PERIPHERAL', 'GAMING', 'SURVEILLANCE', 'FURNITURE', 'OFFICE', 'CONSUMABLE'][Math.floor(Math.random() * 8)],
        status: ['AVAILABLE', 'DEPLOYED', 'MAINTENANCE', 'RESERVED', 'DAMAGED', 'RETIRED'][Math.floor(Math.random() * 6)],
        manufacturer: `Manufacturer ${Math.floor(i / 10) + 1}`,
        model: `Model ${String.fromCharCode(65 + Math.floor(i / 5))}-${i % 5 + 1}`,
        serial_number: `SN-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
        asset_tag: `AT-${(i + 1).toString().padStart(4, '0')}`,
        purchase_date: new Date(2023, Math.floor(i / 10), (i % 28) + 1).toISOString(),
        purchase_price: Math.floor(Math.random() * 10000) + 100,
        location: {
          location_id: Math.floor(i / 8) + 1,
          name: [`Main Casino Floor`, `Server Room`, `Security Office`, `Storage Room`, `Administrative Office`, `Gaming Pit`][Math.floor(i / 8) % 6]
        }
      }));
      
      setItems(mockItems);
      setLoading(false);
      setShowSearchDialog(false);
      
      setNotification({
        open: true,
        message: 'Search reset, showing all items',
        severity: 'info'
      });
    }, 500);
  };

  // Format currency
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'CHF'
    }).format(value);
  };

  // Get status color
  const getStatusColor = (status) => {
    switch (status) {
      case 'AVAILABLE':
        return 'success';
      case 'DEPLOYED':
        return 'primary';
      case 'MAINTENANCE':
        return 'warning';
      case 'RESERVED':
        return 'info';
      case 'DAMAGED':
        return 'error';
      case 'RETIRED':
        return 'default';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4">Inventory Items</Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<SearchIcon />} 
            sx={{ mr: 1 }}
            onClick={() => setShowSearchDialog(true)}
          >
            Search
          </Button>
          <Button 
            variant="contained" 
            startIcon={<AddIcon />}
            onClick={() => window.location.href = '/inventory/items/new'}
          >
            Add Item
          </Button>
        </Box>
      </Box>
      
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Asset Tag</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Location</TableCell>
              <TableCell>Manufacturer</TableCell>
              <TableCell>Model</TableCell>
              <TableCell>Purchase Date</TableCell>
              <TableCell>Value</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((item) => (
                <TableRow key={item.item_id}>
                  <TableCell>{item.asset_tag}</TableCell>
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.category}</TableCell>
                  <TableCell>
                    <Chip 
                      label={item.status} 
                      color={getStatusColor(item.status)} 
                      size="small" 
                    />
                  </TableCell>
                  <TableCell>{item.location?.name || '—'}</TableCell>
                  <TableCell>{item.manufacturer}</TableCell>
                  <TableCell>{item.model}</TableCell>
                  <TableCell>{new Date(item.purchase_date).toLocaleDateString()}</TableCell>
                  <TableCell>{formatCurrency(item.purchase_price)}</TableCell>
                  <TableCell>
                    <IconButton 
                      size="small" 
                      onClick={() => window.location.href = `/inventory/items/${item.item_id}`}
                    >
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton 
                      size="small" 
                      color="error"
                      onClick={() => {
                        setNotification({
                          open: true,
                          message: `Item ${item.name} deleted successfully`,
                          severity: 'success'
                        });
                      }}
                    >
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={items.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </TableContainer>
      
      {/* Search Dialog */}
      <Dialog open={showSearchDialog} onClose={() => setShowSearchDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Search Inventory Items</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                label="Item Name"
                fullWidth
                value={searchParams.name}
                onChange={(e) => setSearchParams({ ...searchParams, name: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Category</InputLabel>
                <Select
                  value={searchParams.category}
                  label="Category"
                  onChange={(e) => setSearchParams({ ...searchParams, category: e.target.value })}
                >
                  <MenuItem value="">All Categories</MenuItem>
                  <MenuItem value="NETWORK">Network</MenuItem>
                  <MenuItem value="COMPUTER">Computer</MenuItem>
                  <MenuItem value="PERIPHERAL">Peripheral</MenuItem>
                  <MenuItem value="GAMING">Gaming</MenuItem>
                  <MenuItem value="SURVEILLANCE">Surveillance</MenuItem>
                  <MenuItem value="FURNITURE">Furniture</MenuItem>
                  <MenuItem value="OFFICE">Office</MenuItem>
                  <MenuItem value="CONSUMABLE">Consumable</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select
                  value={searchParams.status}
                  label="Status"
                  onChange={(e) => setSearchParams({ ...searchParams, status: e.target.value })}
                >
                  <MenuItem value="">All Statuses</MenuItem>
                  <MenuItem value="AVAILABLE">Available</MenuItem>
                  <MenuItem value="DEPLOYED">Deployed</MenuItem>
                  <MenuItem value="MAINTENANCE">Maintenance</MenuItem>
                  <MenuItem value="RESERVED">Reserved</MenuItem>
                  <MenuItem value="DAMAGED">Damaged</MenuItem>
                  <MenuItem value="RETIRED">Retired</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <Autocomplete
                options={locations}
                getOptionLabel={(option) => option.name}
                value={locations.find(loc => loc.location_id === searchParams.location_id) || null}
                onChange={(e, newValue) => setSearchParams({ 
                  ...searchParams, 
                  location_id: newValue ? newValue.location_id : null 
                })}
                renderInput={(params) => <TextField {...params} label="Location" />}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleResetSearch}>Reset</Button>
          <Button onClick={() => setShowSearchDialog(false)}>Cancel</Button>
          <Button onClick={handleSearch} variant="contained" color="primary">
            Search
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Notification Snackbar */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={() => setNotification({ ...notification, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert 
          onClose={() => setNotification({ ...notification, open: false })} 
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

// Inventory Floor Plan View Component
export const InventoryFloorPlanView = () => {
  const [floorPlan, setFloorPlan] = useState(null);
  const [items, setItems] = useState([]);
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [selectedType, setSelectedType] = useState(null); // 'item' or 'location'
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [showItemDialog, setShowItemDialog] = useState(false);
  const [itemDetails, setItemDetails] = useState(null);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
  
  const stageRef = useRef(null);
  
  // Mock floor plan ID for demonstration
  const floorPlanId = 1;
  
  useEffect(() => {
    // Fetch floor plan data from API
    const fetchFloorPlanData = async () => {
      try {
        setLoading(true);
        // In a real implementation, these would be API calls
        // const floorPlanResponse = await fetch(`/api/network/floor-plans/${floorPlanId}`);
        // const itemsResponse = await fetch(`/api/inventory/items/floor-plan/${floorPlanId}`);
        // const locationsResponse = await fetch(`/api/inventory/locations/floor-plan/${floorPlanId}`);
        
        // const floorPlanData = await floorPlanResponse.json();
        // const itemsData = await itemsResponse.json();
        // const locationsData = await locationsResponse.json();
        
        // Mock data for demonstration
        const mockFloorPlan = {
          floor_plan_id: 1,
          name: "Main Casino Floor",
          description: "First floor of the main casino building",
          file_path: "/floor_plans/main_casino_floor.jpg",
          width: 1200,
          height: 800,
          scale: 0.1, // meters per pixel
          floor_number: 1,
          building: "Main Building"
        };
        
        const mockItems = [
          {
            item_id: 1,
            name: "Surveillance Camera 1",
            category: "SURVEILLANCE",
            status: "DEPLOYED",
            x_position: 200,
            y_position: 150,
            rotation: 45,
            manufacturer: "Axis",
            model: "P3375-V",
            serial_number: "SN-123456",
            asset_tag: "AT-0001",
            purchase_date: "2023-05-15T00:00:00",
            purchase_price: 850,
            properties: {
              resolution: "4K",
              ptz: true
            }
          },
          {
            item_id: 2,
            name: "Gaming Server",
            category: "COMPUTER",
            status: "DEPLOYED",
            x_position: 500,
            y_position: 300,
            rotation: 0,
            manufacturer: "Dell",
            model: "PowerEdge R740",
            serial_number: "SN-789012",
            asset_tag: "AT-0002",
            purchase_date: "2023-03-10T00:00:00",
            purchase_price: 12500,
            properties: {
              cpu: "Intel Xeon Gold 6248R",
              ram: "128GB",
              storage: "4TB SSD RAID"
            }
          },
          {
            item_id: 3,
            name: "Slot Machine #42",
            category: "GAMING",
            status: "DEPLOYED",
            x_position: 800,
            y_position: 200,
            rotation: 0,
            manufacturer: "IGT",
            model: "Crystal Dual",
            serial_number: "SN-345678",
            asset_tag: "AT-0003",
            purchase_date: "2023-01-20T00:00:00",
            purchase_price: 15000,
            properties: {
              game: "Buffalo Gold",
              denomination: "0.01"
            }
          }
        ];
        
        const mockLocations = [
          {
            location_id: 1,
            name: "Gaming Area A",
            description: "Main slot machine area",
            x_position: 300,
            y_position: 200,
            width: 400,
            height: 300
          },
          {
            location_id: 2,
            name: "Server Room",
            description: "Main IT infrastructure room",
            x_position: 900,
            y_position: 100,
            width: 200,
            height: 150
          }
        ];
        
        setFloorPlan(mockFloorPlan);
        setItems(mockItems);
        setLocations(mockLocations);
        setLoading(false);
      } catch (err) {
        setError('Failed to load floor plan data');
        setLoading(false);
        console.error(err);
      }
    };

    fetchFloorPlanData();
  }, [floorPlanId]);
  
  // Handle item selection
  const handleSelectItem = (itemId) => {
    setSelectedId(itemId);
    setSelectedType('item');
    
    // Find the item
    const item = items.find(i => i.item_id === itemId);
    if (item) {
      setItemDetails(item);
      setShowItemDialog(true);
    }
  };
  
  // Handle location selection
  const handleSelectLocation = (locationId) => {
    setSelectedId(locationId);
    setSelectedType('location');
  };
  
  // Handle stage click (background)
  const handleStageClick = (e) => {
    // If clicking on the background, deselect
    if (e.target === e.currentTarget) {
      setSelectedId(null);
      setSelectedType(null);
    }
  };
  
  // Handle zoom in
  const handleZoomIn = () => {
    setScale(scale * 1.2);
  };
  
  // Handle zoom out
  const handleZoomOut = () => {
    setScale(scale / 1.2);
  };
  
  // Get item component based on category
  const getItemComponent = (item) => {
    const { item_id, category, x_position, y_position, rotation, name } = item;
    
    // Base properties for all item types
    const baseProps = {
      x: x_position,
      y: y_position,
      rotation: rotation || 0,
      onClick: () => handleSelectItem(item_id),
      name: `item-${item_id}`,
      id: `item-${item_id}`
    };
    
    // Determine color based on category
    let fill = '#3f51b5'; // Default blue
    
    switch (category) {
      case 'NETWORK':
        fill = '#2196f3'; // Blue for network
        break;
      case 'COMPUTER':
        fill = '#4caf50'; // Green for computers
        break;
      case 'SURVEILLANCE':
        fill = '#f44336'; // Red for surveillance
        break;
      case 'GAMING':
        fill = '#ff9800'; // Orange for gaming
        break;
      case 'PERIPHERAL':
        fill = '#9c27b0'; // Purple for peripherals
        break;
      case 'FURNITURE':
        fill = '#795548'; // Brown for furniture
        break;
      case 'OFFICE':
        fill = '#607d8b'; // Gray for office
        break;
      case 'CONSUMABLE':
        fill = '#ffeb3b'; // Yellow for consumables
        break;
    }
    
    // Create different shapes based on category
    if (category === 'SURVEILLANCE') {
      // Camera shape
      return (
        <Group {...baseProps}>
          <Circle radius={10} fill={fill} stroke="black" strokeWidth={1} />
          <Text 
            text={name}
            x={-50}
            y={15}
            width={100}
            align="center"
            fontSize={10}
          />
        </Group>
      );
    } else if (category === 'COMPUTER' || category === 'NETWORK') {
      // Rectangle for computers and network
      return (
        <Group {...baseProps}>
          <Rect
            width={30}
            height={20}
            fill={fill}
            stroke="black"
            strokeWidth={1}
            offsetX={15}
            offsetY={10}
          />
          <Text 
            text={name}
            x={-50}
            y={15}
            width={100}
            align="center"
            fontSize={10}
          />
        </Group>
      );
    } else if (category === 'GAMING') {
      // Square for gaming
      return (
        <Group {...baseProps}>
          <Rect
            width={20}
            height={20}
            fill={fill}
            stroke="black"
            strokeWidth={1}
            offsetX={10}
            offsetY={10}
          />
          <Text 
            text={name}
            x={-50}
            y={15}
            width={100}
            align="center"
            fontSize={10}
          />
        </Group>
      );
    } else {
      // Circle for other items
      return (
        <Group {...baseProps}>
          <Circle radius={10} fill={fill} stroke="black" strokeWidth={1} />
          <Text 
            text={name}
            x={-50}
            y={15}
            width={100}
            align="center"
            fontSize={10}
          />
        </Group>
      );
    }
  };
  
  // Get location component
  const getLocationComponent = (location) => {
    const { location_id, name, x_position, y_position, width, height } = location;
    
    return (
      <Group
        x={x_position}
        y={y_position}
        onClick={() => handleSelectLocation(location_id)}
        name={`location-${location_id}`}
        id={`location-${location_id}`}
      >
        <Rect
          width={width}
          height={height}
          fill="rgba(0, 0, 0, 0.1)"
          stroke="rgba(0, 0, 0, 0.3)"
          strokeWidth={1}
          dash={[5, 5]}
        />
        <Text 
          text={name}
          x={5}
          y={5}
          fontSize={12}
          fill="rgba(0, 0, 0, 0.7)"
        />
      </Group>
    );
  };
  
  // Format currency
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'CHF'
    }).format(value);
  };
  
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }
  
  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }
  
  return (
    <Box sx={{ p: 3, height: 'calc(100vh - 100px)', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h4">{floorPlan.name} - Inventory View</Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            onClick={() => {
              setNotification({
                open: true,
                message: 'Inventory data exported successfully',
                severity: 'success'
              });
            }}
          >
            Export
          </Button>
        </Box>
      </Box>
      
      <Box sx={{ display: 'flex', mb: 2 }}>
        <Box sx={{ mr: 2 }}>
          <Typography variant="subtitle1">Tools</Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <Tooltip title="Zoom In">
              <IconButton onClick={handleZoomIn}>
                <ZoomInIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Zoom Out">
              <IconButton onClick={handleZoomOut}>
                <ZoomOutIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
        
        <Box sx={{ flexGrow: 1 }} />
        
        <Box>
          <Typography variant="subtitle1">Legend</Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Box sx={{ width: 16, height: 16, borderRadius: '50%', bgcolor: '#f44336', mr: 1 }} />
              <Typography variant="body2">Surveillance</Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Box sx={{ width: 16, height: 16, borderRadius: 0, bgcolor: '#4caf50', mr: 1 }} />
              <Typography variant="body2">Computer</Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Box sx={{ width: 16, height: 16, borderRadius: 0, bgcolor: '#2196f3', mr: 1 }} />
              <Typography variant="body2">Network</Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Box sx={{ width: 16, height: 16, borderRadius: 0, bgcolor: '#ff9800', mr: 1 }} />
              <Typography variant="body2">Gaming</Typography>
            </Box>
          </Box>
        </Box>
      </Box>
      
      <Paper 
        elevation={3} 
        sx={{ 
          flexGrow: 1, 
          overflow: 'hidden',
          position: 'relative'
        }}
      >
        <Stage
          width={window.innerWidth - 100}
          height={window.innerHeight - 250}
          ref={stageRef}
          scaleX={scale}
          scaleY={scale}
          x={position.x}
          y={position.y}
          onMouseDown={(e) => {
            if (e.evt.button === 1) { // Middle mouse button
              e.evt.preventDefault();
              stageRef.current.container().style.cursor = 'grabbing';
            }
          }}
          onMouseUp={(e) => {
            if (e.evt.button === 1) { // Middle mouse button
              stageRef.current.container().style.cursor = 'default';
            }
          }}
          onMouseMove={(e) => {
            if (e.evt.buttons === 4) { // Middle mouse button
              const dx = e.evt.movementX;
              const dy = e.evt.movementY;
              setPosition({
                x: position.x + dx,
                y: position.y + dy
              });
            }
          }}
          onClick={handleStageClick}
        >
          <Layer>
            {/* Floor plan background image */}
            {/* <Image 
              image={floorPlanImage} 
              width={floorPlan.width} 
              height={floorPlan.height} 
            /> */}
            
            {/* Locations */}
            {locations.map(location => getLocationComponent(location))}
            
            {/* Items */}
            {items.map(item => getItemComponent(item))}
          </Layer>
        </Stage>
      </Paper>
      
      {/* Item Details Dialog */}
      <Dialog open={showItemDialog} onClose={() => setShowItemDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {itemDetails?.name || 'Item Details'}
        </DialogTitle>
        <DialogContent>
          {itemDetails && (
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Category</Typography>
                <Typography variant="body1">{itemDetails.category}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Status</Typography>
                <Chip 
                  label={itemDetails.status} 
                  color={
                    itemDetails.status === "DEPLOYED" ? "primary" :
                    itemDetails.status === "AVAILABLE" ? "success" :
                    itemDetails.status === "MAINTENANCE" ? "warning" :
                    "default"
                  } 
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Manufacturer</Typography>
                <Typography variant="body1">{itemDetails.manufacturer}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Model</Typography>
                <Typography variant="body1">{itemDetails.model}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Serial Number</Typography>
                <Typography variant="body1">{itemDetails.serial_number}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Asset Tag</Typography>
                <Typography variant="body1">{itemDetails.asset_tag}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Purchase Date</Typography>
                <Typography variant="body1">{new Date(itemDetails.purchase_date).toLocaleDateString()}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Purchase Price</Typography>
                <Typography variant="body1">{formatCurrency(itemDetails.purchase_price)}</Typography>
              </Grid>
              
              {itemDetails.properties && Object.keys(itemDetails.properties).length > 0 && (
                <Grid item xs={12}>
                  <Typography variant="subtitle2">Properties</Typography>
                  <Box sx={{ mt: 1 }}>
                    {Object.entries(itemDetails.properties).map(([key, value]) => (
                      <Chip 
                        key={key}
                        label={`${key}: ${value}`}
                        size="small"
                        sx={{ mr: 1, mb: 1 }}
                      />
                    ))}
                  </Box>
                </Grid>
              )}
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowItemDialog(false)}>Close</Button>
          <Button 
            variant="outlined" 
            color="primary"
            onClick={() => {
              setShowItemDialog(false);
              window.location.href = `/inventory/items/${itemDetails.item_id}`;
            }}
          >
            Edit
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Notification Snackbar */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={() => setNotification({ ...notification, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert 
          onClose={() => setNotification({ ...notification, open: false })} 
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

// Export all components
export default {
  InventoryDashboard,
  InventoryItemList,
  InventoryFloorPlanView
};
