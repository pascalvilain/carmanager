"""
Alpin Royal Casino Management System - Inventory Management Module Services
This module provides business logic for inventory management.
"""

from typing import List, Optional, Dict, Any, Tuple
import datetime
import os
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import UploadFile, HTTPException

from modules.inventory_management.models.inventory import (
    InventoryItem, InventoryLocation, InventoryTag, InventoryTransaction, InventoryReport,
    ItemCategory, ItemStatus, TransactionType,
    InventoryItemCreate, InventoryItemUpdate, InventoryLocationCreate, InventoryLocationUpdate,
    InventoryTagCreate, InventoryTagUpdate, InventoryTransactionCreate, InventorySearch,
    InventoryDashboard
)
from modules.inventory_management.repositories.inventory_repository import (
    InventoryItemRepository, InventoryLocationRepository, InventoryTagRepository,
    InventoryTransactionRepository, InventoryReportRepository
)
from base_layer.utils.storage import StorageManager
from base_layer.utils.event_bus import EventBus
from base_layer.config.settings import get_settings

class InventoryService:
    """Service for inventory management"""
    
    def __init__(self, session: AsyncSession, storage_manager: StorageManager, event_bus: EventBus):
        """Initialize the service"""
        self.session = session
        self.storage_manager = storage_manager
        self.event_bus = event_bus
        self.settings = get_settings()
    
    # Item Services
    
    async def create_item(self, item_data: InventoryItemCreate, item_image: Optional[UploadFile] = None) -> InventoryItem:
        """Create a new inventory item"""
        # Check if serial number is already in use
        if item_data.serial_number:
            existing_item = await InventoryItemRepository.get_by_serial_number(self.session, item_data.serial_number)
            if existing_item:
                raise HTTPException(status_code=400, detail="Serial number already in use")
        
        # Check if asset tag is already in use
        if item_data.asset_tag:
            existing_item = await InventoryItemRepository.get_by_asset_tag(self.session, item_data.asset_tag)
            if existing_item:
                raise HTTPException(status_code=400, detail="Asset tag already in use")
        
        # If a file is provided, upload it to storage
        if item_image:
            # Generate a unique filename
            file_extension = os.path.splitext(item_image.filename)[1]
            unique_filename = f"inventory_item_{uuid.uuid4()}{file_extension}"
            
            # Upload the file
            file_path = await self.storage_manager.upload_file(
                item_image.file,
                f"inventory/items/{unique_filename}",
                content_type=item_image.content_type
            )
            
            # Update the item data with the image path
            if not item_data.properties:
                item_data.properties = {}
            item_data.properties["image_path"] = file_path
        
        # Create the item
        item = await InventoryItemRepository.create(self.session, item_data)
        
        # Publish an event
        await self.event_bus.publish("inventory.item.created", {
            "item_id": item.item_id,
            "name": item.name,
            "category": item.category.value if item.category else None,
            "status": item.status.value if item.status else None
        })
        
        return item
    
    async def get_item(self, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item by ID"""
        return await InventoryItemRepository.get_by_id(self.session, item_id)
    
    async def get_all_items(self, skip: int = 0, limit: int = 100) -> List[InventoryItem]:
        """Get all inventory items"""
        return await InventoryItemRepository.get_all(self.session, skip, limit)
    
    async def update_item(self, item_id: int, item_data: InventoryItemUpdate, item_image: Optional[UploadFile] = None) -> Optional[InventoryItem]:
        """Update an inventory item"""
        # Check if the item exists
        existing_item = await InventoryItemRepository.get_by_id(self.session, item_id)
        if not existing_item:
            return None
        
        # Check if serial number is already in use
        if item_data.serial_number and item_data.serial_number != existing_item.serial_number:
            existing_serial = await InventoryItemRepository.get_by_serial_number(self.session, item_data.serial_number)
            if existing_serial and existing_serial.item_id != item_id:
                raise HTTPException(status_code=400, detail="Serial number already in use")
        
        # Check if asset tag is already in use
        if item_data.asset_tag and item_data.asset_tag != existing_item.asset_tag:
            existing_tag = await InventoryItemRepository.get_by_asset_tag(self.session, item_data.asset_tag)
            if existing_tag and existing_tag.item_id != item_id:
                raise HTTPException(status_code=400, detail="Asset tag already in use")
        
        # If a file is provided, upload it to storage
        if item_image:
            # Generate a unique filename
            file_extension = os.path.splitext(item_image.filename)[1]
            unique_filename = f"inventory_item_{uuid.uuid4()}{file_extension}"
            
            # Upload the file
            file_path = await self.storage_manager.upload_file(
                item_image.file,
                f"inventory/items/{unique_filename}",
                content_type=item_image.content_type
            )
            
            # Update the item data with the image path
            if not item_data.properties:
                item_data.properties = existing_item.properties or {}
            item_data.properties["image_path"] = file_path
            
            # Delete the old image if it exists
            if existing_item.properties and "image_path" in existing_item.properties:
                try:
                    await self.storage_manager.delete_file(existing_item.properties["image_path"])
                except Exception as e:
                    # Log the error but continue
                    print(f"Error deleting old item image: {e}")
        
        # Update the item
        item = await InventoryItemRepository.update(self.session, item_id, item_data)
        
        # Publish an event
        if item:
            await self.event_bus.publish("inventory.item.updated", {
                "item_id": item.item_id,
                "name": item.name,
                "category": item.category.value if item.category else None,
                "status": item.status.value if item.status else None
            })
        
        return item
    
    async def delete_item(self, item_id: int) -> bool:
        """Delete an inventory item"""
        # Check if the item exists
        item = await InventoryItemRepository.get_by_id(self.session, item_id)
        if not item:
            return False
        
        # Check if the item has transactions
        transactions = await InventoryTransactionRepository.get_by_item(self.session, item_id)
        if transactions:
            raise HTTPException(status_code=400, detail="Cannot delete item with transaction history")
        
        # Delete the item image if it exists
        if item.properties and "image_path" in item.properties:
            try:
                await self.storage_manager.delete_file(item.properties["image_path"])
            except Exception as e:
                # Log the error but continue
                print(f"Error deleting item image: {e}")
        
        # Delete the item
        result = await InventoryItemRepository.delete(self.session, item_id)
        
        # Publish an event
        if result:
            await self.event_bus.publish("inventory.item.deleted", {
                "item_id": item_id,
                "name": item.name,
                "category": item.category.value if item.category else None,
                "status": item.status.value if item.status else None
            })
        
        return result
    
    async def search_items(self, search_params: InventorySearch, skip: int = 0, limit: int = 100) -> List[InventoryItem]:
        """Search for inventory items based on various criteria"""
        return await InventoryItemRepository.search(self.session, search_params, skip, limit)
    
    async def get_items_by_category(self, category: ItemCategory) -> List[InventoryItem]:
        """Get inventory items by category"""
        return await InventoryItemRepository.get_by_category(self.session, category)
    
    async def get_items_by_status(self, status: ItemStatus) -> List[InventoryItem]:
        """Get inventory items by status"""
        return await InventoryItemRepository.get_by_status(self.session, status)
    
    async def get_items_by_location(self, location_id: int) -> List[InventoryItem]:
        """Get inventory items by location"""
        return await InventoryItemRepository.get_by_location(self.session, location_id)
    
    async def get_items_by_floor_plan(self, floor_plan_id: int) -> List[InventoryItem]:
        """Get inventory items by floor plan"""
        return await InventoryItemRepository.get_by_floor_plan(self.session, floor_plan_id)
    
    async def get_items_by_tag(self, tag_id: int) -> List[InventoryItem]:
        """Get inventory items by tag"""
        return await InventoryItemRepository.get_by_tag(self.session, tag_id)
    
    async def get_item_with_location(self, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item with its location"""
        return await InventoryItemRepository.get_with_location(self.session, item_id)
    
    async def get_item_with_tags(self, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item with its tags"""
        return await InventoryItemRepository.get_with_tags(self.session, item_id)
    
    async def get_item_with_transactions(self, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item with its transactions"""
        return await InventoryItemRepository.get_with_transactions(self.session, item_id)
    
    # Location Services
    
    async def create_location(self, location_data: InventoryLocationCreate) -> InventoryLocation:
        """Create a new inventory location"""
        # Check if parent location exists if provided
        if location_data.parent_id:
            parent = await InventoryLocationRepository.get_by_id(self.session, location_data.parent_id)
            if not parent:
                raise HTTPException(status_code=404, detail="Parent location not found")
        
        # Create the location
        location = await InventoryLocationRepository.create(self.session, location_data)
        
        # Publish an event
        await self.event_bus.publish("inventory.location.created", {
            "location_id": location.location_id,
            "name": location.name,
            "parent_id": location.parent_id
        })
        
        return location
    
    async def get_location(self, location_id: int) -> Optional[InventoryLocation]:
        """Get an inventory location by ID"""
        return await InventoryLocationRepository.get_by_id(self.session, location_id)
    
    async def get_all_locations(self, skip: int = 0, limit: int = 100) -> List[InventoryLocation]:
        """Get all inventory locations"""
        return await InventoryLocationRepository.get_all(self.session, skip, limit)
    
    async def update_location(self, location_id: int, location_data: InventoryLocationUpdate) -> Optional[InventoryLocation]:
        """Update an inventory location"""
        # Check if the location exists
        existing_location = await InventoryLocationRepository.get_by_id(self.session, location_id)
        if not existing_location:
            return None
        
        # Check if parent location exists if provided
        if location_data.parent_id:
            parent = await InventoryLocationRepository.get_by_id(self.session, location_data.parent_id)
            if not parent:
                raise HTTPException(status_code=404, detail="Parent location not found")
            
            # Check for circular reference
            if location_data.parent_id == location_id:
                raise HTTPException(status_code=400, detail="Location cannot be its own parent")
            
            # Check if the new parent is a descendant of this location
            current_parent_id = location_data.parent_id
            while current_parent_id:
                current_parent = await InventoryLocationRepository.get_by_id(self.session, current_parent_id)
                if not current_parent:
                    break
                
                if current_parent.parent_id == location_id:
                    raise HTTPException(status_code=400, detail="Circular reference detected in location hierarchy")
                
                current_parent_id = current_parent.parent_id
        
        # Update the location
        location = await InventoryLocationRepository.update(self.session, location_id, location_data)
        
        # Publish an event
        if location:
            await self.event_bus.publish("inventory.location.updated", {
                "location_id": location.location_id,
                "name": location.name,
                "parent_id": location.parent_id
            })
        
        return location
    
    async def delete_location(self, location_id: int) -> bool:
        """Delete an inventory location"""
        # Check if the location exists
        location = await InventoryLocationRepository.get_by_id(self.session, location_id)
        if not location:
            return False
        
        # Delete the location
        try:
            result = await InventoryLocationRepository.delete(self.session, location_id)
            
            # Publish an event
            if result:
                await self.event_bus.publish("inventory.location.deleted", {
                    "location_id": location_id,
                    "name": location.name
                })
            
            return result
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
    
    async def get_locations_by_parent(self, parent_id: int) -> List[InventoryLocation]:
        """Get inventory locations by parent ID"""
        return await InventoryLocationRepository.get_by_parent(self.session, parent_id)
    
    async def get_locations_by_floor_plan(self, floor_plan_id: int) -> List[InventoryLocation]:
        """Get inventory locations by floor plan ID"""
        return await InventoryLocationRepository.get_by_floor_plan(self.session, floor_plan_id)
    
    async def get_root_locations(self) -> List[InventoryLocation]:
        """Get root inventory locations (no parent)"""
        return await InventoryLocationRepository.get_root_locations(self.session)
    
    async def get_location_with_items(self, location_id: int) -> Optional[InventoryLocation]:
        """Get an inventory location with its items"""
        return await InventoryLocationRepository.get_with_items(self.session, location_id)
    
    async def get_location_with_children(self, location_id: int) -> Optional[InventoryLocation]:
        """Get an inventory location with its children"""
        return await InventoryLocationRepository.get_with_children(self.session, location_id)
    
    async def get_location_hierarchy(self) -> List[Dict[str, Any]]:
        """Get the complete location hierarchy"""
        return await InventoryLocationRepository.get_location_hierarchy(self.session)
    
    # Tag Services
    
    async def create_tag(self, tag_data: InventoryTagCreate) -> InventoryTag:
        """Create a new inventory tag"""
        # Check if tag name is already in use
        existing_tag = await InventoryTagRepository.get_by_name(self.session, tag_data.name)
        if existing_tag:
            raise HTTPException(status_code=400, detail="Tag name already in use")
        
        # Create the tag
        tag = await InventoryTagRepository.create(self.session, tag_data)
        
        # Publish an event
        await self.event_bus.publish("inventory.tag.created", {
            "tag_id": tag.tag_id,
            "name": tag.name
        })
        
        return tag
    
    async def get_tag(self, tag_id: int) -> Optional[InventoryTag]:
        """Get an inventory tag by ID"""
        return await InventoryTagRepository.get_by_id(self.session, tag_id)
    
    async def get_all_tags(self) -> List[InventoryTag]:
        """Get all inventory tags"""
        return await InventoryTagRepository.get_all(self.session)
    
    async def update_tag(self, tag_id: int, tag_data: InventoryTagUpdate) -> Optional[InventoryTag]:
        """Update an inventory tag"""
        # Check if the tag exists
        existing_tag = await InventoryTagRepository.get_by_id(self.session, tag_id)
        if not existing_tag:
            return None
        
        # Check if tag name is already in use
        if tag_data.name and tag_data.name != existing_tag.name:
            existing_name = await InventoryTagRepository.get_by_name(self.session, tag_data.name)
            if existing_name:
                raise HTTPException(status_code=400, detail="Tag name already in use")
        
        # Update the tag
        tag = await InventoryTagRepository.update(self.session, tag_id, tag_data)
        
        # Publish an event
        if tag:
            await self.event_bus.publish("inventory.tag.updated", {
                "tag_id": tag.tag_id,
                "name": tag.name
            })
        
        return tag
    
    async def delete_tag(self, tag_id: int) -> bool:
        """Delete an inventory tag"""
        # Check if the tag exists
        tag = await InventoryTagRepository.get_by_id(self.session, tag_id)
        if not tag:
            return False
        
        # Check if the tag is used by any items
        tag_with_items = await InventoryTagRepository.get_with_items(self.session, tag_id)
        if tag_with_items and tag_with_items.items:
            raise HTTPException(status_code=400, detail="Cannot delete tag that is used by items")
        
        # Delete the tag
        result = await InventoryTagRepository.delete(self.session, tag_id)
        
        # Publish an event
        if result:
            await self.event_bus.publish("inventory.tag.deleted", {
                "tag_id": tag_id,
                "name": tag.name
            })
        
        return result
    
    async def get_tag_with_items(self, tag_id: int) -> Optional[InventoryTag]:
        """Get an inventory tag with its items"""
        return await InventoryTagRepository.get_with_items(self.session, tag_id)
    
    # Transaction Services
    
    async def create_transaction(self, transaction_data: InventoryTransactionCreate) -> InventoryTransaction:
        """Create a new inventory transaction"""
        # Check if the item exists
        item = await InventoryItemRepository.get_by_id(self.session, transaction_data.item_id)
        if not item:
            raise HTTPException(status_code=404, detail="Item not found")
        
        # Check if source location exists if provided
        if transaction_data.source_location_id:
            source_location = await InventoryLocationRepository.get_by_id(self.session, transaction_data.source_location_id)
            if not source_location:
                raise HTTPException(status_code=404, detail="Source location not found")
        
        # Check if destination location exists if provided
        if transaction_data.destination_location_id:
            destination_location = await InventoryLocationRepository.get_by_id(self.session, transaction_data.destination_location_id)
            if not destination_location:
                raise HTTPException(status_code=404, detail="Destination location not found")
        
        # Create the transaction
        transaction = await InventoryTransactionRepository.create(self.session, transaction_data)
        
        # Update the item status and location based on the transaction type
        item_update = InventoryItemUpdate()
        
        if transaction_data.transaction_type == TransactionType.DEPLOYMENT:
            item_update.status = ItemStatus.DEPLOYED
            item_update.location_id = transaction_data.destination_location_id
        elif transaction_data.transaction_type == TransactionType.RETURN:
            item_update.status = ItemStatus.AVAILABLE
            item_update.location_id = transaction_data.destination_location_id
        elif transaction_data.transaction_type == TransactionType.TRANSFER:
            item_update.location_id = transaction_data.destination_location_id
        elif transaction_data.transaction_type == TransactionType.MAINTENANCE:
            item_update.status = ItemStatus.MAINTENANCE
        elif transaction_data.transaction_type == TransactionType.DISPOSAL:
            item_update.status = ItemStatus.RETIRED
        
        if any(value is not None for value in vars(item_update).values()):
            await InventoryItemRepository.update(self.session, transaction_data.item_id, item_update)
        
        # Publish an event
        await self.event_bus.publish("inventory.transaction.created", {
            "transaction_id": transaction.transaction_id,
            "item_id": transaction.item_id,
            "transaction_type": transaction.transaction_type.value,
            "source_location_id": transaction.source_location_id,
            "destination_location_id": transaction.destination_location_id
        })
        
        return transaction
    
    async def get_transaction(self, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction by ID"""
        return await InventoryTransactionRepository.get_by_id(self.session, transaction_id)
    
    async def get_all_transactions(self, skip: int = 0, limit: int = 100) -> List[InventoryTransaction]:
        """Get all inventory transactions"""
        return await InventoryTransactionRepository.get_all(self.session, skip, limit)
    
    async def get_transactions_by_item(self, item_id: int) -> List[InventoryTransaction]:
        """Get inventory transactions by item ID"""
        return await InventoryTransactionRepository.get_by_item(self.session, item_id)
    
    async def get_transactions_by_location(self, location_id: int) -> List[InventoryTransaction]:
        """Get inventory transactions by location ID (source or destination)"""
        return await InventoryTransactionRepository.get_by_location(self.session, location_id)
    
    async def get_transactions_by_employee(self, employee_id: int) -> List[InventoryTransaction]:
        """Get inventory transactions by employee ID"""
        return await InventoryTransactionRepository.get_by_employee(self.session, employee_id)
    
    async def get_transactions_by_type(self, transaction_type: TransactionType) -> List[InventoryTransaction]:
        """Get inventory transactions by type"""
        return await InventoryTransactionRepository.get_by_type(self.session, transaction_type)
    
    async def get_transaction_with_item(self, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction with its item"""
        return await InventoryTransactionRepository.get_with_item(self.session, transaction_id)
    
    async def get_transaction_with_locations(self, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction with its source and destination locations"""
        return await InventoryTransactionRepository.get_with_locations(self.session, transaction_id)
    
    async def get_transaction_with_employee(self, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction with its employee"""
        return await InventoryTransactionRepository.get_with_employee(self.session, transaction_id)
    
    async def get_recent_transactions(self, limit: int = 10) -> List[InventoryTransaction]:
        """Get recent inventory transactions"""
        return await InventoryTransactionRepository.get_recent_transactions(self.session, limit)
    
    # Report Services
    
    async def create_report(self, name: str, description: str, report_type: str, parameters: Dict[str, Any], created_by: int) -> InventoryReport:
        """Create a new inventory report"""
        # Generate the report result based on the report type and parameters
        result = await self._generate_report_result(report_type, parameters)
        
        # Create the report
        report = await InventoryReportRepository.create(
            self.session, name, description, report_type, parameters, result, created_by
        )
        
        return report
    
    async def get_report(self, report_id: int) -> Optional[InventoryReport]:
        """Get an inventory report by ID"""
        return await InventoryReportRepository.get_by_id(self.session, report_id)
    
    async def get_all_reports(self, skip: int = 0, limit: int = 100) -> List[InventoryReport]:
        """Get all inventory reports"""
        return await InventoryReportRepository.get_all(self.session, skip, limit)
    
    async def get_reports_by_type(self, report_type: str) -> List[InventoryReport]:
        """Get inventory reports by type"""
        return await InventoryReportRepository.get_by_type(self.session, report_type)
    
    async def get_reports_by_creator(self, created_by: int) -> List[InventoryReport]:
        """Get inventory reports by creator"""
        return await InventoryReportRepository.get_by_creator(self.session, created_by)
    
    async def delete_report(self, report_id: int) -> bool:
        """Delete an inventory report"""
        return await InventoryReportRepository.delete(self.session, report_id)
    
    async def _generate_report_result(self, report_type: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a report result based on the report type and parameters"""
        if report_type == "items_by_category":
            return {
                "items_by_category": await InventoryItemRepository.get_item_counts_by_category(self.session)
            }
        elif report_type == "items_by_status":
            return {
                "items_by_status": await InventoryItemRepository.get_item_counts_by_status(self.session)
            }
        elif report_type == "items_by_location":
            location_counts = await InventoryItemRepository.get_item_counts_by_location(self.session)
            
            # Get location names
            location_names = {}
            for location_id in location_counts.keys():
                location = await InventoryLocationRepository.get_by_id(self.session, location_id)
                if location:
                    location_names[location_id] = location.name
            
            return {
                "items_by_location": location_counts,
                "location_names": location_names
            }
        elif report_type == "value_by_category":
            return {
                "value_by_category": await InventoryItemRepository.get_total_value_by_category(self.session)
            }
        elif report_type == "expiring_warranties":
            days = parameters.get("days", 30)
            items = await InventoryItemRepository.get_expiring_warranties(self.session, days)
            
            return {
                "expiring_warranties": [
                    {
                        "item_id": item.item_id,
                        "name": item.name,
                        "warranty_expiry": item.warranty_expiry.isoformat() if item.warranty_expiry else None,
                        "days_remaining": (item.warranty_expiry - datetime.datetime.utcnow()).days if item.warranty_expiry else None
                    }
                    for item in items
                ]
            }
        else:
            return {}
    
    # Dashboard Services
    
    async def get_inventory_dashboard(self) -> InventoryDashboard:
        """Get inventory dashboard data"""
        # Get item counts
        total_items_query = await self.session.execute("SELECT COUNT(*) FROM inventory_items")
        total_items = total_items_query.scalar()
        
        # Get item counts by category
        items_by_category = await InventoryItemRepository.get_item_counts_by_category(self.session)
        
        # Get item counts by status
        items_by_status = await InventoryItemRepository.get_item_counts_by_status(self.session)
        
        # Get item counts by location
        items_by_location_raw = await InventoryItemRepository.get_item_counts_by_location(self.session)
        
        # Get location names
        items_by_location = {}
        for location_id, count in items_by_location_raw.items():
            location = await InventoryLocationRepository.get_by_id(self.session, location_id)
            if location:
                items_by_location[location.name] = count
        
        # Get recent transactions
        recent_transactions = await InventoryTransactionRepository.get_recent_transactions(self.session, 5)
        
        # Format recent transactions
        formatted_transactions = []
        for transaction in recent_transactions:
            item = await InventoryItemRepository.get_by_id(self.session, transaction.item_id)
            
            source_location = None
            if transaction.source_location_id:
                source_loc = await InventoryLocationRepository.get_by_id(self.session, transaction.source_location_id)
                if source_loc:
                    source_location = source_loc.name
            
            destination_location = None
            if transaction.destination_location_id:
                dest_loc = await InventoryLocationRepository.get_by_id(self.session, transaction.destination_location_id)
                if dest_loc:
                    destination_location = dest_loc.name
            
            formatted_transactions.append({
                "transaction_id": transaction.transaction_id,
                "item_name": item.name if item else "Unknown",
                "transaction_type": transaction.transaction_type.value,
                "source_location": source_location,
                "destination_location": destination_location,
                "timestamp": transaction.timestamp.isoformat()
            })
        
        # Get total value by category
        value_by_category = await InventoryItemRepository.get_total_value_by_category(self.session)
        
        # Get expiring warranties
        expiring_items = await InventoryItemRepository.get_expiring_warranties(self.session, 30)
        expiring_warranties = [
            {
                "item_id": item.item_id,
                "name": item.name,
                "warranty_expiry": item.warranty_expiry.isoformat() if item.warranty_expiry else None,
                "days_remaining": (item.warranty_expiry - datetime.datetime.utcnow()).days if item.warranty_expiry else None
            }
            for item in expiring_items
        ]
        
        # Create dashboard data
        dashboard = InventoryDashboard(
            total_items=total_items,
            items_by_category=items_by_category,
            items_by_status=items_by_status,
            items_by_location=items_by_location,
            recent_transactions=formatted_transactions,
            value_by_category=value_by_category,
            expiring_warranties=expiring_warranties
        )
        
        return dashboard
    
    # Export Services
    
    async def export_inventory_data(self, location_id: Optional[int] = None) -> Dict[str, Any]:
        """Export inventory data for a location or the entire inventory"""
        if location_id:
            # Export data for a specific location
            location = await InventoryLocationRepository.get_by_id(self.session, location_id)
            if not location:
                raise HTTPException(status_code=404, detail="Location not found")
            
            items = await InventoryItemRepository.get_by_location(self.session, location_id)
            
            return {
                "location": {
                    "location_id": location.location_id,
                    "name": location.name,
                    "description": location.description,
                    "parent_id": location.parent_id,
                    "floor_plan_id": location.floor_plan_id,
                    "x_position": location.x_position,
                    "y_position": location.y_position,
                    "width": location.width,
                    "height": location.height
                },
                "items": [
                    {
                        "item_id": item.item_id,
                        "name": item.name,
                        "description": item.description,
                        "category": item.category.value if item.category else None,
                        "manufacturer": item.manufacturer,
                        "model": item.model,
                        "serial_number": item.serial_number,
                        "asset_tag": item.asset_tag,
                        "purchase_date": item.purchase_date.isoformat() if item.purchase_date else None,
                        "purchase_price": item.purchase_price,
                        "warranty_expiry": item.warranty_expiry.isoformat() if item.warranty_expiry else None,
                        "status": item.status.value if item.status else None,
                        "properties": item.properties
                    }
                    for item in items
                ]
            }
        else:
            # Export data for the entire inventory
            locations = await InventoryLocationRepository.get_all(self.session)
            items = await InventoryItemRepository.get_all(self.session)
            tags = await InventoryTagRepository.get_all(self.session)
            
            # Get item tags
            item_tags = {}
            for item in items:
                item_with_tags = await InventoryItemRepository.get_with_tags(self.session, item.item_id)
                if item_with_tags and item_with_tags.tags:
                    item_tags[item.item_id] = [tag.tag_id for tag in item_with_tags.tags]
            
            return {
                "locations": [
                    {
                        "location_id": location.location_id,
                        "name": location.name,
                        "description": location.description,
                        "parent_id": location.parent_id,
                        "floor_plan_id": location.floor_plan_id,
                        "x_position": location.x_position,
                        "y_position": location.y_position,
                        "width": location.width,
                        "height": location.height
                    }
                    for location in locations
                ],
                "items": [
                    {
                        "item_id": item.item_id,
                        "name": item.name,
                        "description": item.description,
                        "category": item.category.value if item.category else None,
                        "manufacturer": item.manufacturer,
                        "model": item.model,
                        "serial_number": item.serial_number,
                        "asset_tag": item.asset_tag,
                        "purchase_date": item.purchase_date.isoformat() if item.purchase_date else None,
                        "purchase_price": item.purchase_price,
                        "warranty_expiry": item.warranty_expiry.isoformat() if item.warranty_expiry else None,
                        "status": item.status.value if item.status else None,
                        "location_id": item.location_id,
                        "floor_plan_id": item.floor_plan_id,
                        "x_position": item.x_position,
                        "y_position": item.y_position,
                        "rotation": item.rotation,
                        "properties": item.properties,
                        "tag_ids": item_tags.get(item.item_id, [])
                    }
                    for item in items
                ],
                "tags": [
                    {
                        "tag_id": tag.tag_id,
                        "name": tag.name,
                        "color": tag.color
                    }
                    for tag in tags
                ]
            }
