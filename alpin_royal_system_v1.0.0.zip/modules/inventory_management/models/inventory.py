"""
Alpin Royal Casino Management System - Inventory Management Module
This module provides models for inventory management.
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, DateTime, Text, JSON, Enum, Table
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum
import uuid

from base_layer.utils.database import Base

class ItemCategory(str, enum.Enum):
    """Enum for item categories"""
    NETWORK = "NETWORK"
    COMPUTER = "COMPUTER"
    PERIPHERAL = "PERIPHERAL"
    GAMING = "GAMING"
    SURVEILLANCE = "SURVEILLANCE"
    FURNITURE = "FURNITURE"
    OFFICE = "OFFICE"
    CONSUMABLE = "CONSUMABLE"
    OTHER = "OTHER"

class ItemStatus(str, enum.Enum):
    """Enum for item status"""
    AVAILABLE = "AVAILABLE"
    DEPLOYED = "DEPLOYED"
    MAINTENANCE = "MAINTENANCE"
    RESERVED = "RESERVED"
    DAMAGED = "DAMAGED"
    RETIRED = "RETIRED"
    LOST = "LOST"

class TransactionType(str, enum.Enum):
    """Enum for transaction types"""
    PURCHASE = "PURCHASE"
    DEPLOYMENT = "DEPLOYMENT"
    RETURN = "RETURN"
    TRANSFER = "TRANSFER"
    MAINTENANCE = "MAINTENANCE"
    DISPOSAL = "DISPOSAL"

# Association table for item tags
item_tags = Table(
    "item_tags",
    Base.metadata,
    Column("item_id", Integer, ForeignKey("inventory_items.item_id"), primary_key=True),
    Column("tag_id", Integer, ForeignKey("inventory_tags.tag_id"), primary_key=True)
)

class InventoryItem(Base):
    """Inventory item model"""
    __tablename__ = "inventory_items"
    
    item_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    category = Column(Enum(ItemCategory), nullable=False)
    manufacturer = Column(String(100), nullable=True)
    model = Column(String(100), nullable=True)
    serial_number = Column(String(100), nullable=True, unique=True)
    asset_tag = Column(String(50), nullable=True, unique=True)
    purchase_date = Column(DateTime, nullable=True)
    purchase_price = Column(Float, nullable=True)
    warranty_expiry = Column(DateTime, nullable=True)
    status = Column(Enum(ItemStatus), default=ItemStatus.AVAILABLE)
    location_id = Column(Integer, ForeignKey("inventory_locations.location_id"), nullable=True)
    floor_plan_id = Column(Integer, ForeignKey("floor_plans.floor_plan_id"), nullable=True)
    x_position = Column(Float, nullable=True)  # X position on floor plan
    y_position = Column(Float, nullable=True)  # Y position on floor plan
    rotation = Column(Float, default=0)  # Rotation in degrees
    properties = Column(JSON, nullable=True)  # Additional item-specific properties
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    location = relationship("InventoryLocation", back_populates="items")
    floor_plan = relationship("FloorPlan", foreign_keys=[floor_plan_id])
    transactions = relationship("InventoryTransaction", back_populates="item")
    tags = relationship("InventoryTag", secondary=item_tags, back_populates="items")
    
    def __repr__(self):
        return f"<InventoryItem {self.name} ({self.item_id})>"

class InventoryLocation(Base):
    """Inventory location model"""
    __tablename__ = "inventory_locations"
    
    location_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    parent_id = Column(Integer, ForeignKey("inventory_locations.location_id"), nullable=True)
    floor_plan_id = Column(Integer, ForeignKey("floor_plans.floor_plan_id"), nullable=True)
    x_position = Column(Float, nullable=True)  # X position on floor plan
    y_position = Column(Float, nullable=True)  # Y position on floor plan
    width = Column(Float, nullable=True)  # Width on floor plan
    height = Column(Float, nullable=True)  # Height on floor plan
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    items = relationship("InventoryItem", back_populates="location")
    children = relationship("InventoryLocation", backref=relationship("parent", remote_side=[location_id]))
    floor_plan = relationship("FloorPlan", foreign_keys=[floor_plan_id])
    
    def __repr__(self):
        return f"<InventoryLocation {self.name} ({self.location_id})>"

class InventoryTag(Base):
    """Inventory tag model"""
    __tablename__ = "inventory_tags"
    
    tag_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False, unique=True)
    color = Column(String(20), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    items = relationship("InventoryItem", secondary=item_tags, back_populates="tags")
    
    def __repr__(self):
        return f"<InventoryTag {self.name}>"

class InventoryTransaction(Base):
    """Inventory transaction model"""
    __tablename__ = "inventory_transactions"
    
    transaction_id = Column(Integer, primary_key=True, index=True)
    item_id = Column(Integer, ForeignKey("inventory_items.item_id"), nullable=False)
    transaction_type = Column(Enum(TransactionType), nullable=False)
    source_location_id = Column(Integer, ForeignKey("inventory_locations.location_id"), nullable=True)
    destination_location_id = Column(Integer, ForeignKey("inventory_locations.location_id"), nullable=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    notes = Column(Text, nullable=True)
    
    # Relationships
    item = relationship("InventoryItem", back_populates="transactions")
    source_location = relationship("InventoryLocation", foreign_keys=[source_location_id])
    destination_location = relationship("InventoryLocation", foreign_keys=[destination_location_id])
    employee = relationship("Employee", foreign_keys=[employee_id])
    
    def __repr__(self):
        return f"<InventoryTransaction {self.transaction_id} ({self.transaction_type})>"

class InventoryReport(Base):
    """Inventory report model"""
    __tablename__ = "inventory_reports"
    
    report_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    report_type = Column(String(50), nullable=False)
    parameters = Column(JSON, nullable=True)
    result = Column(JSON, nullable=True)
    created_by = Column(Integer, ForeignKey("employees.employee_id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    creator = relationship("Employee", foreign_keys=[created_by])
    
    def __repr__(self):
        return f"<InventoryReport {self.name} ({self.report_id})>"

# Models for API requests and responses

class InventoryItemCreate:
    """Schema for creating an inventory item"""
    def __init__(
        self,
        name: str,
        description: str = None,
        category: ItemCategory = None,
        manufacturer: str = None,
        model: str = None,
        serial_number: str = None,
        asset_tag: str = None,
        purchase_date: datetime = None,
        purchase_price: float = None,
        warranty_expiry: datetime = None,
        status: ItemStatus = ItemStatus.AVAILABLE,
        location_id: int = None,
        floor_plan_id: int = None,
        x_position: float = None,
        y_position: float = None,
        rotation: float = 0,
        properties: dict = None,
        notes: str = None,
        tag_ids: list = None
    ):
        self.name = name
        self.description = description
        self.category = category
        self.manufacturer = manufacturer
        self.model = model
        self.serial_number = serial_number
        self.asset_tag = asset_tag
        self.purchase_date = purchase_date
        self.purchase_price = purchase_price
        self.warranty_expiry = warranty_expiry
        self.status = status
        self.location_id = location_id
        self.floor_plan_id = floor_plan_id
        self.x_position = x_position
        self.y_position = y_position
        self.rotation = rotation
        self.properties = properties
        self.notes = notes
        self.tag_ids = tag_ids or []

class InventoryItemUpdate:
    """Schema for updating an inventory item"""
    def __init__(
        self,
        name: str = None,
        description: str = None,
        category: ItemCategory = None,
        manufacturer: str = None,
        model: str = None,
        serial_number: str = None,
        asset_tag: str = None,
        purchase_date: datetime = None,
        purchase_price: float = None,
        warranty_expiry: datetime = None,
        status: ItemStatus = None,
        location_id: int = None,
        floor_plan_id: int = None,
        x_position: float = None,
        y_position: float = None,
        rotation: float = None,
        properties: dict = None,
        notes: str = None,
        tag_ids: list = None
    ):
        self.name = name
        self.description = description
        self.category = category
        self.manufacturer = manufacturer
        self.model = model
        self.serial_number = serial_number
        self.asset_tag = asset_tag
        self.purchase_date = purchase_date
        self.purchase_price = purchase_price
        self.warranty_expiry = warranty_expiry
        self.status = status
        self.location_id = location_id
        self.floor_plan_id = floor_plan_id
        self.x_position = x_position
        self.y_position = y_position
        self.rotation = rotation
        self.properties = properties
        self.notes = notes
        self.tag_ids = tag_ids

class InventoryLocationCreate:
    """Schema for creating an inventory location"""
    def __init__(
        self,
        name: str,
        description: str = None,
        parent_id: int = None,
        floor_plan_id: int = None,
        x_position: float = None,
        y_position: float = None,
        width: float = None,
        height: float = None
    ):
        self.name = name
        self.description = description
        self.parent_id = parent_id
        self.floor_plan_id = floor_plan_id
        self.x_position = x_position
        self.y_position = y_position
        self.width = width
        self.height = height

class InventoryLocationUpdate:
    """Schema for updating an inventory location"""
    def __init__(
        self,
        name: str = None,
        description: str = None,
        parent_id: int = None,
        floor_plan_id: int = None,
        x_position: float = None,
        y_position: float = None,
        width: float = None,
        height: float = None,
        is_active: bool = None
    ):
        self.name = name
        self.description = description
        self.parent_id = parent_id
        self.floor_plan_id = floor_plan_id
        self.x_position = x_position
        self.y_position = y_position
        self.width = width
        self.height = height
        self.is_active = is_active

class InventoryTagCreate:
    """Schema for creating an inventory tag"""
    def __init__(
        self,
        name: str,
        color: str = None
    ):
        self.name = name
        self.color = color

class InventoryTagUpdate:
    """Schema for updating an inventory tag"""
    def __init__(
        self,
        name: str = None,
        color: str = None
    ):
        self.name = name
        self.color = color

class InventoryTransactionCreate:
    """Schema for creating an inventory transaction"""
    def __init__(
        self,
        item_id: int,
        transaction_type: TransactionType,
        source_location_id: int = None,
        destination_location_id: int = None,
        employee_id: int = None,
        notes: str = None
    ):
        self.item_id = item_id
        self.transaction_type = transaction_type
        self.source_location_id = source_location_id
        self.destination_location_id = destination_location_id
        self.employee_id = employee_id
        self.notes = notes

class InventorySearch:
    """Schema for searching inventory items"""
    def __init__(
        self,
        name: str = None,
        category: ItemCategory = None,
        status: ItemStatus = None,
        location_id: int = None,
        floor_plan_id: int = None,
        tag_ids: list = None,
        serial_number: str = None,
        asset_tag: str = None
    ):
        self.name = name
        self.category = category
        self.status = status
        self.location_id = location_id
        self.floor_plan_id = floor_plan_id
        self.tag_ids = tag_ids or []
        self.serial_number = serial_number
        self.asset_tag = asset_tag

class InventoryDashboard:
    """Schema for inventory dashboard data"""
    def __init__(
        self,
        total_items: int = 0,
        items_by_category: dict = None,
        items_by_status: dict = None,
        items_by_location: dict = None,
        recent_transactions: list = None,
        value_by_category: dict = None,
        expiring_warranties: list = None
    ):
        self.total_items = total_items
        self.items_by_category = items_by_category or {}
        self.items_by_status = items_by_status or {}
        self.items_by_location = items_by_location or {}
        self.recent_transactions = recent_transactions or []
        self.value_by_category = value_by_category or {}
        self.expiring_warranties = expiring_warranties or []
