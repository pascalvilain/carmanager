"""
Alpin Royal Casino Management System - Inventory Management Module Repositories
This module provides data access for inventory management.
"""

from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy import select, update, delete, func, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload, selectinload

from modules.inventory_management.models.inventory import (
    InventoryItem, InventoryLocation, InventoryTag, InventoryTransaction, InventoryReport,
    ItemCategory, ItemStatus, TransactionType,
    InventoryItemCreate, InventoryItemUpdate, InventoryLocationCreate, InventoryLocationUpdate,
    InventoryTagCreate, InventoryTagUpdate, InventoryTransactionCreate, InventorySearch
)

class InventoryItemRepository:
    """Repository for inventory items"""
    
    @staticmethod
    async def create(session: AsyncSession, item_data: InventoryItemCreate) -> InventoryItem:
        """Create a new inventory item"""
        # Create the item
        item = InventoryItem(
            name=item_data.name,
            description=item_data.description,
            category=item_data.category,
            manufacturer=item_data.manufacturer,
            model=item_data.model,
            serial_number=item_data.serial_number,
            asset_tag=item_data.asset_tag,
            purchase_date=item_data.purchase_date,
            purchase_price=item_data.purchase_price,
            warranty_expiry=item_data.warranty_expiry,
            status=item_data.status,
            location_id=item_data.location_id,
            floor_plan_id=item_data.floor_plan_id,
            x_position=item_data.x_position,
            y_position=item_data.y_position,
            rotation=item_data.rotation,
            properties=item_data.properties,
            notes=item_data.notes
        )
        
        session.add(item)
        await session.flush()
        
        # Add tags if provided
        if item_data.tag_ids:
            for tag_id in item_data.tag_ids:
                stmt = select(InventoryTag).where(InventoryTag.tag_id == tag_id)
                result = await session.execute(stmt)
                tag = result.scalar_one_or_none()
                if tag:
                    item.tags.append(tag)
        
        await session.commit()
        await session.refresh(item)
        return item
    
    @staticmethod
    async def get_by_id(session: AsyncSession, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item by ID"""
        stmt = select(InventoryItem).where(InventoryItem.item_id == item_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_by_serial_number(session: AsyncSession, serial_number: str) -> Optional[InventoryItem]:
        """Get an inventory item by serial number"""
        stmt = select(InventoryItem).where(InventoryItem.serial_number == serial_number)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_by_asset_tag(session: AsyncSession, asset_tag: str) -> Optional[InventoryItem]:
        """Get an inventory item by asset tag"""
        stmt = select(InventoryItem).where(InventoryItem.asset_tag == asset_tag)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[InventoryItem]:
        """Get all inventory items"""
        stmt = select(InventoryItem).offset(skip).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, item_id: int, item_data: InventoryItemUpdate) -> Optional[InventoryItem]:
        """Update an inventory item"""
        # Get the item
        stmt = select(InventoryItem).where(InventoryItem.item_id == item_id)
        result = await session.execute(stmt)
        item = result.scalar_one_or_none()
        
        if not item:
            return None
        
        # Update the item fields
        update_data = {}
        for key, value in vars(item_data).items():
            if value is not None and key != 'tag_ids':
                update_data[key] = value
        
        if update_data:
            stmt = update(InventoryItem).where(InventoryItem.item_id == item_id).values(**update_data)
            await session.execute(stmt)
        
        # Update tags if provided
        if item_data.tag_ids is not None:
            # Clear existing tags
            item.tags = []
            
            # Add new tags
            for tag_id in item_data.tag_ids:
                stmt = select(InventoryTag).where(InventoryTag.tag_id == tag_id)
                result = await session.execute(stmt)
                tag = result.scalar_one_or_none()
                if tag:
                    item.tags.append(tag)
        
        await session.commit()
        await session.refresh(item)
        return item
    
    @staticmethod
    async def delete(session: AsyncSession, item_id: int) -> bool:
        """Delete an inventory item"""
        stmt = delete(InventoryItem).where(InventoryItem.item_id == item_id)
        result = await session.execute(stmt)
        await session.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def get_by_category(session: AsyncSession, category: ItemCategory) -> List[InventoryItem]:
        """Get inventory items by category"""
        stmt = select(InventoryItem).where(InventoryItem.category == category)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_status(session: AsyncSession, status: ItemStatus) -> List[InventoryItem]:
        """Get inventory items by status"""
        stmt = select(InventoryItem).where(InventoryItem.status == status)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_location(session: AsyncSession, location_id: int) -> List[InventoryItem]:
        """Get inventory items by location"""
        stmt = select(InventoryItem).where(InventoryItem.location_id == location_id)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_floor_plan(session: AsyncSession, floor_plan_id: int) -> List[InventoryItem]:
        """Get inventory items by floor plan"""
        stmt = select(InventoryItem).where(InventoryItem.floor_plan_id == floor_plan_id)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_tag(session: AsyncSession, tag_id: int) -> List[InventoryItem]:
        """Get inventory items by tag"""
        stmt = select(InventoryItem).join(InventoryItem.tags).where(InventoryTag.tag_id == tag_id)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_with_location(session: AsyncSession, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item with its location"""
        stmt = select(InventoryItem).options(joinedload(InventoryItem.location)).where(InventoryItem.item_id == item_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_with_tags(session: AsyncSession, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item with its tags"""
        stmt = select(InventoryItem).options(selectinload(InventoryItem.tags)).where(InventoryItem.item_id == item_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_with_transactions(session: AsyncSession, item_id: int) -> Optional[InventoryItem]:
        """Get an inventory item with its transactions"""
        stmt = select(InventoryItem).options(selectinload(InventoryItem.transactions)).where(InventoryItem.item_id == item_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def search(session: AsyncSession, search_params: InventorySearch, skip: int = 0, limit: int = 100) -> List[InventoryItem]:
        """Search for inventory items based on various criteria"""
        conditions = []
        
        if search_params.name:
            conditions.append(InventoryItem.name.ilike(f"%{search_params.name}%"))
        
        if search_params.category:
            conditions.append(InventoryItem.category == search_params.category)
        
        if search_params.status:
            conditions.append(InventoryItem.status == search_params.status)
        
        if search_params.location_id:
            conditions.append(InventoryItem.location_id == search_params.location_id)
        
        if search_params.floor_plan_id:
            conditions.append(InventoryItem.floor_plan_id == search_params.floor_plan_id)
        
        if search_params.serial_number:
            conditions.append(InventoryItem.serial_number.ilike(f"%{search_params.serial_number}%"))
        
        if search_params.asset_tag:
            conditions.append(InventoryItem.asset_tag.ilike(f"%{search_params.asset_tag}%"))
        
        query = select(InventoryItem)
        
        if conditions:
            query = query.where(and_(*conditions))
        
        if search_params.tag_ids:
            query = query.join(InventoryItem.tags).where(InventoryTag.tag_id.in_(search_params.tag_ids))
        
        query = query.offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_item_counts_by_category(session: AsyncSession) -> Dict[str, int]:
        """Get item counts by category"""
        stmt = select(InventoryItem.category, func.count(InventoryItem.item_id)).group_by(InventoryItem.category)
        result = await session.execute(stmt)
        return {category.value: count for category, count in result.all()}
    
    @staticmethod
    async def get_item_counts_by_status(session: AsyncSession) -> Dict[str, int]:
        """Get item counts by status"""
        stmt = select(InventoryItem.status, func.count(InventoryItem.item_id)).group_by(InventoryItem.status)
        result = await session.execute(stmt)
        return {status.value: count for status, count in result.all()}
    
    @staticmethod
    async def get_item_counts_by_location(session: AsyncSession) -> Dict[int, int]:
        """Get item counts by location"""
        stmt = select(InventoryItem.location_id, func.count(InventoryItem.item_id)).group_by(InventoryItem.location_id)
        result = await session.execute(stmt)
        return {location_id: count for location_id, count in result.all() if location_id is not None}
    
    @staticmethod
    async def get_total_value_by_category(session: AsyncSession) -> Dict[str, float]:
        """Get total value by category"""
        stmt = select(InventoryItem.category, func.sum(InventoryItem.purchase_price)).group_by(InventoryItem.category)
        result = await session.execute(stmt)
        return {category.value: float(value) if value else 0 for category, value in result.all()}
    
    @staticmethod
    async def get_expiring_warranties(session: AsyncSession, days: int = 30) -> List[InventoryItem]:
        """Get items with warranties expiring within the specified number of days"""
        from datetime import datetime, timedelta
        
        expiry_date = datetime.utcnow() + timedelta(days=days)
        stmt = select(InventoryItem).where(
            and_(
                InventoryItem.warranty_expiry.is_not(None),
                InventoryItem.warranty_expiry <= expiry_date
            )
        ).order_by(InventoryItem.warranty_expiry)
        
        result = await session.execute(stmt)
        return result.scalars().all()

class InventoryLocationRepository:
    """Repository for inventory locations"""
    
    @staticmethod
    async def create(session: AsyncSession, location_data: InventoryLocationCreate) -> InventoryLocation:
        """Create a new inventory location"""
        location = InventoryLocation(
            name=location_data.name,
            description=location_data.description,
            parent_id=location_data.parent_id,
            floor_plan_id=location_data.floor_plan_id,
            x_position=location_data.x_position,
            y_position=location_data.y_position,
            width=location_data.width,
            height=location_data.height
        )
        
        session.add(location)
        await session.commit()
        await session.refresh(location)
        return location
    
    @staticmethod
    async def get_by_id(session: AsyncSession, location_id: int) -> Optional[InventoryLocation]:
        """Get an inventory location by ID"""
        stmt = select(InventoryLocation).where(InventoryLocation.location_id == location_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[InventoryLocation]:
        """Get all inventory locations"""
        stmt = select(InventoryLocation).offset(skip).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, location_id: int, location_data: InventoryLocationUpdate) -> Optional[InventoryLocation]:
        """Update an inventory location"""
        # Get the location
        stmt = select(InventoryLocation).where(InventoryLocation.location_id == location_id)
        result = await session.execute(stmt)
        location = result.scalar_one_or_none()
        
        if not location:
            return None
        
        # Update the location fields
        update_data = {}
        for key, value in vars(location_data).items():
            if value is not None:
                update_data[key] = value
        
        if update_data:
            stmt = update(InventoryLocation).where(InventoryLocation.location_id == location_id).values(**update_data)
            await session.execute(stmt)
        
        await session.commit()
        await session.refresh(location)
        return location
    
    @staticmethod
    async def delete(session: AsyncSession, location_id: int) -> bool:
        """Delete an inventory location"""
        # Check if the location has items
        stmt = select(func.count(InventoryItem.item_id)).where(InventoryItem.location_id == location_id)
        result = await session.execute(stmt)
        item_count = result.scalar_one()
        
        if item_count > 0:
            return False
        
        # Check if the location has children
        stmt = select(func.count(InventoryLocation.location_id)).where(InventoryLocation.parent_id == location_id)
        result = await session.execute(stmt)
        child_count = result.scalar_one()
        
        if child_count > 0:
            return False
        
        # Delete the location
        stmt = delete(InventoryLocation).where(InventoryLocation.location_id == location_id)
        result = await session.execute(stmt)
        await session.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def get_by_parent(session: AsyncSession, parent_id: int) -> List[InventoryLocation]:
        """Get inventory locations by parent ID"""
        stmt = select(InventoryLocation).where(InventoryLocation.parent_id == parent_id)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_floor_plan(session: AsyncSession, floor_plan_id: int) -> List[InventoryLocation]:
        """Get inventory locations by floor plan ID"""
        stmt = select(InventoryLocation).where(InventoryLocation.floor_plan_id == floor_plan_id)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_root_locations(session: AsyncSession) -> List[InventoryLocation]:
        """Get root inventory locations (no parent)"""
        stmt = select(InventoryLocation).where(InventoryLocation.parent_id.is_(None))
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_with_items(session: AsyncSession, location_id: int) -> Optional[InventoryLocation]:
        """Get an inventory location with its items"""
        stmt = select(InventoryLocation).options(selectinload(InventoryLocation.items)).where(InventoryLocation.location_id == location_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_with_children(session: AsyncSession, location_id: int) -> Optional[InventoryLocation]:
        """Get an inventory location with its children"""
        stmt = select(InventoryLocation).options(selectinload(InventoryLocation.children)).where(InventoryLocation.location_id == location_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_location_hierarchy(session: AsyncSession) -> List[Dict[str, Any]]:
        """Get the complete location hierarchy"""
        # Get all locations
        stmt = select(InventoryLocation).order_by(InventoryLocation.name)
        result = await session.execute(stmt)
        locations = result.scalars().all()
        
        # Build a dictionary of locations by ID
        location_dict = {location.location_id: {
            "id": location.location_id,
            "name": location.name,
            "description": location.description,
            "parent_id": location.parent_id,
            "floor_plan_id": location.floor_plan_id,
            "children": []
        } for location in locations}
        
        # Build the hierarchy
        root_locations = []
        for location_id, location_data in location_dict.items():
            if location_data["parent_id"] is None:
                root_locations.append(location_data)
            else:
                parent = location_dict.get(location_data["parent_id"])
                if parent:
                    parent["children"].append(location_data)
        
        return root_locations

class InventoryTagRepository:
    """Repository for inventory tags"""
    
    @staticmethod
    async def create(session: AsyncSession, tag_data: InventoryTagCreate) -> InventoryTag:
        """Create a new inventory tag"""
        tag = InventoryTag(
            name=tag_data.name,
            color=tag_data.color
        )
        
        session.add(tag)
        await session.commit()
        await session.refresh(tag)
        return tag
    
    @staticmethod
    async def get_by_id(session: AsyncSession, tag_id: int) -> Optional[InventoryTag]:
        """Get an inventory tag by ID"""
        stmt = select(InventoryTag).where(InventoryTag.tag_id == tag_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_by_name(session: AsyncSession, name: str) -> Optional[InventoryTag]:
        """Get an inventory tag by name"""
        stmt = select(InventoryTag).where(InventoryTag.name == name)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_all(session: AsyncSession) -> List[InventoryTag]:
        """Get all inventory tags"""
        stmt = select(InventoryTag).order_by(InventoryTag.name)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, tag_id: int, tag_data: InventoryTagUpdate) -> Optional[InventoryTag]:
        """Update an inventory tag"""
        # Get the tag
        stmt = select(InventoryTag).where(InventoryTag.tag_id == tag_id)
        result = await session.execute(stmt)
        tag = result.scalar_one_or_none()
        
        if not tag:
            return None
        
        # Update the tag fields
        update_data = {}
        for key, value in vars(tag_data).items():
            if value is not None:
                update_data[key] = value
        
        if update_data:
            stmt = update(InventoryTag).where(InventoryTag.tag_id == tag_id).values(**update_data)
            await session.execute(stmt)
        
        await session.commit()
        await session.refresh(tag)
        return tag
    
    @staticmethod
    async def delete(session: AsyncSession, tag_id: int) -> bool:
        """Delete an inventory tag"""
        stmt = delete(InventoryTag).where(InventoryTag.tag_id == tag_id)
        result = await session.execute(stmt)
        await session.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def get_with_items(session: AsyncSession, tag_id: int) -> Optional[InventoryTag]:
        """Get an inventory tag with its items"""
        stmt = select(InventoryTag).options(selectinload(InventoryTag.items)).where(InventoryTag.tag_id == tag_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()

class InventoryTransactionRepository:
    """Repository for inventory transactions"""
    
    @staticmethod
    async def create(session: AsyncSession, transaction_data: InventoryTransactionCreate) -> InventoryTransaction:
        """Create a new inventory transaction"""
        transaction = InventoryTransaction(
            item_id=transaction_data.item_id,
            transaction_type=transaction_data.transaction_type,
            source_location_id=transaction_data.source_location_id,
            destination_location_id=transaction_data.destination_location_id,
            employee_id=transaction_data.employee_id,
            notes=transaction_data.notes
        )
        
        session.add(transaction)
        await session.commit()
        await session.refresh(transaction)
        return transaction
    
    @staticmethod
    async def get_by_id(session: AsyncSession, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction by ID"""
        stmt = select(InventoryTransaction).where(InventoryTransaction.transaction_id == transaction_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[InventoryTransaction]:
        """Get all inventory transactions"""
        stmt = select(InventoryTransaction).order_by(InventoryTransaction.timestamp.desc()).offset(skip).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_item(session: AsyncSession, item_id: int) -> List[InventoryTransaction]:
        """Get inventory transactions by item ID"""
        stmt = select(InventoryTransaction).where(InventoryTransaction.item_id == item_id).order_by(InventoryTransaction.timestamp.desc())
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_location(session: AsyncSession, location_id: int) -> List[InventoryTransaction]:
        """Get inventory transactions by location ID (source or destination)"""
        stmt = select(InventoryTransaction).where(
            or_(
                InventoryTransaction.source_location_id == location_id,
                InventoryTransaction.destination_location_id == location_id
            )
        ).order_by(InventoryTransaction.timestamp.desc())
        
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_employee(session: AsyncSession, employee_id: int) -> List[InventoryTransaction]:
        """Get inventory transactions by employee ID"""
        stmt = select(InventoryTransaction).where(InventoryTransaction.employee_id == employee_id).order_by(InventoryTransaction.timestamp.desc())
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_type(session: AsyncSession, transaction_type: TransactionType) -> List[InventoryTransaction]:
        """Get inventory transactions by type"""
        stmt = select(InventoryTransaction).where(InventoryTransaction.transaction_type == transaction_type).order_by(InventoryTransaction.timestamp.desc())
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_with_item(session: AsyncSession, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction with its item"""
        stmt = select(InventoryTransaction).options(joinedload(InventoryTransaction.item)).where(InventoryTransaction.transaction_id == transaction_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_with_locations(session: AsyncSession, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction with its source and destination locations"""
        stmt = select(InventoryTransaction).options(
            joinedload(InventoryTransaction.source_location),
            joinedload(InventoryTransaction.destination_location)
        ).where(InventoryTransaction.transaction_id == transaction_id)
        
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_with_employee(session: AsyncSession, transaction_id: int) -> Optional[InventoryTransaction]:
        """Get an inventory transaction with its employee"""
        stmt = select(InventoryTransaction).options(joinedload(InventoryTransaction.employee)).where(InventoryTransaction.transaction_id == transaction_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_recent_transactions(session: AsyncSession, limit: int = 10) -> List[InventoryTransaction]:
        """Get recent inventory transactions"""
        stmt = select(InventoryTransaction).order_by(InventoryTransaction.timestamp.desc()).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()

class InventoryReportRepository:
    """Repository for inventory reports"""
    
    @staticmethod
    async def create(session: AsyncSession, name: str, description: str, report_type: str, parameters: Dict[str, Any], result: Dict[str, Any], created_by: int) -> InventoryReport:
        """Create a new inventory report"""
        report = InventoryReport(
            name=name,
            description=description,
            report_type=report_type,
            parameters=parameters,
            result=result,
            created_by=created_by
        )
        
        session.add(report)
        await session.commit()
        await session.refresh(report)
        return report
    
    @staticmethod
    async def get_by_id(session: AsyncSession, report_id: int) -> Optional[InventoryReport]:
        """Get an inventory report by ID"""
        stmt = select(InventoryReport).where(InventoryReport.report_id == report_id)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[InventoryReport]:
        """Get all inventory reports"""
        stmt = select(InventoryReport).order_by(InventoryReport.created_at.desc()).offset(skip).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_type(session: AsyncSession, report_type: str) -> List[InventoryReport]:
        """Get inventory reports by type"""
        stmt = select(InventoryReport).where(InventoryReport.report_type == report_type).order_by(InventoryReport.created_at.desc())
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_creator(session: AsyncSession, created_by: int) -> List[InventoryReport]:
        """Get inventory reports by creator"""
        stmt = select(InventoryReport).where(InventoryReport.created_by == created_by).order_by(InventoryReport.created_at.desc())
        result = await session.execute(stmt)
        return result.scalars().all()
    
    @staticmethod
    async def delete(session: AsyncSession, report_id: int) -> bool:
        """Delete an inventory report"""
        stmt = delete(InventoryReport).where(InventoryReport.report_id == report_id)
        result = await session.execute(stmt)
        await session.commit()
        return result.rowcount > 0
