"""
Alpin Royal Casino Management System - Inventory Management Module API
This module provides API endpoints for inventory management.
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, Path
from sqlalchemy.ext.asyncio import AsyncSession

from modules.inventory_management.models.inventory import (
    InventoryItem, InventoryLocation, InventoryTag, InventoryTransaction, InventoryReport,
    ItemCategory, ItemStatus, TransactionType,
    InventoryItemCreate, InventoryItemUpdate, InventoryLocationCreate, InventoryLocationUpdate,
    InventoryTagCreate, InventoryTagUpdate, InventoryTransactionCreate, InventorySearch,
    InventoryDashboard
)
from modules.inventory_management.services.inventory_service import InventoryService
from base_layer.utils.database import get_db_session
from base_layer.utils.storage import get_storage_manager
from base_layer.utils.event_bus import get_event_bus
from base_layer.auth.auth_manager import get_current_user, User

router = APIRouter(prefix="/api/inventory", tags=["inventory"])

# Helper function to get the inventory service
async def get_inventory_service(
    session: AsyncSession = Depends(get_db_session),
    storage_manager = Depends(get_storage_manager),
    event_bus = Depends(get_event_bus)
) -> InventoryService:
    """Get the inventory service"""
    return InventoryService(session, storage_manager, event_bus)

# Item Endpoints

@router.post("/items", response_model=InventoryItem)
async def create_item(
    name: str = Form(...),
    description: str = Form(None),
    category: ItemCategory = Form(...),
    manufacturer: str = Form(None),
    model: str = Form(None),
    serial_number: str = Form(None),
    asset_tag: str = Form(None),
    purchase_date: str = Form(None),
    purchase_price: float = Form(None),
    warranty_expiry: str = Form(None),
    status: ItemStatus = Form(ItemStatus.AVAILABLE),
    location_id: int = Form(None),
    floor_plan_id: int = Form(None),
    x_position: float = Form(None),
    y_position: float = Form(None),
    rotation: float = Form(0),
    properties: str = Form(None),
    notes: str = Form(None),
    tag_ids: List[int] = Form([]),
    image: UploadFile = File(None),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new inventory item"""
    import json
    from datetime import datetime
    
    # Parse dates
    purchase_date_obj = None
    if purchase_date:
        purchase_date_obj = datetime.fromisoformat(purchase_date)
    
    warranty_expiry_obj = None
    if warranty_expiry:
        warranty_expiry_obj = datetime.fromisoformat(warranty_expiry)
    
    # Parse properties
    properties_obj = None
    if properties:
        try:
            properties_obj = json.loads(properties)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON in properties field")
    
    item_data = InventoryItemCreate(
        name=name,
        description=description,
        category=category,
        manufacturer=manufacturer,
        model=model,
        serial_number=serial_number,
        asset_tag=asset_tag,
        purchase_date=purchase_date_obj,
        purchase_price=purchase_price,
        warranty_expiry=warranty_expiry_obj,
        status=status,
        location_id=location_id,
        floor_plan_id=floor_plan_id,
        x_position=x_position,
        y_position=y_position,
        rotation=rotation,
        properties=properties_obj,
        notes=notes,
        tag_ids=tag_ids
    )
    
    return await service.create_item(item_data, image)

@router.get("/items", response_model=List[InventoryItem])
async def get_all_items(
    skip: int = 0,
    limit: int = 100,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get all inventory items"""
    return await service.get_all_items(skip, limit)

@router.get("/items/{item_id}", response_model=InventoryItem)
async def get_item(
    item_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory item by ID"""
    item = await service.get_item(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@router.put("/items/{item_id}", response_model=InventoryItem)
async def update_item(
    item_id: int = Path(...),
    name: str = Form(None),
    description: str = Form(None),
    category: ItemCategory = Form(None),
    manufacturer: str = Form(None),
    model: str = Form(None),
    serial_number: str = Form(None),
    asset_tag: str = Form(None),
    purchase_date: str = Form(None),
    purchase_price: float = Form(None),
    warranty_expiry: str = Form(None),
    status: ItemStatus = Form(None),
    location_id: int = Form(None),
    floor_plan_id: int = Form(None),
    x_position: float = Form(None),
    y_position: float = Form(None),
    rotation: float = Form(None),
    properties: str = Form(None),
    notes: str = Form(None),
    tag_ids: List[int] = Form(None),
    image: UploadFile = File(None),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Update an inventory item"""
    import json
    from datetime import datetime
    
    # Parse dates
    purchase_date_obj = None
    if purchase_date:
        purchase_date_obj = datetime.fromisoformat(purchase_date)
    
    warranty_expiry_obj = None
    if warranty_expiry:
        warranty_expiry_obj = datetime.fromisoformat(warranty_expiry)
    
    # Parse properties
    properties_obj = None
    if properties:
        try:
            properties_obj = json.loads(properties)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON in properties field")
    
    item_data = InventoryItemUpdate(
        name=name,
        description=description,
        category=category,
        manufacturer=manufacturer,
        model=model,
        serial_number=serial_number,
        asset_tag=asset_tag,
        purchase_date=purchase_date_obj,
        purchase_price=purchase_price,
        warranty_expiry=warranty_expiry_obj,
        status=status,
        location_id=location_id,
        floor_plan_id=floor_plan_id,
        x_position=x_position,
        y_position=y_position,
        rotation=rotation,
        properties=properties_obj,
        notes=notes,
        tag_ids=tag_ids
    )
    
    item = await service.update_item(item_id, item_data, image)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@router.delete("/items/{item_id}", response_model=Dict[str, bool])
async def delete_item(
    item_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Delete an inventory item"""
    result = await service.delete_item(item_id)
    if not result:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"success": True}

@router.get("/items/search", response_model=List[InventoryItem])
async def search_items(
    name: Optional[str] = None,
    category: Optional[ItemCategory] = None,
    status: Optional[ItemStatus] = None,
    location_id: Optional[int] = None,
    floor_plan_id: Optional[int] = None,
    serial_number: Optional[str] = None,
    asset_tag: Optional[str] = None,
    tag_ids: List[int] = Query([]),
    skip: int = 0,
    limit: int = 100,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Search for inventory items based on various criteria"""
    search_params = InventorySearch(
        name=name,
        category=category,
        status=status,
        location_id=location_id,
        floor_plan_id=floor_plan_id,
        serial_number=serial_number,
        asset_tag=asset_tag,
        tag_ids=tag_ids
    )
    return await service.search_items(search_params, skip, limit)

@router.get("/items/category/{category}", response_model=List[InventoryItem])
async def get_items_by_category(
    category: ItemCategory = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory items by category"""
    return await service.get_items_by_category(category)

@router.get("/items/status/{status}", response_model=List[InventoryItem])
async def get_items_by_status(
    status: ItemStatus = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory items by status"""
    return await service.get_items_by_status(status)

@router.get("/items/location/{location_id}", response_model=List[InventoryItem])
async def get_items_by_location(
    location_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory items by location"""
    return await service.get_items_by_location(location_id)

@router.get("/items/floor-plan/{floor_plan_id}", response_model=List[InventoryItem])
async def get_items_by_floor_plan(
    floor_plan_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory items by floor plan"""
    return await service.get_items_by_floor_plan(floor_plan_id)

@router.get("/items/tag/{tag_id}", response_model=List[InventoryItem])
async def get_items_by_tag(
    tag_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory items by tag"""
    return await service.get_items_by_tag(tag_id)

@router.get("/items/{item_id}/with-location", response_model=InventoryItem)
async def get_item_with_location(
    item_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory item with its location"""
    item = await service.get_item_with_location(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@router.get("/items/{item_id}/with-tags", response_model=InventoryItem)
async def get_item_with_tags(
    item_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory item with its tags"""
    item = await service.get_item_with_tags(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@router.get("/items/{item_id}/with-transactions", response_model=InventoryItem)
async def get_item_with_transactions(
    item_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory item with its transactions"""
    item = await service.get_item_with_transactions(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

# Location Endpoints

@router.post("/locations", response_model=InventoryLocation)
async def create_location(
    location_data: InventoryLocationCreate,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new inventory location"""
    return await service.create_location(location_data)

@router.get("/locations", response_model=List[InventoryLocation])
async def get_all_locations(
    skip: int = 0,
    limit: int = 100,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get all inventory locations"""
    return await service.get_all_locations(skip, limit)

@router.get("/locations/{location_id}", response_model=InventoryLocation)
async def get_location(
    location_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory location by ID"""
    location = await service.get_location(location_id)
    if not location:
        raise HTTPException(status_code=404, detail="Location not found")
    return location

@router.put("/locations/{location_id}", response_model=InventoryLocation)
async def update_location(
    location_id: int,
    location_data: InventoryLocationUpdate,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Update an inventory location"""
    location = await service.update_location(location_id, location_data)
    if not location:
        raise HTTPException(status_code=404, detail="Location not found")
    return location

@router.delete("/locations/{location_id}", response_model=Dict[str, bool])
async def delete_location(
    location_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Delete an inventory location"""
    try:
        result = await service.delete_location(location_id)
        if not result:
            raise HTTPException(status_code=404, detail="Location not found")
        return {"success": True}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/locations/parent/{parent_id}", response_model=List[InventoryLocation])
async def get_locations_by_parent(
    parent_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory locations by parent ID"""
    return await service.get_locations_by_parent(parent_id)

@router.get("/locations/floor-plan/{floor_plan_id}", response_model=List[InventoryLocation])
async def get_locations_by_floor_plan(
    floor_plan_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory locations by floor plan ID"""
    return await service.get_locations_by_floor_plan(floor_plan_id)

@router.get("/locations/root", response_model=List[InventoryLocation])
async def get_root_locations(
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get root inventory locations (no parent)"""
    return await service.get_root_locations()

@router.get("/locations/{location_id}/with-items", response_model=InventoryLocation)
async def get_location_with_items(
    location_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory location with its items"""
    location = await service.get_location_with_items(location_id)
    if not location:
        raise HTTPException(status_code=404, detail="Location not found")
    return location

@router.get("/locations/{location_id}/with-children", response_model=InventoryLocation)
async def get_location_with_children(
    location_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory location with its children"""
    location = await service.get_location_with_children(location_id)
    if not location:
        raise HTTPException(status_code=404, detail="Location not found")
    return location

@router.get("/locations/hierarchy", response_model=List[Dict[str, Any]])
async def get_location_hierarchy(
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get the complete location hierarchy"""
    return await service.get_location_hierarchy()

# Tag Endpoints

@router.post("/tags", response_model=InventoryTag)
async def create_tag(
    tag_data: InventoryTagCreate,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new inventory tag"""
    return await service.create_tag(tag_data)

@router.get("/tags", response_model=List[InventoryTag])
async def get_all_tags(
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get all inventory tags"""
    return await service.get_all_tags()

@router.get("/tags/{tag_id}", response_model=InventoryTag)
async def get_tag(
    tag_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory tag by ID"""
    tag = await service.get_tag(tag_id)
    if not tag:
        raise HTTPException(status_code=404, detail="Tag not found")
    return tag

@router.put("/tags/{tag_id}", response_model=InventoryTag)
async def update_tag(
    tag_id: int,
    tag_data: InventoryTagUpdate,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Update an inventory tag"""
    tag = await service.update_tag(tag_id, tag_data)
    if not tag:
        raise HTTPException(status_code=404, detail="Tag not found")
    return tag

@router.delete("/tags/{tag_id}", response_model=Dict[str, bool])
async def delete_tag(
    tag_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Delete an inventory tag"""
    try:
        result = await service.delete_tag(tag_id)
        if not result:
            raise HTTPException(status_code=404, detail="Tag not found")
        return {"success": True}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/tags/{tag_id}/with-items", response_model=InventoryTag)
async def get_tag_with_items(
    tag_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory tag with its items"""
    tag = await service.get_tag_with_items(tag_id)
    if not tag:
        raise HTTPException(status_code=404, detail="Tag not found")
    return tag

# Transaction Endpoints

@router.post("/transactions", response_model=InventoryTransaction)
async def create_transaction(
    transaction_data: InventoryTransactionCreate,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new inventory transaction"""
    return await service.create_transaction(transaction_data)

@router.get("/transactions", response_model=List[InventoryTransaction])
async def get_all_transactions(
    skip: int = 0,
    limit: int = 100,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get all inventory transactions"""
    return await service.get_all_transactions(skip, limit)

@router.get("/transactions/{transaction_id}", response_model=InventoryTransaction)
async def get_transaction(
    transaction_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory transaction by ID"""
    transaction = await service.get_transaction(transaction_id)
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return transaction

@router.get("/transactions/item/{item_id}", response_model=List[InventoryTransaction])
async def get_transactions_by_item(
    item_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory transactions by item ID"""
    return await service.get_transactions_by_item(item_id)

@router.get("/transactions/location/{location_id}", response_model=List[InventoryTransaction])
async def get_transactions_by_location(
    location_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory transactions by location ID (source or destination)"""
    return await service.get_transactions_by_location(location_id)

@router.get("/transactions/employee/{employee_id}", response_model=List[InventoryTransaction])
async def get_transactions_by_employee(
    employee_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory transactions by employee ID"""
    return await service.get_transactions_by_employee(employee_id)

@router.get("/transactions/type/{transaction_type}", response_model=List[InventoryTransaction])
async def get_transactions_by_type(
    transaction_type: TransactionType = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory transactions by type"""
    return await service.get_transactions_by_type(transaction_type)

@router.get("/transactions/{transaction_id}/with-item", response_model=InventoryTransaction)
async def get_transaction_with_item(
    transaction_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory transaction with its item"""
    transaction = await service.get_transaction_with_item(transaction_id)
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return transaction

@router.get("/transactions/{transaction_id}/with-locations", response_model=InventoryTransaction)
async def get_transaction_with_locations(
    transaction_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory transaction with its source and destination locations"""
    transaction = await service.get_transaction_with_locations(transaction_id)
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return transaction

@router.get("/transactions/{transaction_id}/with-employee", response_model=InventoryTransaction)
async def get_transaction_with_employee(
    transaction_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory transaction with its employee"""
    transaction = await service.get_transaction_with_employee(transaction_id)
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return transaction

@router.get("/transactions/recent", response_model=List[InventoryTransaction])
async def get_recent_transactions(
    limit: int = 10,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get recent inventory transactions"""
    return await service.get_recent_transactions(limit)

# Report Endpoints

@router.post("/reports", response_model=InventoryReport)
async def create_report(
    name: str,
    description: str,
    report_type: str,
    parameters: Dict[str, Any],
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new inventory report"""
    return await service.create_report(name, description, report_type, parameters, current_user.id)

@router.get("/reports", response_model=List[InventoryReport])
async def get_all_reports(
    skip: int = 0,
    limit: int = 100,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get all inventory reports"""
    return await service.get_all_reports(skip, limit)

@router.get("/reports/{report_id}", response_model=InventoryReport)
async def get_report(
    report_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get an inventory report by ID"""
    report = await service.get_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report

@router.get("/reports/type/{report_type}", response_model=List[InventoryReport])
async def get_reports_by_type(
    report_type: str = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory reports by type"""
    return await service.get_reports_by_type(report_type)

@router.get("/reports/creator/{created_by}", response_model=List[InventoryReport])
async def get_reports_by_creator(
    created_by: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory reports by creator"""
    return await service.get_reports_by_creator(created_by)

@router.delete("/reports/{report_id}", response_model=Dict[str, bool])
async def delete_report(
    report_id: int = Path(...),
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Delete an inventory report"""
    result = await service.delete_report(report_id)
    if not result:
        raise HTTPException(status_code=404, detail="Report not found")
    return {"success": True}

# Dashboard Endpoints

@router.get("/dashboard", response_model=InventoryDashboard)
async def get_inventory_dashboard(
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Get inventory dashboard data"""
    return await service.get_inventory_dashboard()

# Export Endpoints

@router.get("/export", response_model=Dict[str, Any])
async def export_inventory_data(
    location_id: Optional[int] = None,
    service: InventoryService = Depends(get_inventory_service),
    current_user: User = Depends(get_current_user)
):
    """Export inventory data for a location or the entire inventory"""
    return await service.export_inventory_data(location_id)
