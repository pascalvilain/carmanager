"""
Alpin Royal Casino Management System - Financial Models
This module defines the data models for financial transactions in the Player Tracking module.
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

class TransactionType(str, Enum):
    BUY_IN = "buy_in"
    CASH_OUT = "cash_out"
    COMP = "comp"
    CREDIT = "credit"
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    JACKPOT = "jackpot"
    HAND_PAY = "hand_pay"
    OTHER = "other"

class PaymentMethod(str, Enum):
    CASH = "cash"
    CREDIT_CARD = "credit_card"
    DEBIT_CARD = "debit_card"
    BANK_TRANSFER = "bank_transfer"
    CHIPS = "chips"
    COMP = "comp"
    OTHER = "other"

class FinancialTransactionBase(BaseModel):
    """Base model for financial transactions"""
    player_id: int
    session_id: Optional[int] = None
    transaction_type: TransactionType
    amount: float
    transaction_time: datetime = Field(default_factory=datetime.now)
    location: Optional[str] = None
    payment_method: Optional[PaymentMethod] = None
    reference_number: Optional[str] = None
    staff_id: Optional[int] = None
    notes: Optional[str] = None

class FinancialTransactionCreate(FinancialTransactionBase):
    """Model for creating a new financial transaction"""
    pass

class FinancialTransactionUpdate(BaseModel):
    """Model for updating a financial transaction"""
    transaction_type: Optional[TransactionType] = None
    amount: Optional[float] = None
    transaction_time: Optional[datetime] = None
    location: Optional[str] = None
    payment_method: Optional[PaymentMethod] = None
    reference_number: Optional[str] = None
    staff_id: Optional[int] = None
    notes: Optional[str] = None

class FinancialTransaction(FinancialTransactionBase):
    """Complete financial transaction model with all fields"""
    transaction_id: int = Field(..., description="Unique identifier for the financial transaction")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class JackpotType(str, Enum):
    PROGRESSIVE = "progressive"
    HAND_PAY = "hand_pay"
    BONUS = "bonus"
    OTHER = "other"

class JackpotHandPayBase(BaseModel):
    """Base model for jackpots and hand pays"""
    player_id: int
    session_id: Optional[int] = None
    machine_id: Optional[int] = None
    table_id: Optional[int] = None
    amount: float
    jackpot_time: datetime = Field(default_factory=datetime.now)
    jackpot_type: JackpotType
    game_outcome: Optional[str] = None
    staff_id: Optional[int] = None
    photo_id: Optional[int] = None
    notes: Optional[str] = None

class JackpotHandPayCreate(JackpotHandPayBase):
    """Model for creating a new jackpot or hand pay"""
    pass

class JackpotHandPayUpdate(BaseModel):
    """Model for updating a jackpot or hand pay"""
    amount: Optional[float] = None
    jackpot_time: Optional[datetime] = None
    jackpot_type: Optional[JackpotType] = None
    game_outcome: Optional[str] = None
    staff_id: Optional[int] = None
    photo_id: Optional[int] = None
    notes: Optional[str] = None

class JackpotHandPay(JackpotHandPayBase):
    """Complete jackpot or hand pay model with all fields"""
    jackpot_id: int = Field(..., description="Unique identifier for the jackpot or hand pay")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class FinancialSummary(BaseModel):
    """Summary of financial activity for a player"""
    total_buy_in: float = 0
    total_cash_out: float = 0
    total_jackpots: float = 0
    total_hand_pays: float = 0
    total_comps: float = 0
    net_win_loss: float = 0
    transaction_count: int = 0
    last_transaction_time: Optional[datetime] = None

class FinancialSearch(BaseModel):
    """Model for financial transaction search parameters"""
    player_id: Optional[int] = None
    session_id: Optional[int] = None
    transaction_type: Optional[TransactionType] = None
    min_amount: Optional[float] = None
    max_amount: Optional[float] = None
    min_transaction_time: Optional[datetime] = None
    max_transaction_time: Optional[datetime] = None
    payment_method: Optional[PaymentMethod] = None
    staff_id: Optional[int] = None
    page: int = 1
    page_size: int = 20
"""
