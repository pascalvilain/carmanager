"""
Alpin Royal Casino Management System - Consumption Models
This module defines the data models for consumption tracking in the Player Tracking module.
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

class ItemType(str, Enum):
    FOOD = "food"
    BEVERAGE = "beverage"
    CIGARETTE = "cigarette"
    OTHER = "other"

class ConsumptionItemBase(BaseModel):
    """Base model for consumption items"""
    item_name: str
    item_type: ItemType
    category: Optional[str] = None
    price: Optional[float] = None
    is_active: bool = True

class ConsumptionItemCreate(ConsumptionItemBase):
    """Model for creating a new consumption item"""
    pass

class ConsumptionItemUpdate(BaseModel):
    """Model for updating a consumption item"""
    item_name: Optional[str] = None
    item_type: Optional[ItemType] = None
    category: Optional[str] = None
    price: Optional[float] = None
    is_active: Optional[bool] = None

class ConsumptionItem(ConsumptionItemBase):
    """Complete consumption item model with all fields"""
    item_id: int = Field(..., description="Unique identifier for the consumption item")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class PlayerConsumptionBase(BaseModel):
    """Base model for player consumption records"""
    player_id: int
    session_id: Optional[int] = None
    item_id: int
    quantity: int = 1
    consumption_time: datetime = Field(default_factory=datetime.now)
    location: Optional[str] = None
    staff_id: Optional[int] = None
    notes: Optional[str] = None

class PlayerConsumptionCreate(PlayerConsumptionBase):
    """Model for creating a new player consumption record"""
    pass

class PlayerConsumptionUpdate(BaseModel):
    """Model for updating a player consumption record"""
    quantity: Optional[int] = None
    consumption_time: Optional[datetime] = None
    location: Optional[str] = None
    staff_id: Optional[int] = None
    notes: Optional[str] = None

class PlayerConsumption(PlayerConsumptionBase):
    """Complete player consumption model with all fields"""
    consumption_id: int = Field(..., description="Unique identifier for the consumption record")
    created_at: datetime
    updated_at: datetime
    item: ConsumptionItem
    
    class Config:
        orm_mode = True

class CigaretteInventoryBase(BaseModel):
    """Base model for cigarette inventory"""
    brand: str
    variant: Optional[str] = None
    quantity: int
    reorder_level: int = 10
    location: Optional[str] = None
    notes: Optional[str] = None

class CigaretteInventoryCreate(CigaretteInventoryBase):
    """Model for creating a new cigarette inventory record"""
    pass

class CigaretteInventoryUpdate(BaseModel):
    """Model for updating a cigarette inventory record"""
    brand: Optional[str] = None
    variant: Optional[str] = None
    quantity: Optional[int] = None
    reorder_level: Optional[int] = None
    location: Optional[str] = None
    notes: Optional[str] = None

class CigaretteInventory(CigaretteInventoryBase):
    """Complete cigarette inventory model with all fields"""
    inventory_id: int = Field(..., description="Unique identifier for the inventory record")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class CigaretteTransactionType(str, Enum):
    PURCHASE = "purchase"
    DISPENSED = "dispensed"
    ADJUSTMENT = "adjustment"
    RETURN = "return"

class CigaretteTransactionBase(BaseModel):
    """Base model for cigarette inventory transactions"""
    inventory_id: int
    transaction_type: CigaretteTransactionType
    quantity: int
    transaction_time: datetime = Field(default_factory=datetime.now)
    player_id: Optional[int] = None
    staff_id: Optional[int] = None
    notes: Optional[str] = None

class CigaretteTransactionCreate(CigaretteTransactionBase):
    """Model for creating a new cigarette transaction record"""
    pass

class CigaretteTransactionUpdate(BaseModel):
    """Model for updating a cigarette transaction record"""
    transaction_type: Optional[CigaretteTransactionType] = None
    quantity: Optional[int] = None
    transaction_time: Optional[datetime] = None
    player_id: Optional[int] = None
    staff_id: Optional[int] = None
    notes: Optional[str] = None

class CigaretteTransaction(CigaretteTransactionBase):
    """Complete cigarette transaction model with all fields"""
    transaction_id: int = Field(..., description="Unique identifier for the transaction")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class ConsumptionSummary(BaseModel):
    """Summary of consumption for a player"""
    total_food_items: int = 0
    total_beverage_items: int = 0
    total_cigarette_packs: int = 0
    total_other_items: int = 0
    total_value: float = 0
    favorite_food: Optional[str] = None
    favorite_beverage: Optional[str] = None
    favorite_cigarette: Optional[str] = None
    last_consumption_time: Optional[datetime] = None

class ConsumptionSearch(BaseModel):
    """Model for consumption search parameters"""
    player_id: Optional[int] = None
    session_id: Optional[int] = None
    item_id: Optional[int] = None
    item_type: Optional[ItemType] = None
    min_consumption_time: Optional[datetime] = None
    max_consumption_time: Optional[datetime] = None
    staff_id: Optional[int] = None
    page: int = 1
    page_size: int = 20
"""
