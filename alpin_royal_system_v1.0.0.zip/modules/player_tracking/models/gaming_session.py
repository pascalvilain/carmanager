"""
Alpin Royal Casino Management System - Gaming Session Models
This module defines the data models for gaming sessions in the Player Tracking module.
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

class SessionStatus(str, Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    INTERRUPTED = "interrupted"

class GameType(str, Enum):
    BLACKJACK = "blackjack"
    ROULETTE = "roulette"
    POKER = "poker"
    UTH_POKER = "uth_poker"
    CASH_GAME_POKER = "cash_game_poker"
    SLOT_MACHINE = "slot_machine"
    OTHER = "other"

class DeviceStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"

class GamingSessionBase(BaseModel):
    """Base model for gaming sessions"""
    player_id: int
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    status: SessionStatus = SessionStatus.ACTIVE
    notes: Optional[str] = None

class GamingSessionCreate(GamingSessionBase):
    """Model for creating a new gaming session"""
    pass

class GamingSessionUpdate(BaseModel):
    """Model for updating a gaming session"""
    end_time: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    status: Optional[SessionStatus] = None
    notes: Optional[str] = None

class GamingSession(GamingSessionBase):
    """Complete gaming session model with all fields"""
    session_id: int = Field(..., description="Unique identifier for the gaming session")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class TableGameBase(BaseModel):
    """Base model for table games"""
    table_number: str
    game_type: GameType
    min_bet: Optional[float] = None
    max_bet: Optional[float] = None
    location: Optional[str] = None
    status: DeviceStatus = DeviceStatus.ACTIVE

class TableGameCreate(TableGameBase):
    """Model for creating a new table game"""
    pass

class TableGameUpdate(BaseModel):
    """Model for updating a table game"""
    table_number: Optional[str] = None
    game_type: Optional[GameType] = None
    min_bet: Optional[float] = None
    max_bet: Optional[float] = None
    location: Optional[str] = None
    status: Optional[DeviceStatus] = None

class TableGame(TableGameBase):
    """Complete table game model with all fields"""
    table_id: int = Field(..., description="Unique identifier for the table game")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class SlotMachineBase(BaseModel):
    """Base model for slot machines"""
    machine_number: str
    game_title: str
    manufacturer: Optional[str] = None
    denomination: Optional[float] = None
    location: Optional[str] = None
    status: DeviceStatus = DeviceStatus.ACTIVE

class SlotMachineCreate(SlotMachineBase):
    """Model for creating a new slot machine"""
    pass

class SlotMachineUpdate(BaseModel):
    """Model for updating a slot machine"""
    machine_number: Optional[str] = None
    game_title: Optional[str] = None
    manufacturer: Optional[str] = None
    denomination: Optional[float] = None
    location: Optional[str] = None
    status: Optional[DeviceStatus] = None

class SlotMachine(SlotMachineBase):
    """Complete slot machine model with all fields"""
    machine_id: int = Field(..., description="Unique identifier for the slot machine")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class TableGameActivityBase(BaseModel):
    """Base model for table game activities"""
    session_id: int
    table_id: int
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    avg_bet: Optional[float] = None
    buy_in: Optional[float] = None
    cash_out: Optional[float] = None
    chips_in: Optional[float] = None
    chips_out: Optional[float] = None
    win_loss: Optional[float] = None
    notes: Optional[str] = None

class TableGameActivityCreate(TableGameActivityBase):
    """Model for creating a new table game activity"""
    pass

class TableGameActivityUpdate(BaseModel):
    """Model for updating a table game activity"""
    end_time: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    avg_bet: Optional[float] = None
    buy_in: Optional[float] = None
    cash_out: Optional[float] = None
    chips_in: Optional[float] = None
    chips_out: Optional[float] = None
    win_loss: Optional[float] = None
    notes: Optional[str] = None

class TableGameActivity(TableGameActivityBase):
    """Complete table game activity model with all fields"""
    activity_id: int = Field(..., description="Unique identifier for the table game activity")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class SlotMachineActivityBase(BaseModel):
    """Base model for slot machine activities"""
    session_id: int
    machine_id: int
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    money_in: Optional[float] = None
    ticket_in: Optional[float] = None
    ticket_out: Optional[float] = None
    hand_pay: Optional[float] = None
    jackpot: Optional[float] = None
    win_loss: Optional[float] = None
    notes: Optional[str] = None

class SlotMachineActivityCreate(SlotMachineActivityBase):
    """Model for creating a new slot machine activity"""
    pass

class SlotMachineActivityUpdate(BaseModel):
    """Model for updating a slot machine activity"""
    end_time: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    money_in: Optional[float] = None
    ticket_in: Optional[float] = None
    ticket_out: Optional[float] = None
    hand_pay: Optional[float] = None
    jackpot: Optional[float] = None
    win_loss: Optional[float] = None
    notes: Optional[str] = None

class SlotMachineActivity(SlotMachineActivityBase):
    """Complete slot machine activity model with all fields"""
    activity_id: int = Field(..., description="Unique identifier for the slot machine activity")
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class GamingSessionSearch(BaseModel):
    """Model for gaming session search parameters"""
    player_id: Optional[int] = None
    status: Optional[SessionStatus] = None
    min_start_time: Optional[datetime] = None
    max_start_time: Optional[datetime] = None
    min_end_time: Optional[datetime] = None
    max_end_time: Optional[datetime] = None
    page: int = 1
    page_size: int = 20
"""
