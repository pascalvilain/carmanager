"""
Alpin Royal Casino Management System - Dashboard Models
This module defines the data models for dashboards in the Player Tracking module.
"""

from datetime import datetime, date
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

class TimeRange(str, Enum):
    TODAY = "today"
    YESTERDAY = "yesterday"
    THIS_WEEK = "this_week"
    LAST_WEEK = "last_week"
    THIS_MONTH = "this_month"
    LAST_MONTH = "last_month"
    THIS_YEAR = "this_year"
    LAST_YEAR = "last_year"
    CUSTOM = "custom"

class ChartType(str, Enum):
    BAR = "bar"
    LINE = "line"
    PIE = "pie"
    AREA = "area"
    SCATTER = "scatter"
    RADAR = "radar"
    HEATMAP = "heatmap"

class DashboardFilter(BaseModel):
    """Model for dashboard filters"""
    time_range: TimeRange = TimeRange.THIS_MONTH
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    player_id: Optional[int] = None
    vip_status: Optional[List[str]] = None
    game_types: Optional[List[str]] = None
    
    @validator('start_date', 'end_date', pre=True, always=True)
    def validate_dates(cls, v, values, **kwargs):
        """Validate that start_date and end_date are provided for custom time range"""
        field_name = kwargs['field'].name
        time_range = values.get('time_range')
        
        if time_range == TimeRange.CUSTOM:
            if v is None:
                raise ValueError(f"{field_name} is required for custom time range")
        
        return v

class DataPoint(BaseModel):
    """Model for a single data point in a chart"""
    label: str
    value: float
    color: Optional[str] = None
    extra_data: Optional[Dict[str, Any]] = None

class ChartData(BaseModel):
    """Model for chart data"""
    title: str
    description: Optional[str] = None
    chart_type: ChartType
    labels: List[str]
    datasets: List[Dict[str, Any]]
    options: Optional[Dict[str, Any]] = None

class KPI(BaseModel):
    """Model for Key Performance Indicators"""
    title: str
    value: Any
    unit: Optional[str] = None
    previous_value: Optional[Any] = None
    change_percentage: Optional[float] = None
    trend: Optional[str] = None  # "up", "down", "stable"
    color: Optional[str] = None
    icon: Optional[str] = None

class PlayerDashboard(BaseModel):
    """Model for player dashboard"""
    player_id: int
    player_name: str
    vip_status: str
    kpis: List[KPI]
    gaming_activity: ChartData
    financial_summary: ChartData
    consumption_summary: ChartData
    recent_visits: List[Dict[str, Any]]
    recommendations: List[Dict[str, Any]]

class OperationalDashboard(BaseModel):
    """Model for operational dashboard"""
    time_range: TimeRange
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    kpis: List[KPI]
    player_activity: ChartData
    revenue_by_game_type: ChartData
    top_players: List[Dict[str, Any]]
    cigarette_inventory: ChartData
    alerts: List[Dict[str, Any]]

class DashboardWidgetConfig(BaseModel):
    """Configuration for a dashboard widget"""
    widget_id: str
    widget_type: str
    title: str
    size: str  # "small", "medium", "large"
    position: Dict[str, int]  # {"row": 0, "col": 0}
    data_source: str
    refresh_interval: Optional[int] = None  # in seconds
    settings: Optional[Dict[str, Any]] = None

class UserDashboardConfig(BaseModel):
    """User-specific dashboard configuration"""
    user_id: int
    dashboard_id: str
    name: str
    is_default: bool = False
    widgets: List[DashboardWidgetConfig]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True
