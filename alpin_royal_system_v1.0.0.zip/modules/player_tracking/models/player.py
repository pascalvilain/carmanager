"""
Alpin Royal Casino Management System - Player Models
This module defines the data models for the Player Tracking module.
"""

from datetime import date, datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, EmailStr, validator
from enum import Enum

class Gender(str, Enum):
    MALE = "male"
    FEMALE = "female"
    OTHER = "other"
    PREFER_NOT_TO_SAY = "prefer_not_to_say"

class IDType(str, Enum):
    PASSPORT = "passport"
    NATIONAL_ID = "national_id"
    DRIVERS_LICENSE = "drivers_license"
    OTHER = "other"

class VIPStatus(str, Enum):
    STANDARD = "standard"
    SILVER = "silver"
    GOLD = "gold"
    PLATINUM = "platinum"
    DIAMOND = "diamond"

class PlayerBase(BaseModel):
    """Base model for player data"""
    first_name: str
    last_name: str
    date_of_birth: Optional[date] = None
    gender: Optional[Gender] = None
    nationality: Optional[str] = None
    id_type: Optional[IDType] = None
    id_number: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state_province: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    preferred_language: Optional[str] = None
    vip_status: VIPStatus = VIPStatus.STANDARD
    notes: Optional[str] = None
    preferred_cigarette_brand: Optional[str] = None

class PlayerCreate(PlayerBase):
    """Model for creating a new player"""
    pass

class PlayerUpdate(BaseModel):
    """Model for updating a player"""
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[Gender] = None
    nationality: Optional[str] = None
    id_type: Optional[IDType] = None
    id_number: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state_province: Optional[str] = None
    postal_code: Optional[str] = None
    country: Optional[str] = None
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    preferred_language: Optional[str] = None
    vip_status: Optional[VIPStatus] = None
    notes: Optional[str] = None
    preferred_cigarette_brand: Optional[str] = None
    is_active: Optional[bool] = None

class PhotoType(str, Enum):
    ID = "id"
    RECEPTION = "reception"
    JACKPOT = "jackpot"
    HANDPAY = "handpay"

class PlayerPhoto(BaseModel):
    """Model for player photos"""
    photo_id: int = Field(..., description="Unique identifier for the photo")
    player_id: int = Field(..., description="ID of the player")
    photo_type: PhotoType
    storage_path: str
    upload_date: datetime
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

class PlayerPhotoCreate(BaseModel):
    """Model for creating a new player photo"""
    player_id: int
    photo_type: PhotoType
    notes: Optional[str] = None

class Player(PlayerBase):
    """Complete player model with all fields"""
    player_id: int = Field(..., description="Unique identifier for the player")
    casino_guest_id: str = Field(..., description="Casino's guest ID")
    registration_date: datetime
    last_visit_date: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    is_active: bool = True
    photos: List[PlayerPhoto] = []
    
    class Config:
        orm_mode = True

class PlayerSummary(BaseModel):
    """Summary model for player listing"""
    player_id: int
    casino_guest_id: str
    first_name: str
    last_name: str
    vip_status: VIPStatus
    last_visit_date: Optional[datetime] = None
    is_active: bool

    class Config:
        orm_mode = True

class PlayerSearch(BaseModel):
    """Model for player search parameters"""
    query: Optional[str] = None
    casino_guest_id: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    vip_status: Optional[VIPStatus] = None
    is_active: Optional[bool] = None
    min_registration_date: Optional[datetime] = None
    max_registration_date: Optional[datetime] = None
    min_last_visit_date: Optional[datetime] = None
    max_last_visit_date: Optional[datetime] = None
    page: int = 1
    page_size: int = 20
