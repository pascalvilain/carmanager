#!/usr/bin/env python3
"""
Casino Management System - Core Application
This is the main entry point for the Casino Management System.
It initializes the base layer and loads all registered modules.
"""

import os
import sys
import logging
import importlib
from pathlib import Path
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

# Add the project root to the Python path
sys.path.append(str(Path(__file__).parent.parent.parent))

# Import base layer components
from base_layer.config.settings import Settings
from base_layer.auth.auth_manager import get_current_user
from base_layer.module_system.module_registry import ModuleRegistry
from base_layer.api.api_router import api_router
from base_layer.utils.logger import setup_logging

# Initialize settings and logging
settings = Settings()
setup_logging(settings.log_level)
logger = logging.getLogger(__name__)

def create_app():
    """Create and configure the FastAPI application."""
    logger.info("Initializing Casino Management System...")
    
    # Create FastAPI app
    app = FastAPI(
        title="Casino Management System",
        description="A modular casino management system with AI integration",
        version="0.1.0",
    )
    
    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include API router
    app.include_router(api_router, prefix="/api")
    
    # Initialize module registry
    module_registry = ModuleRegistry(app, settings)
    
    # Discover and register modules
    module_registry.discover_modules()
    
    # Mount static files for UI
    app.mount("/static", StaticFiles(directory="static"), name="static")
    
    @app.get("/")
    async def root():
        """Root endpoint that returns basic system information."""
        return {
            "system": "Casino Management System",
            "version": "0.1.0",
            "modules": module_registry.get_registered_modules(),
            "status": "online"
        }
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint for monitoring."""
        return {"status": "healthy"}
    
    logger.info("Casino Management System initialized successfully")
    return app

app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level=settings.log_level.lower(),
    )
