import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Typography, 
  Button, 
  TextField, 
  Box, 
  Tabs, 
  Tab, 
  AppBar, 
  Toolbar, 
  IconButton, 
  Menu, 
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  CircularProgress,
  Divider,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Badge
} from '@mui/material';
import { 
  Search as SearchIcon, 
  Person as PersonIcon, 
  Casino as CasinoIcon,
  AttachMoney as MoneyIcon,
  LocalBar as DrinkIcon,
  SmokingRooms as SmokingIcon,
  Dashboard as DashboardIcon,
  Menu as MenuIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Print as PrintIcon,
  Save as SaveIcon,
  Close as CloseIcon,
  PhotoCamera as CameraIcon,
  Refresh as RefreshIcon,
  MoreVert as MoreVertIcon
} from '@mui/icons-material';
import { DataGrid } from '@mui/x-data-grid';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

// Custom components
import PlayerSearchForm from '../components/PlayerSearchForm';
import PlayerProfileCard from '../components/PlayerProfileCard';
import GamingSessionForm from '../components/GamingSessionForm';
import ConsumptionForm from '../components/ConsumptionForm';
import FinancialTransactionForm from '../components/FinancialTransactionForm';
import PlayerDashboard from '../components/PlayerDashboard';
import NumPad from '../components/NumPad';
import PhotoCapture from '../components/PhotoCapture';
import ReportGenerator from '../components/ReportGenerator';

const PlayerTrackingPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  const { playerId } = useParams();
  
  // State
  const [loading, setLoading] = useState(false);
  const [player, setPlayer] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [gamingSessions, setGamingSessions] = useState([]);
  const [activeSession, setActiveSession] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [consumptions, setConsumptions] = useState([]);
  const [cigaretteInventory, setCigaretteInventory] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogType, setDialogType] = useState('');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
  const [anchorEl, setAnchorEl] = useState(null);
  const [dashboardData, setDashboardData] = useState(null);
  const [reportTemplates, setReportTemplates] = useState([]);
  
  // Fetch player data
  useEffect(() => {
    if (playerId) {
      fetchPlayerData();
    }
  }, [playerId]);
  
  const fetchPlayerData = async () => {
    setLoading(true);
    try {
      // Fetch player profile
      const playerResponse = await axios.get(`/api/player-tracking/players/${playerId}`);
      setPlayer(playerResponse.data);
      
      // Fetch gaming sessions
      const sessionsResponse = await axios.get(`/api/player-tracking/players/${playerId}/gaming-sessions`);
      setGamingSessions(sessionsResponse.data);
      
      // Check for active session
      const activeSessions = sessionsResponse.data.filter(session => !session.end_time);
      if (activeSessions.length > 0) {
        setActiveSession(activeSessions[0]);
      }
      
      // Fetch financial transactions
      const transactionsResponse = await axios.get(`/api/player-tracking/players/${playerId}/financial-transactions`);
      setTransactions(transactionsResponse.data);
      
      // Fetch consumption records
      const consumptionsResponse = await axios.get(`/api/player-tracking/players/${playerId}/consumptions`);
      setConsumptions(consumptionsResponse.data);
      
      // Fetch cigarette inventory
      const inventoryResponse = await axios.get(`/api/player-tracking/cigarette-inventory`);
      setCigaretteInventory(inventoryResponse.data);
      
      // Fetch dashboard data
      const dashboardResponse = await axios.get(`/api/player-tracking/players/${playerId}/report-data?time_range=THIS_MONTH`);
      setDashboardData(dashboardResponse.data);
      
      // Fetch report templates
      const templatesResponse = await axios.get(`/api/player-tracking/reports/templates?report_type=PLAYER`);
      setReportTemplates(templatesResponse.data);
      
    } catch (error) {
      console.error('Error fetching player data:', error);
      setSnackbar({
        open: true,
        message: 'Error loading player data. Please try again.',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  
  // Open dialog
  const handleOpenDialog = (type) => {
    setDialogType(type);
    setOpenDialog(true);
  };
  
  // Close dialog
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };
  
  // Open menu
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  
  // Close menu
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  
  // Start gaming session
  const handleStartSession = async (sessionData) => {
    try {
      const response = await axios.post('/api/player-tracking/gaming-sessions', {
        ...sessionData,
        player_id: playerId,
        start_time: new Date().toISOString()
      });
      
      setActiveSession(response.data);
      setGamingSessions([response.data, ...gamingSessions]);
      
      setSnackbar({
        open: true,
        message: 'Gaming session started successfully',
        severity: 'success'
      });
      
      handleCloseDialog();
    } catch (error) {
      console.error('Error starting gaming session:', error);
      setSnackbar({
        open: true,
        message: 'Error starting gaming session',
        severity: 'error'
      });
    }
  };
  
  // End gaming session
  const handleEndSession = async () => {
    try {
      const response = await axios.post(`/api/player-tracking/gaming-sessions/${activeSession.id}/end`);
      
      // Update sessions list
      const updatedSessions = gamingSessions.map(session => 
        session.id === response.data.id ? response.data : session
      );
      
      setGamingSessions(updatedSessions);
      setActiveSession(null);
      
      setSnackbar({
        open: true,
        message: 'Gaming session ended successfully',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error ending gaming session:', error);
      setSnackbar({
        open: true,
        message: 'Error ending gaming session',
        severity: 'error'
      });
    }
  };
  
  // Add consumption
  const handleAddConsumption = async (consumptionData) => {
    try {
      const response = await axios.post('/api/player-tracking/player-consumptions', {
        ...consumptionData,
        player_id: playerId,
        session_id: activeSession?.id,
        timestamp: new Date().toISOString()
      });
      
      setConsumptions([response.data, ...consumptions]);
      
      // If it's a cigarette, update inventory
      if (response.data.item_type === 'CIGARETTE') {
        // Refresh cigarette inventory
        const inventoryResponse = await axios.get('/api/player-tracking/cigarette-inventory');
        setCigaretteInventory(inventoryResponse.data);
      }
      
      setSnackbar({
        open: true,
        message: 'Consumption added successfully',
        severity: 'success'
      });
      
      handleCloseDialog();
    } catch (error) {
      console.error('Error adding consumption:', error);
      setSnackbar({
        open: true,
        message: 'Error adding consumption',
        severity: 'error'
      });
    }
  };
  
  // Add financial transaction
  const handleAddTransaction = async (transactionData) => {
    try {
      const response = await axios.post('/api/player-tracking/financial-transactions', {
        ...transactionData,
        player_id: playerId,
        timestamp: new Date().toISOString()
      });
      
      setTransactions([response.data, ...transactions]);
      
      setSnackbar({
        open: true,
        message: 'Transaction added successfully',
        severity: 'success'
      });
      
      handleCloseDialog();
    } catch (error) {
      console.error('Error adding transaction:', error);
      setSnackbar({
        open: true,
        message: 'Error adding transaction',
        severity: 'error'
      });
    }
  };
  
  // Generate report
  const handleGenerateReport = async (templateId, timeRange) => {
    try {
      // Open in new window
      window.open(
        `/api/player-tracking/reports/generate/player/${playerId}?template_id=${templateId}&time_range=${timeRange}`,
        '_blank'
      );
      
      handleCloseDialog();
    } catch (error) {
      console.error('Error generating report:', error);
      setSnackbar({
        open: true,
        message: 'Error generating report',
        severity: 'error'
      });
    }
  };
  
  // Capture photo
  const handleCapturePhoto = async (photoData, photoType) => {
    try {
      // Create form data
      const formData = new FormData();
      formData.append('photo_type', photoType);
      formData.append('photo', photoData);
      
      // Upload photo
      await axios.post(`/api/player-tracking/players/${playerId}/photos`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      
      setSnackbar({
        open: true,
        message: 'Photo captured successfully',
        severity: 'success'
      });
      
      // Refresh player data to get updated photos
      fetchPlayerData();
      
      handleCloseDialog();
    } catch (error) {
      console.error('Error capturing photo:', error);
      setSnackbar({
        open: true,
        message: 'Error capturing photo',
        severity: 'error'
      });
    }
  };
  
  // Render loading state
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }
  
  // Render player not found
  if (playerId && !player) {
    return (
      <Container>
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography variant="h4" gutterBottom>
            Player Not Found
          </Typography>
          <Typography variant="body1" paragraph>
            The player you are looking for could not be found.
          </Typography>
          <Button 
            variant="contained" 
            color="primary" 
            onClick={() => navigate('/player-tracking')}
          >
            Back to Search
          </Button>
        </Box>
      </Container>
    );
  }
  
  // Render player search if no player selected
  if (!playerId) {
    return (
      <Container>
        <Box sx={{ mt: 4 }}>
          <Typography variant="h4" gutterBottom>
            Player Tracking
          </Typography>
          <PlayerSearchForm 
            onPlayerSelect={(selectedPlayer) => navigate(`/player-tracking/${selectedPlayer.id}`)} 
          />
        </Box>
      </Container>
    );
  }
  
  return (
    <Container maxWidth="lg">
      {/* Header */}
      <Box sx={{ mt: 3, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={isMobile ? 10 : 6}>
            <Typography variant="h4">
              Player Tracking
            </Typography>
          </Grid>
          <Grid item xs={isMobile ? 2 : 6} sx={{ textAlign: 'right' }}>
            <IconButton 
              aria-label="menu" 
              aria-controls="player-menu" 
              aria-haspopup="true"
              onClick={handleMenuOpen}
            >
              <MoreVertIcon />
            </IconButton>
            <Menu
              id="player-menu"
              anchorEl={anchorEl}
              keepMounted
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
            >
              <MenuItem onClick={() => { handleMenuClose(); handleOpenDialog('report'); }}>
                <PrintIcon fontSize="small" sx={{ mr: 1 }} />
                Generate Report
              </MenuItem>
              <MenuItem onClick={() => { handleMenuClose(); handleOpenDialog('photo'); }}>
                <CameraIcon fontSize="small" sx={{ mr: 1 }} />
                Capture Photo
              </MenuItem>
              <MenuItem onClick={() => { handleMenuClose(); navigate('/player-tracking'); }}>
                <SearchIcon fontSize="small" sx={{ mr: 1 }} />
                Search Players
              </MenuItem>
              <MenuItem onClick={() => { handleMenuClose(); fetchPlayerData(); }}>
                <RefreshIcon fontSize="small" sx={{ mr: 1 }} />
                Refresh Data
              </MenuItem>
            </Menu>
          </Grid>
        </Grid>
      </Box>
      
      {/* Player Profile Card */}
      <PlayerProfileCard 
        player={player} 
        activeSession={activeSession}
        onStartSession={() => handleOpenDialog('session')}
        onEndSession={handleEndSession}
      />
      
      {/* Tabs */}
      <Box sx={{ mt: 3 }}>
        <AppBar position="static" color="default" elevation={0}>
          <Tabs
            value={activeTab}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant={isMobile ? "scrollable" : "fullWidth"}
            scrollButtons={isMobile ? "auto" : "off"}
          >
            <Tab label="Dashboard" icon={<DashboardIcon />} />
            <Tab label="Gaming" icon={<CasinoIcon />} />
            <Tab label="Financial" icon={<MoneyIcon />} />
            <Tab label="Consumption" icon={<DrinkIcon />} />
            <Tab label="Cigarettes" icon={<SmokingIcon />} />
          </Tabs>
        </AppBar>
        
        {/* Dashboard Tab */}
        {activeTab === 0 && (
          <Box sx={{ p: 2 }}>
            <PlayerDashboard 
              playerData={player}
              dashboardData={dashboardData}
              onGenerateReport={() => handleOpenDialog('report')}
            />
          </Box>
        )}
        
        {/* Gaming Tab */}
        {activeTab === 1 && (
          <Box sx={{ p: 2 }}>
            <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="h6">Gaming Sessions</Typography>
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={() => handleOpenDialog('session')}
                disabled={!!activeSession}
              >
                {isMobile ? 'New' : 'New Session'}
              </Button>
            </Box>
            
            {activeSession && (
              <Paper sx={{ p: 2, mb: 3, border: '2px solid #4caf50' }}>
                <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                  Active Session
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="body2">
                      Started: {new Date(activeSession.start_time).toLocaleString()}
                    </Typography>
                    <Typography variant="body2">
                      Location: {activeSession.location}
                    </Typography>
                  </Grid>
                  <Grid item xs={12} sm={6} sx={{ textAlign: 'right' }}>
                    <Button
                      variant="outlined"
                      color="secondary"
                      onClick={handleEndSession}
                    >
                      End Se<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>