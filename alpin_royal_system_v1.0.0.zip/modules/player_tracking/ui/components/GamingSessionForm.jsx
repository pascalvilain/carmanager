import React, { useState, useEffect } from 'react';
import { 
  Box, 
  TextField, 
  Button, 
  Grid, 
  Typography, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import NumPad from './NumPad';

/**
 * GamingSessionForm component for starting new gaming sessions
 * 
 * @param {Object} props Component props
 * @param {Function} props.onSubmit Function to call when form is submitted
 */
const GamingSessionForm = ({ onSubmit }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Form state
  const [formData, setFormData] = useState({
    location: '',
    game_type: '',
    table_number: '',
    machine_number: '',
    initial_buy_in: 0
  });
  
  // Validation state
  const [errors, setErrors] = useState({});
  
  // NumPad state
  const [numPadOpen, setNumPadOpen] = useState(false);
  const [numPadField, setNumPadField] = useState('');
  const [numPadValue, setNumPadValue] = useState('');
  
  // Location options
  const locationOptions = [
    'Main Floor',
    'High Limit Room',
    'VIP Area',
    'Poker Room',
    'Slot Area 1',
    'Slot Area 2',
    'Slot Area 3'
  ];
  
  // Game type options
  const gameTypeOptions = [
    'Blackjack',
    'Roulette',
    'Baccarat',
    'Craps',
    'Poker',
    'Slot Machine',
    'Video Poker',
    'Other'
  ];
  
  // Handle text input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  // Handle number input change
  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value === '' ? '' : Number(value)
    });
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  // Open numpad for a specific field
  const handleOpenNumPad = (field, currentValue) => {
    setNumPadField(field);
    setNumPadValue(currentValue.toString());
    setNumPadOpen(true);
  };
  
  // Handle numpad submit
  const handleNumPadSubmit = (value) => {
    setFormData({
      ...formData,
      [numPadField]: value
    });
    
    // Clear error for this field
    if (errors[numPadField]) {
      setErrors({
        ...errors,
        [numPadField]: ''
      });
    }
    
    setNumPadOpen(false);
  };
  
  // Validate form
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.location) {
      newErrors.location = 'Location is required';
    }
    
    if (!formData.game_type) {
      newErrors.game_type = 'Game type is required';
    }
    
    // If game type is Slot Machine, require machine number
    if (formData.game_type === 'Slot Machine' && !formData.machine_number) {
      newErrors.machine_number = 'Machine number is required for slot machines';
    }
    
    // If game type is not Slot Machine, require table number
    if (formData.game_type && 
        formData.game_type !== 'Slot Machine' && 
        formData.game_type !== 'Other' && 
        !formData.table_number) {
      newErrors.table_number = 'Table number is required for table games';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle form submit
  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    
    if (validateForm()) {
      onSubmit(formData);
    }
  };
  
  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <FormControl fullWidth error={!!errors.location}>
            <InputLabel id="location-label">Location</InputLabel>
            <Select
              labelId="location-label"
              id="location"
              name="location"
              value={formData.location}
              onChange={handleInputChange}
              label="Location"
            >
              {locationOptions.map((option) => (
                <MenuItem key={option} value={option}>{option}</MenuItem>
              ))}
            </Select>
            {errors.location && <FormHelperText>{errors.location}</FormHelperText>}
          </FormControl>
        </Grid>
        
        <Grid item xs={12}>
          <FormControl fullWidth error={!!errors.game_type}>
            <InputLabel id="game-type-label">Game Type</InputLabel>
            <Select
              labelId="game-type-label"
              id="game_type"
              name="game_type"
              value={formData.game_type}
              onChange={handleInputChange}
              label="Game Type"
            >
              {gameTypeOptions.map((option) => (
                <MenuItem key={option} value={option}>{option}</MenuItem>
              ))}
            </Select>
            {errors.game_type && <FormHelperText>{errors.game_type}</FormHelperText>}
          </FormControl>
        </Grid>
        
        {formData.game_type && formData.game_type !== 'Slot Machine' && formData.game_type !== 'Other' && (
          <Grid item xs={12}>
            {isMobile ? (
              <TextField
                fullWidth
                label="Table Number"
                name="table_number"
                value={formData.table_number}
                onChange={handleInputChange}
                error={!!errors.table_number}
                helperText={errors.table_number}
                InputProps={{
                  readOnly: true,
                  onClick: () => handleOpenNumPad('table_number', formData.table_number)
                }}
              />
            ) : (
              <TextField
                fullWidth
                label="Table Number"
                name="table_number"
                value={formData.table_number}
                onChange={handleInputChange}
                error={!!errors.table_number}
                helperText={errors.table_number}
                type="number"
              />
            )}
          </Grid>
        )}
        
        {formData.game_type === 'Slot Machine' && (
          <Grid item xs={12}>
            {isMobile ? (
              <TextField
                fullWidth
                label="Machine Number"
                name="machine_number"
                value={formData.machine_number}
                onChange={handleInputChange}
                error={!!errors.machine_number}
                helperText={errors.machine_number}
                InputProps={{
                  readOnly: true,
                  onClick: () => handleOpenNumPad('machine_number', formData.machine_number)
                }}
              />
            ) : (
              <TextField
                fullWidth
                label="Machine Number"
                name="machine_number"
                value={formData.machine_number}
                onChange={handleInputChange}
                error={!!errors.machine_number}
                helperText={errors.machine_number}
                type="number"
              />
            )}
          </Grid>
        )}
        
        <Grid item xs={12}>
          {isMobile ? (
            <TextField
              fullWidth
              label="Initial Buy-in ($)"
              name="initial_buy_in"
              value={formData.initial_buy_in === 0 ? '' : formData.initial_buy_in}
              onChange={handleNumberChange}
              InputProps={{
                readOnly: true,
                onClick: () => handleOpenNumPad('initial_buy_in', formData.initial_buy_in)
              }}
              placeholder="0.00"
            />
          ) : (
            <TextField
              fullWidth
              label="Initial Buy-in ($)"
              name="initial_buy_in"
              value={formData.initial_buy_in === 0 ? '' : formData.initial_buy_in}
              onChange={handleNumberChange}
              type="number"
              inputProps={{ step: "0.01" }}
              placeholder="0.00"
            />
          )}
        </Grid>
      </Grid>
      
      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          size="large"
        >
          Start Session
        </Button>
      </Box>
      
      {/* NumPad Dialog for Mobile */}
      {isMobile && (
        <NumPad
          open={numPadOpen}
          value={numPadValue}
          onChange={setNumPadValue}
          onClose={() => setNumPadOpen(false)}
          onSubmit={handleNumPadSubmit}
          label={numPadField === 'initial_buy_in' ? 'Enter Buy-in Amount' : 
                 numPadField === 'table_number' ? 'Enter Table Number' : 
                 'Enter Machine Number'}
          type={numPadField === 'initial_buy_in' ? 'currency' : 'number'}
        />
      )}
    </Box>
  );
};

export default GamingSessionForm;
