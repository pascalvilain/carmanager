import React, { useState } from 'react';
import { 
  Box, 
  TextField, 
  Button, 
  Grid, 
  Typography, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import NumPad from './NumPad';

/**
 * FinancialTransactionForm component for recording financial transactions
 * 
 * @param {Object} props Component props
 * @param {Function} props.onSubmit Function to call when form is submitted
 */
const FinancialTransactionForm = ({ onSubmit }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Form state
  const [formData, setFormData] = useState({
    transaction_type: '',
    amount: 0,
    payment_method: '',
    notes: ''
  });
  
  // Validation state
  const [errors, setErrors] = useState({});
  
  // NumPad state
  const [numPadOpen, setNumPadOpen] = useState(false);
  const [numPadField, setNumPadField] = useState('');
  const [numPadValue, setNumPadValue] = useState('');
  
  // Transaction type options
  const transactionTypeOptions = [
    'BUY_IN',
    'CASH_OUT',
    'HAND_PAY',
    'JACKPOT',
    'COMP',
    'CREDIT',
    'OTHER'
  ];
  
  // Payment method options
  const paymentMethodOptions = [
    'CASH',
    'CREDIT_CARD',
    'DEBIT_CARD',
    'CASINO_CREDIT',
    'COMP',
    'OTHER'
  ];
  
  // Handle text input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  // Handle number input change
  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value === '' ? '' : Number(value)
    });
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  // Open numpad for a specific field
  const handleOpenNumPad = (field, currentValue) => {
    setNumPadField(field);
    setNumPadValue(currentValue.toString());
    setNumPadOpen(true);
  };
  
  // Handle numpad submit
  const handleNumPadSubmit = (value) => {
    setFormData({
      ...formData,
      [numPadField]: value
    });
    
    // Clear error for this field
    if (errors[numPadField]) {
      setErrors({
        ...errors,
        [numPadField]: ''
      });
    }
    
    setNumPadOpen(false);
  };
  
  // Validate form
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.transaction_type) {
      newErrors.transaction_type = 'Transaction type is required';
    }
    
    if (!formData.amount || formData.amount <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    }
    
    if (!formData.payment_method) {
      newErrors.payment_method = 'Payment method is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle form submit
  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    
    if (validateForm()) {
      onSubmit(formData);
    }
  };
  
  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <FormControl fullWidth error={!!errors.transaction_type}>
            <InputLabel id="transaction-type-label">Transaction Type</InputLabel>
            <Select
              labelId="transaction-type-label"
              id="transaction_type"
              name="transaction_type"
              value={formData.transaction_type}
              onChange={handleInputChange}
              label="Transaction Type"
            >
              {transactionTypeOptions.map((option) => (
                <MenuItem key={option} value={option}>{option.replace('_', ' ')}</MenuItem>
              ))}
            </Select>
            {errors.transaction_type && <FormHelperText>{errors.transaction_type}</FormHelperText>}
          </FormControl>
        </Grid>
        
        <Grid item xs={12}>
          {isMobile ? (
            <TextField
              fullWidth
              label="Amount ($)"
              name="amount"
              value={formData.amount === 0 ? '' : formData.amount}
              onChange={handleNumberChange}
              error={!!errors.amount}
              helperText={errors.amount}
              InputProps={{
                readOnly: true,
                onClick: () => handleOpenNumPad('amount', formData.amount)
              }}
              placeholder="0.00"
            />
          ) : (
            <TextField
              fullWidth
              label="Amount ($)"
              name="amount"
              value={formData.amount === 0 ? '' : formData.amount}
              onChange={handleNumberChange}
              error={!!errors.amount}
              helperText={errors.amount}
              type="number"
              inputProps={{ step: "0.01", min: "0" }}
              placeholder="0.00"
            />
          )}
        </Grid>
        
        <Grid item xs={12}>
          <FormControl fullWidth error={!!errors.payment_method}>
            <InputLabel id="payment-method-label">Payment Method</InputLabel>
            <Select
              labelId="payment-method-label"
              id="payment_method"
              name="payment_method"
              value={formData.payment_method}
              onChange={handleInputChange}
              label="Payment Method"
            >
              {paymentMethodOptions.map((option) => (
                <MenuItem key={option} value={option}>{option.replace('_', ' ')}</MenuItem>
              ))}
            </Select>
            {errors.payment_method && <FormHelperText>{errors.payment_method}</FormHelperText>}
          </FormControl>
        </Grid>
        
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Notes"
            name="notes"
            value={formData.notes}
            onChange={handleInputChange}
            multiline
            rows={2}
          />
        </Grid>
      </Grid>
      
      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          size="large"
        >
          Add Transaction
        </Button>
      </Box>
      
      {/* NumPad Dialog for Mobile */}
      {isMobile && (
        <NumPad
          open={numPadOpen}
          value={numPadValue}
          onChange={setNumPadValue}
          onClose={() => setNumPadOpen(false)}
          onSubmit={handleNumPadSubmit}
          label="Enter Amount"
          type="currency"
        />
      )}
    </Box>
  );
};

export default FinancialTransactionForm;
