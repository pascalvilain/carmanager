import React, { useState } from 'react';
import { 
  Box, 
  TextField, 
  Button, 
  Grid, 
  Typography, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  IconButton
} from '@mui/material';
import { 
  Search as SearchIcon,
  Clear as ClearIcon
} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import axios from 'axios';

/**
 * PlayerSearchForm component for searching players
 * 
 * @param {Object} props Component props
 * @param {Function} props.onPlayerSelect Function to call when a player is selected
 */
const PlayerSearchForm = ({ onPlayerSelect }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Search state
  const [searchType, setSearchType] = useState('casino_id');
  const [searchValue, setSearchValue] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Handle search type change
  const handleSearchTypeChange = (e) => {
    setSearchType(e.target.value);
    setSearchResults([]);
    setError('');
  };
  
  // Handle search value change
  const handleSearchValueChange = (e) => {
    setSearchValue(e.target.value);
    setError('');
  };
  
  // Clear search
  const handleClearSearch = () => {
    setSearchValue('');
    setSearchResults([]);
    setError('');
  };
  
  // Handle search submit
  const handleSearch = async (e) => {
    if (e) e.preventDefault();
    
    if (!searchValue.trim()) {
      setError('Please enter a search value');
      return;
    }
    
    setLoading(true);
    setError('');
    
    try {
      const response = await axios.get('/api/player-tracking/players/search', {
        params: {
          search_type: searchType,
          search_value: searchValue
        }
      });
      
      if (response.data.length === 0) {
        setError('No players found');
      }
      
      setSearchResults(response.data);
    } catch (error) {
      console.error('Error searching players:', error);
      setError('Error searching players. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  // Handle player selection
  const handlePlayerSelect = (player) => {
    if (onPlayerSelect) {
      onPlayerSelect(player);
    }
  };
  
  return (
    <Box>
      <Box component="form" onSubmit={handleSearch} sx={{ mb: 3 }}>
        <Grid container spacing={2} alignItems="flex-end">
          <Grid item xs={12} sm={3}>
            <FormControl fullWidth>
              <InputLabel id="search-type-label">Search By</InputLabel>
              <Select
                labelId="search-type-label"
                id="search-type"
                value={searchType}
                onChange={handleSearchTypeChange}
                label="Search By"
              >
                <MenuItem value="casino_id">Casino ID</MenuItem>
                <MenuItem value="name">Name</MenuItem>
                <MenuItem value="phone">Phone</MenuItem>
                <MenuItem value="email">Email</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} sm={7}>
            <TextField
              fullWidth
              label={`Search by ${searchType.replace('_', ' ')}`}
              value={searchValue}
              onChange={handleSearchValueChange}
              error={!!error}
              helperText={error}
              InputProps={{
                endAdornment: searchValue ? (
                  <IconButton
                    size="small"
                    onClick={handleClearSearch}
                    edge="end"
                  >
                    <ClearIcon />
                  </IconButton>
                ) : null
              }}
            />
          </Grid>
          
          <Grid item xs={12} sm={2}>
            <Button
              fullWidth
              variant="contained"
              color="primary"
              onClick={handleSearch}
              disabled={loading}
              startIcon={<SearchIcon />}
            >
              {loading ? 'Searching...' : 'Search'}
            </Button>
          </Grid>
        </Grid>
      </Box>
      
      {searchResults.length > 0 && (
        <Box>
          <Typography variant="h6" gutterBottom>
            Search Results
          </Typography>
          
          <Grid container spacing={2}>
            {searchResults.map((player) => (
              <Grid item xs={12} sm={6} md={4} key={player.id}>
                <Box
                  sx={{
                    p: 2,
                    border: '1px solid',
                    borderColor: 'divider',
                    borderRadius: 1,
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    '&:hover': {
                      borderColor: 'primary.main',
                      boxShadow: 1
                    }
                  }}
                  onClick={() => handlePlayerSelect(player)}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box
                      sx={{
                        width: 40,
                        height: 40,
                        borderRadius: '50%',
                        backgroundColor: player.vip_status ? 'secondary.main' : 'primary.main',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 'bold',
                        mr: 2
                      }}
                    >
                      {player.full_name.charAt(0)}
                    </Box>
                    
                    <Box>
                      <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                        {player.full_name}
                        {player.vip_status && (
                          <Box
                            component="span"
                            sx={{
                              ml: 1,
                              px: 1,
                              py: 0.5,
                              backgroundColor: 'secondary.main',
                              color: 'white',
                              borderRadius: 1,
                              fontSize: '0.75rem'
                            }}
                          >
                            VIP
                          </Box>
                        )}
                      </Typography>
                      
                      <Typography variant="body2" color="textSecondary">
                        ID: {player.casino_guest_id}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default PlayerSearchForm;
