// Alpin Royal Casino Management System - Player Tracking UI Components
// This file contains React components for the player tracking module UI

import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  TextField, 
  Select, 
  MenuItem, 
  FormControl, 
  InputLabel,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  Card,
  CardContent,
  CardMedia,
  CardActions,
  Chip,
  Avatar,
  Badge,
  Divider,
  CircularProgress,
  LinearProgress,
  Snackbar,
  Alert,
  Tooltip,
  Autocomplete
} from '@mui/material';
import { 
  Add as AddIcon, 
  Edit as EditIcon, 
  Delete as DeleteIcon, 
  Search as SearchIcon,
  Person as PersonIcon,
  Casino as CasinoIcon,
  AttachMoney as MoneyIcon,
  LocalBar as DrinkIcon,
  SmokingRooms as SmokingIcon,
  Dashboard as DashboardIcon,
  PhotoCamera as CameraIcon,
  Save as SaveIcon,
  Print as PrintIcon,
  Close as CloseIcon,
  Refresh as RefreshIcon,
  ArrowBack as ArrowBackIcon,
  ArrowForward as ArrowForwardIcon
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';
import { useTheme } from '@mui/material/styles';
import { useMediaQuery } from '@mui/material';
import { Chart as ChartJS, ArcElement, Tooltip as ChartTooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title } from 'chart.js';
import { Pie, Bar, Line } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(ArcElement, ChartTooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title);

// Styled components
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  borderRadius: theme.shape.borderRadius * 2,
  boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
}));

const DashboardCard = styled(Card)(({ theme }) => ({
  borderRadius: theme.shape.borderRadius * 2,
  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.08)',
  height: '100%',
  transition: 'transform 0.3s ease, box-shadow 0.3s ease',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: '0 8px 25px rgba(0, 0, 0, 0.15)',
  },
}));

const StyledBadge = styled(Badge)(({ theme }) => ({
  '& .MuiBadge-badge': {
    backgroundColor: '#44b700',
    color: '#44b700',
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    '&::after': {
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      borderRadius: '50%',
      animation: 'ripple 1.2s infinite ease-in-out',
      border: '1px solid currentColor',
      content: '""',
    },
  },
  '@keyframes ripple': {
    '0%': {
      transform: 'scale(.8)',
      opacity: 1,
    },
    '100%': {
      transform: 'scale(2.4)',
      opacity: 0,
    },
  },
}));

const NumPad = styled(Box)(({ theme }) => ({
  display: 'grid',
  gridTemplateColumns: 'repeat(3, 1fr)',
  gap: theme.spacing(1),
  marginTop: theme.spacing(2),
}));

const NumPadButton = styled(Button)(({ theme }) => ({
  padding: theme.spacing(2),
  fontSize: '1.5rem',
  fontWeight: 'bold',
}));

// Dashboard Component
export const PlayerTrackingDashboard = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [stats, setStats] = useState({
    totalPlayers: 0,
    activeSessions: 0,
    todayRevenue: 0,
    popularItems: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call to fetch dashboard data
    setTimeout(() => {
      setStats({
        totalPlayers: 1243,
        activeSessions: 87,
        todayRevenue: 125750,
        popularItems: [
          { name: 'Marlboro Red', count: 142 },
          { name: 'Heineken', count: 98 },
          { name: 'Whiskey Sour', count: 76 },
          { name: 'Club Sandwich', count: 54 }
        ]
      });
      setLoading(false);
    }, 1000);
  }, []);

  // Sample data for charts
  const pieData = {
    labels: ['Slots', 'Roulette', 'Blackjack', 'Poker'],
    datasets: [
      {
        data: [65, 15, 12, 8],
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 206, 86, 0.7)',
          'rgba(75, 192, 192, 0.7)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const barData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Revenue (CHF)',
        data: [65000, 72000, 68000, 81000, 96000, 124000, 115000],
        backgroundColor: 'rgba(75, 192, 192, 0.7)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };

  const lineData = {
    labels: ['10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00', '00:00', '02:00', '04:00'],
    datasets: [
      {
        label: 'Active Players',
        data: [25, 42, 58, 69, 85, 112, 132, 145, 120, 78],
        fill: false,
        backgroundColor: 'rgba(54, 162, 235, 0.7)',
        borderColor: 'rgba(54, 162, 235, 1)',
        tension: 0.4,
      },
    ],
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Player Tracking Dashboard
        </Typography>
        <Box>
          <Button 
            variant="contained" 
            startIcon={<RefreshIcon />}
            onClick={() => setLoading(true)}
            sx={{ mr: 2 }}
          >
            Refresh
          </Button>
          <Button 
            variant="outlined" 
            startIcon={<PrintIcon />}
          >
            Export Report
          </Button>
        </Box>
      </Box>

      {loading ? (
        <Box sx={{ width: '100%', mt: 10, textAlign: 'center' }}>
          <CircularProgress size={60} />
          <Typography variant="h6" sx={{ mt: 2 }}>
            Loading dashboard data...
          </Typography>
        </Box>
      ) : (
        <>
          {/* Stats Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Total Players
                    </Typography>
                    <Avatar sx={{ bgcolor: 'primary.main' }}>
                      <PersonIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div">
                    {stats.totalPlayers.toLocaleString()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    +12% from last month
                  </Typography>
                </CardContent>
              </DashboardCard>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Active Sessions
                    </Typography>
                    <Avatar sx={{ bgcolor: 'success.main' }}>
                      <CasinoIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div">
                    {stats.activeSessions}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Current active players
                  </Typography>
                </CardContent>
              </DashboardCard>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Today's Revenue
                    </Typography>
                    <Avatar sx={{ bgcolor: 'warning.main' }}>
                      <MoneyIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div">
                    {stats.todayRevenue.toLocaleString()} CHF
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    +8% from yesterday
                  </Typography>
                </CardContent>
              </DashboardCard>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Cigarette Stock
                    </Typography>
                    <Avatar sx={{ bgcolor: 'error.main' }}>
                      <SmokingIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div">
                    85%
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                    <Box sx={{ width: '100%', mr: 1 }}>
                      <LinearProgress variant="determinate" value={85} color="success" />
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Healthy
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </DashboardCard>
            </Grid>
          </Grid>

          {/* Charts */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={8}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Weekly Revenue
                </Typography>
                <Box sx={{ height: 300, mt: 2 }}>
                  <Bar 
                    data={barData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          position: 'top',
                        },
                        title: {
                          display: false,
                        },
                      },
                    }}
                  />
                </Box>
              </StyledPaper>
            </Grid>
            <Grid item xs={12} md={4}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Game Distribution
                </Typography>
                <Box sx={{ height: 300, mt: 2, display: 'flex', justifyContent: 'center' }}>
                  <Pie 
                    data={pieData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          position: 'bottom',
                        },
                      },
                    }}
                  />
                </Box>
              </StyledPaper>
            </Grid>
          </Grid>

          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Player Activity (24h)
                </Typography>
                <Box sx={{ height: 300, mt: 2 }}>
                  <Line 
                    data={lineData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          position: 'top',
                        },
                      },
                      scales: {
                        y: {
                          beginAtZero: true,
                        },
                      },
                    }}
                  />
                </Box>
              </StyledPaper>
            </Grid>
            <Grid item xs={12} md={4}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Popular Items
                </Typography>
                <List>
                  {stats.popularItems.map((item, index) => (
                    <ListItem key={index} sx={{ py: 1 }}>
                      <ListItemAvatar>
                        <Avatar sx={{ bgcolor: index === 0 ? 'primary.main' : index === 1 ? 'secondary.main' : 'grey.500' }}>
                          {index === 0 ? <SmokingIcon /> : index === 1 ? <DrinkIcon /> : <RestaurantIcon />}
                        </Avatar>
                      </ListItemAvatar>
                      <ListItemText 
                        primary={item.name} 
                        secondary={`${item.count} orders today`} 
                      />
                      <Typography variant="body2" color="text.secondary">
                        {index === 0 ? '+18%' : index === 1 ? '+12%' : index === 2 ? '+5%' : '+2%'}
                      </Typography>
                    </ListItem>
                  ))}
                </List>
              </StyledPaper>
            </Grid>
          </Grid>
        </>
      )}
    </Container>
  );
};

// Player Search Component
export const PlayerSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = () => {
    if (!searchTerm) return;
    
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      // Mock data
      setSearchResults([
        { id: 1, casino_guest_id: 'AR-10042', first_name: 'John', last_name: 'Smith', vip_status: 'GOLD', last_visit: '2025-03-25' },
        { id: 2, casino_guest_id: 'AR-10156', first_name: 'Emma', last_name: 'Johnson', vip_status: 'PLATINUM', last_visit: '2025-03-26' },
        { id: 3, casino_guest_id: 'AR-10089', first_name: 'Michael', last_name: 'Brown', vip_status: 'SILVER', last_visit: '2025-03-24' },
      ]);
      setLoading(false);
    }, 800);
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Player Search
      </Typography>
      
      <StyledPaper sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <TextField
            fullWidth
            label="Search by Name, ID, or Phone Number"
            variant="outlined"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            sx={{ mr: 2 }}
          />
          <Button
            variant="contained"
            startIcon={<SearchIcon />}
            onClick={handleSearch}
            disabled={!searchTerm || loading}
          >
            Search
          </Button>
        </Box>
        
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
          <Chip label="Advanced Search" onClick={() => {}} />
          <Chip label="Recent Players" onClick={() => {}} />
          <Chip label="VIP Players" onClick={() => {}} />
          <Chip label="Today's Birthdays" onClick={() => {}} />
        </Box>
      </StyledPaper>
      
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <CircularProgress />
        </Box>
      ) : searchResults.length > 0 ? (
        <TableContainer component={StyledPaper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Guest ID</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>VIP Status</TableCell>
                <TableCell>Last Visit</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {searchResults.map((player) => (
                <TableRow key={player.id} hover>
                  <TableCell>{player.casino_guest_id}</TableCell>
                  <TableCell>{`${player.first_name} ${player.last_name}`}</TableCell>
                  <TableCell>
                    <Chip 
                      label={player.vip_status} 
                      color={
                        player.vip_status === 'PLATINUM' ? 'primary' : 
                        player.vip_status === 'GOLD' ? 'warning' : 
                        player.vip_status === 'SILVER' ? 'secondary' : 
                        'default'
                      }
                      size="small"
                    />
                  </TableCell>
                  <TableCell>{player.last_visit}</TableCell>
                  <TableCell align="right">
                    <Tooltip title="View Profile">
                      <IconButton size="small" color="primary">
                        <PersonIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Start Session">
                      <IconButton size="small" color="success">
                        <CasinoIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Edit">
                      <IconButton size="small">
                        <EditIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : searchTerm && (
        <Box sx={{ textAlign: 'center', my: 4 }}>
          <Typography variant="h6" color="text.secondary">
            No players found matching "{searchTerm}"
          </Typography>
          <Button 
            variant="contained" 
            startIcon={<AddIcon />}
            sx={{ mt: 2 }}
          >
            Create New Player
          </Button>
        </Box>
      )}
    </Container>
  );
};

// Player Profile Component
export const PlayerProfile = ({ playerId = 1 }) => {
  const [player, setPlayer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);

  useEffect(() => {
    // Simulate API call to fetch player data
    setTimeout(() => {
      setPlayer({
        id: 1,
        casino_guest_id: 'AR-10042',
        first_name: 'John',
        last_name: 'Smith',
        email: 'john.smith@example.com',
        phone: '+41 79 123 4567',
        address: 'Bahnhofstrasse 123, 8001 Zürich, Switzerland',
        date_of_birth: '1985-06-15',
        nationality: 'Swiss',
        vip_status: 'GOLD',
        registration_date: '2023-11-10',
        last_visit: '2025-03-25',
        notes: 'Prefers window seating at restaurants. Allergic to shellfish.',
        photo_url: 'https://randomuser.me/api/portraits/men/32.jpg',
        stats: {
          total_visits: 42,
          total_hours: 156.5,
          avg_session_hours: 3.7,
          total_buy_in: 85000,
          total_cash_out: 92500,
          net_win_loss: 7500,
          favorite_game: 'Roulette',
          favorite_beverage: 'Whiskey Sour',
          favorite_cigarette: 'Marlboro Red'
        }
      });
      setLoading(false);
    }, 1000);
  }, [playerId]);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress size={60} />
      </Box>
    );
  }

  if (!player) {
    return (
      <Box sx={{ textAlign: 'center', my: 4 }}>
        <Typography variant="h6" color="text.secondary">
          Player not found
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<ArrowBackIcon />}
          sx={{ mt: 2 }}
        >
          Back to Search
        </Button>
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Player Profile
        </Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<ArrowBackIcon />}
            sx={{ mr: 2 }}
          >
            Back
          </Button>
          <Button 
            variant="contained" 
            startIcon={<CasinoIcon />}
            color="success"
          >
            Start Session
          </Button>
        </Box>
      </Box>

      {/* Player Header Card */}
      <StyledPaper sx={{ mb: 4 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={3}>
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
              <Avatar
                src={player.photo_url}
                alt={`${player.first_name} ${player.last_name}`}
                sx={{ width: 150, height: 150, border: '3px solid', borderColor: 'primary.main' }}
              />
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Typography variant="h4" component="h2">
                  {`${player.first_name} ${player.last_name}`}
                </Typography>
                <Chip 
                  label={player.vip_status} 
                  color={
                    player.vip_status === 'PLATINUM' ? 'primary' : 
                    player.vip_status === 'GOLD' ? 'warning' : 
                    player.vip_status === 'SILVER' ? 'secondary' : 
                    'default'
                  }
                  sx={{ ml: 2 }}
                />
              </Box>
              <Typography variant="subtitle1" color="text.secondary" gutterBottom>
                ID: {player.casino_guest_id}
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mt: 2 }}>
                <Typography variant="body1">
                  <strong>Email:</strong> {player.email}
                </Typography>
                <Typography variant="body1">
                  <strong>Phone:</strong> {player.phone}
                </Typography>
                <Typography variant="body1">
                  <strong>Date of Birth:</strong> {player.date_of_birth}
                </Typography>
                <Typography variant="body1">
                  <strong>Last Visit:</strong> {player.last_visit}
                </Typography>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} md={3}>
            <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'space-between' }}>
              <Box>
                <Typography variant="h6" gutterBottom>
                  Quick Stats
                </Typography>
                <Typography variant="body1">
                  <strong>Total Visits:</strong> {player.stats.total_visits}
                </Typography>
                <Typography variant="body1">
                  <strong>Total Hours:</strong> {player.stats.total_hours}
                </Typography>
                <Typography variant="body1">
                  <strong>Net Win/Loss:</strong> {player.stats.net_win_loss > 0 ? '+' : ''}{player.stats.net_win_loss.toLocaleString()} CHF
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
                <Button variant="outlined" size="small" startIcon={<EditIcon />}>
                  Edit
                </Button>
                <Button variant="outlined" size="small" startIcon={<PrintIcon />}>
                  Report
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </StyledPaper>

      {/* Tabs */}
      <Box sx={{ mb: 2 }}>
        <Tabs value={activeTab} onChange={handleTabChange} variant="scrollable" scrollButtons="auto">
          <Tab label="Overview" />
          <Tab label="Gaming History" />
          <Tab label="Financial" />
          <Tab label="Consumption" />
          <Tab label="Notes & Photos" />
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box sx={{ mt: 3 }}>
        {activeTab === 0 && (
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Player Summary
                </Typography>
                <Grid container spacing={3}>
                  <Grid item xs={12} sm={6}>
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Registration Date
                      </Typography>
                      <Typography variant="body1">
                        {player.registration_date}
                      </Typography>
                    </Box>
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Nationality
                      </Typography>
                      <Typography variant="body1">
                        {player.nationality}
                      </Typography>
                    </Box>
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Address
                      </Typography>
                      <Typography variant="body1">
                        {player.address}
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Favorite Game
                      </Typography>
                      <Typography variant="body1">
                        {player.stats.favorite_game}
                      </Typography>
                    </Box>
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Favorite Beverage
                      </Typography>
                      <Typography variant="body1">
                        {player.stats.favorite_beverage}
                      </Typography>
                    </Box>
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Favorite Cigarette
                      </Typography>
                      <Typography variant="body1">
                        {player.stats.favorite_cigarette}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
                <Box sx={{ mt: 2 }}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Notes
                  </Typography>
                  <Typography variant="body1">
                    {player.notes}
                  </Typography>
                </Box>
              </StyledPaper>
            </Grid>
            <Grid item xs={12} md={4}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Recent Activity
                </Typography>
                <Timeline>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot color="primary">
                        <CasinoIcon />
                      </TimelineDot>
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="body1">
                        Gaming Session
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        March 25, 2025 - 4.5 hours
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot color="success">
                        <MoneyIcon />
                      </TimelineDot>
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="body1">
                        Jackpot Win
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        March 25, 2025 - 5,000 CHF
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot color="warning">
                        <DrinkIcon />
                      </TimelineDot>
                      <TimelineConnector />
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="body1">
                        Beverage Order
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        March 25, 2025 - Whiskey Sour (2)
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>
                  <TimelineItem>
                    <TimelineSeparator>
                      <TimelineDot>
                        <SmokingIcon />
                      </TimelineDot>
                    </TimelineSeparator>
                    <TimelineContent>
                      <Typography variant="body1">
                        Cigarette Purchase
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        March 25, 2025 - Marlboro Red
                      </Typography>
                    </TimelineContent>
                  </TimelineItem>
                </Timeline>
              </StyledPaper>
            </Grid>
          </Grid>
        )}

        {activeTab === 1 && (
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Gaming History
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Date</TableCell>
                    <TableCell>Duration</TableCell>
                    <TableCell>Game Type</TableCell>
                    <TableCell>Location</TableCell>
                    <TableCell>Avg. Bet</TableCell>
                    <TableCell align="right">Win/Loss</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell>Mar 25, 2025</TableCell>
                    <TableCell>4.5 hours</TableCell>
                    <TableCell>Roulette</TableCell>
                    <TableCell>Table #3</TableCell>
                    <TableCell>250 CHF</TableCell>
                    <TableCell align="right" sx={{ color: 'success.main' }}>+2,500 CHF</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Mar 22, 2025</TableCell>
                    <TableCell>3.2 hours</TableCell>
                    <TableCell>Blackjack</TableCell>
                    <TableCell>Table #1</TableCell>
                    <TableCell>200 CHF</TableCell>
                    <TableCell align="right" sx={{ color: 'error.main' }}>-1,800 CHF</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Mar 18, 2025</TableCell>
                    <TableCell>5.0 hours</TableCell>
                    <TableCell>Slot Machine</TableCell>
                    <TableCell>Machine #42</TableCell>
                    <TableCell>50 CHF</TableCell>
                    <TableCell align="right" sx={{ color: 'success.main' }}>+3,200 CHF</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </StyledPaper>
        )}

        {activeTab === 2 && (
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Financial Transactions
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Date</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Amount</TableCell>
                    <TableCell>Payment Method</TableCell>
                    <TableCell>Staff</TableCell>
                    <TableCell>Notes</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell>Mar 25, 2025</TableCell>
                    <TableCell>Cash Out</TableCell>
                    <TableCell>7,500 CHF</TableCell>
                    <TableCell>Cash</TableCell>
                    <TableCell>Maria K.</TableCell>
                    <TableCell>End of session</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Mar 25, 2025</TableCell>
                    <TableCell>Jackpot</TableCell>
                    <TableCell>5,000 CHF</TableCell>
                    <TableCell>Hand Pay</TableCell>
                    <TableCell>Thomas L.</TableCell>
                    <TableCell>Slot machine #42</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Mar 25, 2025</TableCell>
                    <TableCell>Buy In</TableCell>
                    <TableCell>5,000 CHF</TableCell>
                    <TableCell>Credit Card</TableCell>
                    <TableCell>Maria K.</TableCell>
                    <TableCell>Session start</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </StyledPaper>
        )}

        {activeTab === 3 && (
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Beverage & Food Consumption
                </Typography>
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Date</TableCell>
                        <TableCell>Item</TableCell>
                        <TableCell>Quantity</TableCell>
                        <TableCell>Staff</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        <TableCell>Mar 25, 2025</TableCell>
                        <TableCell>Whiskey Sour</TableCell>
                        <TableCell>2</TableCell>
                        <TableCell>Anna M.</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Mar 25, 2025</TableCell>
                        <TableCell>Club Sandwich</TableCell>
                        <TableCell>1</TableCell>
                        <TableCell>Anna M.</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Mar 22, 2025</TableCell>
                        <TableCell>Heineken</TableCell>
                        <TableCell>3</TableCell>
                        <TableCell>David R.</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </StyledPaper>
            </Grid>
            <Grid item xs={12} md={6}>
              <StyledPaper>
                <Typography variant="h6" gutterBottom>
                  Cigarette Consumption
                </Typography>
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Date</TableCell>
                        <TableCell>Brand</TableCell>
                        <TableCell>Quantity</TableCell>
                        <TableCell>Staff</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        <TableCell>Mar 25, 2025</TableCell>
                        <TableCell>Marlboro Red</TableCell>
                        <TableCell>1 pack</TableCell>
                        <TableCell>Anna M.</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Mar 22, 2025</TableCell>
                        <TableCell>Marlboro Red</TableCell>
                        <TableCell>1 pack</TableCell>
                        <TableCell>David R.</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Mar 18, 2025</TableCell>
                        <TableCell>Marlboro Red</TableCell>
                        <TableCell>2 packs</TableCell>
                        <TableCell>Thomas L.</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </StyledPaper>
            </Grid>
          </Grid>
        )}

        {activeTab === 4 && (
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <StyledPaper>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    Notes
                  </Typography>
                  <Button startIcon={<AddIcon />} size="small">
                    Add Note
                  </Button>
                </Box>
                <List>
                  <ListItem>
                    <ListItemText
                      primary="VIP Preferences"
                      secondary="Prefers window seating at restaurants. Allergic to shellfish."
                      secondaryTypographyProps={{ paragraph: true }}
                    />
                    <Typography variant="caption" color="text.secondary">
                      Added by Maria K. on Mar 15, 2025
                    </Typography>
                  </ListItem>
                  <Divider />
                  <ListItem>
                    <ListItemText
                      primary="Birthday Celebration"
                      secondary="Celebrated birthday at the casino on June 15. Complimentary champagne and cake provided."
                      secondaryTypographyProps={{ paragraph: true }}
                    />
                    <Typography variant="caption" color="text.secondary">
                      Added by Thomas L. on Jun 15, 2024
                    </Typography>
                  </ListItem>
                </List>
              </StyledPaper>
            </Grid>
            <Grid item xs={12} md={6}>
              <StyledPaper>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    Photos
                  </Typography>
                  <Button startIcon={<CameraIcon />} size="small">
                    Add Photo
                  </Button>
                </Box>
                <Grid container spacing={2}>
                  <Grid item xs={6} sm={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        height="140"
                        image={player.photo_url}
                        alt="ID Photo"
                      />
                      <CardContent sx={{ py: 1 }}>
                        <Typography variant="body2">
                          ID Photo
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item xs={6} sm={4}>
                    <Card>
                      <CardMedia
                        component="img"
                        height="140"
                        image="https://images.unsplash.com/photo-1606167668584-78701c57f13d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=80"
                        alt="Jackpot Win"
                      />
                      <CardContent sx={{ py: 1 }}>
                        <Typography variant="body2">
                          Jackpot Win
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              </StyledPaper>
            </Grid>
          </Grid>
        )}
      </Box>
    </Container>
  );
};

// Mobile Quick Input Component for Slot Attendants
export const MobileQuickInput = () => {
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const [inputType, setInputType] = useState(null);
  const [numericValue, setNumericValue] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSearch = () => {
    if (!searchTerm) return;
    
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      // Mock data
      setSearchResults([
        { id: 1, casino_guest_id: 'AR-10042', first_name: 'John', last_name: 'Smith', vip_status: 'GOLD' },
        { id: 2, casino_guest_id: 'AR-10156', first_name: 'Emma', last_name: 'Johnson', vip_status: 'PLATINUM' },
        { id: 3, casino_guest_id: 'AR-10089', first_name: 'Michael', last_name: 'Brown', vip_status: 'SILVER' },
      ]);
      setLoading(false);
    }, 500);
  };

  const handlePlayerSelect = (player) => {
    setSelectedPlayer(player);
    setSearchResults([]);
    setSearchTerm('');
  };

  const handleNumPadClick = (value) => {
    if (value === 'clear') {
      setNumericValue('');
    } else if (value === 'backspace') {
      setNumericValue(prev => prev.slice(0, -1));
    } else {
      setNumericValue(prev => prev + value);
    }
  };

  const handleSubmit = () => {
    // Simulate API call to submit data
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      // Reset after showing success message
      setTimeout(() => {
        setSuccess(false);
        setSelectedPlayer(null);
        setInputType(null);
        setNumericValue('');
      }, 2000);
    }, 800);
  };

  const renderInputTypeSelection = () => (
    <Box>
      <Typography variant="h6" gutterBottom>
        Select Input Type
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <Button 
            fullWidth 
            variant="contained" 
            size="large"
            startIcon={<CasinoIcon />}
            onClick={() => setInputType('slot')}
            sx={{ py: 3 }}
          >
            Slot Activity
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button 
            fullWidth 
            variant="contained" 
            size="large"
            startIcon={<MoneyIcon />}
            onClick={() => setInputType('money')}
            sx={{ py: 3 }}
          >
            Money In/Out
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button 
            fullWidth 
            variant="contained" 
            size="large"
            startIcon={<DrinkIcon />}
            onClick={() => setInputType('drink')}
            sx={{ py: 3 }}
          >
            Drinks/Food
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button 
            fullWidth 
            variant="contained" 
            size="large"
            startIcon={<SmokingIcon />}
            onClick={() => setInputType('cigarette')}
            sx={{ py: 3 }}
          >
            Cigarettes
          </Button>
        </Grid>
      </Grid>
    </Box>
  );

  const renderNumericInput = () => {
    let title = '';
    let label = '';
    
    switch (inputType) {
      case 'slot':
        title = 'Slot Machine Activity';
        label = 'Slot Machine Number';
        break;
      case 'money':
        title = 'Money Transaction';
        label = 'Amount (CHF)';
        break;
      case 'drink':
        title = 'Drink/Food Order';
        label = 'Item Number';
        break;
      case 'cigarette':
        title = 'Cigarette Purchase';
        label = 'Quantity';
        break;
      default:
        break;
    }
    
    return (
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <IconButton onClick={() => setInputType(null)}>
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6">
            {title}
          </Typography>
        </Box>
        
        <TextField
          fullWidth
          label={label}
          variant="outlined"
          value={numericValue}
          InputProps={{
            readOnly: true,
          }}
          sx={{ mb: 2 }}
        />
        
        <NumPad>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('1')}>1</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('2')}>2</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('3')}>3</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('4')}>4</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('5')}>5</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('6')}>6</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('7')}>7</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('8')}>8</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('9')}>9</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('clear')} color="error">C</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('0')}>0</NumPadButton>
          <NumPadButton variant="outlined" onClick={() => handleNumPadClick('backspace')}>←</NumPadButton>
        </NumPad>
        
        <Button 
          fullWidth 
          variant="contained" 
          size="large" 
          onClick={handleSubmit}
          disabled={!numericValue || loading}
          sx={{ mt: 2, py: 1.5 }}
        >
          {loading ? <CircularProgress size={24} /> : 'Submit'}
        </Button>
      </Box>
    );
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 4, mb: 4 }}>
      <StyledPaper>
        <Typography variant="h5" component="h1" gutterBottom align="center">
          Quick Input
        </Typography>
        
        {!selectedPlayer ? (
          <Box>
            <Typography variant="h6" gutterBottom>
              Select Player
            </Typography>
            <Box sx={{ mb: 2 }}>
              <TextField
                fullWidth
                label="Search Player"
                variant="outlined"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                InputProps={{
                  endAdornment: (
                    <IconButton onClick={handleSearch} disabled={!searchTerm || loading}>
                      {loading ? <CircularProgress size={24} /> : <SearchIcon />}
                    </IconButton>
                  ),
                }}
              />
            </Box>
            
            {searchResults.length > 0 && (
              <List sx={{ mb: 2 }}>
                {searchResults.map((player) => (
                  <ListItem 
                    key={player.id} 
                    button 
                    onClick={() => handlePlayerSelect(player)}
                    divider
                  >
                    <ListItemAvatar>
                      <Avatar>
                        <PersonIcon />
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText 
                      primary={`${player.first_name} ${player.last_name}`} 
                      secondary={player.casino_guest_id} 
                    />
                    <Chip 
                      label={player.vip_status} 
                      color={
                        player.vip_status === 'PLATINUM' ? 'primary' : 
                        player.vip_status === 'GOLD' ? 'warning' : 
                        player.vip_status === 'SILVER' ? 'secondary' : 
                        'default'
                      }
                      size="small"
                    />
                  </ListItem>
                ))}
              </List>
            )}
            
            <Typography variant="h6" gutterBottom>
              Recent Players
            </Typography>
            <List>
              <ListItem button onClick={() => handlePlayerSelect({ id: 1, casino_guest_id: 'AR-10042', first_name: 'John', last_name: 'Smith', vip_status: 'GOLD' })}>
                <ListItemAvatar>
                  <StyledBadge
                    overlap="circular"
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                    variant="dot"
                  >
                    <Avatar>
                      <PersonIcon />
                    </Avatar>
                  </StyledBadge>
                </ListItemAvatar>
                <ListItemText 
                  primary="John Smith" 
                  secondary="AR-10042" 
                />
                <Chip label="GOLD" color="warning" size="small" />
              </ListItem>
              <ListItem button onClick={() => handlePlayerSelect({ id: 2, casino_guest_id: 'AR-10156', first_name: 'Emma', last_name: 'Johnson', vip_status: 'PLATINUM' })}>
                <ListItemAvatar>
                  <Avatar>
                    <PersonIcon />
                  </Avatar>
                </ListItemAvatar>
                <ListItemText 
                  primary="Emma Johnson" 
                  secondary="AR-10156" 
                />
                <Chip label="PLATINUM" color="primary" size="small" />
              </ListItem>
            </List>
          </Box>
        ) : !inputType ? (
          <Box>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
              <IconButton onClick={() => setSelectedPlayer(null)}>
                <ArrowBackIcon />
              </IconButton>
              <Typography variant="h6">
                {`${selectedPlayer.first_name} ${selectedPlayer.last_name}`}
              </Typography>
              <Chip 
                label={selectedPlayer.vip_status} 
                color={
                  selectedPlayer.vip_status === 'PLATINUM' ? 'primary' : 
                  selectedPlayer.vip_status === 'GOLD' ? 'warning' : 
                  selectedPlayer.vip_status === 'SILVER' ? 'secondary' : 
                  'default'
                }
                size="small"
                sx={{ ml: 1 }}
              />
            </Box>
            
            {renderInputTypeSelection()}
          </Box>
        ) : (
          renderNumericInput()
        )}
      </StyledPaper>
      
      <Snackbar
        open={success}
        autoHideDuration={2000}
        onClose={() => setSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity="success" sx={{ width: '100%' }}>
          Data submitted successfully!
        </Alert>
      </Snackbar>
    </Container>
  );
};

// Cigarette Inventory Management Component
export const CigaretteInventory = () => {
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newItem, setNewItem] = useState({
    brand: '',
    variant: '',
    quantity: 0,
    reorder_level: 5
  });

  useEffect(() => {
    // Simulate API call to fetch inventory data
    setTimeout(() => {
      setInventory([
        { id: 1, brand: 'Marlboro', variant: 'Red', quantity: 42, reorder_level: 10 },
        { id: 2, brand: 'Marlboro', variant: 'Gold', quantity: 28, reorder_level: 10 },
        { id: 3, brand: 'Camel', variant: 'Blue', quantity: 15, reorder_level: 8 },
        { id: 4, brand: 'Camel', variant: 'Yellow', quantity: 7, reorder_level: 8 },
        { id: 5, brand: 'Lucky Strike', variant: 'Red', quantity: 3, reorder_level: 5 },
        { id: 6, brand: 'Dunhill', variant: 'International', quantity: 12, reorder_level: 5 },
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewItem({
      ...newItem,
      [name]: name === 'quantity' || name === 'reorder_level' ? parseInt(value) || 0 : value
    });
  };

  const handleAddItem = () => {
    // Simulate API call to add item
    setLoading(true);
    setTimeout(() => {
      const newId = Math.max(...inventory.map(item => item.id)) + 1;
      setInventory([...inventory, { id: newId, ...newItem }]);
      setDialogOpen(false);
      setNewItem({
        brand: '',
        variant: '',
        quantity: 0,
        reorder_level: 5
      });
      setLoading(false);
    }, 500);
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Cigarette Inventory
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => setDialogOpen(true)}
        >
          Add New Item
        </Button>
      </Box>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Total Items
                    </Typography>
                    <Avatar sx={{ bgcolor: 'primary.main' }}>
                      <SmokingIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div">
                    {inventory.length}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Different cigarette brands/variants
                  </Typography>
                </CardContent>
              </DashboardCard>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Total Stock
                    </Typography>
                    <Avatar sx={{ bgcolor: 'success.main' }}>
                      <InventoryIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div">
                    {inventory.reduce((sum, item) => sum + item.quantity, 0)}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Total packs in inventory
                  </Typography>
                </CardContent>
              </DashboardCard>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Low Stock Items
                    </Typography>
                    <Avatar sx={{ bgcolor: 'error.main' }}>
                      <WarningIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div">
                    {inventory.filter(item => item.quantity <= item.reorder_level).length}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Items below reorder level
                  </Typography>
                </CardContent>
              </DashboardCard>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <DashboardCard>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography color="text.secondary" gutterBottom>
                      Most Popular
                    </Typography>
                    <Avatar sx={{ bgcolor: 'warning.main' }}>
                      <TrendingUpIcon />
                    </Avatar>
                  </Box>
                  <Typography variant="h4" component="div" noWrap>
                    Marlboro
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Based on last 30 days
                  </Typography>
                </CardContent>
              </DashboardCard>
            </Grid>
          </Grid>

          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Inventory Items
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Brand</TableCell>
                    <TableCell>Variant</TableCell>
                    <TableCell align="center">Quantity</TableCell>
                    <TableCell align="center">Reorder Level</TableCell>
                    <TableCell align="center">Status</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {inventory.map((item) => (
                    <TableRow key={item.id} hover>
                      <TableCell>{item.brand}</TableCell>
                      <TableCell>{item.variant}</TableCell>
                      <TableCell align="center">{item.quantity}</TableCell>
                      <TableCell align="center">{item.reorder_level}</TableCell>
                      <TableCell align="center">
                        <Chip 
                          label={item.quantity <= item.reorder_level ? "Low Stock" : "In Stock"} 
                          color={item.quantity <= item.reorder_level ? "error" : "success"} 
                          size="small"
                        />
                      </TableCell>
                      <TableCell align="right">
                        <Tooltip title="Add Stock">
                          <IconButton size="small" color="primary">
                            <AddIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit">
                          <IconButton size="small">
                            <EditIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </StyledPaper>
        </>
      )}

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
        <DialogTitle>Add New Cigarette Item</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            name="brand"
            label="Brand"
            type="text"
            fullWidth
            variant="outlined"
            value={newItem.brand}
            onChange={handleInputChange}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            name="variant"
            label="Variant"
            type="text"
            fullWidth
            variant="outlined"
            value={newItem.variant}
            onChange={handleInputChange}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            name="quantity"
            label="Initial Quantity"
            type="number"
            fullWidth
            variant="outlined"
            value={newItem.quantity}
            onChange={handleInputChange}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            name="reorder_level"
            label="Reorder Level"
            type="number"
            fullWidth
            variant="outlined"
            value={newItem.reorder_level}
            onChange={handleInputChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button 
            onClick={handleAddItem} 
            variant="contained"
            disabled={!newItem.brand}
          >
            Add Item
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

// Export all components
export default {
  PlayerTrackingDashboard,
  PlayerSearch,
  PlayerProfile,
  MobileQuickInput,
  CigaretteInventory
};
