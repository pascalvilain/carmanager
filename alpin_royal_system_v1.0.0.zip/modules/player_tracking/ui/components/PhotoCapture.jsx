import React, { useState, useRef } from 'react';
import { 
  Box, 
  Button, 
  Grid, 
  Typography, 
  Paper,
  IconButton,
  CircularProgress
} from '@mui/material';
import { 
  PhotoCamera as CameraIcon,
  FlipCameraAndroid as FlipCameraIcon,
  Check as CheckIcon,
  Close as CloseIcon
} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';

/**
 * PhotoCapture component for capturing player photos
 * 
 * @param {Object} props Component props
 * @param {Function} props.onCapture Function to call when photo is captured
 */
const PhotoCapture = ({ onCapture }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Refs
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  
  // State
  const [stream, setStream] = useState(null);
  const [photoType, setPhotoType] = useState('ID');
  const [capturedImage, setCapturedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [facingMode, setFacingMode] = useState('user'); // 'user' for front camera, 'environment' for back camera
  
  // Photo type options
  const photoTypeOptions = [
    { value: 'ID', label: 'ID Photo' },
    { value: 'RECEPTION', label: 'Reception Photo' },
    { value: 'JACKPOT', label: 'Jackpot Photo' },
    { value: 'HANDPAY', label: 'Hand Pay Photo' }
  ];
  
  // Start camera
  const startCamera = async () => {
    try {
      setLoading(true);
      
      if (stream) {
        // Stop existing stream
        stream.getTracks().forEach(track => track.stop());
      }
      
      const constraints = {
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: facingMode
        }
      };
      
      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
    } finally {
      setLoading(false);
    }
  };
  
  // Stop camera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };
  
  // Capture photo
  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw video frame to canvas
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Get image data
    const imageData = canvas.toDataURL('image/jpeg');
    setCapturedImage(imageData);
    
    // Stop camera
    stopCamera();
  };
  
  // Reset capture
  const resetCapture = () => {
    setCapturedImage(null);
    startCamera();
  };
  
  // Switch camera (front/back)
  const switchCamera = () => {
    setFacingMode(prevMode => prevMode === 'user' ? 'environment' : 'user');
  };
  
  // Handle photo type change
  const handlePhotoTypeChange = (type) => {
    setPhotoType(type);
  };
  
  // Handle save photo
  const handleSavePhoto = () => {
    if (capturedImage && photoType) {
      // Convert base64 to blob
      const base64Response = fetch(capturedImage);
      base64Response.then(res => res.blob())
        .then(blob => {
          onCapture(blob, photoType);
        });
    }
  };
  
  // Start camera on mount
  React.useEffect(() => {
    startCamera();
    
    // Cleanup on unmount
    return () => {
      stopCamera();
    };
  }, [facingMode]);
  
  return (
    <Box sx={{ mt: 1 }}>
      <Typography variant="h6" gutterBottom>
        Capture Photo
      </Typography>
      
      {/* Photo type selection */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle2" gutterBottom>
          Photo Type
        </Typography>
        
        <Grid container spacing={1}>
          {photoTypeOptions.map((option) => (
            <Grid item xs={6} sm={3} key={option.value}>
              <Button
                fullWidth
                variant={photoType === option.value ? "contained" : "outlined"}
                color="primary"
                onClick={() => handlePhotoTypeChange(option.value)}
                sx={{ mb: 1 }}
              >
                {option.label}
              </Button>
            </Grid>
          ))}
        </Grid>
      </Paper>
      
      {/* Camera view */}
      <Box sx={{ position: 'relative', mb: 2 }}>
        {loading && (
          <Box sx={{ 
            position: 'absolute', 
            top: 0, 
            left: 0, 
            right: 0, 
            bottom: 0, 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 10
          }}>
            <CircularProgress color="primary" />
          </Box>
        )}
        
        {capturedImage ? (
          <Box sx={{ textAlign: 'center' }}>
            <img 
              src={capturedImage} 
              alt="Captured" 
              style={{ 
                maxWidth: '100%', 
                maxHeight: '300px',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }} 
            />
          </Box>
        ) : (
          <Box sx={{ textAlign: 'center' }}>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              style={{ 
                maxWidth: '100%', 
                maxHeight: '300px',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </Box>
        )}
        
        {/* Hidden canvas for capturing */}
        <canvas ref={canvasRef} style={{ display: 'none' }} />
      </Box>
      
      {/* Camera controls */}
      <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, mb: 2 }}>
        {capturedImage ? (
          <>
            <Button
              variant="outlined"
              color="secondary"
              startIcon={<CloseIcon />}
              onClick={resetCapture}
            >
              Retake
            </Button>
            
            <Button
              variant="contained"
              color="primary"
              startIcon={<CheckIcon />}
              onClick={handleSavePhoto}
            >
              Save Photo
            </Button>
          </>
        ) : (
          <>
            {isMobile && (
              <IconButton 
                color="primary" 
                onClick={switchCamera}
                disabled={loading}
              >
                <FlipCameraIcon />
              </IconButton>
            )}
            
            <Button
              variant="contained"
              color="primary"
              startIcon={<CameraIcon />}
              onClick={capturePhoto}
              disabled={!stream || loading}
            >
              Capture
            </Button>
          </>
        )}
      </Box>
    </Box>
  );
};

export default PhotoCapture;
