import React, { useState } from 'react';
import { 
  Box, 
  TextField, 
  Button, 
  Grid, 
  Typography, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  IconButton
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import NumPad from './NumPad';

/**
 * ConsumptionForm component for recording player consumption
 * 
 * @param {Object} props Component props
 * @param {Function} props.onSubmit Function to call when form is submitted
 * @param {string} props.sessionId Current active session ID
 */
const ConsumptionForm = ({ onSubmit, sessionId }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Form state
  const [formData, setFormData] = useState({
    item_type: '',
    item_name: '',
    quantity: 1,
    price: 0
  });
  
  // Validation state
  const [errors, setErrors] = useState({});
  
  // NumPad state
  const [numPadOpen, setNumPadOpen] = useState(false);
  const [numPadField, setNumPadField] = useState('');
  const [numPadValue, setNumPadValue] = useState('');
  
  // Item type options
  const itemTypeOptions = [
    'DRINK',
    'FOOD',
    'CIGARETTE',
    'OTHER'
  ];
  
  // Predefined items by type
  const predefinedItems = {
    DRINK: [
      { name: 'Beer', price: 8.00 },
      { name: 'Wine', price: 12.00 },
      { name: 'Cocktail', price: 15.00 },
      { name: 'Whiskey', price: 18.00 },
      { name: 'Vodka', price: 16.00 },
      { name: 'Soft Drink', price: 5.00 },
      { name: 'Water', price: 3.00 },
      { name: 'Coffee', price: 4.50 }
    ],
    FOOD: [
      { name: 'Sandwich', price: 12.00 },
      { name: 'Burger', price: 18.00 },
      { name: 'Pizza', price: 16.00 },
      { name: 'Salad', price: 14.00 },
      { name: 'Steak', price: 35.00 },
      { name: 'Fries', price: 8.00 },
      { name: 'Snack Mix', price: 6.00 }
    ],
    CIGARETTE: [
      { name: 'Marlboro', price: 12.00 },
      { name: 'Camel', price: 11.50 },
      { name: 'Newport', price: 12.50 },
      { name: 'Winston', price: 11.00 },
      { name: 'Parliament', price: 13.00 }
    ],
    OTHER: [
      { name: 'Magazine', price: 8.00 },
      { name: 'Phone Charger', price: 25.00 },
      { name: 'Aspirin', price: 5.00 }
    ]
  };
  
  // Handle text input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
    
    // If item type changes, reset item name and price
    if (name === 'item_type') {
      setFormData({
        ...formData,
        item_type: value,
        item_name: '',
        price: 0
      });
    }
    
    // If item name changes and it's a predefined item, set the price
    if (name === 'item_name' && formData.item_type) {
      const selectedItem = predefinedItems[formData.item_type]?.find(item => item.name === value);
      if (selectedItem) {
        setFormData({
          ...formData,
          item_name: value,
          price: selectedItem.price
        });
      }
    }
  };
  
  // Handle number input change
  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value === '' ? '' : Number(value)
    });
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  // Open numpad for a specific field
  const handleOpenNumPad = (field, currentValue) => {
    setNumPadField(field);
    setNumPadValue(currentValue.toString());
    setNumPadOpen(true);
  };
  
  // Handle numpad submit
  const handleNumPadSubmit = (value) => {
    setFormData({
      ...formData,
      [numPadField]: value
    });
    
    // Clear error for this field
    if (errors[numPadField]) {
      setErrors({
        ...errors,
        [numPadField]: ''
      });
    }
    
    setNumPadOpen(false);
  };
  
  // Validate form
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.item_type) {
      newErrors.item_type = 'Item type is required';
    }
    
    if (!formData.item_name) {
      newErrors.item_name = 'Item name is required';
    }
    
    if (!formData.quantity || formData.quantity <= 0) {
      newErrors.quantity = 'Quantity must be greater than 0';
    }
    
    if (formData.price < 0) {
      newErrors.price = 'Price cannot be negative';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Handle form submit
  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    
    if (validateForm()) {
      onSubmit({
        ...formData,
        session_id: sessionId
      });
    }
  };
  
  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <FormControl fullWidth error={!!errors.item_type}>
            <InputLabel id="item-type-label">Item Type</InputLabel>
            <Select
              labelId="item-type-label"
              id="item_type"
              name="item_type"
              value={formData.item_type}
              onChange={handleInputChange}
              label="Item Type"
            >
              {itemTypeOptions.map((option) => (
                <MenuItem key={option} value={option}>{option}</MenuItem>
              ))}
            </Select>
            {errors.item_type && <FormHelperText>{errors.item_type}</FormHelperText>}
          </FormControl>
        </Grid>
        
        {formData.item_type && (
          <Grid item xs={12}>
            <FormControl fullWidth error={!!errors.item_name}>
              <InputLabel id="item-name-label">Item Name</InputLabel>
              <Select
                labelId="item-name-label"
                id="item_name"
                name="item_name"
                value={formData.item_name}
                onChange={handleInputChange}
                label="Item Name"
              >
                {predefinedItems[formData.item_type]?.map((item) => (
                  <MenuItem key={item.name} value={item.name}>
                    {item.name} - ${item.price.toFixed(2)}
                  </MenuItem>
                ))}
              </Select>
              {errors.item_name && <FormHelperText>{errors.item_name}</FormHelperText>}
            </FormControl>
          </Grid>
        )}
        
        <Grid item xs={12} sm={6}>
          {isMobile ? (
            <TextField
              fullWidth
              label="Quantity"
              name="quantity"
              value={formData.quantity}
              onChange={handleNumberChange}
              error={!!errors.quantity}
              helperText={errors.quantity}
              InputProps={{
                readOnly: true,
                onClick: () => handleOpenNumPad('quantity', formData.quantity)
              }}
            />
          ) : (
            <TextField
              fullWidth
              label="Quantity"
              name="quantity"
              value={formData.quantity}
              onChange={handleNumberChange}
              error={!!errors.quantity}
              helperText={errors.quantity}
              type="number"
              inputProps={{ min: 1 }}
            />
          )}
        </Grid>
        
        <Grid item xs={12} sm={6}>
          {isMobile ? (
            <TextField
              fullWidth
              label="Price ($)"
              name="price"
              value={formData.price}
              onChange={handleNumberChange}
              error={!!errors.price}
              helperText={errors.price}
              InputProps={{
                readOnly: true,
                onClick: () => handleOpenNumPad('price', formData.price)
              }}
            />
          ) : (
            <TextField
              fullWidth
              label="Price ($)"
              name="price"
              value={formData.price}
              onChange={handleNumberChange}
              error={!!errors.price}
              helperText={errors.price}
              type="number"
              inputProps={{ step: "0.01" }}
            />
          )}
        </Grid>
      </Grid>
      
      <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          size="large"
        >
          Add Consumption
        </Button>
      </Box>
      
      {/* NumPad Dialog for Mobile */}
      {isMobile && (
        <NumPad
          open={numPadOpen}
          value={numPadValue}
          onChange={setNumPadValue}
          onClose={() => setNumPadOpen(false)}
          onSubmit={handleNumPadSubmit}
          label={numPadField === 'price' ? 'Enter Price' : 'Enter Quantity'}
          type={numPadField === 'price' ? 'currency' : 'number'}
        />
      )}
    </Box>
  );
};

export default ConsumptionForm;
