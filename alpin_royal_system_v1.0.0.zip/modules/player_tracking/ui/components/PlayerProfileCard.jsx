import React, { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  Typography, 
  Grid, 
  Box, 
  Button, 
  Chip,
  Avatar,
  Divider
} from '@mui/material';
import { 
  Casino as CasinoIcon,
  AccessTime as AccessTimeIcon,
  LocationOn as LocationIcon
} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';

/**
 * PlayerProfileCard component displays player information and active session status
 * 
 * @param {Object} props Component props
 * @param {Object} props.player Player data object
 * @param {Object} props.activeSession Active gaming session data (if any)
 * @param {Function} props.onStartSession Function to call when starting a new session
 * @param {Function} props.onEndSession Function to call when ending the active session
 */
const PlayerProfileCard = ({ 
  player, 
  activeSession, 
  onStartSession, 
  onEndSession 
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [sessionDuration, setSessionDuration] = useState('');
  
  // Calculate and update session duration if there's an active session
  useEffect(() => {
    if (!activeSession) return;
    
    const updateDuration = () => {
      const startTime = new Date(activeSession.start_time);
      const now = new Date();
      const diffMs = now - startTime;
      const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      
      setSessionDuration(`${diffHrs}h ${diffMins}m`);
    };
    
    // Update immediately and then every minute
    updateDuration();
    const interval = setInterval(updateDuration, 60000);
    
    return () => clearInterval(interval);
  }, [activeSession]);
  
  if (!player) return null;
  
  return (
    <Card 
      elevation={3} 
      className={player.vip_status ? 'vip-player-card' : 'player-card'}
      sx={{ 
        position: 'relative',
        overflow: 'visible',
        mb: 3
      }}
    >
      {player.vip_status && (
        <Chip
          label="VIP"
          color="secondary"
          sx={{
            position: 'absolute',
            top: -12,
            right: 16,
            fontWeight: 'bold'
          }}
        />
      )}
      
      <CardContent>
        <Grid container spacing={2}>
          {/* Player Photo */}
          <Grid item xs={4} sm={3} md={2}>
            <Avatar
              src={player.profile_photo_url}
              alt={player.full_name}
              sx={{ 
                width: isMobile ? 80 : 100, 
                height: isMobile ? 80 : 100,
                border: '2px solid',
                borderColor: player.vip_status ? 'secondary.main' : 'primary.main'
              }}
            >
              {player.full_name.charAt(0)}
            </Avatar>
          </Grid>
          
          {/* Player Info */}
          <Grid item xs={8} sm={5} md={6}>
            <Typography variant="h5" component="h2" gutterBottom>
              {player.full_name}
            </Typography>
            
            <Typography variant="body2" color="textSecondary" gutterBottom>
              ID: {player.casino_guest_id}
            </Typography>
            
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
              {player.preferences && player.preferences.map((pref, index) => (
                <Chip 
                  key={index} 
                  label={pref} 
                  size="small" 
                  variant="outlined" 
                />
              ))}
            </Box>
          </Grid>
          
          {/* Session Status */}
          <Grid item xs={12} sm={4} md={4} sx={{ textAlign: isMobile ? 'left' : 'right' }}>
            {activeSession ? (
              <Box>
                <Typography variant="subtitle1" color="primary" sx={{ fontWeight: 'bold' }}>
                  Active Session
                </Typography>
                
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: isMobile ? 'flex-start' : 'flex-end', mt: 1 }}>
                  <AccessTimeIcon fontSize="small" sx={{ mr: 0.5 }} />
                  <Typography variant="body2">
                    Duration: {sessionDuration}
                  </Typography>
                </Box>
                
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: isMobile ? 'flex-start' : 'flex-end', mt: 0.5 }}>
                  <LocationIcon fontSize="small" sx={{ mr: 0.5 }} />
                  <Typography variant="body2">
                    {activeSession.location}
                  </Typography>
                </Box>
                
                <Button
                  variant="outlined"
                  color="secondary"
                  size="small"
                  onClick={onEndSession}
                  sx={{ mt: 1 }}
                >
                  End Session
                </Button>
              </Box>
            ) : (
              <Box>
                <Typography variant="subtitle1" color="textSecondary">
                  No Active Session
                </Typography>
                
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<CasinoIcon />}
                  onClick={onStartSession}
                  sx={{ mt: 1 }}
                >
                  Start Session
                </Button>
              </Box>
            )}
          </Grid>
        </Grid>
        
        <Divider sx={{ my: 2 }} />
        
        {/* Player Stats */}
        <Grid container spacing={2}>
          <Grid item xs={6} sm={3}>
            <Typography variant="body2" color="textSecondary">
              Last Visit
            </Typography>
            <Typography variant="body1">
              {player.last_visit_date ? new Date(player.last_visit_date).toLocaleDateString() : 'N/A'}
            </Typography>
          </Grid>
          
          <Grid item xs={6} sm={3}>
            <Typography variant="body2" color="textSecondary">
              Total Visits
            </Typography>
            <Typography variant="body1">
              {player.total_visits || 0}
            </Typography>
          </Grid>
          
          <Grid item xs={6} sm={3}>
            <Typography variant="body2" color="textSecondary">
              Avg. Bet
            </Typography>
            <Typography variant="body1">
              ${player.average_bet?.toFixed(2) || '0.00'}
            </Typography>
          </Grid>
          
          <Grid item xs={6} sm={3}>
            <Typography variant="body2" color="textSecondary">
              Win/Loss
            </Typography>
            <Typography 
              variant="body1" 
              sx={{ 
                color: (player.total_win_loss || 0) >= 0 ? 'success.main' : 'error.main',
                fontWeight: 'bold'
              }}
            >
              {(player.total_win_loss || 0) >= 0 ? '+' : ''}
              ${Math.abs(player.total_win_loss || 0).toFixed(2)}
            </Typography>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

export default PlayerProfileCard;
