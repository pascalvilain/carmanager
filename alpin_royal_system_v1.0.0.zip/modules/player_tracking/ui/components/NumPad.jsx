import React, { useState, useEffect } from 'react';
import { 
  Box, 
  TextField, 
  Button, 
  Grid, 
  Typography, 
  Paper,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import { 
  Backspace as BackspaceIcon,
  Check as CheckIcon
} from '@mui/icons-material';

/**
 * NumPad component for mobile data entry
 * 
 * @param {Object} props Component props
 * @param {string} props.value Current value
 * @param {function} props.onChange Function to call when value changes
 * @param {string} props.label Input label
 * @param {string} props.type Input type (number, currency, text)
 * @param {boolean} props.open Whether the numpad is open
 * @param {function} props.onClose Function to call when numpad is closed
 * @param {function} props.onSubmit Function to call when value is submitted
 * @param {boolean} props.fullWidth Whether the component should take full width
 */
const NumPad = ({
  value = '',
  onChange,
  label = 'Enter value',
  type = 'number',
  open = false,
  onClose,
  onSubmit,
  fullWidth = false
}) => {
  const [internalValue, setInternalValue] = useState(value.toString());
  
  useEffect(() => {
    setInternalValue(value.toString());
  }, [value, open]);
  
  const handleButtonClick = (digit) => {
    let newValue = internalValue;
    
    // Handle decimal point
    if (digit === '.' && type !== 'text') {
      if (!newValue.includes('.')) {
        newValue += '.';
      }
    } 
    // Handle digits
    else {
      newValue += digit;
    }
    
    setInternalValue(newValue);
    if (onChange) {
      onChange(type === 'number' || type === 'currency' ? parseFloat(newValue) : newValue);
    }
  };
  
  const handleBackspace = () => {
    if (internalValue.length > 0) {
      const newValue = internalValue.slice(0, -1);
      setInternalValue(newValue);
      if (onChange) {
        onChange(type === 'number' || type === 'currency' ? 
          (newValue.length > 0 ? parseFloat(newValue) : '') : 
          newValue);
      }
    }
  };
  
  const handleClear = () => {
    setInternalValue('');
    if (onChange) {
      onChange(type === 'number' || type === 'currency' ? '' : '');
    }
  };
  
  const handleSubmit = () => {
    if (onSubmit) {
      onSubmit(type === 'number' || type === 'currency' ? 
        (internalValue.length > 0 ? parseFloat(internalValue) : 0) : 
        internalValue);
    }
    if (onClose) {
      onClose();
    }
  };
  
  const renderNumPad = () => (
    <Box sx={{ width: '100%', maxWidth: 300, mx: 'auto' }}>
      <TextField
        fullWidth
        label={label}
        value={type === 'currency' ? `$${internalValue}` : internalValue}
        InputProps={{
          readOnly: true,
        }}
        variant="outlined"
        margin="normal"
      />
      
      <Grid container spacing={1} sx={{ mt: 1 }}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
          <Grid item xs={4} key={digit}>
            <Button
              variant="outlined"
              fullWidth
              sx={{ 
                height: 60, 
                fontSize: '1.5rem',
                borderRadius: 2
              }}
              onClick={() => handleButtonClick(digit.toString())}
            >
              {digit}
            </Button>
          </Grid>
        ))}
        
        <Grid item xs={4}>
          <Button
            variant="outlined"
            fullWidth
            sx={{ 
              height: 60, 
              fontSize: '1.5rem',
              borderRadius: 2
            }}
            onClick={() => handleButtonClick('.')}
            disabled={type === 'text'}
          >
            .
          </Button>
        </Grid>
        
        <Grid item xs={4}>
          <Button
            variant="outlined"
            fullWidth
            sx={{ 
              height: 60, 
              fontSize: '1.5rem',
              borderRadius: 2
            }}
            onClick={() => handleButtonClick('0')}
          >
            0
          </Button>
        </Grid>
        
        <Grid item xs={4}>
          <Button
            variant="outlined"
            color="error"
            fullWidth
            sx={{ 
              height: 60,
              borderRadius: 2
            }}
            onClick={handleBackspace}
          >
            <BackspaceIcon />
          </Button>
        </Grid>
      </Grid>
      
      <Grid container spacing={1} sx={{ mt: 1 }}>
        <Grid item xs={6}>
          <Button
            variant="outlined"
            color="secondary"
            fullWidth
            sx={{ height: 50 }}
            onClick={handleClear}
          >
            Clear
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button
            variant="contained"
            color="primary"
            fullWidth
            sx={{ height: 50 }}
            onClick={handleSubmit}
            endIcon={<CheckIcon />}
          >
            Enter
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
  
  // If used as a dialog
  if (onClose) {
    return (
      <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
        <DialogTitle>
          {label}
        </DialogTitle>
        <DialogContent>
          {renderNumPad()}
        </DialogContent>
      </Dialog>
    );
  }
  
  // If used inline
  return (
    <Box sx={{ width: fullWidth ? '100%' : 'auto' }}>
      {renderNumPad()}
    </Box>
  );
};

export default NumPad;
