import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button,
  CircularProgress,
  Tabs,
  Tab,
  Paper
} from '@mui/material';
import { 
  BarChart as BarChartIcon,
  PieChart as PieChartIcon,
  TrendingUp as TrendingUpIcon,
  Print as PrintIcon
} from '@mui/icons-material';

/**
 * PlayerDashboard component displays player statistics and charts
 * 
 * @param {Object} props Component props
 * @param {Object} props.playerData Player data object
 * @param {Object} props.dashboardData Dashboard data from API
 * @param {Function} props.onGenerateReport Function to call when generating a report
 */
const PlayerDashboard = ({ 
  playerData, 
  dashboardData, 
  onGenerateReport 
}) => {
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  
  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  
  if (!dashboardData) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }
  
  return (
    <Box>
      {/* Header with action buttons */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h5">
          Player Dashboard
        </Typography>
        
        <Button
          variant="outlined"
          startIcon={<PrintIcon />}
          onClick={onGenerateReport}
        >
          Generate Report
        </Button>
      </Box>
      
      {/* Summary Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={3}>
          <Card className="stat-card">
            <CardContent>
              <div className="stat-value">{dashboardData.total_visits || 0}</div>
              <div className="stat-label">Total Visits</div>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={6} sm={3}>
          <Card className="stat-card">
            <CardContent>
              <div className="stat-value">{dashboardData.total_hours?.toFixed(1) || '0.0'}</div>
              <div className="stat-label">Hours Played</div>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={6} sm={3}>
          <Card className="stat-card">
            <CardContent>
              <div className="stat-value">${dashboardData.avg_bet?.toFixed(2) || '0.00'}</div>
              <div className="stat-label">Average Bet</div>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={6} sm={3}>
          <Card className="stat-card">
            <CardContent>
              <div className="stat-value" style={{ 
                color: (dashboardData.financial_summary?.net_win_loss || 0) >= 0 ? 'var(--success-color)' : 'var(--danger-color)' 
              }}>
                {(dashboardData.financial_summary?.net_win_loss || 0) >= 0 ? '+' : ''}
                ${Math.abs(dashboardData.financial_summary?.net_win_loss || 0).toFixed(2)}
              </div>
              <div className="stat-label">Net Win/Loss</div>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      
      {/* Dashboard Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="fullWidth"
        >
          <Tab icon={<BarChartIcon />} label="Gaming" />
          <Tab icon={<TrendingUpIcon />} label="Financial" />
          <Tab icon={<PieChartIcon />} label="Consumption" />
        </Tabs>
      </Paper>
      
      {/* Gaming Tab */}
      {activeTab === 0 && (
        <Box>
          <Typography variant="h6" gutterBottom>
            Gaming Activity
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>
                    Table Games
                  </Typography>
                  
                  {dashboardData.table_games_summary && dashboardData.table_games_summary.length > 0 ? (
                    <Box sx={{ mt: 2 }}>
                      {dashboardData.table_games_summary.map((game, index) => (
                        <Box key={index} sx={{ mb: 1, display: 'flex', justifyContent: 'space-between' }}>
                          <Typography variant="body2">
                            {game.game_name}
                          </Typography>
                          <Typography variant="body2" fontWeight="bold">
                            {game.total_hours.toFixed(1)} hrs
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  ) : (
                    <Typography variant="body2" color="textSecondary">
                      No table game data available
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>
                    Slot Machines
                  </Typography>
                  
                  {dashboardData.slot_machines_summary && dashboardData.slot_machines_summary.length > 0 ? (
                    <Box sx={{ mt: 2 }}>
                      {dashboardData.slot_machines_summary.map((machine, index) => (
                        <Box key={index} sx={{ mb: 1, display: 'flex', justifyContent: 'space-between' }}>
                          <Typography variant="body2">
                            {machine.machine_name}
                          </Typography>
                          <Typography variant="body2" fontWeight="bold">
                            {machine.total_hours.toFixed(1)} hrs
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  ) : (
                    <Typography variant="body2" color="textSecondary">
                      No slot machine data available
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          
          <Typography variant="h6" gutterBottom sx={{ mt: 3 }}>
            Recent Sessions
          </Typography>
          
          <Card>
            <CardContent>
              {dashboardData.recent_sessions && dashboardData.recent_sessions.length > 0 ? (
                <Box>
                  {dashboardData.recent_sessions.map((session, index) => (
                    <Box key={index} sx={{ 
                      mb: 2, 
                      pb: 2, 
                      borderBottom: index < dashboardData.recent_sessions.length - 1 ? '1px solid #eee' : 'none' 
                    }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                        <Typography variant="subtitle2">
                          {new Date(session.start_time).toLocaleDateString()}
                        </Typography>
                        <Typography variant="subtitle2">
                          {session.duration_minutes ? `${Math.floor(session.duration_minutes / 60)}h ${session.duration_minutes % 60}m` : 'Active'}
                        </Typography>
                      </Box>
                      <Typography variant="body2" color="textSecondary">
                        Location: {session.location}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              ) : (
                <Typography variant="body2" color="textSecondary">
                  No recent sessions available
                </Typography>
              )}
            </CardContent>
          </Card>
        </Box>
      )}
      
      {/* Financial Tab */}
      {activeTab === 1 && (
        <Box>
          <Typography variant="h6" gutterBottom>
            Financial Summary
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>
                    Transactions
                  </Typography>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
                    <Box>
                      <Typography variant="body2" color="textSecondary">Total Buy-ins</Typography>
                      <Typography variant="h6">${dashboardData.financial_summary?.total_buy_ins?.toFixed(2) || '0.00'}</Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="textSecondary">Total Cash-outs</Typography>
                      <Typography variant="h6">${dashboardData.financial_summary?.total_cash_outs?.toFixed(2) || '0.00'}</Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>
                    Jackpots & Hand Pays
                  </Typography>
                  
                  {dashboardData.jackpots && dashboardData.jackpots.length > 0 ? (
                    <Box sx={{ mt: 2 }}>
                      {dashboardData.jackpots.map((jackpot, index) => (
                        <Box key={index} sx={{ mb: 1, display: 'flex', justifyContent: 'space-between' }}>
                          <Typography variant="body2">
                            {new Date(jackpot.timestamp).toLocaleDateString()} - {jackpot.type}
                          </Typography>
                          <Typography variant="body2" fontWeight="bold" color="success.main">
                            ${jackpot.amount.toFixed(2)}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  ) : (
                    <Typography variant="body2" color="textSecondary">
                      No jackpot data available
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          
          <Typography variant="h6" gutterBottom sx={{ mt: 3 }}>
            Win/Loss Trend
          </Typography>
          
          <Card>
            <CardContent>
              {dashboardData.win_loss_trend && dashboardData.win_loss_trend.length > 0 ? (
                <Box sx={{ height: 200, display: 'flex', alignItems: 'flex-end' }}>
                  {dashboardData.win_loss_trend.map((item, index) => (
                    <Box 
                      key={index} 
                      sx={{ 
                        flex: 1,
                        mx: 0.5,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center'
                      }}
                    >
                      <Box 
                        sx={{ 
                          width: '100%',
                          height: `${Math.min(Math.abs(item.amount) / 100 * 150, 150)}px`,
                          backgroundColor: item.amount >= 0 ? 'success.main' : 'error.main',
                          borderRadius: '4px 4px 0 0',
                          transition: 'height 0.3s ease'
                        }} 
                      />
                      <Typography variant="caption" sx={{ mt: 0.5 }}>
                        {new Date(item.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              ) : (
                <Typography variant="body2" color="textSecondary">
                  No win/loss trend data available
                </Typography>
              )}
            </CardContent>
          </Card>
        </Box>
      )}
      
      {/* Consumption Tab */}
      {activeTab === 2 && (
        <Box>
          <Typography variant="h6" gutterBottom>
            Consumption Summary
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>
                    Cigarette Preferences
                  </Typography>
                  
                  {dashboardData.cigarette_preferences && dashboardData.cigarette_preferences.length > 0 ? (
                    <Box sx={{ mt: 2 }}>
                      {dashboardData.cigarette_preferences.map((item, index) => (
                        <Box key={index} sx={{ mb: 1 }}>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Typography variant="body2">
                              {item.brand}
                            </Typography>
                            <Typography variant="body2">
                              {item.packs} packs
                            </Typography>
                          </Box>
                          <Box sx={{ width: '100%', height: 4, backgroundColor: '#eee', borderRadius: 2, mt: 0.5 }}>
                            <Box 
                              sx={{ 
                                width: `${item.percentage}%`, 
                                height: '100%', 
                                backgroundColor: 'primary.main',
                                borderRadius: 2
                              }} 
                            />
                          </Box>
                        </Box>
                      ))}
                    </Box>
                  ) : (
                    <Typography variant="body2" color="textSecondary">
                      No cigarette data available
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="subtitle1" gutterBottom>
                    Drink Preferences
                  </Typography>
                  
                  {dashboardData.drink_preferences && dashboardData.drink_preferences.length > 0 ? (
                    <Box sx={{ mt: 2 }}>
                      {dashboardData.drink_preferences.map((item, index) => (
                        <Box key={index} sx={{ mb: 1 }}>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Typography variant="body2">
                              {item.name}
                            </Typography>
                            <Typography variant="body2">
                              {item.count}
                            </Typography>
                          </Box>
                          <Box sx={{ width: '100%', height: 4, backgroundColor: '#eee', borderRadius: 2, mt: 0.5 }}>
                            <Box 
                              sx={{ 
                                width: `${item.percentage}%`, 
                                height: '100%', 
                                backgroundColor: 'secondary.main',
                                borderRadius: 2
                              }} 
                            />
                          </Box>
                        </Box>
                      ))}
                    </Box>
        <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>