import React, { useState } from 'react';
import { 
  Box, 
  Button, 
  Grid, 
  Typography, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Paper
} from '@mui/material';
import { 
  PictureAsPdf as PdfIcon,
  CalendarToday as CalendarIcon
} from '@mui/icons-material';

/**
 * ReportGenerator component for generating player reports
 * 
 * @param {Object} props Component props
 * @param {Array} props.templates Available report templates
 * @param {Function} props.onGenerate Function to call when generating a report
 */
const ReportGenerator = ({ templates = [], onGenerate }) => {
  // State
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [timeRange, setTimeRange] = useState('THIS_MONTH');
  
  // Time range options
  const timeRangeOptions = [
    { value: 'TODAY', label: 'Today' },
    { value: 'YESTERDAY', label: 'Yesterday' },
    { value: 'THIS_WEEK', label: 'This Week' },
    { value: 'LAST_WEEK', label: 'Last Week' },
    { value: 'THIS_MONTH', label: 'This Month' },
    { value: 'LAST_MONTH', label: 'Last Month' },
    { value: 'THIS_QUARTER', label: 'This Quarter' },
    { value: 'LAST_QUARTER', label: 'Last Quarter' },
    { value: 'THIS_YEAR', label: 'This Year' },
    { value: 'LAST_YEAR', label: 'Last Year' },
    { value: 'CUSTOM', label: 'Custom Date Range' }
  ];
  
  // Handle template change
  const handleTemplateChange = (e) => {
    setSelectedTemplate(e.target.value);
  };
  
  // Handle time range change
  const handleTimeRangeChange = (e) => {
    setTimeRange(e.target.value);
  };
  
  // Handle generate report
  const handleGenerateReport = () => {
    if (selectedTemplate && timeRange) {
      onGenerate(selectedTemplate, timeRange);
    }
  };
  
  return (
    <Box sx={{ mt: 1 }}>
      <Typography variant="h6" gutterBottom>
        Generate Player Report
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <FormControl fullWidth>
            <InputLabel id="template-label">Report Template</InputLabel>
            <Select
              labelId="template-label"
              id="template"
              value={selectedTemplate}
              onChange={handleTemplateChange}
              label="Report Template"
            >
              {templates.map((template) => (
                <MenuItem key={template.id} value={template.id}>
                  {template.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        
        <Grid item xs={12}>
          <FormControl fullWidth>
            <InputLabel id="time-range-label">Time Range</InputLabel>
            <Select
              labelId="time-range-label"
              id="time-range"
              value={timeRange}
              onChange={handleTimeRangeChange}
              label="Time Range"
            >
              {timeRangeOptions.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        
        {timeRange === 'CUSTOM' && (
          <Grid item xs={12}>
            <Paper sx={{ p: 2, bgcolor: 'background.default' }}>
              <Typography variant="body2" color="text.secondary" align="center">
                Custom date range selection will be available in the next update.
              </Typography>
            </Paper>
          </Grid>
        )}
        
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
            <Button
              variant="outlined"
              startIcon={<CalendarIcon />}
              disabled
            >
              Schedule Report
            </Button>
            
            <Button
              variant="contained"
              color="primary"
              startIcon={<PdfIcon />}
              onClick={handleGenerateReport}
              disabled={!selectedTemplate || !timeRange}
            >
              Generate PDF
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ReportGenerator;
