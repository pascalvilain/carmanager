"""
Alpin Royal Casino Management System - Cigarette Inventory Service
This module provides business logic for cigarette inventory operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from modules.player_tracking.models.consumption import (
    CigaretteInventory, CigaretteInventoryCreate, CigaretteInventoryUpdate,
    CigaretteTransaction, CigaretteTransactionCreate, CigaretteTransactionUpdate,
    CigaretteTransactionType
)
from modules.player_tracking.repositories.cigarette_inventory_repository import CigaretteInventoryRepository
from modules.player_tracking.services.player_service import PlayerService
from base_layer.utils.database import get_db_session
from base_layer.utils.event_bus import get_event_bus

logger = logging.getLogger(__name__)

class CigaretteInventoryService:
    """Service for cigarette inventory-related operations"""
    
    def __init__(self, cigarette_inventory_repository: CigaretteInventoryRepository = None):
        """
        Initialize the cigarette inventory service.
        
        Args:
            cigarette_inventory_repository: Cigarette inventory repository
        """
        self.cigarette_inventory_repository = cigarette_inventory_repository or CigaretteInventoryRepository()
        self.player_service = PlayerService()
        self.event_bus = get_event_bus()
    
    async def create_inventory_item(self, inventory_data: CigaretteInventoryCreate, db: AsyncSession = Depends(get_db_session)) -> CigaretteInventory:
        """
        Create a new cigarette inventory item.
        
        Args:
            inventory_data: Cigarette inventory data
            db: Database session
            
        Returns:
            CigaretteInventory: Created cigarette inventory item
            
        Raises:
            HTTPException: If item with same brand and variant already exists
        """
        # Check if item with same brand and variant already exists
        existing_item = await self.cigarette_inventory_repository.get_inventory_item_by_brand_variant(
            inventory_data.brand, inventory_data.variant, db
        )
        if existing_item:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cigarette inventory item with brand '{inventory_data.brand}' and variant '{inventory_data.variant}' already exists"
            )
        
        # Create inventory item
        inventory = await self.cigarette_inventory_repository.create_inventory_item(inventory_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "cigarette_inventory.item_created",
            {
                "inventory_id": inventory.inventory_id,
                "brand": inventory.brand,
                "variant": inventory.variant,
                "quantity": inventory.quantity,
                "reorder_level": inventory.reorder_level
            },
            source="cigarette_inventory_service"
        )
        
        return inventory
    
    async def update_inventory_item(self, inventory_id: int, inventory_data: CigaretteInventoryUpdate, db: AsyncSession = Depends(get_db_session)) -> Optional[CigaretteInventory]:
        """
        Update a cigarette inventory item.
        
        Args:
            inventory_id: Cigarette inventory ID
            inventory_data: Cigarette inventory data to update
            db: Database session
            
        Returns:
            Optional[CigaretteInventory]: Updated cigarette inventory item or None if not found
        """
        # Update inventory item
        inventory = await self.cigarette_inventory_repository.update_inventory_item(inventory_id, inventory_data, db)
        
        if inventory:
            # Publish event
            await self.event_bus.publish(
                "cigarette_inventory.item_updated",
                {
                    "inventory_id": inventory_id,
                    "brand": inventory.brand,
                    "variant": inventory.variant,
                    "quantity": inventory.quantity,
                    "reorder_level": inventory.reorder_level
                },
                source="cigarette_inventory_service"
            )
        
        return inventory
    
    async def get_inventory_item_by_id(self, inventory_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[CigaretteInventory]:
        """
        Get a cigarette inventory item by ID.
        
        Args:
            inventory_id: Cigarette inventory ID
            db: Database session
            
        Returns:
            Optional[CigaretteInventory]: Cigarette inventory item if found, None otherwise
        """
        return await self.cigarette_inventory_repository.get_inventory_item_by_id(inventory_id, db)
    
    async def get_inventory_item_by_brand_variant(self, brand: str, variant: Optional[str], db: AsyncSession = Depends(get_db_session)) -> Optional[CigaretteInventory]:
        """
        Get a cigarette inventory item by brand and variant.
        
        Args:
            brand: Cigarette brand
            variant: Cigarette variant
            db: Database session
            
        Returns:
            Optional[CigaretteInventory]: Cigarette inventory item if found, None otherwise
        """
        return await self.cigarette_inventory_repository.get_inventory_item_by_brand_variant(brand, variant, db)
    
    async def get_all_inventory_items(self, db: AsyncSession = Depends(get_db_session)) -> List[CigaretteInventory]:
        """
        Get all cigarette inventory items.
        
        Args:
            db: Database session
            
        Returns:
            List[CigaretteInventory]: List of all cigarette inventory items
        """
        return await self.cigarette_inventory_repository.get_all_inventory_items(db)
    
    async def get_low_stock_items(self, db: AsyncSession = Depends(get_db_session)) -> List[CigaretteInventory]:
        """
        Get cigarette inventory items with low stock.
        
        Args:
            db: Database session
            
        Returns:
            List[CigaretteInventory]: List of cigarette inventory items with low stock
        """
        return await self.cigarette_inventory_repository.get_low_stock_items(db)
    
    async def record_purchase(
        self, 
        inventory_id: int, 
        quantity: int, 
        staff_id: int, 
        notes: Optional[str] = None,
        db: AsyncSession = Depends(get_db_session)
    ) -> Tuple[CigaretteTransaction, CigaretteInventory]:
        """
        Record a purchase of cigarettes.
        
        Args:
            inventory_id: Cigarette inventory ID
            quantity: Quantity purchased
            staff_id: Staff ID
            notes: Optional notes
            db: Database session
            
        Returns:
            Tuple[CigaretteTransaction, CigaretteInventory]: Created transaction and updated inventory
            
        Raises:
            HTTPException: If inventory item not found or quantity is invalid
        """
        # Check if inventory item exists
        inventory = await self.cigarette_inventory_repository.get_inventory_item_by_id(inventory_id, db)
        if not inventory:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Cigarette inventory item with ID {inventory_id} not found"
            )
        
        # Validate quantity
        if quantity <= 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Quantity must be greater than 0"
            )
        
        # Create transaction data
        transaction_data = CigaretteTransactionCreate(
            inventory_id=inventory_id,
            transaction_type=CigaretteTransactionType.PURCHASE,
            quantity=quantity,
            transaction_time=datetime.now(),
            staff_id=staff_id,
            notes=notes
        )
        
        # Create transaction and update inventory
        transaction, updated_inventory = await self.cigarette_inventory_repository.create_transaction(transaction_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "cigarette_inventory.purchase",
            {
                "transaction_id": transaction.transaction_id,
                "inventory_id": inventory_id,
                "brand": inventory.brand,
                "variant": inventory.variant,
                "quantity": quantity,
                "new_stock_level": updated_inventory.quantity
            },
            source="cigarette_inventory_service"
        )
        
        return transaction, updated_inventory
    
    async def dispense_to_player(
        self, 
        inventory_id: int, 
        player_id: int, 
        quantity: int, 
        staff_id: int, 
        session_id: Optional[int] = None,
        notes: Optional[str] = None,
        db: AsyncSession = Depends(get_db_session)
    ) -> Tuple[CigaretteTransaction, CigaretteInventory]:
        """
        Dispense cigarettes to a player.
        
        Args:
            inventory_id: Cigarette inventory ID
            player_id: Player ID
            quantity: Quantity dispensed
            staff_id: Staff ID
            session_id: Optional gaming session ID
            notes: Optional notes
            db: Database session
            
        Returns:
            Tuple[CigaretteTransaction, CigaretteInventory]: Created transaction and updated inventory
            
        Raises:
            HTTPException: If inventory item or player not found, or quantity is invalid
        """
        # Check if inventory item exists
        inventory = await self.cigarette_inventory_repository.get_inventory_item_by_id(inventory_id, db)
        if not inventory:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Cigarette inventory item with ID {inventory_id} not found"
            )
        
        # Check if player exists
        player = await self.player_service.get_player_by_id(player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {player_id} not found"
            )
        
        # Validate quantity
        if quantity <= 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Quantity must be greater than 0"
            )
        
        # Check if enough stock
        if inventory.quantity < quantity:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Not enough stock. Current stock: {inventory.quantity}, requested: {quantity}"
            )
        
        # Create transaction data
        transaction_data = CigaretteTransactionCreate(
            inventory_id=inventory_id,
            transaction_type=CigaretteTransactionType.DISPENSED,
            quantity=quantity,
            transaction_time=datetime.now(),
            player_id=player_id,
            session_id=session_id,
            staff_id=staff_id,
            notes=notes
        )
        
        # Create transaction and update inventory
        transaction, updated_inventory = await self.cigarette_inventory_repository.create_transaction(transaction_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "cigarette_inventory.dispensed",
            {
                "transaction_id": transaction.transaction_id,
                "inventory_id": inventory_id,
                "player_id": player_id,
                "session_id": session_id,
                "brand": inventory.brand,
                "variant": inventory.variant,
                "quantity": quantity,
                "new_stock_level": updated_inventory.quantity
            },
            source="cigarette_inventory_service"
        )
        
        # Also record as a consumption item if integrated with consumption tracking
        try:
            from modules.player_tracking.services.consumption_service import ConsumptionService
            from modules.player_tracking.models.consumption import PlayerConsumptionCreate, ItemType
            
            # Find or create corresponding consumption item
            consumption_service = ConsumptionService()
            items = await consumption_service.get_all_consumption_items(ItemType.CIGARETTE, db)
            
            # Find matching item by brand and variant
            matching_item = next(
                (item for item in items if item.item_name.lower() == f"{inventory.brand} {inventory.variant or ''}".lower().strip()),
                None
            )
            
            if matching_item:
                # Record consumption
                consumption_data = PlayerConsumptionCreate(
                    player_id=player_id,
                    session_id=session_id,
                    item_id=matching_item.item_id,
                    quantity=quantity,
                    consumption_time=datetime.now(),
                    staff_id=staff_id,
                    notes=notes
                )
                await consumption_service.record_player_consumption(consumption_data, db)
        except Exception as e:
            # Log but don't fail if consumption recording fails
            logger.warning(f"Failed to record cigarette dispensing as consumption: {str(e)}")
        
        return transaction, updated_inventory
    
    async def record_inventory_adjustment(
        self, 
        inventory_id: int, 
        quantity_change: int, 
        staff_id: int, 
        notes: str,
        db: AsyncSession = Depends(get_db_session)
    ) -> Tuple[CigaretteTransaction, CigaretteInventory]:
        """
        Record an inventory adjustment.
        
        Args:
            inventory_id: Cigarette inventory ID
            quantity_change: Change in quantity (positive for increase, negative for decrease)
            staff_id: Staff ID
            notes: Notes explaining the adjustment
            db: Database session
            
        Returns:
            Tuple[CigaretteTransaction, CigaretteInventory]: Created transaction and updated inventory
            
        Raises:
            HTTPException: If inventory item not found or notes not provided
        """
        # Check if inventory item exists
        inventory = await self.cigarette_inventory_repository.get_inventory_item_by_id(inventory_id, db)
        if not inventory:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Cigarette inventory item with ID {inventory_id} not found"
            )
        
        # Require notes for adjustments
        if not notes:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Notes are required for inventory adjustments"
            )
        
        # Create transaction data
        transaction_data = CigaretteTransactionCreate(
            inventory_id=inventory_id,
            transaction_type=CigaretteTransactionType.ADJUSTMENT,
            quantity=quantity_change,
            transaction_time=datetime.now(),
            staff_id=staff_id,
            notes=notes
        )
        
        # Create transaction and update inventory
        transaction, updated_inventory = await self.cigarette_inventory_repository.create_transaction(transaction_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "cigarette_inventory.adjustment",
            {
                "transaction_id": transaction.transaction_id,
                "inventory_id": inventory_id,
                "brand": inventory.brand,
                "variant": inventory.variant,
                "quantity_change": quantity_change,
                "new_stock_level": updated_inventory.quantity,
                "notes": notes
            },
            source="cigarette_inventory_service"
        )
        
        return transaction, updated_inventory
    
    async def get_inventory_summary(self, db: AsyncSession = Depends(get_db_session)) -> Dict[str, Any]:
        """
        Get a summary of cigarette inventory.
        
        Args:
            db: Database session
            
        Returns:
            Dict[str, Any]: Inventory summary
        """
        return await self.cigarette_inventory_repository.get_inventory_summary(db)
    
    async def get_dashboard_data(self, db: AsyncSession = Depends(get_db_session)) -> Dict[str, Any]:
        """
        Get dashboard data for cigarette inventory.
        
        Args:
            db: Database session
            
        Returns:
            Dict[str, Any]: Dashboard data
        """
        # Get inventory summary
        summary = await self.get_inventory_summary(db)
        
        # Get all inventory items
        all_items = await self.get_all_inventory_items(db)
        
        # Get low stock items
        low_stock_items = await self.get_low_stock_items(db)
        
        # Calculate stock status percentages
        total_items = len(all_items)
        low_stock_count = len(low_stock_items)
        healthy_stock_count = total_items - low_stock_count
        
        # Compile dashboard data
        dashboard_data = {
            "total_items": total_items,
            "total_quantity": summary["total_quantity"],
            "low_stock_count": low_stock_count,
            "low_stock_percentage": (low_stock_count / total_items * 100) if total_items > 0 else 0,
            "healthy_stock_percentage": (healthy_stock_count / total_items * 100) if total_items > 0 else 0,
            "most_popular_brand": summary["most_popular_brand"],
            "low_stock_items": [
                {
                    "inventory_id": item.inventory_id,
                    "brand": item.brand,
                    "variant": item.variant,
                    "quantity": item.quantity,
                    "reorder_level": item.reorder_level
                }
                for item in low_stock_items[:5]  # Top 5 low stock items
            ],
            "recent_transactions": [
                {
                    "transaction_id": transaction.transaction_id,
                    "transaction_type": transaction.transaction_type,
                    "quantity": transaction.quantity,
                    "transaction_time": transaction.transaction_time.isoformat()
                }
                for transaction in summary["recent_transactions"][:5]  # Top 5 recent transactions
            ]
        }
        
        return dashboard_data
