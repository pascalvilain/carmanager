"""
Alpin Royal Casino Management System - Financial Service
This module provides business logic for financial transaction operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from fastapi import Depends, HTTPException, status, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from modules.player_tracking.models.financial import (
    FinancialTransaction, FinancialTransactionCreate, FinancialTransactionUpdate,
    JackpotHandPay, JackpotHandPayCreate, JackpotHandPayUpdate,
    FinancialSummary, FinancialSearch, TransactionType
)
from modules.player_tracking.repositories.financial_repository import FinancialRepository
from modules.player_tracking.services.player_service import PlayerService
from modules.player_tracking.services.gaming_session_service import GamingSessionService
from base_layer.utils.database import get_db_session
from base_layer.utils.storage import upload_fastapi_file
from base_layer.utils.event_bus import get_event_bus

logger = logging.getLogger(__name__)

class FinancialService:
    """Service for financial transaction-related operations"""
    
    def __init__(self, financial_repository: FinancialRepository = None):
        """
        Initialize the financial service.
        
        Args:
            financial_repository: Financial repository
        """
        self.financial_repository = financial_repository or FinancialRepository()
        self.player_service = PlayerService()
        self.gaming_session_service = GamingSessionService()
        self.event_bus = get_event_bus()
    
    async def create_transaction(self, transaction_data: FinancialTransactionCreate, db: AsyncSession = Depends(get_db_session)) -> FinancialTransaction:
        """
        Create a new financial transaction.
        
        Args:
            transaction_data: Financial transaction data
            db: Database session
            
        Returns:
            FinancialTransaction: Created financial transaction
            
        Raises:
            HTTPException: If player or session not found
        """
        # Check if player exists
        player = await self.player_service.get_player_by_id(transaction_data.player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {transaction_data.player_id} not found"
            )
        
        # Check if session exists if provided
        if transaction_data.session_id:
            session = await self.gaming_session_service.get_gaming_session_by_id(transaction_data.session_id, db)
            if not session:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Gaming session with ID {transaction_data.session_id} not found"
                )
        
        # Create transaction
        transaction = await self.financial_repository.create_transaction(transaction_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "financial.transaction",
            {
                "transaction_id": transaction.transaction_id,
                "player_id": transaction.player_id,
                "session_id": transaction.session_id,
                "transaction_type": transaction.transaction_type,
                "amount": transaction.amount,
                "transaction_time": transaction.transaction_time.isoformat()
            },
            source="financial_service"
        )
        
        return transaction
    
    async def update_transaction(self, transaction_id: int, transaction_data: FinancialTransactionUpdate, db: AsyncSession = Depends(get_db_session)) -> Optional[FinancialTransaction]:
        """
        Update a financial transaction.
        
        Args:
            transaction_id: Financial transaction ID
            transaction_data: Financial transaction data to update
            db: Database session
            
        Returns:
            Optional[FinancialTransaction]: Updated financial transaction or None if not found
        """
        # Update transaction
        transaction = await self.financial_repository.update_transaction(transaction_id, transaction_data, db)
        
        if transaction:
            # Publish event
            await self.event_bus.publish(
                "financial.transaction_updated",
                {
                    "transaction_id": transaction_id,
                    "player_id": transaction.player_id,
                    "transaction_type": transaction.transaction_type,
                    "amount": transaction.amount
                },
                source="financial_service"
            )
        
        return transaction
    
    async def get_transaction_by_id(self, transaction_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[FinancialTransaction]:
        """
        Get a financial transaction by ID.
        
        Args:
            transaction_id: Financial transaction ID
            db: Database session
            
        Returns:
            Optional[FinancialTransaction]: Financial transaction if found, None otherwise
        """
        return await self.financial_repository.get_transaction_by_id(transaction_id, db)
    
    async def search_transactions(self, search_params: FinancialSearch, db: AsyncSession = Depends(get_db_session)) -> List[FinancialTransaction]:
        """
        Search for financial transactions based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[FinancialTransaction]: List of matching financial transactions
        """
        return await self.financial_repository.search_transactions(search_params, db)
    
    async def get_player_financial_summary(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> FinancialSummary:
        """
        Get a summary of a player's financial transactions.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            FinancialSummary: Summary of financial transactions
            
        Raises:
            HTTPException: If player not found
        """
        # Check if player exists
        player = await self.player_service.get_player_by_id(player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {player_id} not found"
            )
        
        return await self.financial_repository.get_player_financial_summary(player_id, db)
    
    # Jackpot and Hand Pay methods
    
    async def record_jackpot_hand_pay(
        self, 
        jackpot_data: JackpotHandPayCreate, 
        photo: Optional[UploadFile] = None,
        db: AsyncSession = Depends(get_db_session)
    ) -> JackpotHandPay:
        """
        Record a new jackpot or hand pay.
        
        Args:
            jackpot_data: Jackpot or hand pay data
            photo: Optional photo of the jackpot or hand pay
            db: Database session
            
        Returns:
            JackpotHandPay: Created jackpot or hand pay record
            
        Raises:
            HTTPException: If player, session, machine, or table not found
        """
        # Check if player exists
        player = await self.player_service.get_player_by_id(jackpot_data.player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {jackpot_data.player_id} not found"
            )
        
        # Check if session exists if provided
        if jackpot_data.session_id:
            session = await self.gaming_session_service.get_gaming_session_by_id(jackpot_data.session_id, db)
            if not session:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Gaming session with ID {jackpot_data.session_id} not found"
                )
        
        # Check if machine exists if provided
        if jackpot_data.machine_id:
            machine = await self.gaming_session_service.get_slot_machine_by_id(jackpot_data.machine_id, db)
            if not machine:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Slot machine with ID {jackpot_data.machine_id} not found"
                )
        
        # Check if table exists if provided
        if jackpot_data.table_id:
            table = await self.gaming_session_service.get_table_game_by_id(jackpot_data.table_id, db)
            if not table:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Table game with ID {jackpot_data.table_id} not found"
                )
        
        # Upload photo if provided
        photo_id = None
        if photo:
            try:
                # Upload photo
                storage_path = f"jackpot_photos/{jackpot_data.player_id}/{datetime.now().strftime('%Y%m%d%H%M%S')}"
                storage_url = await upload_fastapi_file(
                    file=photo,
                    destination_path=storage_path,
                    metadata={
                        "player_id": str(jackpot_data.player_id),
                        "jackpot_type": jackpot_data.jackpot_type,
                        "amount": str(jackpot_data.amount),
                        "original_filename": photo.filename
                    }
                )
                
                # Create photo record
                from modules.player_tracking.models.player import PlayerPhotoCreate, PhotoType
                photo_data = PlayerPhotoCreate(
                    player_id=jackpot_data.player_id,
                    photo_type=PhotoType.JACKPOT if jackpot_data.jackpot_type in ["progressive", "bonus"] else PhotoType.HANDPAY,
                    notes=f"Jackpot/Hand Pay: {jackpot_data.amount} CHF"
                )
                player_photo = await self.player_service.add_player_photo(
                    jackpot_data.player_id,
                    photo_data.photo_type,
                    photo,
                    photo_data.notes,
                    db
                )
                photo_id = player_photo.photo_id
                
            except Exception as e:
                logger.error(f"Error uploading jackpot photo for player {jackpot_data.player_id}: {str(e)}")
                # Continue without photo if upload fails
        
        # Update jackpot data with photo ID if available
        if photo_id:
            jackpot_data_dict = jackpot_data.dict()
            jackpot_data_dict["photo_id"] = photo_id
            jackpot_data = JackpotHandPayCreate(**jackpot_data_dict)
        
        # Create jackpot record
        jackpot = await self.financial_repository.create_jackpot_hand_pay(jackpot_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "financial.jackpot_hand_pay",
            {
                "jackpot_id": jackpot.jackpot_id,
                "player_id": jackpot.player_id,
                "session_id": jackpot.session_id,
                "machine_id": jackpot.machine_id,
                "table_id": jackpot.table_id,
                "amount": jackpot.amount,
                "jackpot_type": jackpot.jackpot_type,
                "jackpot_time": jackpot.jackpot_time.isoformat(),
                "photo_id": jackpot.photo_id
            },
            source="financial_service"
        )
        
        return jackpot
    
    async def update_jackpot_hand_pay(self, jackpot_id: int, jackpot_data: JackpotHandPayUpdate, db: AsyncSession = Depends(get_db_session)) -> Optional[JackpotHandPay]:
        """
        Update a jackpot or hand pay record.
        
        Args:
            jackpot_id: Jackpot or hand pay ID
            jackpot_data: Jackpot or hand pay data to update
            db: Database session
            
        Returns:
            Optional[JackpotHandPay]: Updated jackpot or hand pay record or None if not found
        """
        # Update jackpot
        jackpot = await self.financial_repository.update_jackpot_hand_pay(jackpot_id, jackpot_data, db)
        
        if jackpot:
            # Publish event
            await self.event_bus.publish(
                "financial.jackpot_hand_pay_updated",
                {
                    "jackpot_id": jackpot_id,
                    "player_id": jackpot.player_id,
                    "amount": jackpot.amount,
                    "jackpot_type": jackpot.jackpot_type
                },
                source="financial_service"
            )
        
        return jackpot
    
    async def get_jackpot_hand_pay_by_id(self, jackpot_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[JackpotHandPay]:
        """
        Get a jackpot or hand pay record by ID.
        
        Args:
            jackpot_id: Jackpot or hand pay ID
            db: Database session
            
        Returns:
            Optional[JackpotHandPay]: Jackpot or hand pay record if found, None otherwise
        """
        return await self.financial_repository.get_jackpot_hand_pay_by_id(jackpot_id, db)
    
    async def get_player_jackpots_hand_pays(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> List[JackpotHandPay]:
        """
        Get all jackpots and hand pays for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            List[JackpotHandPay]: List of jackpots and hand pays
            
        Raises:
            HTTPException: If player not found
        """
        # Check if player exists
        player = await self.player_service.get_player_by_id(player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {player_id} not found"
            )
        
        return await self.financial_repository.get_player_jackpots_hand_pays(player_id, db)
