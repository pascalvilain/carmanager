"""
Casino Management System - Player Tracking Service
This module provides business logic for player tracking operations.
"""

import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, date, timedelta

from modules.player_tracking.repositories.player_repository import PlayerRepository
from modules.player_tracking.repositories.gaming_session_repository import GamingSessionRepository
from modules.player_tracking.repositories.financial_repository import FinancialRepository
from modules.player_tracking.repositories.consumption_repository import ConsumptionRepository
from modules.player_tracking.repositories.dashboard_repository import DashboardRepository

from modules.player_tracking.models.player import (
    Player, PlayerCreate, PlayerUpdate, PlayerSearch,
    PlayerPhoto, PlayerPhotoCreate, PlayerPhotoUpdate
)
from modules.player_tracking.models.gaming_session import (
    GamingSession, GamingSessionCreate, GamingSessionUpdate,
    TableGameActivity, TableGameActivityCreate, TableGameActivityUpdate,
    SlotMachineActivity, SlotMachineActivityCreate, SlotMachineActivityUpdate
)
from modules.player_tracking.models.financial import (
    FinancialTransaction, FinancialTransactionCreate, FinancialTransactionUpdate,
    JackpotHandPay, JackpotHandPayCreate, JackpotHandPayUpdate
)
from modules.player_tracking.models.consumption import (
    ConsumptionItem, ConsumptionItemCreate, ConsumptionItemUpdate,
    PlayerConsumption, PlayerConsumptionCreate, PlayerConsumptionUpdate,
    CigaretteInventory, CigaretteInventoryCreate, CigaretteInventoryUpdate,
    CigaretteInventoryTransaction, CigaretteInventoryTransactionCreate,
    CigaretteInventoryTransactionUpdate, ConsumptionSummary
)
from modules.player_tracking.models.dashboard import (
    Dashboard, DashboardCreate, DashboardUpdate,
    DashboardWidget, DashboardWidgetCreate, DashboardWidgetUpdate,
    ReportTemplate, ReportTemplateCreate, ReportTemplateUpdate,
    Report, ReportCreate, ReportUpdate, PlayerReportData,
    TimeRange
)

from base_layer.utils.storage import StorageManager
from base_layer.utils.ai_service import AIService

logger = logging.getLogger(__name__)

class PlayerTrackingService:
    """Service for player tracking operations."""
    
    def __init__(self):
        """Initialize the service with repositories."""
        self.player_repository = PlayerRepository()
        self.gaming_session_repository = GamingSessionRepository()
        self.financial_repository = FinancialRepository()
        self.consumption_repository = ConsumptionRepository()
        self.dashboard_repository = DashboardRepository()
        self.storage_manager = StorageManager()
        self.ai_service = AIService()
    
    # Player management
    
    async def create_player(self, player: PlayerCreate) -> Player:
        """
        Create a new player.
        
        Args:
            player: The player data
            
        Returns:
            The created player
        """
        return await self.player_repository.create_player(player)
    
    async def get_player(self, player_id: int) -> Optional[Player]:
        """
        Get a player by ID.
        
        Args:
            player_id: The player ID
            
        Returns:
            The player or None if not found
        """
        return await self.player_repository.get_player(player_id)
    
    async def get_player_by_casino_id(self, casino_guest_id: str) -> Optional[Player]:
        """
        Get a player by casino guest ID.
        
        Args:
            casino_guest_id: The casino guest ID
            
        Returns:
            The player or None if not found
        """
        return await self.player_repository.get_player_by_casino_id(casino_guest_id)
    
    async def update_player(self, player_id: int, player_update: PlayerUpdate) -> Optional[Player]:
        """
        Update a player.
        
        Args:
            player_id: The player ID
            player_update: The player update data
            
        Returns:
            The updated player or None if not found
        """
        return await self.player_repository.update_player(player_id, player_update)
    
    async def search_players(self, search: PlayerSearch, limit: int = 20, offset: int = 0) -> List[Player]:
        """
        Search for players.
        
        Args:
            search: The search criteria
            limit: Maximum number of results
            offset: Result offset
            
        Returns:
            List of matching players
        """
        return await self.player_repository.search_players(search, limit, offset)
    
    async def upload_player_photo(self, player_id: int, photo_create: PlayerPhotoCreate) -> PlayerPhoto:
        """
        Upload a player photo.
        
        Args:
            player_id: The player ID
            photo_create: The photo data
            
        Returns:
            The created photo
        """
        # Save photo to storage
        file_path = f"player_photos/{player_id}/{photo_create.photo_type.value}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.jpg"
        
        await self.storage_manager.save_file(
            file_path, 
            photo_create.photo_data,
            content_type="image/jpeg"
        )
        
        # Create photo record
        photo_create.file_path = file_path
        return await self.player_repository.create_player_photo(player_id, photo_create)
    
    async def get_player_photos(self, player_id: int, photo_type: Optional[str] = None) -> List[PlayerPhoto]:
        """
        Get photos for a player.
        
        Args:
            player_id: The player ID
            photo_type: Filter by photo type
            
        Returns:
            List of player photos
        """
        return await self.player_repository.get_player_photos(player_id, photo_type)
    
    # Gaming session management
    
    async def create_gaming_session(self, session: GamingSessionCreate) -> GamingSession:
        """
        Create a new gaming session.
        
        Args:
            session: The session data
            
        Returns:
            The created session
        """
        # Create session
        gaming_session = await self.gaming_session_repository.create_gaming_session(session)
        
        # Update player's last visit date
        await self.player_repository.update_player(
            session.player_id,
            PlayerUpdate(last_visit_date=session.start_time.date())
        )
        
        return gaming_session
    
    async def get_gaming_session(self, session_id: int) -> Optional[GamingSession]:
        """
        Get a gaming session by ID.
        
        Args:
            session_id: The session ID
            
        Returns:
            The session or None if not found
        """
        return await self.gaming_session_repository.get_gaming_session(session_id)
    
    async def update_gaming_session(self, session_id: int, session_update: GamingSessionUpdate) -> Optional[GamingSession]:
        """
        Update a gaming session.
        
        Args:
            session_id: The session ID
            session_update: The session update data
            
        Returns:
            The updated session or None if not found
        """
        return await self.gaming_session_repository.update_gaming_session(session_id, session_update)
    
    async def end_gaming_session(self, session_id: int) -> Optional[GamingSession]:
        """
        End a gaming session.
        
        Args:
            session_id: The session ID
            
        Returns:
            The updated session or None if not found
        """
        # Get current session
        session = await self.gaming_session_repository.get_gaming_session(session_id)
        
        if not session:
            return None
            
        if session.end_time:
            # Session already ended
            return session
            
        # Calculate duration
        end_time = datetime.utcnow()
        duration_minutes = int((end_time - session.start_time).total_seconds() / 60)
        
        # Update session
        session_update = GamingSessionUpdate(
            end_time=end_time,
            duration_minutes=duration_minutes
        )
        
        return await self.gaming_session_repository.update_gaming_session(session_id, session_update)
    
    async def get_player_gaming_sessions(self, player_id: int, limit: int = 20, offset: int = 0) -> List[GamingSession]:
        """
        Get gaming sessions for a player.
        
        Args:
            player_id: The player ID
            limit: Maximum number of results
            offset: Result offset
            
        Returns:
            List of gaming sessions
        """
        return await self.gaming_session_repository.get_player_gaming_sessions(player_id, limit, offset)
    
    async def get_active_gaming_sessions(self) -> List[GamingSession]:
        """
        Get all active gaming sessions.
        
        Returns:
            List of active gaming sessions
        """
        return await self.gaming_session_repository.get_active_gaming_sessions()
    
    async def create_table_game_activity(self, activity: TableGameActivityCreate) -> TableGameActivity:
        """
        Create a new table game activity.
        
        Args:
            activity: The activity data
            
        Returns:
            The created activity
        """
        return await self.gaming_session_repository.create_table_game_activity(activity)
    
    async def update_table_game_activity(self, activity_id: int, activity_update: TableGameActivityUpdate) -> Optional[TableGameActivity]:
        """
        Update a table game activity.
        
        Args:
            activity_id: The activity ID
            activity_update: The activity update data
            
        Returns:
            The updated activity or None if not found
        """
        return await self.gaming_session_repository.update_table_game_activity(activity_id, activity_update)
    
    async def end_table_game_activity(self, activity_id: int, cash_out: float, win_loss: float) -> Optional[TableGameActivity]:
        """
        End a table game activity.
        
        Args:
            activity_id: The activity ID
            cash_out: The cash out amount
            win_loss: The win/loss amount
            
        Returns:
            The updated activity or None if not found
        """
        # Get current activity
        activity = await self.gaming_session_repository.get_table_game_activity(activity_id)
        
        if not activity:
            return None
            
        if activity.end_time:
            # Activity already ended
            return activity
            
        # Calculate duration
        end_time = datetime.utcnow()
        duration_minutes = int((end_time - activity.start_time).total_seconds() / 60)
        
        # Update activity
        activity_update = TableGameActivityUpdate(
            end_time=end_time,
            duration_minutes=duration_minutes,
            cash_out=cash_out,
            win_loss=win_loss
        )
        
        return await self.gaming_session_repository.update_table_game_activity(activity_id, activity_update)
    
    async def create_slot_machine_activity(self, activity: SlotMachineActivityCreate) -> SlotMachineActivity:
        """
        Create a new slot machine activity.
        
        Args:
            activity: The activity data
            
        Returns:
            The created activity
        """
        return await self.gaming_session_repository.create_slot_machine_activity(activity)
    
    async def update_slot_machine_activity(self, activity_id: int, activity_update: SlotMachineActivityUpdate) -> Optional[SlotMachineActivity]:
        """
        Update a slot machine activity.
        
        Args:
            activity_id: The activity ID
            activity_update: The activity update data
            
        Returns:
            The updated activity or None if not found
        """
        return await self.gaming_session_repository.update_slot_machine_activity(activity_id, activity_update)
    
    async def end_slot_machine_activity(self, activity_id: int, ticket_out: float, hand_pay: float = 0, jackpot: float = 0) -> Optional[SlotMachineActivity]:
        """
        End a slot machine activity.
        
        Args:
            activity_id: The activity ID
            ticket_out: The ticket out amount
            hand_pay: The hand pay amount
            jackpot: The jackpot amount
            
        Returns:
            The updated activity or None if not found
        """
        # Get current activity
        activity = await self.gaming_session_repository.get_slot_machine_activity(activity_id)
        
        if not activity:
            return None
            
        if activity.end_time:
            # Activity already ended
            return activity
            
        # Calculate duration
        end_time = datetime.utcnow()
        duration_minutes = int((end_time - activity.start_time).total_seconds() / 60)
        
        # Calculate win/loss
        win_loss = (ticket_out + hand_pay + jackpot) - activity.money_in
        
        # Update activity
        activity_update = SlotMachineActivityUpdate(
            end_time=end_time,
            duration_minutes=duration_minutes,
            ticket_out=ticket_out,
            hand_pay=hand_pay,
            jackpot=jackpot,
            win_loss=win_loss
        )
        
        return await self.gaming_session_repository.update_slot_machine_activity(activity_id, activity_update)
    
    # Financial management
    
    async def create_financial_transaction(self, transaction: FinancialTransactionCreate) -> FinancialTransaction:
        """
        Create a new financial transaction.
        
        Args:
            transaction: The transaction data
            
        Returns:
            The created transaction
        """
        return await self.financial_repository.create_financial_transaction(transaction)
    
    async def get_financial_transaction(self, transaction_id: int) -> Optional[FinancialTransaction]:
        """
        Get a financial transaction by ID.
        
        Args:
            transaction_id: The transaction ID
            
        Returns:
            The transaction or None if not found
        """
        return await self.financial_repository.get_financial_transaction(transaction_id)
    
    async def update_financial_transaction(self, transaction_id: int, transaction_update: FinancialTransactionUpdate) -> Optional[FinancialTransaction]:
        """
        Update a financial transaction.
        
        Args:
            transaction_id: The transaction ID
            transaction_update: The transaction update data
            
        Returns:
            The updated transaction or None if not found
        """
        return await self.financial_repository.update_financial_transaction(transaction_id, transaction_update)
    
    async def get_player_financial_transactions(self, player_id: int, limit: int = 50, offset: int = 0) -> List[FinancialTransaction]:
        """
        Get financial transactions for a player.
        
        Args:
            player_id: The player ID
            limit: Maximum number of results
            offset: Result offset
            
        Returns:
            List of financial transactions
        """
        return await self.financial_repository.get_player_financial_transactions(player_id, limit, offset)
    
    async def create_jackpot_hand_pay(self, jackpot: JackpotHandPayCreate) -> JackpotHandPay:
        """
        Create a new jackpot or hand pay record.
        
        Args:
            jackpot: The jackpot data
            
        <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>