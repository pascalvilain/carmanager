"""
Alpin Royal Casino Management System - Gaming Session Service
This module provides business logic for gaming session-related operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from modules.player_tracking.models.gaming_session import (
    GamingSession, GamingSessionCreate, GamingSessionUpdate, GamingSessionSearch,
    TableGame, TableGameCreate, TableGameUpdate,
    SlotMachine, SlotMachineCreate, SlotMachineUpdate,
    TableGameActivity, TableGameActivityCreate, TableGameActivityUpdate,
    SlotMachineActivity, SlotMachineActivityCreate, SlotMachineActivityUpdate,
    SessionStatus
)
from modules.player_tracking.repositories.gaming_session_repository import GamingSessionRepository
from modules.player_tracking.services.player_service import PlayerService
from base_layer.utils.database import get_db_session
from base_layer.utils.event_bus import get_event_bus

logger = logging.getLogger(__name__)

class GamingSessionService:
    """Service for gaming session-related operations"""
    
    def __init__(self, gaming_session_repository: GamingSessionRepository = None):
        """
        Initialize the gaming session service.
        
        Args:
            gaming_session_repository: Gaming session repository
        """
        self.gaming_session_repository = gaming_session_repository or GamingSessionRepository()
        self.player_service = PlayerService()
        self.event_bus = get_event_bus()
    
    async def start_gaming_session(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> GamingSession:
        """
        Start a new gaming session for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            GamingSession: Created gaming session
            
        Raises:
            HTTPException: If player not found or already has an active session
        """
        # Check if player exists
        player = await self.player_service.get_player_by_id(player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {player_id} not found"
            )
        
        # Check if player already has an active session
        active_session = await self.gaming_session_repository.get_active_session_for_player(player_id, db)
        if active_session:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Player with ID {player_id} already has an active session"
            )
        
        # Create session data
        now = datetime.now()
        session_data = GamingSessionCreate(
            player_id=player_id,
            start_time=now,
            status=SessionStatus.ACTIVE
        )
        
        # Create session
        session = await self.gaming_session_repository.create_gaming_session(session_data, db)
        
        # Update player's last visit date
        await self.player_service.update_last_visit_date(player_id, now, db)
        
        # Publish event
        await self.event_bus.publish(
            "gaming_session.started",
            {
                "session_id": session.session_id,
                "player_id": player_id,
                "start_time": now.isoformat()
            },
            source="gaming_session_service"
        )
        
        return session
    
    async def end_gaming_session(self, session_id: int, end_time: Optional[datetime] = None, db: AsyncSession = Depends(get_db_session)) -> Optional[GamingSession]:
        """
        End a gaming session.
        
        Args:
            session_id: Gaming session ID
            end_time: End time, defaults to current time
            db: Database session
            
        Returns:
            Optional[GamingSession]: Updated gaming session or None if not found
            
        Raises:
            HTTPException: If session not found or already ended
        """
        # Check if session exists
        session = await self.gaming_session_repository.get_gaming_session_by_id(session_id, db)
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Gaming session with ID {session_id} not found"
            )
        
        # Check if session is already ended
        if session.status != SessionStatus.ACTIVE:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Gaming session with ID {session_id} is already ended"
            )
        
        # Set end time if not provided
        if end_time is None:
            end_time = datetime.now()
        
        # End session
        updated_session = await self.gaming_session_repository.end_gaming_session(session_id, end_time, db)
        
        # Publish event
        await self.event_bus.publish(
            "gaming_session.ended",
            {
                "session_id": session_id,
                "player_id": session.player_id,
                "start_time": session.start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_minutes": updated_session.duration_minutes
            },
            source="gaming_session_service"
        )
        
        return updated_session
    
    async def update_gaming_session(self, session_id: int, session_data: GamingSessionUpdate, db: AsyncSession = Depends(get_db_session)) -> Optional[GamingSession]:
        """
        Update a gaming session.
        
        Args:
            session_id: Gaming session ID
            session_data: Gaming session data to update
            db: Database session
            
        Returns:
            Optional[GamingSession]: Updated gaming session or None if not found
        """
        # Update session
        session = await self.gaming_session_repository.update_gaming_session(session_id, session_data, db)
        
        if session:
            # Publish event
            await self.event_bus.publish(
                "gaming_session.updated",
                {
                    "session_id": session_id,
                    "player_id": session.player_id,
                    "status": session.status
                },
                source="gaming_session_service"
            )
        
        return session
    
    async def get_gaming_session_by_id(self, session_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[GamingSession]:
        """
        Get a gaming session by ID.
        
        Args:
            session_id: Gaming session ID
            db: Database session
            
        Returns:
            Optional[GamingSession]: Gaming session if found, None otherwise
        """
        return await self.gaming_session_repository.get_gaming_session_by_id(session_id, db)
    
    async def get_active_session_for_player(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[GamingSession]:
        """
        Get the active gaming session for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            Optional[GamingSession]: Active gaming session if found, None otherwise
        """
        return await self.gaming_session_repository.get_active_session_for_player(player_id, db)
    
    async def search_gaming_sessions(self, search_params: GamingSessionSearch, db: AsyncSession = Depends(get_db_session)) -> List[GamingSession]:
        """
        Search for gaming sessions based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[GamingSession]: List of matching gaming sessions
        """
        return await self.gaming_session_repository.search_gaming_sessions(search_params, db)
    
    async def get_player_session_stats(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> Dict[str, Any]:
        """
        Get statistics about a player's gaming sessions.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            Dict[str, Any]: Session statistics
        """
        return await self.gaming_session_repository.get_player_session_stats(player_id, db)
    
    # Table Game methods
    
    async def create_table_game(self, table_data: TableGameCreate, db: AsyncSession = Depends(get_db_session)) -> TableGame:
        """
        Create a new table game.
        
        Args:
            table_data: Table game data
            db: Database session
            
        Returns:
            TableGame: Created table game
        """
        return await self.gaming_session_repository.create_table_game(table_data, db)
    
    async def get_table_game_by_id(self, table_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[TableGame]:
        """
        Get a table game by ID.
        
        Args:
            table_id: Table game ID
            db: Database session
            
        Returns:
            Optional[TableGame]: Table game if found, None otherwise
        """
        return await self.gaming_session_repository.get_table_game_by_id(table_id, db)
    
    async def get_all_table_games(self, db: AsyncSession = Depends(get_db_session)) -> List[TableGame]:
        """
        Get all table games.
        
        Args:
            db: Database session
            
        Returns:
            List[TableGame]: List of all table games
        """
        return await self.gaming_session_repository.get_all_table_games(db)
    
    # Slot Machine methods
    
    async def create_slot_machine(self, machine_data: SlotMachineCreate, db: AsyncSession = Depends(get_db_session)) -> SlotMachine:
        """
        Create a new slot machine.
        
        Args:
            machine_data: Slot machine data
            db: Database session
            
        Returns:
            SlotMachine: Created slot machine
        """
        return await self.gaming_session_repository.create_slot_machine(machine_data, db)
    
    async def get_slot_machine_by_id(self, machine_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[SlotMachine]:
        """
        Get a slot machine by ID.
        
        Args:
            machine_id: Slot machine ID
            db: Database session
            
        Returns:
            Optional[SlotMachine]: Slot machine if found, None otherwise
        """
        return await self.gaming_session_repository.get_slot_machine_by_id(machine_id, db)
    
    async def get_all_slot_machines(self, db: AsyncSession = Depends(get_db_session)) -> List[SlotMachine]:
        """
        Get all slot machines.
        
        Args:
            db: Database session
            
        Returns:
            List[SlotMachine]: List of all slot machines
        """
        return await self.gaming_session_repository.get_all_slot_machines(db)
    
    # Table Game Activity methods
    
    async def start_table_game_activity(
        self, 
        session_id: int, 
        table_id: int, 
        db: AsyncSession = Depends(get_db_session)
    ) -> TableGameActivity:
        """
        Start a new table game activity.
        
        Args:
            session_id: Gaming session ID
            table_id: Table game ID
            db: Database session
            
        Returns:
            TableGameActivity: Created table game activity
            
        Raises:
            HTTPException: If session or table not found
        """
        # Check if session exists
        session = await self.gaming_session_repository.get_gaming_session_by_id(session_id, db)
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Gaming session with ID {session_id} not found"
            )
        
        # Check if table exists
        table = await self.gaming_session_repository.get_table_game_by_id(table_id, db)
        if not table:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Table game with ID {table_id} not found"
            )
        
        # Create activity data
        now = datetime.now()
        activity_data = TableGameActivityCreate(
            session_id=session_id,
            table_id=table_id,
            start_time=now
        )
        
        # Create activity
        activity = await self.gaming_session_repository.create_table_game_activity(activity_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "table_game_activity.started",
            {
                "activity_id": activity.activity_id,
                "session_id": session_id,
                "table_id": table_id,
                "player_id": session.player_id,
                "start_time": now.isoformat()
            },
            source="gaming_session_service"
        )
        
        return activity
    
    async def end_table_game_activity(
        self, 
        activity_id: int, 
        activity_data: TableGameActivityUpdate, 
        db: AsyncSession = Depends(get_db_session)
    ) -> Optional[TableGameActivity]:
        """
        End a table game activity.
        
        Args:
            activity_id: Table game activity ID
            activity_data: Table game activity data to update
            db: Database session
            
        Returns:
            Optional[TableGameActivity]: Updated table game activity or None if not found
            
        Raises:
            HTTPException: If activity not found
        """
        # Check if activity exists
        activity = await self.gaming_session_repository.get_table_game_activity_by_id(activity_id, db)
        if not activity:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Table game activity with ID {activity_id} not found"
            )
        
        # Set end time if not provided
        if activity_data.end_time is None:
            activity_data.end_time = datetime.now()
        
        # Update activity
        updated_activity = await self.gaming_session_repository.update_table_game_activity(activity_id, activity_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "table_game_activity.ended",
            {
                "activity_id": activity_id,
                "session_id": activity.session_id,
                "table_id": activity.table_id,
                "end_time": updated_activity.end_time.isoformat(),
                "duration_minutes": updated_activity.duration_minutes,
                "avg_bet": updated_activity.avg_bet,
                "win_loss": updated_activity.win_loss
            },
            source="gaming_session_service"
        )
        
        return updated_activity
    
    # Slot Machine Activity methods
    
    async def start_slot_machine_activity(
        self, 
        session_id: int, 
        machine_id: int, 
        db: AsyncSession = Depends(get_db_session)
    ) -> SlotMachineActivity:
        """
        Start a new slot machine activity.
        
        Args:
            session_id: Gaming session ID
            machine_id: Slot machine ID
            db: Database session
            
        Returns:
            SlotMachineActivity: Created slot machine activity
            
        Raises:
            HTTPException: If session or machine not found
        """
        # Check if session exists
        session = await self.gaming_session_repository.get_gaming_session_by_id(session_id, db)
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Gaming session with ID {session_id} not found"
            )
        
        # Check if machine exists
        machine = await self.gaming_session_repository.get_slot_machine_by_id(machine_id, db)
        if not machine:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Slot machine with ID {machine_id} not found"
            )
        
        # Create activity data
        now = datetime.now()
        activity_data = SlotMachineActivityCreate(
            session_id=session_id,
            machine_id=machine_id,
            start_time=now
        )
        
        # Create activity
        activity = await self.gaming_session_repository.create_slot_machine_activity(activity_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "slot_machine_activity.started",
            {
                "activity_id": activity.activity_id,
                "session_id": session_id,
                "machine_id": machine_id,
                "player_id": session.player_id,
                "start_time": now.isoformat()
            },
            source="gaming_session_service"
        )
        
        return activity
    
    async def end_slot_machine_activity(
        self, 
        activity_id: int, 
        activity_data: SlotMachineActivityUpdate, 
        db: AsyncSession = Depends(get_db_session)
    ) -> Optional[SlotMachineActivity]:
        """
        End a slot machine activity.
        
        Args:
            activity_id: Slot machine activity ID
            activity_data: Slot machine activity data to update
            db: Database session
            
        Returns:
            Optional[SlotMachineActivity]: Updated slot machine activity or None if not found
            
        Raises:
            HTTPException: If activity not found
        """
        # Check if activity exists
        activity = await self.gaming_session_repository.get_slot_machine_activity_by_id(activity_id, db)
        if not activity:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Slot machine activity with ID {activity_id} not found"
            )
        
        # Set end time if not provided
        if activity_data.end_time is None:
            activity_data.end_time = datetime.now()
        
        # Update activity
        updated_activity = await self.gaming_session_repository.update_slot_machine_activity(activity_id, activity_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "slot_machine_activity.ended",
            {
                "activity_id": activity_id,
                "session_id": activity.session_id,
                "machine_id": activity.machine_id,
                "end_time": updated_activity.end_time.isoformat(),
                "duration_minutes": updated_activity.duration_minutes,
                "money_in": updated_activity.money_in,
                "ticket_in": updated_activity.ticket_in,
                "ticket_out": updated_activity.ticket_out,
                "hand_pay": updated_activity.hand_pay,
                "jackpot": updated_activity.jackpot,
                "win_loss": updated_activity.win_loss
            },
            source="gaming_session_service"
        )
        
        return updated_activity
