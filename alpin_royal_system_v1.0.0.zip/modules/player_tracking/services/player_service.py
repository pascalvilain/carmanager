"""
Alpin Royal Casino Management System - Player Service
This module provides business logic for player-related operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import Depends, UploadFile, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from modules.player_tracking.models.player import (
    Player, PlayerCreate, PlayerUpdate, PlayerSummary, 
    PlayerSearch, PlayerPhoto, PlayerPhotoCreate
)
from modules.player_tracking.repositories.player_repository import PlayerRepository
from base_layer.utils.database import get_db_session
from base_layer.utils.storage import upload_fastapi_file
from base_layer.utils.event_bus import get_event_bus

logger = logging.getLogger(__name__)

class PlayerService:
    """Service for player-related operations"""
    
    def __init__(self, player_repository: PlayerRepository = None):
        """
        Initialize the player service.
        
        Args:
            player_repository: Player repository
        """
        self.player_repository = player_repository or PlayerRepository()
        self.event_bus = get_event_bus()
    
    async def create_player(self, player_data: PlayerCreate, db: AsyncSession = Depends(get_db_session)) -> Player:
        """
        Create a new player.
        
        Args:
            player_data: Player data
            db: Database session
            
        Returns:
            Player: Created player
        """
        # Create player
        player = await self.player_repository.create_player(player_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "player.created",
            {
                "player_id": player.player_id,
                "casino_guest_id": player.casino_guest_id,
                "first_name": player.first_name,
                "last_name": player.last_name,
                "vip_status": player.vip_status
            },
            source="player_service"
        )
        
        return player
    
    async def update_player(self, player_id: int, player_data: PlayerUpdate, db: AsyncSession = Depends(get_db_session)) -> Optional[Player]:
        """
        Update a player.
        
        Args:
            player_id: Player ID
            player_data: Player data to update
            db: Database session
            
        Returns:
            Optional[Player]: Updated player or None if not found
        """
        # Update player
        player = await self.player_repository.update_player(player_id, player_data, db)
        
        if player:
            # Publish event
            await self.event_bus.publish(
                "player.updated",
                {
                    "player_id": player.player_id,
                    "casino_guest_id": player.casino_guest_id,
                    "first_name": player.first_name,
                    "last_name": player.last_name,
                    "vip_status": player.vip_status
                },
                source="player_service"
            )
        
        return player
    
    async def delete_player(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> bool:
        """
        Delete a player (soft delete by setting is_active to False).
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            bool: True if player was deleted, False if not found
        """
        # Delete player
        success = await self.player_repository.delete_player(player_id, db)
        
        if success:
            # Publish event
            await self.event_bus.publish(
                "player.deleted",
                {
                    "player_id": player_id
                },
                source="player_service"
            )
        
        return success
    
    async def get_player_by_id(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[Player]:
        """
        Get a player by ID.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            Optional[Player]: Player if found, None otherwise
        """
        return await self.player_repository.get_player_by_id(player_id, db)
    
    async def get_player_by_casino_guest_id(self, casino_guest_id: str, db: AsyncSession = Depends(get_db_session)) -> Optional[Player]:
        """
        Get a player by casino guest ID.
        
        Args:
            casino_guest_id: Casino guest ID
            db: Database session
            
        Returns:
            Optional[Player]: Player if found, None otherwise
        """
        return await self.player_repository.get_player_by_casino_guest_id(casino_guest_id, db)
    
    async def search_players(self, search_params: PlayerSearch, db: AsyncSession = Depends(get_db_session)) -> List[PlayerSummary]:
        """
        Search for players based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[PlayerSummary]: List of matching players
        """
        return await self.player_repository.search_players(search_params, db)
    
    async def add_player_photo(
        self, 
        player_id: int, 
        photo_type: str, 
        photo: UploadFile, 
        notes: Optional[str] = None,
        db: AsyncSession = Depends(get_db_session)
    ) -> PlayerPhoto:
        """
        Add a photo to a player.
        
        Args:
            player_id: Player ID
            photo_type: Photo type
            photo: Photo file
            notes: Optional notes
            db: Database session
            
        Returns:
            PlayerPhoto: Created photo
            
        Raises:
            HTTPException: If player not found or photo upload fails
        """
        # Check if player exists
        player = await self.player_repository.get_player_by_id(player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {player_id} not found"
            )
        
        # Create photo data
        photo_data = PlayerPhotoCreate(
            player_id=player_id,
            photo_type=photo_type,
            notes=notes
        )
        
        # Upload photo
        try:
            storage_path = f"player_photos/{player_id}/{photo_type}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
            storage_url = await upload_fastapi_file(
                file=photo,
                destination_path=storage_path,
                metadata={
                    "player_id": str(player_id),
                    "photo_type": photo_type,
                    "original_filename": photo.filename
                }
            )
            
            # Create photo record
            player_photo = await self.player_repository.add_player_photo(photo_data, storage_path, db)
            
            # Publish event
            await self.event_bus.publish(
                "player.photo_added",
                {
                    "player_id": player_id,
                    "photo_id": player_photo.photo_id,
                    "photo_type": photo_type,
                    "storage_path": storage_path
                },
                source="player_service"
            )
            
            return player_photo
            
        except Exception as e:
            logger.error(f"Error uploading photo for player {player_id}: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error uploading photo: {str(e)}"
            )
    
    async def get_player_photos(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> List[PlayerPhoto]:
        """
        Get all photos for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            List[PlayerPhoto]: List of player photos
        """
        return await self.player_repository.get_player_photos(player_id, db)
    
    async def update_last_visit_date(self, player_id: int, visit_date: Optional[datetime] = None, db: AsyncSession = Depends(get_db_session)) -> bool:
        """
        Update the last visit date for a player.
        
        Args:
            player_id: Player ID
            visit_date: Visit date, defaults to current time
            db: Database session
            
        Returns:
            bool: True if player was updated, False if not found
        """
        if visit_date is None:
            visit_date = datetime.now()
            
        return await self.player_repository.update_last_visit_date(player_id, visit_date, db)
