"""
Alpin Royal Casino Management System - Consumption Service
This module provides business logic for consumption-related operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from modules.player_tracking.models.consumption import (
    ConsumptionItem, ConsumptionItemCreate, ConsumptionItemUpdate,
    PlayerConsumption, PlayerConsumptionCreate, PlayerConsumptionUpdate,
    ConsumptionSummary, ConsumptionSearch, ItemType
)
from modules.player_tracking.repositories.consumption_repository import ConsumptionRepository
from modules.player_tracking.services.player_service import PlayerService
from modules.player_tracking.services.gaming_session_service import GamingSessionService
from base_layer.utils.database import get_db_session
from base_layer.utils.event_bus import get_event_bus

logger = logging.getLogger(__name__)

class ConsumptionService:
    """Service for consumption-related operations"""
    
    def __init__(self, consumption_repository: ConsumptionRepository = None):
        """
        Initialize the consumption service.
        
        Args:
            consumption_repository: Consumption repository
        """
        self.consumption_repository = consumption_repository or ConsumptionRepository()
        self.player_service = PlayerService()
        self.gaming_session_service = GamingSessionService()
        self.event_bus = get_event_bus()
    
    async def create_consumption_item(self, item_data: ConsumptionItemCreate, db: AsyncSession = Depends(get_db_session)) -> ConsumptionItem:
        """
        Create a new consumption item.
        
        Args:
            item_data: Consumption item data
            db: Database session
            
        Returns:
            ConsumptionItem: Created consumption item
        """
        # Create consumption item
        item = await self.consumption_repository.create_consumption_item(item_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "consumption.item_created",
            {
                "item_id": item.item_id,
                "item_name": item.item_name,
                "item_type": item.item_type,
                "price": item.price
            },
            source="consumption_service"
        )
        
        return item
    
    async def update_consumption_item(self, item_id: int, item_data: ConsumptionItemUpdate, db: AsyncSession = Depends(get_db_session)) -> Optional[ConsumptionItem]:
        """
        Update a consumption item.
        
        Args:
            item_id: Consumption item ID
            item_data: Consumption item data to update
            db: Database session
            
        Returns:
            Optional[ConsumptionItem]: Updated consumption item or None if not found
        """
        # Update consumption item
        item = await self.consumption_repository.update_consumption_item(item_id, item_data, db)
        
        if item:
            # Publish event
            await self.event_bus.publish(
                "consumption.item_updated",
                {
                    "item_id": item_id,
                    "item_name": item.item_name,
                    "item_type": item.item_type,
                    "price": item.price,
                    "is_active": item.is_active
                },
                source="consumption_service"
            )
        
        return item
    
    async def get_consumption_item_by_id(self, item_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[ConsumptionItem]:
        """
        Get a consumption item by ID.
        
        Args:
            item_id: Consumption item ID
            db: Database session
            
        Returns:
            Optional[ConsumptionItem]: Consumption item if found, None otherwise
        """
        return await self.consumption_repository.get_consumption_item_by_id(item_id, db)
    
    async def get_all_consumption_items(self, item_type: Optional[ItemType] = None, db: AsyncSession = Depends(get_db_session)) -> List[ConsumptionItem]:
        """
        Get all consumption items, optionally filtered by type.
        
        Args:
            item_type: Optional filter by item type
            db: Database session
            
        Returns:
            List[ConsumptionItem]: List of consumption items
        """
        return await self.consumption_repository.get_all_consumption_items(db, item_type)
    
    async def record_player_consumption(self, consumption_data: PlayerConsumptionCreate, db: AsyncSession = Depends(get_db_session)) -> PlayerConsumption:
        """
        Record a new player consumption.
        
        Args:
            consumption_data: Player consumption data
            db: Database session
            
        Returns:
            PlayerConsumption: Created player consumption record
            
        Raises:
            HTTPException: If player, session, or item not found
        """
        # Check if player exists
        player = await self.player_service.get_player_by_id(consumption_data.player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {consumption_data.player_id} not found"
            )
        
        # Check if session exists if provided
        if consumption_data.session_id:
            session = await self.gaming_session_service.get_gaming_session_by_id(consumption_data.session_id, db)
            if not session:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Gaming session with ID {consumption_data.session_id} not found"
                )
        
        # Check if item exists
        item = await self.consumption_repository.get_consumption_item_by_id(consumption_data.item_id, db)
        if not item:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Consumption item with ID {consumption_data.item_id} not found"
            )
        
        # Create consumption record
        consumption = await self.consumption_repository.create_player_consumption(consumption_data, db)
        
        # Publish event
        await self.event_bus.publish(
            "consumption.recorded",
            {
                "consumption_id": consumption.consumption_id,
                "player_id": consumption.player_id,
                "session_id": consumption.session_id,
                "item_id": consumption.item_id,
                "item_type": item.item_type,
                "item_name": item.item_name,
                "quantity": consumption.quantity,
                "consumption_time": consumption.consumption_time.isoformat()
            },
            source="consumption_service"
        )
        
        return consumption
    
    async def update_player_consumption(self, consumption_id: int, consumption_data: PlayerConsumptionUpdate, db: AsyncSession = Depends(get_db_session)) -> Optional[PlayerConsumption]:
        """
        Update a player consumption record.
        
        Args:
            consumption_id: Player consumption ID
            consumption_data: Player consumption data to update
            db: Database session
            
        Returns:
            Optional[PlayerConsumption]: Updated player consumption record or None if not found
        """
        # Update consumption record
        consumption = await self.consumption_repository.update_player_consumption(consumption_id, consumption_data, db)
        
        if consumption:
            # Publish event
            await self.event_bus.publish(
                "consumption.updated",
                {
                    "consumption_id": consumption_id,
                    "player_id": consumption.player_id,
                    "quantity": consumption.quantity
                },
                source="consumption_service"
            )
        
        return consumption
    
    async def get_player_consumption_by_id(self, consumption_id: int, db: AsyncSession = Depends(get_db_session)) -> Optional[PlayerConsumption]:
        """
        Get a player consumption record by ID.
        
        Args:
            consumption_id: Player consumption ID
            db: Database session
            
        Returns:
            Optional[PlayerConsumption]: Player consumption record if found, None otherwise
        """
        return await self.consumption_repository.get_player_consumption_by_id(consumption_id, db)
    
    async def search_player_consumptions(self, search_params: ConsumptionSearch, db: AsyncSession = Depends(get_db_session)) -> List[PlayerConsumption]:
        """
        Search for player consumption records based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[PlayerConsumption]: List of matching player consumption records
        """
        return await self.consumption_repository.search_player_consumptions(search_params, db)
    
    async def get_player_consumption_summary(self, player_id: int, db: AsyncSession = Depends(get_db_session)) -> ConsumptionSummary:
        """
        Get a summary of a player's consumption records.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            ConsumptionSummary: Summary of consumption records
            
        Raises:
            HTTPException: If player not found
        """
        # Check if player exists
        player = await self.player_service.get_player_by_id(player_id, db)
        if not player:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Player with ID {player_id} not found"
            )
        
        return await self.consumption_repository.get_player_consumption_summary(player_id, db)
    
    async def get_consumption_dashboard_data(self, db: AsyncSession = Depends(get_db_session)) -> Dict[str, Any]:
        """
        Get dashboard data for consumption.
        
        Args:
            db: Database session
            
        Returns:
            Dict[str, Any]: Dashboard data
        """
        # This method would typically aggregate data for dashboard displays
        # For example, most popular items, consumption trends, etc.
        
        # Get all consumption items
        items = await self.consumption_repository.get_all_consumption_items(db)
        
        # Placeholder for dashboard data
        dashboard_data = {
            "total_items": len(items),
            "items_by_type": {
                "food": len([i for i in items if i.item_type == ItemType.FOOD]),
                "beverage": len([i for i in items if i.item_type == ItemType.BEVERAGE]),
                "cigarette": len([i for i in items if i.item_type == ItemType.CIGARETTE]),
                "other": len([i for i in items if i.item_type == ItemType.OTHER])
            },
            # Additional data would be added here based on specific dashboard requirements
        }
        
        return dashboard_data
