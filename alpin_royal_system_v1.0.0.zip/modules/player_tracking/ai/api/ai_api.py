"""
Casino Management System - AI API Integration
This module provides API endpoints for AI features in the player tracking module.
"""

from fastapi import APIRouter, Depends, HTTPException, Body
from typing import List, Dict, Any, Optional
import logging
from datetime import datetime

from modules.player_tracking.ai.services.ai_service import AIService
from modules.player_tracking.repositories.player_repository import PlayerRepository
from modules.player_tracking.repositories.gaming_session_repository import GamingSessionRepository
from modules.player_tracking.repositories.financial_repository import FinancialRepository
from modules.player_tracking.repositories.consumption_repository import ConsumptionRepository

router = APIRouter(prefix="/api/player-tracking/ai", tags=["AI"])
logger = logging.getLogger(__name__)

# Initialize services
ai_service = AIService()

@router.post("/train-models")
async def train_models(
    player_repo: PlayerRepository = Depends(),
    session_repo: GamingSessionRepository = Depends(),
    financial_repo: FinancialRepository = Depends(),
    consumption_repo: ConsumptionRepository = Depends()
):
    """
    Train all AI models with current data.
    
    Returns:
        Dictionary with training results
    """
    try:
        # Get data from repositories
        player_data = await player_repo.get_all_players_with_features()
        session_data = await session_repo.get_all_sessions()
        transaction_data = await financial_repo.get_all_transactions()
        consumption_data = await consumption_repo.get_all_consumption_records()
        
        # Get available offers (placeholder - would come from an offer repository)
        offer_data = None
        
        # Train models
        results = await ai_service.train_models(
            player_data, session_data, transaction_data, consumption_data, offer_data
        )
        
        return {
            "status": "success",
            "message": "AI models trained successfully",
            "results": results
        }
    
    except Exception as e:
        logger.error(f"Error training AI models: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error training AI models: {str(e)}")

@router.get("/player-segment/{player_id}")
async def get_player_segment(
    player_id: str,
    player_repo: PlayerRepository = Depends()
):
    """
    Get the player segment (cluster) for a player.
    
    Args:
        player_id: ID of the player
        
    Returns:
        Dictionary with player segment information
    """
    try:
        # Get player data
        player_data = await player_repo.get_player_with_features(player_id)
        
        if not player_data:
            raise HTTPException(status_code=404, detail=f"Player {player_id} not found")
        
        # Get player segment
        result = await ai_service.get_player_segment(player_id, player_data)
        
        if result["status"] == "error":
            raise HTTPException(status_code=500, detail=result["message"])
        
        return result
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting player segment: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting player segment: {str(e)}")

@router.get("/unusual-behavior/{player_id}")
async def detect_unusual_behavior(
    player_id: str,
    player_repo: PlayerRepository = Depends()
):
    """
    Detect unusual behavior for a player.
    
    Args:
        player_id: ID of the player
        
    Returns:
        Dictionary with anomaly detection results
    """
    try:
        # Get player data
        player_data = await player_repo.get_player_with_features(player_id)
        
        if not player_data:
            raise HTTPException(status_code=404, detail=f"Player {player_id} not found")
        
        # Detect unusual behavior
        result = await ai_service.detect_unusual_behavior(player_id, player_data)
        
        if result["status"] == "error":
            raise HTTPException(status_code=500, detail=result["message"])
        
        return result
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error detecting unusual behavior: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error detecting unusual behavior: {str(e)}")

@router.get("/predict/{player_id}/{prediction_target}")
async def predict_player_behavior(
    player_id: str,
    prediction_target: str,
    player_repo: PlayerRepository = Depends()
):
    """
    Predict player behavior for a specific target.
    
    Args:
        player_id: ID of the player
        prediction_target: Target behavior to predict
        
    Returns:
        Dictionary with prediction results
    """
    try:
        # Validate prediction target
        valid_targets = [
            "next_visit_date", "expected_bet_amount", "expected_session_length",
            "game_preference", "drink_preference", "cigarette_preference", "churn_risk"
        ]
        
        if prediction_target not in valid_targets:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid prediction target. Must be one of: {', '.join(valid_targets)}"
            )
        
        # Get player data
        player_data = await player_repo.get_player_with_features(player_id)
        
        if not player_data:
            raise HTTPException(status_code=404, detail=f"Player {player_id} not found")
        
        # Make prediction
        result = await ai_service.predict_player_behavior(player_id, prediction_target, player_data)
        
        if result["status"] == "error":
            raise HTTPException(status_code=500, detail=result["message"])
        
        return result
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error predicting player behavior: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error predicting player behavior: {str(e)}")

@router.post("/recommendations/{player_id}")
async def get_personalized_recommendations(
    player_id: str,
    n_recommendations: int = 3,
    player_repo: PlayerRepository = Depends(),
    available_offers: List[Dict[str, Any]] = Body(...)
):
    """
    Get personalized recommendations for a player.
    
    Args:
        player_id: ID of the player
        n_recommendations: Number of recommendations to generate
        available_offers: List of available offers
        
    Returns:
        Dictionary with recommendation results
    """
    try:
        # Get player data
        player_data = await player_repo.get_player_with_features(player_id)
        
        if not player_data:
            raise HTTPException(status_code=404, detail=f"Player {player_id} not found")
        
        # Convert available offers to DataFrame
        import pandas as pd
        offers_df = pd.DataFrame(available_offers)
        
        # Get recommendations
        result = await ai_service.get_personalized_recommendations(
            player_id, offers_df, player_data, n_recommendations
        )
        
        if result["status"] == "error":
            raise HTTPException(status_code=500, detail=result["message"])
        
        return result
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting personalized recommendations: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting personalized recommendations: {str(e)}")
