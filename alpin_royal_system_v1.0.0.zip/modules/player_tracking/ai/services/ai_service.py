"""
Casino Management System - AI Service
This module provides services for integrating AI models with the player tracking module.
"""

import logging
import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

from modules.player_tracking.ai.models.player_behavior_model import PlayerBehaviorModel
from modules.player_tracking.ai.models.player_predictive_model import PlayerPredictiveModel
from modules.player_tracking.ai.models.recommendation_engine import RecommendationEngine

logger = logging.getLogger(__name__)

class AIService:
    """Service for AI integration with player tracking module."""
    
    def __init__(self):
        """Initialize the AI service."""
        self.models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        os.makedirs(self.models_dir, exist_ok=True)
        
        # Initialize models
        self.behavior_model = PlayerBehaviorModel(
            model_path=os.path.join(self.models_dir, "behavior_model.joblib")
            if os.path.exists(os.path.join(self.models_dir, "behavior_model.joblib")) else None
        )
        
        self.predictive_model = PlayerPredictiveModel(
            model_path=os.path.join(self.models_dir, "predictive_model.joblib")
            if os.path.exists(os.path.join(self.models_dir, "predictive_model.joblib")) else None
        )
        
        self.recommendation_engine = RecommendationEngine(
            model_path=os.path.join(self.models_dir, "recommendation_model.joblib")
            if os.path.exists(os.path.join(self.models_dir, "recommendation_model.joblib")) else None
        )
    
    async def train_models(self, player_data, session_data, transaction_data, consumption_data, offer_data=None):
        """
        Train all AI models with the provided data.
        
        Args:
            player_data: DataFrame containing player profiles
            session_data: DataFrame containing gaming sessions
            transaction_data: DataFrame containing financial transactions
            consumption_data: DataFrame containing consumption records
            offer_data: Optional DataFrame containing available offers
            
        Returns:
            Dictionary with training results for each model
        """
        try:
            # Prepare data for behavior model
            behavior_features = self._prepare_behavior_features(
                player_data, session_data, transaction_data, consumption_data
            )
            
            # Train behavior model
            behavior_results = {}
            if len(behavior_features) > 10:  # Need enough data for meaningful clusters
                cluster_labels, cluster_analysis = self.behavior_model.train_clustering_model(
                    behavior_features, n_clusters=min(5, len(behavior_features) // 2)
                )
                anomalies = self.behavior_model.train_anomaly_model(behavior_features)
                
                behavior_results = {
                    'clusters': len(cluster_analysis),
                    'cluster_analysis': cluster_analysis,
                    'anomalies_detected': sum(anomalies),
                    'anomaly_percentage': sum(anomalies) / len(behavior_features) * 100
                }
                
                # Save behavior model
                self.behavior_model.save_model(os.path.join(self.models_dir, "behavior_model.joblib"))
            
            # Prepare data for predictive model
            predictive_features = self._prepare_predictive_features(
                player_data, session_data, transaction_data, consumption_data
            )
            
            # Train predictive models
            predictive_results = {}
            if len(predictive_features) > 20:  # Need enough data for meaningful predictions
                for target in self.predictive_model.prediction_targets.keys():
                    if target in predictive_features.columns:
                        metrics = self.predictive_model.train_model(predictive_features, target)
                        predictive_results[target] = metrics
                
                # Save predictive model
                self.predictive_model.save_model(os.path.join(self.models_dir, "predictive_model.joblib"))
            
            # Prepare data for recommendation engine
            recommendation_results = {}
            if offer_data is not None and len(player_data) > 10:
                # Create interaction data
                interaction_data = self._create_interaction_data(
                    player_data, offer_data, transaction_data, consumption_data
                )
                
                if len(interaction_data) > 0:
                    # Train recommendation engine
                    recommendation_results = self.recommendation_engine.train_model(
                        player_data, offer_data, interaction_data
                    )
                    
                    # Save recommendation model
                    self.recommendation_engine.save_model(os.path.join(self.models_dir, "recommendation_model.joblib"))
            
            return {
                'behavior_model': behavior_results,
                'predictive_model': predictive_results,
                'recommendation_engine': recommendation_results
            }
        
        except Exception as e:
            logger.error(f"Error training AI models: {str(e)}")
            raise
    
    async def get_player_segment(self, player_id, player_data=None):
        """
        Get the player segment (cluster) for a player.
        
        Args:
            player_id: ID of the player
            player_data: Optional DataFrame containing player data
            
        Returns:
            Dictionary with player segment information
        """
        try:
            # Check if behavior model is trained
            if not hasattr(self.behavior_model, 'kmeans_model') or self.behavior_model.kmeans_model is None:
                return {
                    'status': 'error',
                    'message': 'Behavior model not trained yet'
                }
            
            # Prepare player features
            if player_data is None:
                return {
                    'status': 'error',
                    'message': 'Player data required'
                }
            
            # Extract player features
            player_features = self._prepare_behavior_features(player_data)
            
            # Get player segment
            cluster, confidence = self.behavior_model.predict_cluster(player_features)
            
            return {
                'status': 'success',
                'player_id': player_id,
                'segment': int(cluster),
                'confidence': float(confidence)
            }
        
        except Exception as e:
            logger.error(f"Error getting player segment: {str(e)}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    async def detect_unusual_behavior(self, player_id, player_data=None):
        """
        Detect unusual behavior for a player.
        
        Args:
            player_id: ID of the player
            player_data: Optional DataFrame containing player data
            
        Returns:
            Dictionary with anomaly detection results
        """
        try:
            # Check if behavior model is trained
            if not hasattr(self.behavior_model, 'anomaly_model') or self.behavior_model.anomaly_model is None:
                return {
                    'status': 'error',
                    'message': 'Anomaly detection model not trained yet'
                }
            
            # Prepare player features
            if player_data is None:
                return {
                    'status': 'error',
                    'message': 'Player data required'
                }
            
            # Extract player features
            player_features = self._prepare_behavior_features(player_data)
            
            # Detect anomalies
            is_anomaly, anomaly_score = self.behavior_model.detect_anomalies(player_features)
            
            return {
                'status': 'success',
                'player_id': player_id,
                'is_unusual': bool(is_anomaly),
                'anomaly_score': float(anomaly_score),
                'threshold': -0.5  # Default threshold for Isolation Forest
            }
        
        except Exception as e:
            logger.error(f"Error detecting unusual behavior: {str(e)}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    async def predict_player_behavior(self, player_id, prediction_target, player_data=None):
        """
        Predict player behavior for a specific target.
        
        Args:
            player_id: ID of the player
            prediction_target: Target behavior to predict
            player_data: Optional DataFrame containing player data
            
        Returns:
            Dictionary with prediction results
        """
        try:
            # Check if predictive model is trained
            if not self.predictive_model.models or prediction_target not in self.predictive_model.models:
                return {
                    'status': 'error',
                    'message': f'Predictive model for {prediction_target} not trained yet'
                }
            
            # Prepare player features
            if player_data is None:
                return {
                    'status': 'error',
                    'message': 'Player data required'
                }
            
            # Extract player features
            player_features = self._prepare_predictive_features(player_data)
            
            # Make prediction
            prediction, confidence = self.predictive_model.predict(player_features, prediction_target)
            
            return {
                'status': 'success',
                'player_id': player_id,
                'prediction_target': prediction_target,
                'prediction': prediction,
                'confidence': float(confidence)
            }
        
        except Exception as e:
            logger.error(f"Error predicting player behavior: {str(e)}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    async def get_personalized_recommendations(self, player_id, available_offers, player_data=None, n_recommendations=3):
        """
        Get personalized recommendations for a player.
        
        Args:
            player_id: ID of the player
            available_offers: DataFrame containing available offers
            player_data: Optional DataFrame containing player data
            n_recommendations: Number of recommendations to generate
            
        Returns:
            Dictionary with recommendation results
        """
        try:
            # Check if recommendation engine is trained
            if not hasattr(self.recommendation_engine, 'player_features') or self.recommendation_engine.player_features is None:
                return {
                    'status': 'error',
                    'message': 'Recommendation engine not trained yet'
                }
            
            # Get personalized offers
            recommendations = self.recommendation_engine.get_personalized_offers(
                player_id, available_offers, player_data, n_recommendations
            )
            
            return {
                'status': 'success',
                'player_id': player_id,
                'recommendations': recommendations
            }
        
        except Exception as e:
            logger.error(f"Error getting personalized recommendations: {str(e)}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def _prepare_behavior_features(self, player_data, session_data=None, transaction_data=None, consumption_data=None):
        """
        Prepare features for behavior analysis.
        
        Args:
            player_data: DataFrame containing player profiles
            session_data: Optional DataFrame containing gaming sessions
            transaction_data: Optional DataFrame containing financial transactions
            consumption_data: Optional DataFrame containing consumption records
            
        Returns:
            DataFrame with behavior features
        """
        # Start with player data
        if isinstance(player_data, pd.DataFrame):
            features = player_data.copy()
        else:
            # Assume it's a single player record
            features = pd.DataFrame([player_data])
        
        # Ensure required columns exist
        required_columns = [
            'avg_bet', 'total_hours', 'visit_frequency', 'avg_session_length',
            'table_game_ratio', 'slot_machine_ratio', 'win_loss_ratio',
            'jackpot_frequency', 'consumption_per_hour', 'evening_preference'
        ]
        
        for col in required_columns:
            if col not in features.columns:
                features[col] = 0
        
        # If additional data is provided, calculate derived features
        if session_data is not None and not session_data.empty:
            # Calculate session-related features
            for player_id, player_sessions in session_data.groupby('player_id'):
                if player_id in features.index:
                    features.loc[player_id, 'total_hours'] = player_sessions['duration_minutes'].sum() / 60
                    features.loc[player_id, 'avg_session_length'] = player_sessions['duration_minutes'].mean() / 60
                    
                    # Calculate table game vs slot machine ratio
                    table_games = player_sessions[player_sessions['game_type'] != 'Slot Machine']
                    slot_machines = player_sessions[player_sessions['game_type'] == 'Slot Machine']
                    
                    total_duration = player_sessions['duration_minutes'].sum()
                    if total_duration > 0:
                        features.loc[player_id, 'table_game_ratio'] = table_games['duration_minutes'].sum() / total_duration
                        features.loc[player_id, 'slot_machine_ratio'] = slot_machines['duration_minutes'].sum() / total_duration
                    
                    # Calculate evening preference
                    evening_sessions = player_sessions[player_sessions['start_time'].dt.hour >= 18]
                    if len(player_sessions) > 0:
                        features.loc[player_id, 'evening_preference'] = len(evening_sessions) / len(player_sessions)
        
        if transaction_data is not None and not transaction_data.empty:
            # Calculate transaction-related features
            for player_id, player_transactions in transaction_data.groupby('player_id'):
                if player_id in features.index:
                    # Calculate win/loss ratio
                    wins = player_transactions[player_transactions['transaction_type'].isin(['JACKPOT', 'HAND_PAY', 'CASH_OUT'])]
                    losses = player_transactions[player_transactions['transaction_type'].isin(['BUY_IN'])]
                    
                    total_wins = wins['amount'].sum()
                    total_losses = losses['amount'].sum()
                    
                    if total_losses > 0:
                        features.loc[player_id, 'win_loss_ratio'] = total_wins / total_losses
                    
                    # Calculate jackpot frequency
                    jackpots = player_transactions[player_transactions['transaction_type'] == 'JACKPOT']
                    if 'total_hours' in features.col<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>