"""
Casino Management System - AI Performance Optimization
This module provides optimization techniques for real-time AI operations in the player tracking module.
"""

import logging
import time
import asyncio
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable
import threading
import queue
import pickle
import os
import joblib
from datetime import datetime, timedelta
import tensorflow as tf
import torch

# Initialize logging
logger = logging.getLogger(__name__)

class AIPerformanceOptimizer:
    """
    Performance optimization for AI operations in the player tracking module.
    Implements caching, model quantization, batch processing, and asynchronous prediction.
    """
    
    def __init__(self, model_dir: str = "/home/ubuntu/casino_management_system/modules/player_tracking/ai/models/optimized"):
        """
        Initialize the AI performance optimizer.
        
        Args:
            model_dir: Directory to store optimized models
        """
        self.model_dir = model_dir
        os.makedirs(model_dir, exist_ok=True)
        
        # Initialize caches
        self.prediction_cache = {}
        self.feature_cache = {}
        self.model_cache = {}
        
        # Initialize batch processing queues
        self.prediction_queue = queue.Queue()
        self.batch_results = {}
        
        # Start batch processing thread
        self.batch_thread_active = True
        self.batch_thread = threading.Thread(target=self._batch_processor, daemon=True)
        self.batch_thread.start()
        
        # Configure TensorFlow for performance
        self._configure_tensorflow()
        
        # Configure PyTorch for performance
        self._configure_pytorch()
        
        # Track performance metrics
        self.performance_metrics = {
            'inference_times': [],
            'cache_hits': 0,
            'cache_misses': 0,
            'batch_sizes': [],
            'memory_usage': []
        }
    
    def _configure_tensorflow(self):
        """Configure TensorFlow for optimal performance."""
        try:
            # Enable mixed precision
            tf.keras.mixed_precision.set_global_policy('mixed_float16')
            
            # Configure threading
            tf.config.threading.set_inter_op_parallelism_threads(4)
            tf.config.threading.set_intra_op_parallelism_threads(4)
            
            # Enable XLA compilation
            tf.config.optimizer.set_jit(True)
            
            logger.info("TensorFlow optimized for performance")
        except Exception as e:
            logger.warning(f"Failed to optimize TensorFlow: {str(e)}")
    
    def _configure_pytorch(self):
        """Configure PyTorch for optimal performance."""
        try:
            # Set number of threads
            torch.set_num_threads(4)
            
            # Enable TF32 precision on Ampere GPUs
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
            
            # Enable cuDNN benchmarking
            torch.backends.cudnn.benchmark = True
            
            logger.info("PyTorch optimized for performance")
        except Exception as e:
            logger.warning(f"Failed to optimize PyTorch: {str(e)}")
    
    def _batch_processor(self):
        """Background thread for batch processing of prediction requests."""
        while self.batch_thread_active:
            try:
                # Collect batch items with a timeout
                batch_items = []
                try:
                    # Get at least one item
                    item = self.prediction_queue.get(timeout=0.1)
                    batch_items.append(item)
                    
                    # Try to get more items without blocking
                    while len(batch_items) < 32:  # Max batch size
                        try:
                            item = self.prediction_queue.get_nowait()
                            batch_items.append(item)
                        except queue.Empty:
                            break
                except queue.Empty:
                    # No items in queue, continue loop
                    continue
                
                if not batch_items:
                    continue
                
                # Group by model type
                model_batches = {}
                for item in batch_items:
                    model_type = item['model_type']
                    if model_type not in model_batches:
                        model_batches[model_type] = []
                    model_batches[model_type].append(item)
                
                # Process each model batch
                for model_type, items in model_batches.items():
                    # Get model
                    model = self.get_model(model_type)
                    if model is None:
                        # Handle missing model
                        for item in items:
                            request_id = item['request_id']
                            self.batch_results[request_id] = {
                                'error': f"Model {model_type} not found",
                                'status': 'error'
                            }
                        continue
                    
                    # Prepare batch input
                    batch_ids = [item['request_id'] for item in items]
                    batch_features = [item['features'] for item in items]
                    
                    # Convert to appropriate format based on model type
                    if model_type.startswith('tf_'):
                        batch_input = tf.convert_to_tensor(batch_features)
                    elif model_type.startswith('torch_'):
                        batch_input = torch.tensor(batch_features)
                    else:
                        batch_input = np.array(batch_features)
                    
                    # Perform batch prediction
                    try:
                        start_time = time.time()
                        batch_predictions = model.predict(batch_input)
                        end_time = time.time()
                        
                        # Record batch size for metrics
                        self.performance_metrics['batch_sizes'].append(len(batch_items))
                        self.performance_metrics['inference_times'].append(end_time - start_time)
                        
                        # Store results
                        for i, request_id in enumerate(batch_ids):
                            self.batch_results[request_id] = {
                                'prediction': batch_predictions[i],
                                'status': 'success',
                                'latency': end_time - start_time
                            }
                    except Exception as e:
                        logger.error(f"Batch prediction error for {model_type}: {str(e)}")
                        for request_id in batch_ids:
                            self.batch_results[request_id] = {
                                'error': str(e),
                                'status': 'error'
                            }
                
                # Mark items as done
                for item in batch_items:
                    self.prediction_queue.task_done()
                
            except Exception as e:
                logger.error(f"Error in batch processor: {str(e)}")
                time.sleep(0.1)  # Prevent tight loop on error
    
    async def optimize_model(self, model, model_type: str, quantize: bool = True) -> Any:
        """
        Optimize a model for inference performance.
        
        Args:
            model: The model to optimize
            model_type: Type of model ('tf', 'torch', 'sklearn', etc.)
            quantize: Whether to apply quantization
            
        Returns:
            Optimized model
        """
        try:
            if model_type.startswith('tf_'):
                return await self._optimize_tensorflow_model(model, quantize)
            elif model_type.startswith('torch_'):
                return await self._optimize_pytorch_model(model, quantize)
            elif model_type.startswith('sklearn_'):
                return await self._optimize_sklearn_model(model)
            else:
                logger.warning(f"No optimization available for model type: {model_type}")
                return model
        except Exception as e:
            logger.error(f"Error optimizing model {model_type}: {str(e)}")
            return model
    
    async def _optimize_tensorflow_model(self, model, quantize: bool) -> tf.keras.Model:
        """
        Optimize a TensorFlow model.
        
        Args:
            model: TensorFlow model
            quantize: Whether to apply quantization
            
        Returns:
            Optimized TensorFlow model
        """
        # Convert to TensorFlow Lite for edge deployment
        if quantize:
            converter = tf.lite.TFLiteConverter.from_keras_model(model)
            converter.optimizations = [tf.lite.Optimize.DEFAULT]
            converter.target_spec.supported_types = [tf.float16]
            tflite_model = converter.convert()
            
            # Save quantized model
            model_path = os.path.join(self.model_dir, f"model_{int(time.time())}.tflite")
            with open(model_path, 'wb') as f:
                f.write(tflite_model)
            
            # Load TFLite model
            interpreter = tf.lite.Interpreter(model_content=tflite_model)
            interpreter.allocate_tensors()
            
            # Create a wrapper class for the interpreter
            class TFLiteModel:
                def __init__(self, interpreter):
                    self.interpreter = interpreter
                    self.input_details = interpreter.get_input_details()
                    self.output_details = interpreter.get_output_details()
                
                def predict(self, input_data):
                    if isinstance(input_data, tf.Tensor):
                        input_data = input_data.numpy()
                    
                    if len(input_data.shape) == 1:
                        input_data = np.expand_dims(input_data, axis=0)
                    
                    results = []
                    for sample in input_data:
                        self.interpreter.set_tensor(
                            self.input_details[0]['index'], 
                            np.expand_dims(sample, axis=0).astype(np.float32)
                        )
                        self.interpreter.invoke()
                        output = self.interpreter.get_tensor(self.output_details[0]['index'])
                        results.append(output[0])
                    
                    return np.array(results)
            
            return TFLiteModel(interpreter)
        else:
            # Apply graph optimization without quantization
            return tf.keras.models.clone_model(model)
    
    async def _optimize_pytorch_model(self, model, quantize: bool) -> torch.nn.Module:
        """
        Optimize a PyTorch model.
        
        Args:
            model: PyTorch model
            quantize: Whether to apply quantization
            
        Returns:
            Optimized PyTorch model
        """
        # Set model to evaluation mode
        model.eval()
        
        if quantize:
            # Quantize the model
            quantized_model = torch.quantization.quantize_dynamic(
                model, {torch.nn.Linear}, dtype=torch.qint8
            )
            
            # Save quantized model
            model_path = os.path.join(self.model_dir, f"model_{int(time.time())}.pt")
            torch.save(quantized_model.state_dict(), model_path)
            
            return quantized_model
        else:
            # Use TorchScript for optimization
            example_input = torch.randn(1, model.input_size)
            traced_model = torch.jit.trace(model, example_input)
            
            # Save traced model
            model_path = os.path.join(self.model_dir, f"model_{int(time.time())}.pt")
            torch.jit.save(traced_model, model_path)
            
            return traced_model
    
    async def _optimize_sklearn_model(self, model) -> Any:
        """
        Optimize a scikit-learn model.
        
        Args:
            model: scikit-learn model
            
        Returns:
            Optimized scikit-learn model
        """
        # Serialize the model for faster loading
        model_path = os.path.join(self.model_dir, f"model_{int(time.time())}.joblib")
        joblib.dump(model, model_path, compress=3)
        
        return model
    
    def get_model(self, model_type: str) -> Any:
        """
        Get a model from cache or load it.
        
        Args:
            model_type: Type of model to retrieve
            
        Returns:
            The requested model or None if not found
        """
        if model_type in self.model_cache:
            return self.model_cache[model_type]
        
        # Model not in cache, would load from storage in a real implementation
        logger.warning(f"Model {model_type} not found in cache")
        return None
    
    def cache_model(self, model: Any, model_type: str):
        """
        Cache a model for faster access.
        
        Args:
            model: The model to cache
            model_type: Type of model
        """
        self.model_cache[model_type] = model
        
        # Limit cache size
        if len(self.model_cache) > 10:
            # Remove least recently used model
            oldest_key = next(iter(self.model_cache))
            del self.model_cache[oldest_key]
    
    async def predict_async(self, features: np.ndarray, model_type: str, 
                           cache_key: Optional[str] = None) -> Dict[str, Any]:
        """
        Perform asynchronous prediction using batch processing.
        
        Args:
            features: Input features for prediction
            model_type: Type of model to use
            cache_key: Optional key for caching results
            
        Returns:
            Dictionary with prediction results
        """
        # Check cache if key provided
        if cache_key and cache_key in self.prediction_cache:
            self.performance_metrics['cache_hits'] += 1
            return self.prediction_cache[cache_key]
        
        self.performance_metrics['cache_misses'] += 1
        
        # Generate request ID
        request_id = f"{model_type}_{int(time.time())}_{np.random.randint(0, 1000000)}"
        
        # Add to batch queue
        self.prediction_queue.put({
            'request_id': request_id,
            'features': features,
            'model_type': model_type,
            'cache_key': cache_key
        })
        
        # Wait for result with timeout
        start_time = time.time()
        while time.time() - start_time < 5.0:  # 5 second timeout
            if request_id in self.batch_results:
                result = self.batch_results[request_id]
                del self.batch_results[request_id]  # Clean up
                
                # Cache result if key provided
                if cache_key and result['status'] == 'success':
                    self.prediction_cache[cache_key] = result
                    
                    # Limit cache size
                    if len(self.prediction_cache) > 1000:
                        # Remove oldest entries
                        oldest_keys = list(self.prediction_cache.keys())[:100]
                        for key in oldest_keys:
                            del self.prediction_cache[key]
                
                return result
            
            await asyncio.sleep<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>