"""
Casino Management System - Natural Language Processing for Search Queries
This module provides NLP capabilities for the player tracking search functionality.
"""

import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import spacy
import logging
import asyncio
from typing import List, Dict, Any, Optional, Tuple

# Initialize logging
logger = logging.getLogger(__name__)

class NLPSearchEngine:
    """
    Natural Language Processing engine for enhanced search capabilities in the player tracking module.
    Provides semantic search, intent recognition, and query expansion.
    """
    
    def __init__(self):
        """Initialize the NLP search engine with required models and resources."""
        # Download required NLTK resources if not already present
        try:
            nltk.data.find('tokenizers/punkt')
            nltk.data.find('corpora/stopwords')
            nltk.data.find('corpora/wordnet')
        except LookupError:
            nltk.download('punkt')
            nltk.download('stopwords')
            nltk.download('wordnet')
        
        # Initialize NLP components
        self.stop_words = set(stopwords.words('english'))
        self.lemmatizer = WordNetLemmatizer()
        
        # Load spaCy model for entity recognition and semantic understanding
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            # If model not found, download it
            import subprocess
            subprocess.run(["python", "-m", "spacy", "download", "en_core_web_sm"])
            self.nlp = spacy.load("en_core_web_sm")
        
        # Initialize TF-IDF vectorizer for semantic search
        self.vectorizer = TfidfVectorizer()
        
        # Define search intents and patterns
        self.search_intents = {
            'find_player': [
                r'find player (named|called)?\s+(.+)',
                r'search for player\s+(.+)',
                r'lookup player\s+(.+)',
                r'player\s+(.+)\s+profile'
            ],
            'find_by_id': [
                r'find player (with )?(id|number|card)\s+(.+)',
                r'search for (id|card|number)\s+(.+)',
                r'player (id|card|number)\s+(.+)'
            ],
            'find_by_game': [
                r'players (who )?(play|playing|played)\s+(.+)',
                r'find players (at|on) (.+) (table|machine|game)',
                r'who plays (.+)'
            ],
            'find_high_value': [
                r'(high|big) (rollers|spenders|bettors)',
                r'players (with|who have) (high|large) (bets|wagers)',
                r'vip players',
                r'players spending (more than|over) (.+)'
            ],
            'find_by_date': [
                r'players (who )?(visited|came) (on|during|at)\s+(.+)',
                r'players from\s+(.+)',
                r'visits on\s+(.+)'
            ],
            'find_by_consumption': [
                r'players (who )?(ordered|consumed|drank|ate)\s+(.+)',
                r'who (ordered|consumed|drank|ate)\s+(.+)',
                r'find players (who )?(like|prefer)\s+(.+)'
            ]
        }
        
        # Casino-specific vocabulary for query expansion
        self.domain_synonyms = {
            'bet': ['wager', 'stake', 'gamble', 'play'],
            'player': ['guest', 'patron', 'customer', 'gambler', 'visitor'],
            'table': ['game', 'blackjack', 'roulette', 'poker', 'baccarat', 'craps'],
            'slot': ['machine', 'slots', 'video poker', 'electronic game'],
            'money': ['cash', 'chips', 'credit', 'funds', 'balance'],
            'win': ['jackpot', 'payout', 'prize', 'profit', 'earnings'],
            'lose': ['loss', 'deficit', 'drop'],
            'drink': ['beverage', 'alcohol', 'cocktail', 'liquor', 'beer', 'wine'],
            'food': ['meal', 'snack', 'dish', 'order'],
            'cigarette': ['smoke', 'tobacco', 'cigar']
        }
        
        # Initialize cache for optimized performance
        self.query_cache = {}
        self.player_corpus = None
        self.player_corpus_embeddings = None
    
    async def preprocess_query(self, query: str) -> str:
        """
        Preprocess the search query by removing stopwords, lemmatizing, and normalizing.
        
        Args:
            query: The raw search query string
            
        Returns:
            Preprocessed query string
        """
        # Convert to lowercase
        query = query.lower()
        
        # Tokenize
        tokens = word_tokenize(query)
        
        # Remove stopwords and lemmatize
        processed_tokens = [
            self.lemmatizer.lemmatize(token) 
            for token in tokens 
            if token not in self.stop_words and token.isalnum()
        ]
        
        # Join tokens back into a string
        processed_query = ' '.join(processed_tokens)
        
        return processed_query
    
    async def identify_intent(self, query: str) -> Tuple[str, Dict[str, Any]]:
        """
        Identify the search intent and extract parameters from the query.
        
        Args:
            query: The search query string
            
        Returns:
            Tuple of (intent_name, extracted_parameters)
        """
        # Default intent if no patterns match
        default_intent = 'general_search'
        extracted_params = {'query': query}
        
        # Check each intent pattern
        for intent, patterns in self.search_intents.items():
            for pattern in patterns:
                match = re.search(pattern, query, re.IGNORECASE)
                if match:
                    # Extract parameters based on the intent
                    if intent == 'find_player':
                        extracted_params['name'] = match.group(2) if len(match.groups()) >= 2 else match.group(1)
                    elif intent == 'find_by_id':
                        extracted_params['id_type'] = match.group(2) if len(match.groups()) >= 2 else 'id'
                        extracted_params['id_value'] = match.group(3) if len(match.groups()) >= 3 else match.group(2)
                    elif intent == 'find_by_game':
                        extracted_params['game'] = match.group(3) if len(match.groups()) >= 3 else match.group(1)
                    elif intent == 'find_high_value':
                        if len(match.groups()) >= 2 and 'more than' in match.group(0):
                            extracted_params['min_amount'] = match.group(2)
                    elif intent == 'find_by_date':
                        extracted_params['date'] = match.group(4) if len(match.groups()) >= 4 else match.group(2)
                    elif intent == 'find_by_consumption':
                        extracted_params['item'] = match.group(3) if len(match.groups()) >= 3 else match.group(2)
                    
                    return intent, extracted_params
        
        # Use spaCy for entity recognition if no pattern matched
        doc = self.nlp(query)
        
        # Extract entities
        for ent in doc.ents:
            if ent.label_ == 'PERSON':
                extracted_params['name'] = ent.text
                return 'find_player', extracted_params
            elif ent.label_ == 'DATE':
                extracted_params['date'] = ent.text
                return 'find_by_date', extracted_params
            elif ent.label_ == 'CARDINAL' or ent.label_ == 'MONEY':
                extracted_params['amount'] = ent.text
                return 'find_high_value', extracted_params
        
        return default_intent, extracted_params
    
    async def expand_query(self, query: str) -> List[str]:
        """
        Expand the query with domain-specific synonyms to improve search results.
        
        Args:
            query: The preprocessed query string
            
        Returns:
            List of expanded query variations
        """
        expanded_queries = [query]
        tokens = query.split()
        
        # Generate query variations using domain synonyms
        for i, token in enumerate(tokens):
            if token in self.domain_synonyms:
                for synonym in self.domain_synonyms[token]:
                    new_tokens = tokens.copy()
                    new_tokens[i] = synonym
                    expanded_queries.append(' '.join(new_tokens))
        
        return expanded_queries
    
    async def semantic_search(self, query: str, player_data: List[Dict[str, Any]], 
                             top_n: int = 10) -> List[Dict[str, Any]]:
        """
        Perform semantic search on player data using query embeddings and cosine similarity.
        
        Args:
            query: The search query string
            player_data: List of player data dictionaries
            top_n: Number of top results to return
            
        Returns:
            List of top matching player data dictionaries
        """
        # Create a corpus from player data if not already cached
        if self.player_corpus is None or len(self.player_corpus) != len(player_data):
            self.player_corpus = []
            for player in player_data:
                # Create a document for each player with relevant fields
                doc = f"{player.get('first_name', '')} {player.get('last_name', '')} "
                doc += f"{player.get('email', '')} {player.get('phone', '')} "
                doc += f"{player.get('notes', '')} {player.get('casino_guest_id', '')}"
                self.player_corpus.append(doc)
            
            # Create TF-IDF matrix for the corpus
            self.player_corpus_embeddings = self.vectorizer.fit_transform(self.player_corpus)
        
        # Transform the query using the same vectorizer
        query_embedding = self.vectorizer.transform([query])
        
        # Calculate cosine similarity between query and all players
        similarities = cosine_similarity(query_embedding, self.player_corpus_embeddings).flatten()
        
        # Get indices of top N results
        top_indices = similarities.argsort()[-top_n:][::-1]
        
        # Filter results with similarity above threshold (0.1)
        results = [
            (player_data[i], similarities[i]) 
            for i in top_indices 
            if similarities[i] > 0.1
        ]
        
        # Return player data with similarity scores
        return [
            {**player, 'relevance_score': float(score)} 
            for player, score in results
        ]
    
    async def process_search_query(self, query: str, player_data: List[Dict[str, Any]],
                                  top_n: int = 10) -> Dict[str, Any]:
        """
        Process a natural language search query and return relevant results.
        
        Args:
            query: The raw search query string
            player_data: List of player data dictionaries
            top_n: Number of top results to return
            
        Returns:
            Dictionary with search results and metadata
        """
        # Check cache for identical queries
        cache_key = f"{query}_{len(player_data)}_{top_n}"
        if cache_key in self.query_cache:
            logger.info(f"Using cached results for query: {query}")
            return self.query_cache[cache_key]
        
        # Preprocess the query
        processed_query = await self.preprocess_query(query)
        
        # Identify intent and extract parameters
        intent, params = await self.identify_intent(query)
        
        # Expand the query with domain-specific synonyms
        expanded_queries = await self.expand_query(processed_query)
        
        # Perform semantic search for each expanded query
        all_results = []
        for exp_query in expanded_queries:
            results = await self.semantic_search(exp_query, player_data, top_n)
            all_results.extend(results)
        
        # Remove duplicates and sort by relevance score
        unique_results = {}
        for result in all_results:
            player_id = result.get('id')
            if player_id not in unique_results or result['relevance_score'] > unique_results[player_id]['relevance_score']:
                unique_results[player_id] = result
        
        sorted_results = sorted(
            unique_results.values(), 
            key=lambda x: x['relevance_score'], 
            reverse=True
        )[:top_n]
        
        # Prepare response
        response = {
            'intent': intent,
            'parameters': params,
            'results': sorted_results,
            'result_count': len(sorted_results),
            'expanded_queries': expanded_queries
        }
        
        # Cache the results
        self.query_cache[cache_key] = response
        
        # Limit cache size to prevent memory issues
        if len(self.query_cache) > 1000:
            # Remove oldest entries
            oldest_keys = list(self.query_cache.keys())[:100]
            for key in oldest_keys:
                del self.query_cache[key]
        
        return response
    
    async def clear_cache(self):
        """Clear the query cache to free memory."""
        self.query_cache = {}
        self.player_corpus = None
        self.player_corpus_embeddings = None
        logger.info("NLP search engine cache cleared")
    
    async def get_query_suggestions(self, partial_query: str) -> List[str]:
        """
        Generate query suggestions based on a partial query.
        
        Args:
            partial_query: The partial search query string
            
        Returns:
            List of suggested complete queries
        """
        suggestions = []
        
        # Basic suggestions based on common intents
        if 'find' in partial_query or 'search' in partial_query:
            suggestions.append(f"{partial_query} player by name")
            suggestions.append(f"{partial_query} player by ID")
            suggestions.append(f"{partial_query} high rollers")
        
        if 'player' in partial_query:
            suggestions.append(f"{partial_query} who plays blackjack")
            suggestions.append(f"{partial_query} who visited today")
            suggestions.append(f"{partial_query} with highest bets")
        
        if 'who' in partial_query:
            suggestions.append(f"{partial_query} ordered whiskey")
            suggestions.append(f"{partial_query} plays slot machines")
            suggestions.append(f"{partial_query} visited last weekend")
        
        # Return unique suggestions
        return list(set(suggestions))[:5]  # Limit to 5 suggestions
