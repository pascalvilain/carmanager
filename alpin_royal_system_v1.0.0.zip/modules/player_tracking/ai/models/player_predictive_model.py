"""
Casino Management System - Predictive Analytics Model
This module provides machine learning models for predicting player preferences and behaviors.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
import joblib
import os
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class PlayerPredictiveModel:
    """
    Machine learning model for predicting player preferences and future behaviors.
    Uses regression and classification models to predict various player metrics.
    """
    
    def __init__(self, model_path=None):
        """
        Initialize the player predictive model.
        
        Args:
            model_path: Optional path to load a pre-trained model
        """
        self.models = {}
        self.preprocessors = {}
        self.feature_importance = {}
        
        # Define prediction targets
        self.prediction_targets = {
            'next_visit_date': 'regression',
            'expected_bet_amount': 'regression',
            'expected_session_length': 'regression',
            'game_preference': 'classification',
            'drink_preference': 'classification',
            'cigarette_preference': 'classification',
            'churn_risk': 'classification'
        }
        
        if model_path and os.path.exists(model_path):
            self.load_model(model_path)
    
    def preprocess_data(self, player_data, target):
        """
        Preprocess player data for model training or prediction.
        
        Args:
            player_data: DataFrame containing player data
            target: Target variable to predict
            
        Returns:
            Preprocessed features and target
        """
        # Define feature sets based on prediction target
        feature_sets = {
            'next_visit_date': [
                'days_since_last_visit', 'total_visits', 'visit_frequency', 
                'avg_session_length', 'total_hours', 'day_of_week_preference',
                'month_in_year', 'is_holiday_season'
            ],
            'expected_bet_amount': [
                'avg_bet', 'max_bet', 'min_bet', 'total_buy_ins', 'total_cash_outs',
                'win_loss_ratio', 'days_since_last_visit', 'vip_status'
            ],
            'expected_session_length': [
                'avg_session_length', 'max_session_length', 'min_session_length',
                'time_of_day_preference', 'day_of_week_preference', 'avg_bet'
            ],
            'game_preference': [
                'table_game_ratio', 'slot_machine_ratio', 'avg_bet', 'win_loss_ratio',
                'age', 'gender', 'vip_status', 'total_hours'
            ],
            'drink_preference': [
                'previous_drink_orders', 'time_of_day_preference', 'age', 'gender',
                'avg_session_length', 'avg_bet', 'vip_status'
            ],
            'cigarette_preference': [
                'previous_cigarette_brands', 'total_cigarette_packs', 'age', 'gender',
                'avg_session_length', 'avg_bet'
            ],
            'churn_risk': [
                'days_since_last_visit', 'visit_frequency_change', 'avg_bet_change',
                'session_length_change', 'win_loss_ratio', 'total_visits',
                'complaint_count', 'age', 'total_hours'
            ]
        }
        
        # Select relevant features
        selected_features = feature_sets.get(target, [])
        
        # Ensure all required columns exist
        for col in selected_features:
            if col not in player_data.columns:
                player_data[col] = 0
        
        # Split features
        categorical_features = []
        numerical_features = []
        
        for feature in selected_features:
            if player_data[feature].dtype == 'object' or feature in ['gender', 'vip_status', 'day_of_week_preference', 'previous_drink_orders', 'previous_cigarette_brands']:
                categorical_features.append(feature)
            else:
                numerical_features.append(feature)
        
        # Create preprocessor if not already created
        if target not in self.preprocessors:
            # Define preprocessing for numerical features
            numerical_transformer = Pipeline(steps=[
                ('scaler', StandardScaler())
            ])
            
            # Define preprocessing for categorical features
            categorical_transformer = Pipeline(steps=[
                ('onehot', OneHotEncoder(handle_unknown='ignore'))
            ])
            
            # Combine preprocessing steps
            preprocessor = ColumnTransformer(
                transformers=[
                    ('num', numerical_transformer, numerical_features),
                    ('cat', categorical_transformer, categorical_features)
                ]
            )
            
            self.preprocessors[target] = preprocessor
        
        # Extract features and target
        X = player_data[selected_features]
        
        if target in player_data.columns:
            y = player_data[target]
        else:
            y = None
        
        return X, y
    
    def train_model(self, player_data, target):
        """
        Train a predictive model for the specified target.
        
        Args:
            player_data: DataFrame containing player data
            target: Target variable to predict
            
        Returns:
            Trained model and evaluation metrics
        """
        try:
            # Preprocess data
            X, y = self.preprocess_data(player_data, target)
            
            if y is None:
                raise ValueError(f"Target variable '{target}' not found in data")
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Fit preprocessor
            self.preprocessors[target].fit(X_train)
            
            # Transform data
            X_train_processed = self.preprocessors[target].transform(X_train)
            X_test_processed = self.preprocessors[target].transform(X_test)
            
            # Select model type based on prediction task
            model_type = self.prediction_targets.get(target)
            
            if model_type == 'regression':
                model = RandomForestRegressor(n_estimators=100, random_state=42)
                
                # Train model
                model.fit(X_train_processed, y_train)
                
                # Evaluate model
                train_score = model.score(X_train_processed, y_train)
                test_score = model.score(X_test_processed, y_test)
                
                # Calculate feature importance
                feature_names = (
                    self.preprocessors[target].named_transformers_['num'].get_feature_names_out(input_features=X.columns) if len(X.columns) > 0 else []
                )
                if hasattr(self.preprocessors[target].named_transformers_['cat'], 'get_feature_names_out'):
                    feature_names = np.append(
                        feature_names,
                        self.preprocessors[target].named_transformers_['cat'].get_feature_names_out(input_features=X.columns)
                    )
                
                self.feature_importance[target] = dict(zip(feature_names, model.feature_importances_))
                
                metrics = {
                    'train_r2': train_score,
                    'test_r2': test_score,
                    'feature_importance': self.feature_importance[target]
                }
            
            elif model_type == 'classification':
                model = RandomForestClassifier(n_estimators=100, random_state=42)
                
                # Train model
                model.fit(X_train_processed, y_train)
                
                # Evaluate model
                train_score = model.score(X_train_processed, y_train)
                test_score = model.score(X_test_processed, y_test)
                
                # Calculate feature importance
                feature_names = (
                    self.preprocessors[target].named_transformers_['num'].get_feature_names_out(input_features=X.columns) if len(X.columns) > 0 else []
                )
                if hasattr(self.preprocessors[target].named_transformers_['cat'], 'get_feature_names_out'):
                    feature_names = np.append(
                        feature_names,
                        self.preprocessors[target].named_transformers_['cat'].get_feature_names_out(input_features=X.columns)
                    )
                
                self.feature_importance[target] = dict(zip(feature_names, model.feature_importances_))
                
                metrics = {
                    'train_accuracy': train_score,
                    'test_accuracy': test_score,
                    'feature_importance': self.feature_importance[target]
                }
            
            else:
                raise ValueError(f"Unknown prediction task type: {model_type}")
            
            # Store model
            self.models[target] = model
            
            return metrics
        
        except Exception as e:
            logger.error(f"Error training model for {target}: {str(e)}")
            raise
    
    def predict(self, player_features, target):
        """
        Make predictions for a player.
        
        Args:
            player_features: DataFrame containing player features
            target: Target variable to predict
            
        Returns:
            Prediction and confidence score
        """
        if target not in self.models:
            raise ValueError(f"No trained model for target: {target}")
        
        try:
            # Preprocess data
            X, _ = self.preprocess_data(player_features, target)
            
            # Transform features
            X_processed = self.preprocessors[target].transform(X)
            
            # Get model
            model = self.models[target]
            
            # Make prediction
            if self.prediction_targets.get(target) == 'regression':
                prediction = model.predict(X_processed)[0]
                
                # Get prediction intervals using forest's variance
                predictions = []
                for estimator in model.estimators_:
                    predictions.append(estimator.predict(X_processed)[0])
                
                std_dev = np.std(predictions)
                confidence = 1.0 / (1.0 + std_dev)
                
                return prediction, confidence
            
            else:  # classification
                # Get class probabilities
                probabilities = model.predict_proba(X_processed)[0]
                
                # Get predicted class
                prediction = model.predict(X_processed)[0]
                
                # Get confidence (probability of predicted class)
                confidence = probabilities[list(model.classes_).index(prediction)]
                
                return prediction, confidence
        
        except Exception as e:
            logger.error(f"Error making prediction for {target}: {str(e)}")
            raise
    
    def save_model(self, model_path):
        """
        Save the trained models to disk.
        
        Args:
            model_path: Path to save the model
        """
        if not self.models:
            raise ValueError("No trained models to save")
        
        model_data = {
            'models': self.models,
            'preprocessors': self.preprocessors,
            'feature_importance': self.feature_importance,
            'prediction_targets': self.prediction_targets
        }
        
        joblib.dump(model_data, model_path)
        logger.info(f"Model saved to {model_path}")
    
    def load_model(self, model_path):
        """
        Load trained models from disk.
        
        Args:
            model_path: Path to load the model from
        """
        try:
            model_data = joblib.load(model_path)
            
            self.models = model_data['models']
            self.preprocessors = model_data['preprocessors']
            self.feature_importance = model_data['feature_importance']
            self.prediction_targets = model_data['prediction_targets']
            
            logger.info(f"Model loaded from {model_path}")
        
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            raise
