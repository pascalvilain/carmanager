"""
Casino Management System - Player Behavior Analysis Model
This module provides machine learning models for analyzing player behavior patterns.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest
import joblib
import os
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class PlayerBehaviorModel:
    """
    Machine learning model for analyzing player behavior patterns.
    Uses clustering to identify player segments and anomaly detection to identify unusual behavior.
    """
    
    def __init__(self, model_path=None):
        """
        Initialize the player behavior model.
        
        Args:
            model_path: Optional path to load a pre-trained model
        """
        self.kmeans_model = None
        self.anomaly_model = None
        self.scaler = StandardScaler()
        self.pca = PCA(n_components=5)
        self.feature_columns = [
            'avg_bet', 'total_hours', 'visit_frequency', 'avg_session_length',
            'table_game_ratio', 'slot_machine_ratio', 'win_loss_ratio',
            'jackpot_frequency', 'consumption_per_hour', 'evening_preference'
        ]
        
        if model_path and os.path.exists(model_path):
            self.load_model(model_path)
    
    def preprocess_data(self, player_data):
        """
        Preprocess player data for model training or prediction.
        
        Args:
            player_data: DataFrame containing player behavior data
            
        Returns:
            Preprocessed data ready for model input
        """
        # Ensure all required columns exist
        for col in self.feature_columns:
            if col not in player_data.columns:
                player_data[col] = 0
        
        # Select relevant features
        features = player_data[self.feature_columns].copy()
        
        # Handle missing values
        features.fillna(0, inplace=True)
        
        # Scale features
        scaled_features = self.scaler.fit_transform(features)
        
        # Apply PCA for dimensionality reduction
        pca_features = self.pca.fit_transform(scaled_features)
        
        return pca_features, features
    
    def train_clustering_model(self, player_data, n_clusters=5):
        """
        Train a clustering model to identify player segments.
        
        Args:
            player_data: DataFrame containing player behavior data
            n_clusters: Number of player segments to identify
            
        Returns:
            Trained model and cluster assignments
        """
        try:
            # Preprocess data
            pca_features, _ = self.preprocess_data(player_data)
            
            # Train KMeans model
            self.kmeans_model = KMeans(n_clusters=n_clusters, random_state=42)
            cluster_labels = self.kmeans_model.fit_predict(pca_features)
            
            # Add cluster labels to original data
            player_data['cluster'] = cluster_labels
            
            # Analyze clusters
            cluster_analysis = self._analyze_clusters(player_data)
            
            return cluster_labels, cluster_analysis
        
        except Exception as e:
            logger.error(f"Error training clustering model: {str(e)}")
            raise
    
    def train_anomaly_model(self, player_data, contamination=0.05):
        """
        Train an anomaly detection model to identify unusual player behavior.
        
        Args:
            player_data: DataFrame containing player behavior data
            contamination: Expected proportion of outliers in the data
            
        Returns:
            Trained model and anomaly scores
        """
        try:
            # Preprocess data
            pca_features, _ = self.preprocess_data(player_data)
            
            # Train Isolation Forest model
            self.anomaly_model = IsolationForest(
                contamination=contamination,
                random_state=42
            )
            
            # Fit model and get anomaly scores
            # -1 for anomalies, 1 for normal observations
            anomaly_labels = self.anomaly_model.fit_predict(pca_features)
            
            # Convert to boolean (True for anomalies)
            anomalies = anomaly_labels == -1
            
            # Add anomaly flag to original data
            player_data['is_anomaly'] = anomalies
            
            return anomalies
        
        except Exception as e:
            logger.error(f"Error training anomaly detection model: {str(e)}")
            raise
    
    def predict_cluster(self, player_features):
        """
        Predict the cluster (player segment) for new player data.
        
        Args:
            player_features: DataFrame containing player behavior features
            
        Returns:
            Predicted cluster and confidence score
        """
        if self.kmeans_model is None:
            raise ValueError("Clustering model not trained yet")
        
        try:
            # Preprocess data
            pca_features, _ = self.preprocess_data(player_features)
            
            # Predict cluster
            cluster = self.kmeans_model.predict(pca_features)[0]
            
            # Calculate distance to cluster center as a confidence measure
            # Closer to center = higher confidence
            distance = np.linalg.norm(pca_features - self.kmeans_model.cluster_centers_[cluster])
            max_distance = np.max([np.linalg.norm(self.kmeans_model.cluster_centers_[i] - self.kmeans_model.cluster_centers_[j]) 
                                 for i in range(len(self.kmeans_model.cluster_centers_)) 
                                 for j in range(i+1, len(self.kmeans_model.cluster_centers_))])
            
            confidence = 1 - (distance / max_distance)
            
            return cluster, confidence
        
        except Exception as e:
            logger.error(f"Error predicting cluster: {str(e)}")
            raise
    
    def detect_anomalies(self, player_features):
        """
        Detect anomalies in player behavior.
        
        Args:
            player_features: DataFrame containing player behavior features
            
        Returns:
            Boolean indicating if behavior is anomalous and anomaly score
        """
        if self.anomaly_model is None:
            raise ValueError("Anomaly detection model not trained yet")
        
        try:
            # Preprocess data
            pca_features, _ = self.preprocess_data(player_features)
            
            # Predict anomaly
            # -1 for anomalies, 1 for normal observations
            anomaly_label = self.anomaly_model.predict(pca_features)[0]
            
            # Get anomaly score
            anomaly_score = self.anomaly_model.score_samples(pca_features)[0]
            
            # Convert to boolean (True for anomalies)
            is_anomaly = anomaly_label == -1
            
            return is_anomaly, anomaly_score
        
        except Exception as e:
            logger.error(f"Error detecting anomalies: {str(e)}")
            raise
    
    def _analyze_clusters(self, player_data_with_clusters):
        """
        Analyze the characteristics of each cluster.
        
        Args:
            player_data_with_clusters: DataFrame with cluster assignments
            
        Returns:
            Dictionary with cluster analysis
        """
        cluster_analysis = {}
        
        for cluster in range(self.kmeans_model.n_clusters):
            cluster_data = player_data_with_clusters[player_data_with_clusters['cluster'] == cluster]
            
            # Skip empty clusters
            if len(cluster_data) == 0:
                continue
            
            # Calculate mean values for each feature
            cluster_profile = {}
            for col in self.feature_columns:
                cluster_profile[col] = cluster_data[col].mean()
            
            # Determine key characteristics
            characteristics = []
            
            # High rollers
            if cluster_profile['avg_bet'] > player_data_with_clusters['avg_bet'].quantile(0.75):
                characteristics.append('high_roller')
            
            # Frequent visitors
            if cluster_profile['visit_frequency'] > player_data_with_clusters['visit_frequency'].quantile(0.75):
                characteristics.append('frequent_visitor')
            
            # Long sessions
            if cluster_profile['avg_session_length'] > player_data_with_clusters['avg_session_length'].quantile(0.75):
                characteristics.append('long_sessions')
            
            # Table game preference
            if cluster_profile['table_game_ratio'] > 0.7:
                characteristics.append('table_game_preference')
            
            # Slot machine preference
            if cluster_profile['slot_machine_ratio'] > 0.7:
                characteristics.append('slot_machine_preference')
            
            # Winners
            if cluster_profile['win_loss_ratio'] > 1.0:
                characteristics.append('winner')
            
            # Losers
            if cluster_profile['win_loss_ratio'] < 0.5:
                characteristics.append('big_spender')
            
            # Jackpot hunters
            if cluster_profile['jackpot_frequency'] > player_data_with_clusters['jackpot_frequency'].quantile(0.75):
                characteristics.append('jackpot_hunter')
            
            # High consumption
            if cluster_profile['consumption_per_hour'] > player_data_with_clusters['consumption_per_hour'].quantile(0.75):
                characteristics.append('high_consumption')
            
            # Evening preference
            if cluster_profile['evening_preference'] > 0.7:
                characteristics.append('evening_player')
            
            cluster_analysis[cluster] = {
                'size': len(cluster_data),
                'percentage': len(cluster_data) / len(player_data_with_clusters) * 100,
                'profile': cluster_profile,
                'characteristics': characteristics
            }
        
        return cluster_analysis
    
    def save_model(self, model_path):
        """
        Save the trained models to disk.
        
        Args:
            model_path: Path to save the model
        """
        if self.kmeans_model is None and self.anomaly_model is None:
            raise ValueError("No trained models to save")
        
        model_data = {
            'kmeans_model': self.kmeans_model,
            'anomaly_model': self.anomaly_model,
            'scaler': self.scaler,
            'pca': self.pca,
            'feature_columns': self.feature_columns
        }
        
        joblib.dump(model_data, model_path)
        logger.info(f"Model saved to {model_path}")
    
    def load_model(self, model_path):
        """
        Load trained models from disk.
        
        Args:
            model_path: Path to load the model from
        """
        try:
            model_data = joblib.load(model_path)
            
            self.kmeans_model = model_data['kmeans_model']
            self.anomaly_model = model_data['anomaly_model']
            self.scaler = model_data['scaler']
            self.pca = model_data['pca']
            self.feature_columns = model_data['feature_columns']
            
            logger.info(f"Model loaded from {model_path}")
        
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            raise
