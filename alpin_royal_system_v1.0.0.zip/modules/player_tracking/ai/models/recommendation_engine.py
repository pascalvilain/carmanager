"""
Casino Management System - Recommendation Engine
This module provides recommendation algorithms for personalized player offers.
"""

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler
import joblib
import os
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class RecommendationEngine:
    """
    Recommendation engine for generating personalized offers and suggestions for players.
    Uses collaborative filtering and content-based approaches.
    """
    
    def __init__(self, model_path=None):
        """
        Initialize the recommendation engine.
        
        Args:
            model_path: Optional path to load pre-trained recommendation data
        """
        self.player_features = None
        self.item_features = None
        self.player_item_matrix = None
        self.item_similarity_matrix = None
        self.player_similarity_matrix = None
        self.scaler = StandardScaler()
        
        # Define feature sets
        self.player_feature_columns = [
            'avg_bet', 'total_hours', 'visit_frequency', 'avg_session_length',
            'table_game_ratio', 'slot_machine_ratio', 'win_loss_ratio',
            'jackpot_frequency', 'consumption_per_hour', 'evening_preference',
            'age', 'gender', 'vip_status'
        ]
        
        self.item_feature_columns = [
            'item_type', 'item_category', 'price_tier', 'popularity_score',
            'is_alcoholic', 'is_food', 'is_entertainment', 'is_service',
            'is_promotion', 'is_comp', 'target_vip_level'
        ]
        
        if model_path and os.path.exists(model_path):
            self.load_model(model_path)
    
    def preprocess_data(self, player_data, item_data, interaction_data):
        """
        Preprocess data for recommendation model training.
        
        Args:
            player_data: DataFrame containing player profiles
            item_data: DataFrame containing item/offer details
            interaction_data: DataFrame containing player-item interactions
            
        Returns:
            Preprocessed data ready for model training
        """
        # Ensure all required columns exist in player data
        for col in self.player_feature_columns:
            if col not in player_data.columns:
                player_data[col] = 0
        
        # Ensure all required columns exist in item data
        for col in self.item_feature_columns:
            if col not in item_data.columns:
                item_data[col] = 0
        
        # Select relevant features
        player_features = player_data[self.player_feature_columns].copy()
        item_features = item_data[self.item_feature_columns].copy()
        
        # Handle missing values
        player_features.fillna(0, inplace=True)
        item_features.fillna(0, inplace=True)
        
        # Convert categorical features to one-hot encoding
        categorical_cols = ['gender', 'vip_status', 'item_type', 'item_category']
        
        for df, cols in [(player_features, [col for col in categorical_cols if col in player_features.columns]),
                         (item_features, [col for col in categorical_cols if col in item_features.columns])]:
            for col in cols:
                if col in df.columns and df[col].dtype == 'object':
                    dummies = pd.get_dummies(df[col], prefix=col)
                    df = pd.concat([df.drop(col, axis=1), dummies], axis=1)
        
        # Scale numerical features
        player_features_scaled = self.scaler.fit_transform(player_features)
        player_features = pd.DataFrame(player_features_scaled, index=player_features.index, columns=player_features.columns)
        
        item_features_scaled = self.scaler.fit_transform(item_features)
        item_features = pd.DataFrame(item_features_scaled, index=item_features.index, columns=item_features.columns)
        
        # Create player-item interaction matrix
        player_item_matrix = interaction_data.pivot(
            index='player_id', 
            columns='item_id', 
            values='interaction_score'
        ).fillna(0)
        
        return player_features, item_features, player_item_matrix
    
    def train_model(self, player_data, item_data, interaction_data):
        """
        Train the recommendation model.
        
        Args:
            player_data: DataFrame containing player profiles
            item_data: DataFrame containing item/offer details
            interaction_data: DataFrame containing player-item interactions
            
        Returns:
            Trained model
        """
        try:
            # Preprocess data
            self.player_features, self.item_features, self.player_item_matrix = self.preprocess_data(
                player_data, item_data, interaction_data
            )
            
            # Calculate item-item similarity matrix
            self.item_similarity_matrix = pd.DataFrame(
                cosine_similarity(self.item_features),
                index=self.item_features.index,
                columns=self.item_features.index
            )
            
            # Calculate player-player similarity matrix
            self.player_similarity_matrix = pd.DataFrame(
                cosine_similarity(self.player_features),
                index=self.player_features.index,
                columns=self.player_features.index
            )
            
            logger.info("Recommendation model trained successfully")
            
            return {
                'player_features': self.player_features.shape,
                'item_features': self.item_features.shape,
                'player_item_matrix': self.player_item_matrix.shape,
                'item_similarity_matrix': self.item_similarity_matrix.shape,
                'player_similarity_matrix': self.player_similarity_matrix.shape
            }
        
        except Exception as e:
            logger.error(f"Error training recommendation model: {str(e)}")
            raise
    
    def get_content_based_recommendations(self, player_id, n_recommendations=5):
        """
        Generate content-based recommendations for a player.
        
        Args:
            player_id: ID of the player
            n_recommendations: Number of recommendations to generate
            
        Returns:
            List of recommended item IDs with scores
        """
        if self.player_features is None or self.item_features is None:
            raise ValueError("Recommendation model not trained yet")
        
        try:
            # Get player features
            if player_id not in self.player_features.index:
                raise ValueError(f"Player {player_id} not found in training data")
            
            player_profile = self.player_features.loc[player_id]
            
            # Calculate similarity between player and all items
            item_scores = {}
            
            for item_id, item_profile in self.item_features.iterrows():
                # Calculate cosine similarity between player and item
                similarity = cosine_similarity(
                    player_profile.values.reshape(1, -1),
                    item_profile.values.reshape(1, -1)
                )[0][0]
                
                item_scores[item_id] = similarity
            
            # Sort items by similarity score
            sorted_items = sorted(item_scores.items(), key=lambda x: x[1], reverse=True)
            
            # Return top N recommendations
            recommendations = [
                {'item_id': item_id, 'score': score}
                for item_id, score in sorted_items[:n_recommendations]
            ]
            
            return recommendations
        
        except Exception as e:
            logger.error(f"Error generating content-based recommendations: {str(e)}")
            raise
    
    def get_collaborative_filtering_recommendations(self, player_id, n_recommendations=5):
        """
        Generate collaborative filtering recommendations for a player.
        
        Args:
            player_id: ID of the player
            n_recommendations: Number of recommendations to generate
            
        Returns:
            List of recommended item IDs with scores
        """
        if self.player_item_matrix is None or self.player_similarity_matrix is None:
            raise ValueError("Recommendation model not trained yet")
        
        try:
            # Get player's interactions
            if player_id not in self.player_item_matrix.index:
                raise ValueError(f"Player {player_id} not found in interaction data")
            
            player_interactions = self.player_item_matrix.loc[player_id]
            
            # Get similar players
            similar_players = self.player_similarity_matrix[player_id].sort_values(ascending=False)[1:11]  # Top 10 similar players
            
            # Calculate predicted scores for items the player hasn't interacted with
            item_scores = {}
            
            for item_id in self.player_item_matrix.columns:
                # Skip items the player has already interacted with
                if player_interactions[item_id] > 0:
                    continue
                
                # Calculate weighted score based on similar players' interactions
                weighted_score = 0
                similarity_sum = 0
                
                for similar_player_id, similarity in similar_players.items():
                    if similar_player_id in self.player_item_matrix.index:
                        similar_player_interaction = self.player_item_matrix.loc[similar_player_id, item_id]
                        weighted_score += similarity * similar_player_interaction
                        similarity_sum += similarity
                
                if similarity_sum > 0:
                    item_scores[item_id] = weighted_score / similarity_sum
            
            # Sort items by predicted score
            sorted_items = sorted(item_scores.items(), key=lambda x: x[1], reverse=True)
            
            # Return top N recommendations
            recommendations = [
                {'item_id': item_id, 'score': score}
                for item_id, score in sorted_items[:n_recommendations]
            ]
            
            return recommendations
        
        except Exception as e:
            logger.error(f"Error generating collaborative filtering recommendations: {str(e)}")
            raise
    
    def get_hybrid_recommendations(self, player_id, n_recommendations=5, content_weight=0.5):
        """
        Generate hybrid recommendations combining content-based and collaborative filtering approaches.
        
        Args:
            player_id: ID of the player
            n_recommendations: Number of recommendations to generate
            content_weight: Weight for content-based recommendations (0-1)
            
        Returns:
            List of recommended item IDs with scores
        """
        try:
            # Get content-based recommendations
            content_recs = self.get_content_based_recommendations(player_id, n_recommendations=10)
            
            # Get collaborative filtering recommendations
            try:
                collab_recs = self.get_collaborative_filtering_recommendations(player_id, n_recommendations=10)
            except ValueError:
                # If player has no interactions yet, use only content-based
                collab_recs = []
                content_weight = 1.0
            
            # Combine recommendations
            item_scores = {}
            
            # Add content-based scores
            for rec in content_recs:
                item_scores[rec['item_id']] = rec['score'] * content_weight
            
            # Add collaborative filtering scores
            for rec in collab_recs:
                if rec['item_id'] in item_scores:
                    item_scores[rec['item_id']] += rec['score'] * (1 - content_weight)
                else:
                    item_scores[rec['item_id']] = rec['score'] * (1 - content_weight)
            
            # Sort items by combined score
            sorted_items = sorted(item_scores.items(), key=lambda x: x[1], reverse=True)
            
            # Return top N recommendations
            recommendations = [
                {'item_id': item_id, 'score': score}
                for item_id, score in sorted_items[:n_recommendations]
            ]
            
            return recommendations
        
        except Exception as e:
            logger.error(f"Error generating hybrid recommendations: {str(e)}")
            raise
    
    def get_personalized_offers(self, player_id, available_offers, player_data=None, n_recommendations=3):
        """
        Generate personalized offers for a player from a list of available offers.
        
        Args:
            player_id: ID of the player
            available_offers: DataFrame containing available offers
            player_data: Optional DataFrame containing player data (if player not in training data)
            n_recommendations: Number of recommendations to generate
            
        Returns:
            List of recommended offer IDs with scores
        """
        try:
            # If player is not in training data, use provided player data
            if player_data is not None and player_id not in self.player_features.index:
                # Preprocess player data
                for col in self.player_feature_columns:
                    if col not in player_data.columns:
                        player_data[col] = 0
                
                player_features = player_data[self.player_feature_columns].copy()
                player_features.fillna(0, inplace=True)
                
                # Scale features
                player_features_scaled = self.scaler.transform(player_features)
                player_features = pd.DataFrame(player_features_scaled, index=player_features.index, columns=player_features.columns)
                
                # Calculate similarity between player and all items
                item_scores = {}
                
                for item_id, item_profile in self.item_features.iterrows():
                    if item_id in available_offers['offer_id'].values:
                        # Calculate cosine similarity between player and item
                        similarity = cosine_similarity(
                            player_features.iloc[0].values.reshape(1, -1),
                            item_profile.values.reshape(1, -1)
                        )[0][0]
                        
                        item_scores[item_id] = similarity
                
                # Sort items by similarity score
                sorted_items = sorted(item_scores.items(), key=lambda x: x[1], reverse=True)
                
                # Return top N recommendations
                recommendations = [
                    {'offer_id': item_id, 'score': score}
                    for item_id, score in sorted_items[:n_recommendations]
                ]
                
                return recommendations
            
            # Otherwise, use hybrid recommendations
            else:
                # Filter item features to only include available offers
                available_item_ids = available_offers['offer_id'].values
                filtered_item_features = self.item_features.loc[self.item_features.index.isin(available_item_ids)]
                
                # Calculate similarity between player and available offers
                player_profile = self.player_features.loc[player_id]
                
                item_scores = {}
           <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>