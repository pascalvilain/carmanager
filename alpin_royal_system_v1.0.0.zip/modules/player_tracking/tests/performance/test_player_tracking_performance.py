"""
Casino Management System - Performance Tests for Player Tracking Module
This module provides performance tests for the player tracking module.
"""

import unittest
import asyncio
import sys
import os
import datetime
import time
import statistics
from unittest.mock import MagicMock, patch
import pandas as pd
import numpy as np

# Add parent directory to path to import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from modules.player_tracking.module import PlayerTrackingModule
from modules.player_tracking.models.player import PlayerProfile
from modules.player_tracking.models.gaming_session import TableGameSession, SlotMachineSession
from modules.player_tracking.ai.services.ai_service import AIService

class TestPlayerTrackingPerformance(unittest.TestCase):
    """Performance tests for the Player Tracking Module."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create module instance
        self.module = PlayerTrackingModule()
        
        # Mock repositories for controlled performance testing
        self.module.player_repository = MagicMock()
        self.module.gaming_session_repository = MagicMock()
        self.module.financial_repository = MagicMock()
        self.module.consumption_repository = MagicMock()
        self.module.dashboard_repository = MagicMock()
        
        # Create AI service instance
        self.ai_service = AIService()
        
        # Mock AI models to isolate performance testing
        self.ai_service.behavior_model = MagicMock()
        self.ai_service.predictive_model = MagicMock()
        self.ai_service.recommendation_engine = MagicMock()
        
        # Assign AI service to module
        self.module.ai_service = self.ai_service
        
        # Generate test data
        self.generate_test_data()
    
    def generate_test_data(self):
        """Generate test data for performance testing."""
        # Generate player data
        self.players = []
        for i in range(100):
            player = PlayerProfile(
                id=f"P{i:05d}",
                casino_guest_id=f"CG-{i:05d}",
                first_name=f"Player{i}",
                last_name=f"Test",
                email=f"player{i}@example.com",
                phone=f"555-{i:03d}-{i:04d}"[-12:],
                date_of_birth=datetime.date(1980, 1, 15),
                gender="MALE" if i % 2 == 0 else "FEMALE",
                address=f"{i} Test St, Testville, TS",
                vip_status=i % 10 == 0,
                registration_date=datetime.date(2023, 1, 1),
                last_visit_date=datetime.date(2023, 3, 15),
                notes="Test player"
            )
            self.players.append(player)
        
        # Generate session data
        self.sessions = []
        for i in range(500):
            player_idx = i % 100
            session = TableGameSession(
                id=f"S{i:05d}",
                player_id=f"P{player_idx:05d}",
                session_type="TABLE_GAME" if i % 2 == 0 else "SLOT_MACHINE",
                start_time=datetime.datetime(2023, 3, 15, 18, 0, 0) + datetime.timedelta(hours=i % 24),
                end_time=datetime.datetime(2023, 3, 15, 20, 0, 0) + datetime.timedelta(hours=i % 24),
                duration_minutes=120,
                game_type="Blackjack" if i % 3 == 0 else "Roulette" if i % 3 == 1 else "Slot Machine",
                table_number=f"T{i % 20:02d}" if i % 2 == 0 else None,
                machine_number=f"M{i % 50:03d}" if i % 2 == 1 else None,
                avg_bet=50.0 + (i % 10) * 10,
                buy_in=500.0 + (i % 5) * 100 if i % 2 == 0 else None,
                cash_out=450.0 + (i % 10) * 50 if i % 2 == 0 else None,
                ticket_in=200.0 + (i % 5) * 50 if i % 2 == 1 else None,
                ticket_out=180.0 + (i % 10) * 20 if i % 2 == 1 else None,
                win_loss=-50.0 + (i % 20) * 10
            )
            self.sessions.append(session)
        
        # Generate player features for AI testing
        self.player_features = pd.DataFrame([{
            "id": f"P{i:05d}",
            "avg_bet": 50.0 + (i % 10) * 10,
            "total_hours": 50.0 + i,
            "visit_frequency": 2.0 + (i % 5),
            "avg_session_length": 2.0 + (i % 3),
            "table_game_ratio": 0.7 if i % 3 == 0 else 0.3,
            "slot_machine_ratio": 0.3 if i % 3 == 0 else 0.7,
            "win_loss_ratio": 0.8 + (i % 5) * 0.1,
            "jackpot_frequency": 0.01 * (i % 10),
            "consumption_per_hour": 20.0 + i % 30,
            "evening_preference": 0.6 + (i % 5) * 0.1
        } for i in range(100)])
    
    def measure_execution_time(self, func, *args, **kwargs):
        """Measure execution time of a function."""
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        return result, end_time - start_time
    
    async def measure_async_execution_time(self, func, *args, **kwargs):
        """Measure execution time of an async function."""
        start_time = time.time()
        result = await func(*args, **kwargs)
        end_time = time.time()
        return result, end_time - start_time
    
    def test_player_search_performance(self):
        """Test performance of player search operations."""
        # Setup
        self.module.player_repository.search_players.return_value = self.players[:5]
        
        # Execute search multiple times and measure performance
        execution_times = []
        for i in range(50):
            search_term = f"Player{i % 10}"
            _, execution_time = asyncio.run(
                self.measure_async_execution_time(
                    self.module.search_players, search_term, "name"
                )
            )
            execution_times.append(execution_time)
        
        # Calculate statistics
        avg_time = statistics.mean(execution_times)
        max_time = max(execution_times)
        min_time = min(execution_times)
        
        # Assert performance meets requirements
        self.assertLess(avg_time, 0.05, f"Average search time ({avg_time:.4f}s) exceeds threshold")
        self.assertLess(max_time, 0.1, f"Maximum search time ({max_time:.4f}s) exceeds threshold")
        
        print(f"Player search performance: Avg={avg_time:.4f}s, Min={min_time:.4f}s, Max={max_time:.4f}s")
    
    def test_session_retrieval_performance(self):
        """Test performance of session retrieval operations."""
        # Setup
        self.module.gaming_session_repository.get_sessions_by_player_id.return_value = self.sessions[:10]
        
        # Execute retrieval multiple times and measure performance
        execution_times = []
        for i in range(50):
            player_id = f"P{i % 100:05d}"
            _, execution_time = asyncio.run(
                self.measure_async_execution_time(
                    self.module.get_player_sessions, player_id
                )
            )
            execution_times.append(execution_time)
        
        # Calculate statistics
        avg_time = statistics.mean(execution_times)
        max_time = max(execution_times)
        min_time = min(execution_times)
        
        # Assert performance meets requirements
        self.assertLess(avg_time, 0.05, f"Average session retrieval time ({avg_time:.4f}s) exceeds threshold")
        self.assertLess(max_time, 0.1, f"Maximum session retrieval time ({max_time:.4f}s) exceeds threshold")
        
        print(f"Session retrieval performance: Avg={avg_time:.4f}s, Min={min_time:.4f}s, Max={max_time:.4f}s")
    
    def test_dashboard_generation_performance(self):
        """Test performance of dashboard generation."""
        # Setup
        dashboard_data = {
            "player_id": "P00001",
            "total_visits": 25,
            "total_hours": 75.5,
            "total_spend": 2500.0,
            "win_loss": 250.0,
            "charts": {
                "visits_by_day": [{"day": "Monday", "count": 5}] * 7,
                "win_loss_trend": [{"date": "2023-03-01", "amount": 100.0}] * 30,
                "game_preference": [{"game": "Blackjack", "hours": 20.5}] * 5,
                "consumption_breakdown": [{"item": "Whiskey", "amount": 150.0}] * 10
            }
        }
        self.module.dashboard_repository.generate_player_dashboard.return_value = dashboard_data
        
        # Execute dashboard generation multiple times and measure performance
        execution_times = []
        for i in range(20):
            player_id = f"P{i % 100:05d}"
            _, execution_time = asyncio.run(
                self.measure_async_execution_time(
                    self.module.generate_player_dashboard, player_id
                )
            )
            execution_times.append(execution_time)
        
        # Calculate statistics
        avg_time = statistics.mean(execution_times)
        max_time = max(execution_times)
        min_time = min(execution_times)
        
        # Assert performance meets requirements
        self.assertLess(avg_time, 0.1, f"Average dashboard generation time ({avg_time:.4f}s) exceeds threshold")
        self.assertLess(max_time, 0.2, f"Maximum dashboard generation time ({max_time:.4f}s) exceeds threshold")
        
        print(f"Dashboard generation performance: Avg={avg_time:.4f}s, Min={min_time:.4f}s, Max={max_time:.4f}s")
    
    def test_ai_prediction_performance(self):
        """Test performance of AI prediction operations."""
        # Setup
        self.ai_service.behavior_model.predict_cluster.return_value = (2, 0.85)
        self.ai_service.predictive_model.models = {"next_visit_date": MagicMock()}
        self.ai_service.predictive_model.predict.return_value = (datetime.datetime(2023, 4, 1), 0.9)
        
        # Execute prediction multiple times and measure performance
        execution_times = []
        for i in range(50):
            player_id = f"P{i % 100:05d}"
            player_data = self.player_features.iloc[i % 100].to_dict()
            
            # Measure _prepare_predictive_features performance
            _, prep_time = self.measure_execution_time(
                self.ai_service._prepare_predictive_features, pd.DataFrame([player_data])
            )
            
            # Measure predict_player_behavior performance
            _, pred_time = asyncio.run(
                self.measure_async_execution_time(
                    self.ai_service.predict_player_behavior, 
                    player_id, "next_visit_date", pd.DataFrame([player_data])
                )
            )
            
            execution_times.append(prep_time + pred_time)
        
        # Calculate statistics
        avg_time = statistics.mean(execution_times)
        max_time = max(execution_times)
        min_time = min(execution_times)
        
        # Assert performance meets requirements
        self.assertLess(avg_time, 0.1, f"Average AI prediction time ({avg_time:.4f}s) exceeds threshold")
        self.assertLess(max_time, 0.2, f"Maximum AI prediction time ({max_time:.4f}s) exceeds threshold")
        
        print(f"AI prediction performance: Avg={avg_time:.4f}s, Min={min_time:.4f}s, Max={max_time:.4f}s")
    
    def test_recommendation_performance(self):
        """Test performance of recommendation generation."""
        # Setup
        self.ai_service.recommendation_engine.get_personalized_offers.return_value = [
            {"offer_id": f"O{i:05d}", "score": 0.9 - (i * 0.1)} for i in range(5)
        ]
        
        # Sample offer data
        offer_data = pd.DataFrame([{
            "offer_id": f"O{i:05d}",
            "offer_type": "DRINK_OFFER" if i % 3 == 0 else "FOOD_OFFER" if i % 3 == 1 else "COMP_OFFER",
            "offer_name": f"Offer {i}",
            "offer_value": 10.0 + (i % 5) * 5,
            "target_vip_level": i % 10 == 0
        } for i in range(20)])
        
        # Execute recommendation generation multiple times and measure performance
        execution_times = []
        for i in range(30):
            player_id = f"P{i % 100:05d}"
            player_data = self.player_features.iloc[i % 100].to_dict()
            
            _, execution_time = asyncio.run(
                self.measure_async_execution_time(
                    self.ai_service.get_personalized_recommendations,
                    player_id, offer_data, pd.DataFrame([player_data]), 3
                )
            )
            execution_times.append(execution_time)
        
        # Calculate statistics
        avg_time = statistics.mean(execution_times)
        max_time = max(execution_times)
        min_time = min(execution_times)
        
        # Assert performance meets requirements
        self.assertLess(avg_time, 0.1, f"Average recommendation time ({avg_time:.4f}s) exceeds threshold")
        self.assertLess(max_time, 0.2, f"Maximum recommendation time ({max_time:.4f}s) exceeds threshold")
        
        print(f"Recommendation performance: Avg={avg_time:.4f}s, Min={min_time:.4f}s, Max={max_time:.4f}s")
    
    def test_concurrent_operations_performance(self):
        """Test performance under concurrent operations."""
        # Setup
        self.module.player_repository.get_player_by_id.side_effect = lambda id: next((p for p in self.players if p.id == id), None)
        self.module.gaming_session_repository.get_sessions_by_player_id.return_value = self.sessions[:5]
        self.module.dashboard_repository.generate_player_dashboard.return_value = {
            "player_id": "P00001",
            "total_visits": 25,
            "charts": {"visits_by_day": [{"day": "Monday", "count": 5}]}
        }
        
        # Define async tasks to run concurrently
        async def run_concurrent_tasks():
            tasks = []
            for i in range(20):
                player_id = f"P{i % 100:05d}"
                
                # Add different types of tasks
                tasks.append(self.module.get_player_by_id(player_id))
                tasks.append(self.module.get_player_sessions(player_id))
                tasks.append(self.module.generate_player_dashboard(player_id))
            
            # Execute all tasks concurrently
            start_time = time.time()
            results = await asyncio.gather(*tasks)
            end_time = time.time()
            
            return end_time - start_time
        
        # Run concurrent tasks multiple times
        execution_times = []
        for _ in range(5):
            execution_time = asyncio.run(run_concurrent_tasks())
            execution_times.append(execution_time)
        
        # Calculate statistics
        avg_time = statistics.mean(execution_times)
        max_time = max(execution_times)
        min_time = min(execution_times)
        
        # Assert performance meets requirements
        self.assertLess(avg_time, 0.5, f"Average concurrent operations time ({avg_time:.4f}s) exceeds threshold")
        
        print(f"Concurrent operations performance: Avg={avg_time:.4f}s, Min={min_time:.4f}s, Max={max_time:.4f}s")

if __name__ == '__main__':
    unittest.main()
