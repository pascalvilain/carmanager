"""
Casino Management System - Integration Tests for Player Tracking Module
This module provides integration tests for the player tracking module.
"""

import unittest
import asyncio
import sys
import os
import datetime
from unittest.mock import MagicMock, patch

# Add parent directory to path to import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from modules.player_tracking.module import PlayerTrackingModule
from modules.player_tracking.models.player import PlayerProfile
from modules.player_tracking.models.gaming_session import TableGameSession, SlotMachineSession
from modules.player_tracking.models.financial import FinancialTransaction
from modules.player_tracking.models.consumption import ConsumptionRecord

class TestPlayerTrackingIntegration(unittest.TestCase):
    """Integration tests for the Player Tracking Module."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Mock database and dependencies
        self.db_mock = MagicMock()
        self.event_bus_mock = MagicMock()
        self.storage_mock = MagicMock()
        self.ai_service_mock = MagicMock()
        
        # Create module instance with mocked dependencies
        self.module = PlayerTrackingModule()
        self.module.db = self.db_mock
        self.module.event_bus = self.event_bus_mock
        self.module.storage = self.storage_mock
        
        # Mock repositories
        self.module.player_repository = MagicMock()
        self.module.gaming_session_repository = MagicMock()
        self.module.financial_repository = MagicMock()
        self.module.consumption_repository = MagicMock()
        self.module.dashboard_repository = MagicMock()
        
        # Mock AI service
        self.module.ai_service = self.ai_service_mock
        
        # Sample player data
        self.sample_player = PlayerProfile(
            id="P12345",
            casino_guest_id="CG-12345",
            first_name="John",
            last_name="Doe",
            email="john.doe@example.com",
            phone="555-123-4567",
            date_of_birth=datetime.date(1980, 1, 15),
            gender="MALE",
            address="123 Main St, Anytown, USA",
            vip_status=True,
            registration_date=datetime.date(2023, 1, 1),
            last_visit_date=datetime.date(2023, 3, 15),
            notes="High roller, prefers blackjack",
            id_photo_url="https://storage.example.com/photos/12345-id.jpg"
        )
        
        # Sample table game session
        self.sample_table_session = TableGameSession(
            id="T12345",
            player_id="P12345",
            session_type="TABLE_GAME",
            start_time=datetime.datetime(2023, 3, 15, 18, 30, 0),
            end_time=datetime.datetime(2023, 3, 15, 21, 45, 0),
            duration_minutes=195,
            game_type="Blackjack",
            table_number="BJ-05",
            dealer_id="D789",
            avg_bet=100.0,
            buy_in=1000.0,
            cash_out=1250.0,
            win_loss=250.0,
            notes="Player was on a winning streak"
        )
        
        # Sample financial transaction
        self.sample_transaction = FinancialTransaction(
            id="F12345",
            player_id="P12345",
            transaction_type="BUY_IN",
            amount=1000.0,
            payment_method="CASH",
            timestamp=datetime.datetime(2023, 3, 15, 18, 30, 0),
            session_id="T12345",
            notes="Initial buy-in"
        )
        
        # Sample consumption record
        self.sample_consumption = ConsumptionRecord(
            id="C12345",
            player_id="P12345",
            session_id="T12345",
            item_type="DRINK",
            item_name="Whiskey",
            quantity=2,
            price=30.0,
            timestamp=datetime.datetime(2023, 3, 15, 19, 30, 0)
        )
    
    async def test_player_registration_workflow(self):
        """Test the complete player registration workflow."""
        # Setup
        self.module.player_repository.create_player.return_value = "P12345"
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        
        # Execute - Register player
        player_id = await self.module.register_player(self.sample_player)
        
        # Assert
        self.assertEqual(player_id, "P12345")
        self.module.player_repository.create_player.assert_called_once()
        self.event_bus_mock.publish.assert_called_once()
    
    async def test_gaming_session_workflow(self):
        """Test the complete gaming session workflow."""
        # Setup
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        self.module.gaming_session_repository.create_session.return_value = "T12345"
        self.module.gaming_session_repository.get_session_by_id.return_value = self.sample_table_session
        self.module.gaming_session_repository.update_session.return_value = True
        self.module.gaming_session_repository.end_session.return_value = True
        
        # Execute - Start session
        session_id = await self.module.start_gaming_session(self.sample_table_session)
        
        # Assert
        self.assertEqual(session_id, "T12345")
        self.module.gaming_session_repository.create_session.assert_called_once()
        self.event_bus_mock.publish.assert_called_once()
        
        # Reset mocks
        self.event_bus_mock.publish.reset_mock()
        
        # Execute - End session
        end_time = datetime.datetime(2023, 3, 15, 21, 45, 0)
        result = await self.module.end_gaming_session(session_id, end_time, 1250.0)
        
        # Assert
        self.assertTrue(result)
        self.module.gaming_session_repository.end_session.assert_called_once_with(
            session_id, end_time, 1250.0
        )
        self.event_bus_mock.publish.assert_called_once()
    
    async def test_financial_transaction_workflow(self):
        """Test the financial transaction workflow."""
        # Setup
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        self.module.gaming_session_repository.get_session_by_id.return_value = self.sample_table_session
        self.module.financial_repository.create_transaction.return_value = "F12345"
        
        # Execute
        transaction_id = await self.module.record_financial_transaction(self.sample_transaction)
        
        # Assert
        self.assertEqual(transaction_id, "F12345")
        self.module.financial_repository.create_transaction.assert_called_once()
        self.event_bus_mock.publish.assert_called_once()
    
    async def test_consumption_record_workflow(self):
        """Test the consumption record workflow."""
        # Setup
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        self.module.gaming_session_repository.get_session_by_id.return_value = self.sample_table_session
        self.module.consumption_repository.create_consumption_record.return_value = "C12345"
        
        # Execute
        record_id = await self.module.record_consumption(self.sample_consumption)
        
        # Assert
        self.assertEqual(record_id, "C12345")
        self.module.consumption_repository.create_consumption_record.assert_called_once()
        self.event_bus_mock.publish.assert_called_once()
    
    async def test_player_search_workflow(self):
        """Test the player search workflow."""
        # Setup
        self.module.player_repository.search_players.return_value = [self.sample_player]
        
        # Execute
        results = await self.module.search_players("John", "name")
        
        # Assert
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, "P12345")
        self.module.player_repository.search_players.assert_called_once_with("John", "name")
    
    async def test_player_analytics_workflow(self):
        """Test the player analytics workflow with AI integration."""
        # Setup
        self.module.player_repository.get_player_with_features.return_value = {
            "id": "P12345",
            "avg_bet": 100.0,
            "total_hours": 75.5
        }
        
        self.ai_service_mock.get_player_segment.return_value = {
            "status": "success",
            "player_id": "P12345",
            "segment": 2,
            "confidence": 0.85
        }
        
        self.ai_service_mock.detect_unusual_behavior.return_value = {
            "status": "success",
            "player_id": "P12345",
            "is_unusual": False,
            "anomaly_score": -0.2
        }
        
        self.ai_service_mock.predict_player_behavior.return_value = {
            "status": "success",
            "player_id": "P12345",
            "prediction_target": "next_visit_date",
            "prediction": "2023-04-01",
            "confidence": 0.9
        }
        
        # Execute - Get player segment
        segment_result = await self.module.get_player_segment("P12345")
        
        # Assert
        self.assertEqual(segment_result["segment"], 2)
        self.ai_service_mock.get_player_segment.assert_called_once()
        
        # Execute - Detect unusual behavior
        anomaly_result = await self.module.detect_unusual_behavior("P12345")
        
        # Assert
        self.assertFalse(anomaly_result["is_unusual"])
        self.ai_service_mock.detect_unusual_behavior.assert_called_once()
        
        # Execute - Predict behavior
        prediction_result = await self.module.predict_player_behavior("P12345", "next_visit_date")
        
        # Assert
        self.assertEqual(prediction_result["prediction_target"], "next_visit_date")
        self.assertEqual(prediction_result["confidence"], 0.9)
        self.ai_service_mock.predict_player_behavior.assert_called_once()
    
    async def test_dashboard_generation_workflow(self):
        """Test the dashboard generation workflow."""
        # Setup
        dashboard_data = {
            "player_id": "P12345",
            "total_visits": 25,
            "total_hours": 75.5,
            "total_spend": 2500.0,
            "win_loss": 250.0,
            "charts": {
                "visits_by_day": [{"day": "Monday", "count": 5}],
                "win_loss_trend": [{"date": "2023-03-01", "amount": 100.0}]
            }
        }
        
        self.module.dashboard_repository.generate_player_dashboard.return_value = dashboard_data
        
        # Execute
        result = await self.module.generate_player_dashboard("P12345")
        
        # Assert
        self.assertEqual(result["player_id"], "P12345")
        self.assertEqual(result["total_visits"], 25)
        self.module.dashboard_repository.generate_player_dashboard.assert_called_once_with("P12345")

if __name__ == '__main__':
    unittest.main()
