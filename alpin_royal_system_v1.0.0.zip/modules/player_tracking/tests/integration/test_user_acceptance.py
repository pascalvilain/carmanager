"""
Casino Management System - User Acceptance Testing
This module provides user acceptance testing for the player tracking module.
"""

import unittest
import asyncio
import sys
import os
import datetime
import logging
from unittest.mock import MagicMock, patch

# Add parent directory to path to import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from modules.player_tracking.module import PlayerTrackingModule

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TestUserAcceptance(unittest.TestCase):
    """Test suite for user acceptance testing of the player tracking module."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create module instance
        self.module = PlayerTrackingModule()
        
        # Mock repositories and services
        self.module.player_repository = MagicMock()
        self.module.gaming_session_repository = MagicMock()
        self.module.financial_repository = MagicMock()
        self.module.consumption_repository = MagicMock()
        self.module.dashboard_repository = MagicMock()
        self.module.ai_service = MagicMock()
        
        # Create test data
        self.create_test_data()
    
    def create_test_data(self):
        """Create test data for user acceptance testing."""
        # Sample player data
        self.sample_player = {
            "id": "P12345",
            "casino_guest_id": "CG-12345",
            "first_name": "John",
            "last_name": "Doe",
            "email": "john.doe@example.com",
            "phone": "555-123-4567",
            "date_of_birth": "1980-01-15",
            "gender": "MALE",
            "address": "123 Main St, Anytown, USA",
            "vip_status": True,
            "registration_date": "2023-01-01",
            "last_visit_date": "2023-03-15",
            "notes": "High roller, prefers blackjack",
            "id_photo_url": "https://storage.example.com/photos/12345-id.jpg"
        }
        
        # Sample table game session
        self.sample_table_session = {
            "id": "T12345",
            "player_id": "P12345",
            "session_type": "TABLE_GAME",
            "start_time": "2023-03-15T18:30:00",
            "end_time": "2023-03-15T21:45:00",
            "duration_minutes": 195,
            "game_type": "Blackjack",
            "table_number": "BJ-05",
            "dealer_id": "D789",
            "avg_bet": 100.0,
            "buy_in": 1000.0,
            "cash_out": 1250.0,
            "win_loss": 250.0,
            "notes": "Player was on a winning streak"
        }
        
        # Sample slot machine session
        self.sample_slot_session = {
            "id": "S12345",
            "player_id": "P12345",
            "session_type": "SLOT_MACHINE",
            "start_time": "2023-03-16T14:00:00",
            "end_time": "2023-03-16T16:30:00",
            "duration_minutes": 150,
            "game_type": "Slot Machine",
            "machine_number": "SM-123",
            "machine_name": "Lucky 7s",
            "avg_bet": 5.0,
            "ticket_in": 200.0,
            "ticket_out": 175.0,
            "win_loss": -25.0,
            "jackpots": 0,
            "hand_pays": 0,
            "notes": "Player tried multiple machines"
        }
        
        # Sample financial transaction
        self.sample_transaction = {
            "id": "F12345",
            "player_id": "P12345",
            "transaction_type": "BUY_IN",
            "amount": 1000.0,
            "payment_method": "CASH",
            "timestamp": "2023-03-15T18:30:00",
            "session_id": "T12345",
            "notes": "Initial buy-in"
        }
        
        # Sample consumption record
        self.sample_consumption = {
            "id": "C12345",
            "player_id": "P12345",
            "session_id": "T12345",
            "item_type": "DRINK",
            "item_name": "Whiskey",
            "quantity": 2,
            "price": 30.0,
            "timestamp": "2023-03-15T19:30:00"
        }
        
        # Sample cigarette consumption
        self.sample_cigarette = {
            "id": "C54321",
            "player_id": "P12345",
            "session_id": "T12345",
            "item_type": "CIGARETTE",
            "item_name": "Marlboro",
            "quantity": 1,
            "price": 10.0,
            "timestamp": "2023-03-15T20:00:00"
        }
        
        # Sample dashboard data
        self.sample_dashboard = {
            "player_id": "P12345",
            "total_visits": 25,
            "total_hours": 75.5,
            "total_spend": 2500.0,
            "win_loss": 250.0,
            "charts": {
                "visits_by_day": [{"day": "Monday", "count": 5}],
                "win_loss_trend": [{"date": "2023-03-01", "amount": 100.0}],
                "game_preference": [{"game": "Blackjack", "hours": 20.5}],
                "consumption_breakdown": [{"item": "Whiskey", "amount": 150.0}]
            }
        }
        
        # Sample AI insights
        self.sample_ai_insights = {
            "player_id": "P12345",
            "segment": {
                "id": 2,
                "name": "High Roller",
                "description": "Players with high average bets and frequent visits",
                "confidence": 0.85
            },
            "predictions": {
                "next_visit_date": "2023-04-01",
                "expected_bet_amount": 120.0,
                "expected_session_length": 180,
                "game_preference": "Blackjack",
                "churn_risk": 0.15
            },
            "recommendations": [
                {"offer_id": "O00001", "offer_name": "Free Drink", "score": 0.95},
                {"offer_id": "O00005", "offer_name": "Dinner Comp", "score": 0.85},
                {"offer_id": "O00010", "offer_name": "Room Upgrade", "score": 0.75}
            ],
            "unusual_behavior": {
                "is_unusual": False,
                "anomaly_score": -0.2,
                "explanation": "Player behavior is within normal patterns"
            }
        }
    
    async def test_uat_player_registration(self):
        """UAT scenario: Casino staff registers a new player."""
        # Setup mock
        self.module.player_repository.create_player.return_value = "P12345"
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        
        # Execute - Register player
        player_id = await self.module.register_player(self.sample_player)
        
        # Verify
        self.assertEqual(player_id, "P12345")
        self.module.player_repository.create_player.assert_called_once()
        
        # Retrieve player to verify
        player = await self.module.get_player_by_id(player_id)
        self.assertEqual(player["first_name"], "John")
        self.assertEqual(player["last_name"], "Doe")
        self.assertTrue(player["vip_status"])
        
        logger.info("UAT: Player registration scenario passed")
    
    async def test_uat_table_game_tracking(self):
        """UAT scenario: Pit boss records a table game session."""
        # Setup mocks
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        self.module.gaming_session_repository.create_session.return_value = "T12345"
        self.module.gaming_session_repository.get_session_by_id.return_value = self.sample_table_session
        self.module.gaming_session_repository.update_session.return_value = True
        self.module.gaming_session_repository.end_session.return_value = True
        
        # Execute - Start session
        session_id = await self.module.start_gaming_session(self.sample_table_session)
        
        # Verify
        self.assertEqual(session_id, "T12345")
        self.module.gaming_session_repository.create_session.assert_called_once()
        
        # Execute - Update session
        updated_session = dict(self.sample_table_session)
        updated_session["avg_bet"] = 150.0
        result = await self.module.update_gaming_session(session_id, updated_session)
        
        # Verify
        self.assertTrue(result)
        self.module.gaming_session_repository.update_session.assert_called_once()
        
        # Execute - End session
        end_time = datetime.datetime.fromisoformat("2023-03-15T21:45:00")
        result = await self.module.end_gaming_session(session_id, end_time, 1250.0)
        
        # Verify
        self.assertTrue(result)
        self.module.gaming_session_repository.end_session.assert_called_once()
        
        logger.info("UAT: Table game tracking scenario passed")
    
    async def test_uat_slot_machine_tracking(self):
        """UAT scenario: Slot attendant records a slot machine session."""
        # Setup mocks
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        self.module.gaming_session_repository.create_session.return_value = "S12345"
        self.module.gaming_session_repository.get_session_by_id.return_value = self.sample_slot_session
        self.module.gaming_session_repository.end_session.return_value = True
        
        # Execute - Start session
        session_id = await self.module.start_gaming_session(self.sample_slot_session)
        
        # Verify
        self.assertEqual(session_id, "S12345")
        self.module.gaming_session_repository.create_session.assert_called_once()
        
        # Execute - End session
        end_time = datetime.datetime.fromisoformat("2023-03-16T16:30:00")
        result = await self.module.end_gaming_session(session_id, end_time, 175.0)
        
        # Verify
        self.assertTrue(result)
        self.module.gaming_session_repository.end_session.assert_called_once()
        
        logger.info("UAT: Slot machine tracking scenario passed")
    
    async def test_uat_financial_transaction(self):
        """UAT scenario: Cashier records financial transactions."""
        # Setup mocks
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        self.module.financial_repository.create_transaction.return_value = "F12345"
        self.module.financial_repository.get_transaction_by_id.return_value = self.sample_transaction
        
        # Execute - Record buy-in
        transaction_id = await self.module.record_financial_transaction(self.sample_transaction)
        
        # Verify
        self.assertEqual(transaction_id, "F12345")
        self.module.financial_repository.create_transaction.assert_called_once()
        
        # Execute - Get transaction
        transaction = await self.module.get_financial_transaction(transaction_id)
        
        # Verify
        self.assertEqual(transaction["transaction_type"], "BUY_IN")
        self.assertEqual(transaction["amount"], 1000.0)
        
        logger.info("UAT: Financial transaction scenario passed")
    
    async def test_uat_consumption_tracking(self):
        """UAT scenario: Server records player consumption."""
        # Setup mocks
        self.module.player_repository.get_player_by_id.return_value = self.sample_player
        self.module.consumption_repository.create_consumption_record.side_effect = ["C12345", "C54321"]
        self.module.consumption_repository.get_consumption_record_by_id.side_effect = [
            self.sample_consumption, self.sample_cigarette
        ]
        
        # Execute - Record drink
        consumption_id = await self.module.record_consumption(self.sample_consumption)
        
        # Verify
        self.assertEqual(consumption_id, "C12345")
        
        # Execute - Record cigarette
        cigarette_id = await self.module.record_consumption(self.sample_cigarette)
        
        # Verify
        self.assertEqual(cigarette_id, "C54321")
        
        # Execute - Get consumption records
        self.module.consumption_repository.get_consumption_records_by_player_id.return_value = [
            self.sample_consumption, self.sample_cigarette
        ]
        
        records = await self.module.get_player_consumption_records("P12345")
        
        # Verify
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0]["item_type"], "DRINK")
        self.assertEqual(records[1]["item_type"], "CIGARETTE")
        
        logger.info("UAT: Consumption tracking scenario passed")
    
    async def test_uat_cigarette_inventory(self):
        """UAT scenario: Managing cigarette inventory."""
        # Setup mocks
        self.module.consumption_repository.get_cigarette_inventory.return_value = [
            {"brand": "Marlboro", "quantity": 10},
            {"brand": "Camel", "quantity": 8},
            {"brand": "Lucky Strike", "quantity": 5}
        ]
        self.module.consumption_repository.update_cigarette_inventory.return_value = True
        
        # Execute - Get inventory
        inventory = await self.module.get_cigarette_inventory()
        
        # Verify
        self.assertEqual(len(inventory), 3)
        self.assertEqual(inventory[0]["brand"], "Marlboro")
        self.assertEqual(inventory[0]["quantity"], 10)
        
        # Execute - Update inventory
        updated_inventory = [
            {"brand": "Marlboro", "quantity": 9},  # Reduced by 1
            {"brand": "Camel", "quantity": 8},
            {"brand": "Lucky Strike", "quantity": 5}
        ]
        result = await self.module.update_cigarette_inventory(updated_inventory)
        
        # Verify
        self.assertTrue(result)
        self.module.consumption_repository.update_cigarette_inventory.assert_called_once_with(updated_inventory)
        
        logger.info("UAT: Cigarette inventory management scenario passed")
    
    async def test_uat_dashboard_generation(self):
        """UAT scenario: Manager views player dashboard."""
        # Setup mocks
        self.module.dashboard_repository.generate_player_dashboard.return_value = self.sample_dashboard
        
        # Execute - Generate dashboard
        dashboard = await self.module.generate_player_dashboard("P12345")
        
        # Verify
        self.assertEqual(dashboard["player_id"], "P12345")
        self.assertEqual(dashboard["total_visits"], 25)
        self.assertEqual(dashboard["total_hours"], 75.5)
        self.assertIn("charts", dashboard)
        self.assertIn("visits_by_day", dashboard["charts"])
        self.assertIn("win_loss_trend", dashboard["charts"])
        self.assertIn("game_preference", dashboard["charts"])
        self.assertIn("consumption_breakdown", dashboard["charts"])
        
        logger.info("UAT: Dashboard generation scenario passed")
    
    async def test_uat_report_generation(self):
        """UAT scenario: Manager generates player reports."""
        # Setup mocks
        self.module.report_service = MagicMock()
        self.module.report_service.generate_player_report.return_value = "/tmp/player_report_P12345.pdf"
        
        # Execute - Generate report
        report_path = await self.module.generate_player_report("P12345", "activity")
        
        # Verify
        self.assertEqual(report_path, "/tmp/player_report_P12345.pdf")
        self.module.report_service.generate_player_report.assert_called_once_with("P12345", "activity")
        
        logger.info("UAT: Report generation scenario passed")
    
    async def test_uat_player_search(self):
        """UAT scenario: Staff searches for players."""
        # Setup mocks
        self.module.player_repository.search_players.return_value = [self.sample_player]
        
        # Execute - Basic search
        results = await self.module.search_players("John", "name")
        
        # Verify
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["first_name"], "John")
        
        # Setup NLP search mock
        self.module.nlp_search = MagicMock()
        self.module.nlp_search.<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>