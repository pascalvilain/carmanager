"""
Casino Management System - Gaming Session Repository Unit Tests
This module provides unit tests for the gaming session repository.
"""

import unittest
import asyncio
from unittest.mock import MagicMock, patch
import sys
import os
import datetime

# Add parent directory to path to import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from modules.player_tracking.repositories.gaming_session_repository import GamingSessionRepository
from modules.player_tracking.models.gaming_session import GamingSession, TableGameSession, SlotMachineSession

class TestGamingSessionRepository(unittest.TestCase):
    """Test cases for GamingSessionRepository class."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create mock database connection
        self.db_mock = MagicMock()
        self.session_repo = GamingSessionRepository(self.db_mock)
        
        # Sample table game session data
        self.sample_table_session = {
            "id": "T12345",
            "player_id": "P12345",
            "session_type": "TABLE_GAME",
            "start_time": datetime.datetime(2023, 3, 15, 18, 30, 0),
            "end_time": datetime.datetime(2023, 3, 15, 21, 45, 0),
            "duration_minutes": 195,
            "game_type": "Blackjack",
            "table_number": "BJ-05",
            "dealer_id": "D789",
            "avg_bet": 100.0,
            "buy_in": 1000.0,
            "cash_out": 1250.0,
            "win_loss": 250.0,
            "notes": "Player was on a winning streak"
        }
        
        # Sample slot machine session data
        self.sample_slot_session = {
            "id": "S12345",
            "player_id": "P12345",
            "session_type": "SLOT_MACHINE",
            "start_time": datetime.datetime(2023, 3, 16, 14, 0, 0),
            "end_time": datetime.datetime(2023, 3, 16, 16, 30, 0),
            "duration_minutes": 150,
            "game_type": "Slot Machine",
            "machine_number": "SM-123",
            "machine_name": "Lucky 7s",
            "avg_bet": 5.0,
            "ticket_in": 200.0,
            "ticket_out": 175.0,
            "win_loss": -25.0,
            "jackpots": 0,
            "hand_pays": 0,
            "notes": "Player tried multiple machines"
        }
    
    def test_create_table_game_session(self):
        """Test creating a new table game session."""
        # Setup
        session_data = TableGameSession(**self.sample_table_session)
        self.db_mock.gaming_session_collection.insert_one.return_value.inserted_id = "T12345"
        
        # Execute
        result = asyncio.run(self.session_repo.create_session(session_data))
        
        # Assert
        self.assertEqual(result, "T12345")
        self.db_mock.gaming_session_collection.insert_one.assert_called_once()
    
    def test_create_slot_machine_session(self):
        """Test creating a new slot machine session."""
        # Setup
        session_data = SlotMachineSession(**self.sample_slot_session)
        self.db_mock.gaming_session_collection.insert_one.return_value.inserted_id = "S12345"
        
        # Execute
        result = asyncio.run(self.session_repo.create_session(session_data))
        
        # Assert
        self.assertEqual(result, "S12345")
        self.db_mock.gaming_session_collection.insert_one.assert_called_once()
    
    def test_get_session_by_id(self):
        """Test retrieving a session by ID."""
        # Setup
        self.db_mock.gaming_session_collection.find_one.return_value = self.sample_table_session
        
        # Execute
        result = asyncio.run(self.session_repo.get_session_by_id("T12345"))
        
        # Assert
        self.assertIsNotNone(result)
        self.assertEqual(result.id, "T12345")
        self.assertEqual(result.player_id, "P12345")
        self.assertEqual(result.game_type, "Blackjack")
        self.db_mock.gaming_session_collection.find_one.assert_called_once_with({"id": "T12345"})
    
    def test_get_sessions_by_player_id(self):
        """Test retrieving sessions by player ID."""
        # Setup
        self.db_mock.gaming_session_collection.find.return_value.to_list.return_value = [
            self.sample_table_session, self.sample_slot_session
        ]
        
        # Execute
        result = asyncio.run(self.session_repo.get_sessions_by_player_id("P12345"))
        
        # Assert
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0].id, "T12345")
        self.assertEqual(result[1].id, "S12345")
        self.db_mock.gaming_session_collection.find.assert_called_once_with({"player_id": "P12345"})
    
    def test_get_active_sessions(self):
        """Test retrieving active sessions."""
        # Setup
        active_session = self.sample_table_session.copy()
        active_session["end_time"] = None
        self.db_mock.gaming_session_collection.find.return_value.to_list.return_value = [active_session]
        
        # Execute
        result = asyncio.run(self.session_repo.get_active_sessions())
        
        # Assert
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].id, "T12345")
        self.assertIsNone(result[0].end_time)
        self.db_mock.gaming_session_collection.find.assert_called_once()
    
    def test_update_session(self):
        """Test updating a session."""
        # Setup
        session_data = TableGameSession(**self.sample_table_session)
        session_data.avg_bet = 150.0
        self.db_mock.gaming_session_collection.update_one.return_value.modified_count = 1
        
        # Execute
        result = asyncio.run(self.session_repo.update_session("T12345", session_data))
        
        # Assert
        self.assertTrue(result)
        self.db_mock.gaming_session_collection.update_one.assert_called_once()
    
    def test_end_session(self):
        """Test ending a session."""
        # Setup
        end_time = datetime.datetime(2023, 3, 15, 22, 0, 0)
        self.db_mock.gaming_session_collection.find_one.return_value = self.sample_table_session
        self.db_mock.gaming_session_collection.update_one.return_value.modified_count = 1
        
        # Execute
        result = asyncio.run(self.session_repo.end_session("T12345", end_time, 1300.0))
        
        # Assert
        self.assertTrue(result)
        self.db_mock.gaming_session_collection.update_one.assert_called_once()
    
    def test_delete_session(self):
        """Test deleting a session."""
        # Setup
        self.db_mock.gaming_session_collection.delete_one.return_value.deleted_count = 1
        
        # Execute
        result = asyncio.run(self.session_repo.delete_session("T12345"))
        
        # Assert
        self.assertTrue(result)
        self.db_mock.gaming_session_collection.delete_one.assert_called_once_with({"id": "T12345"})
    
    def test_get_sessions_by_date_range(self):
        """Test retrieving sessions by date range."""
        # Setup
        start_date = datetime.datetime(2023, 3, 15)
        end_date = datetime.datetime(2023, 3, 17)
        self.db_mock.gaming_session_collection.find.return_value.to_list.return_value = [
            self.sample_table_session, self.sample_slot_session
        ]
        
        # Execute
        result = asyncio.run(self.session_repo.get_sessions_by_date_range(start_date, end_date))
        
        # Assert
        self.assertEqual(len(result), 2)
        self.db_mock.gaming_session_collection.find.assert_called_once()
    
    def test_get_all_sessions(self):
        """Test retrieving all sessions."""
        # Setup
        self.db_mock.gaming_session_collection.find.return_value.to_list.return_value = [
            self.sample_table_session, self.sample_slot_session
        ]
        
        # Execute
        result = asyncio.run(self.session_repo.get_all_sessions())
        
        # Assert
        self.assertEqual(len(result), 2)
        self.db_mock.gaming_session_collection.find.assert_called_once_with({})

if __name__ == '__main__':
    unittest.main()
