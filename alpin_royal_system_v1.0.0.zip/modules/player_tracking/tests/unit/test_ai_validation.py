"""
Casino Management System - AI Validation Test Suite
This module provides tests to validate AI functionality and accuracy in the player tracking module.
"""

import unittest
import asyncio
import sys
import os
import datetime
import numpy as np
import pandas as pd
from unittest.mock import MagicMock, patch
import json
import logging

# Add parent directory to path to import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from modules.player_tracking.ai.services.ai_service import AIService
from modules.player_tracking.ai.models.player_behavior_model import PlayerBehaviorModel
from modules.player_tracking.ai.models.player_predictive_model import PlayerPredictiveModel
from modules.player_tracking.ai.models.recommendation_engine import RecommendationEngine
from modules.player_tracking.ai.utils.nlp_search import NLPSearchEngine
from modules.player_tracking.ai.utils.performance_optimizer import AIPerformanceOptimizer, RealTimeAIOptimizer

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TestAIValidation(unittest.TestCase):
    """Test suite for validating AI functionality and accuracy."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create AI service and models
        self.ai_service = AIService()
        self.behavior_model = PlayerBehaviorModel()
        self.predictive_model = PlayerPredictiveModel()
        self.recommendation_engine = RecommendationEngine()
        self.nlp_search = NLPSearchEngine()
        self.performance_optimizer = RealTimeAIOptimizer()
        
        # Assign models to service
        self.ai_service.behavior_model = self.behavior_model
        self.ai_service.predictive_model = self.predictive_model
        self.ai_service.recommendation_engine = self.recommendation_engine
        
        # Load test data
        self.load_test_data()
    
    def load_test_data(self):
        """Load test data for AI validation."""
        # Create synthetic player data
        self.player_data = pd.DataFrame([
            {
                "id": f"P{i:05d}",
                "casino_guest_id": f"CG-{i:05d}",
                "first_name": f"Player{i}",
                "last_name": f"Test",
                "email": f"player{i}@example.com",
                "phone": f"555-{i:03d}-{i:04d}"[-12:],
                "date_of_birth": datetime.date(1980, 1, 15).isoformat(),
                "gender": "MALE" if i % 2 == 0 else "FEMALE",
                "vip_status": i % 10 == 0,
                "avg_bet": 50.0 + (i % 10) * 10,
                "total_hours": 50.0 + i,
                "visit_frequency": 2.0 + (i % 5),
                "avg_session_length": 2.0 + (i % 3),
                "table_game_ratio": 0.7 if i % 3 == 0 else 0.3,
                "slot_machine_ratio": 0.3 if i % 3 == 0 else 0.7,
                "win_loss_ratio": 0.8 + (i % 5) * 0.1,
                "jackpot_frequency": 0.01 * (i % 10),
                "consumption_per_hour": 20.0 + i % 30,
                "evening_preference": 0.6 + (i % 5) * 0.1,
                "notes": f"Player {i} likes {'blackjack' if i % 3 == 0 else 'slots' if i % 3 == 1 else 'roulette'} and drinks {'whiskey' if i % 4 == 0 else 'beer' if i % 4 == 1 else 'wine' if i % 4 == 2 else 'water'}"
            } for i in range(100)
        ])
        
        # Create synthetic session data
        self.session_data = pd.DataFrame([
            {
                "id": f"S{i:05d}",
                "player_id": f"P{i % 100:05d}",
                "session_type": "TABLE_GAME" if i % 2 == 0 else "SLOT_MACHINE",
                "start_time": (datetime.datetime(2023, 3, 15, 18, 0, 0) + datetime.timedelta(hours=i % 24)).isoformat(),
                "end_time": (datetime.datetime(2023, 3, 15, 20, 0, 0) + datetime.timedelta(hours=i % 24)).isoformat(),
                "duration_minutes": 120,
                "game_type": "Blackjack" if i % 3 == 0 else "Roulette" if i % 3 == 1 else "Slot Machine",
                "avg_bet": 50.0 + (i % 10) * 10,
                "win_loss": -50.0 + (i % 20) * 10
            } for i in range(500)
        ])
        
        # Create synthetic transaction data
        self.transaction_data = pd.DataFrame([
            {
                "id": f"T{i:05d}",
                "player_id": f"P{i % 100:05d}",
                "transaction_type": "BUY_IN" if i % 3 == 0 else "CASH_OUT" if i % 3 == 1 else "JACKPOT",
                "amount": 500.0 + (i % 10) * 100 if i % 3 == 0 else 450.0 + (i % 10) * 50,
                "timestamp": (datetime.datetime(2023, 3, 15, 18, 0, 0) + datetime.timedelta(hours=i % 24)).isoformat()
            } for i in range(300)
        ])
        
        # Create synthetic consumption data
        self.consumption_data = pd.DataFrame([
            {
                "id": f"C{i:05d}",
                "player_id": f"P{i % 100:05d}",
                "item_type": "DRINK" if i % 3 == 0 else "FOOD" if i % 3 == 1 else "CIGARETTE",
                "item_name": ("Whiskey" if i % 4 == 0 else "Beer" if i % 4 == 1 else "Wine" if i % 4 == 2 else "Water") if i % 3 == 0 else
                            ("Steak" if i % 4 == 0 else "Burger" if i % 4 == 1 else "Salad" if i % 4 == 2 else "Sandwich") if i % 3 == 1 else
                            ("Marlboro" if i % 4 == 0 else "Camel" if i % 4 == 1 else "Lucky Strike" if i % 4 == 2 else "Newport"),
                "quantity": 1 + (i % 3),
                "price": 15.0 + (i % 5) * 5 if i % 3 == 0 else 25.0 + (i % 5) * 10 if i % 3 == 1 else 10.0 + (i % 2) * 5,
                "timestamp": (datetime.datetime(2023, 3, 15, 19, 0, 0) + datetime.timedelta(hours=i % 24)).isoformat()
            } for i in range(400)
        ])
        
        # Create synthetic offer data
        self.offer_data = pd.DataFrame([
            {
                "offer_id": f"O{i:05d}",
                "offer_type": "DRINK_OFFER" if i % 3 == 0 else "FOOD_OFFER" if i % 3 == 1 else "COMP_OFFER",
                "offer_name": f"Free {'Drink' if i % 3 == 0 else 'Meal' if i % 3 == 1 else 'Room Upgrade'}",
                "offer_value": 15.0 + (i % 5) * 5 if i % 3 == 0 else 25.0 + (i % 5) * 10 if i % 3 == 1 else 100.0 + (i % 5) * 50,
                "target_vip_level": i % 10 == 0
            } for i in range(20)
        ])
        
        # Create NLP search test queries
        self.nlp_test_queries = [
            "find player John",
            "search for player with id CG-00010",
            "players who play blackjack",
            "high rollers",
            "players who visited during evening",
            "players who ordered whiskey",
            "find players with bets over 100",
            "who plays slots and drinks beer",
            "vip players who play roulette",
            "players with highest win ratio"
        ]
    
    async def test_behavior_model_clustering(self):
        """Test player behavior clustering functionality and accuracy."""
        # Mock training to avoid actual computation
        with patch.object(self.behavior_model, 'train_clustering_model', return_value=(
            [0, 1, 2, 0, 1] * 20,  # Cluster assignments
            {"0": {"size": 40, "avg_bet": 75.0}, "1": {"size": 40, "avg_bet": 125.0}, "2": {"size": 20, "avg_bet": 150.0}}  # Cluster info
        )):
            # Train the model
            cluster_results = await self.behavior_model.train_clustering_model(self.player_data)
            
            # Validate results
            self.assertIsNotNone(cluster_results)
            clusters, cluster_info = cluster_results
            
            # Check cluster assignments
            self.assertEqual(len(clusters), 100)
            self.assertTrue(all(c in [0, 1, 2] for c in clusters))
            
            # Check cluster information
            self.assertEqual(len(cluster_info), 3)
            self.assertIn("0", cluster_info)
            self.assertIn("size", cluster_info["0"])
            
            # Test prediction for a single player
            player_features = self.player_data.iloc[0].to_dict()
            cluster, confidence = self.behavior_model.predict_cluster(player_features)
            
            # Validate prediction
            self.assertIn(cluster, [0, 1, 2])
            self.assertTrue(0 <= confidence <= 1)
            
            logger.info(f"Behavior model clustering validation passed: {len(clusters)} players assigned to {len(cluster_info)} clusters")
    
    async def test_anomaly_detection(self):
        """Test anomaly detection functionality and accuracy."""
        # Mock training to avoid actual computation
        with patch.object(self.behavior_model, 'train_anomaly_model', return_value=[False, True, False] * 33 + [False]):
            # Train the model
            anomaly_results = await self.behavior_model.train_anomaly_model(self.player_data)
            
            # Validate results
            self.assertIsNotNone(anomaly_results)
            self.assertEqual(len(anomaly_results), 100)
            
            # Count anomalies
            anomaly_count = sum(1 for is_anomaly in anomaly_results if is_anomaly)
            self.assertEqual(anomaly_count, 33)  # Based on our mock
            
            # Test anomaly detection for a single player
            player_features = self.player_data.iloc[0].to_dict()
            is_anomaly, score = self.behavior_model.detect_anomalies(player_features)
            
            # Validate detection
            self.assertIsInstance(is_anomaly, bool)
            self.assertTrue(-1 <= score <= 1)
            
            logger.info(f"Anomaly detection validation passed: {anomaly_count} anomalies detected out of 100 players")
    
    async def test_predictive_model(self):
        """Test predictive model functionality and accuracy."""
        # Mock training to avoid actual computation
        with patch.object(self.predictive_model, 'train_model', return_value={"test_r2": 0.85, "test_mae": 10.5}):
            # Define prediction targets
            targets = ["next_visit_date", "expected_bet_amount", "expected_session_length", "game_preference"]
            
            for target in targets:
                # Train the model for this target
                metrics = await self.predictive_model.train_model(self.player_data, target)
                
                # Validate metrics
                self.assertIsNotNone(metrics)
                self.assertIn("test_r2", metrics)
                self.assertTrue(0 <= metrics["test_r2"] <= 1)
                
                # Mock the model
                self.predictive_model.models[target] = MagicMock()
                
                # Test prediction for a single player
                player_features = self.player_data.iloc[0].to_dict()
                
                # Mock prediction result based on target
                if target == "next_visit_date":
                    prediction_value = datetime.datetime.now() + datetime.timedelta(days=3)
                elif target == "expected_bet_amount":
                    prediction_value = 75.0
                elif target == "expected_session_length":
                    prediction_value = 120
                else:
                    prediction_value = "Blackjack"
                
                self.predictive_model.models[target].predict.return_value = np.array([prediction_value])
                
                # Make prediction
                prediction, confidence = self.predictive_model.predict(player_features, target)
                
                # Validate prediction
                self.assertIsNotNone(prediction)
                self.assertTrue(0 <= confidence <= 1)
            
            logger.info(f"Predictive model validation passed for {len(targets)} prediction targets")
    
    async def test_recommendation_engine(self):
        """Test recommendation engine functionality and accuracy."""
        # Mock training to avoid actual computation
        with patch.object(self.recommendation_engine, 'train_model', return_value={"player_features": (100, 10), "item_features": (20, 5)}):
            # Train the model
            metrics = await self.recommendation_engine.train_model(self.player_data, self.offer_data)
            
            # Validate metrics
            self.assertIsNotNone(metrics)
            self.assertIn("player_features", metrics)
            self.assertIn("item_features", metrics)
            
            # Mock get_personalized_offers
            self.recommendation_engine.get_personalized_offers = MagicMock(return_value=[
                {"offer_id": "O00001", "score": 0.95},
                {"offer_id": "O00005", "score": 0.85},
                {"offer_id": "O00010", "score": 0.75}
            ])
            
            # Test recommendations for a single player
            player_id = "P00001"
            recommendations = self.recommendation_engine.get_personalized_offers(player_id, self.offer_data, 3)
            
            # Validate recommendations
            self.assertIsNotNone(recommendations)
            self.assertEqual(len(recommendations), 3)
            self.assertIn("offer_id", recommendations[0])
            self.assertIn("score", recommendations[0])
            self.assertTrue(0 <= recommendations[0]["score"] <= 1)
            
            # Check that recommendations are sorted by score
            self.assertTrue(recommendations[0]["score"] >= recommendations[1]["score"])
            self.assertTrue(recommendations[1]["score"] >= recommendations[2]["score"])
            
            logger.info(f"Recommendation engine validation passed with {len(recommendations)} recommendations generated")
    
    async def test_nlp_search(self):
        """Test NLP search functionality and accuracy."""
        # Process each test query
        for query in self.nlp_test_queries:
            # Convert player data to list of dicts
            player_list = self.player_data.to_dict('records')
            
            # Process the query
            result = await self.nlp_search.process_search_query(query, player_list)
            
            # Validate result structure
            self.assertIsNotNone(result)
            self.assertIn("intent", result)
            self.assertIn("parameters", result)
            self.assertIn("results", result)
            self.assertIn("result_count", result)
            
            # Check that we got some results
            self.assertTrue(len(result["results"]) > 0)
            
            # Check that results have relevance scores
            self.assertIn("relevance_score", result["results"][0])
            self.assertTrue(0 <= result["results"][0]["relevance_score"] <= 1)
            
            # Check that results are sorted by relevance
            if len(result["results"]) > 1:
                self.assertTrue(result["results"][0]["relevance_score"] >= result["results"][1]["relevance_score"])
            
            logger.info(f"NLP search validation passed for query: '{query}' with {len(result['results'])} results")
        
        # Test query suggestions
        partial_query = "find player who"
        suggestions = await self.nlp_search.get_query_suggestions(partial_query)
        
        # Validate suggestions
        self.assertIsNotNone(suggestions)
        self.assertTrue(len(suggestions) > 0)
        
        logger.info(f"NLP query suggestions validation passed with {len(suggestions)} suggestions generated")
    
    async def test_performance_optimization(self):
        """Test AI performance optimization functionality."""
        # Create a simple test model
        class TestModel:
            def predict(self, features):
                return np.array([1.0] * len(features))
        
        test_model = TestModel()
        
        # Optimize the model
        optimized_model = await self.performance_optimizer.optimize_for_real_time({"tes<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>