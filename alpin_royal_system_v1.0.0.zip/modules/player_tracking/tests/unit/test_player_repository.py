"""
Casino Management System - Player Repository Unit Tests
This module provides unit tests for the player repository.
"""

import unittest
import asyncio
from unittest.mock import MagicMock, patch
import sys
import os
import datetime

# Add parent directory to path to import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from modules.player_tracking.repositories.player_repository import PlayerRepository
from modules.player_tracking.models.player import Player, PlayerProfile

class TestPlayerRepository(unittest.TestCase):
    """Test cases for PlayerRepository class."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Create mock database connection
        self.db_mock = MagicMock()
        self.player_repo = PlayerRepository(self.db_mock)
        
        # Sample player data
        self.sample_player = {
            "id": "12345",
            "casino_guest_id": "CG-12345",
            "first_name": "John",
            "last_name": "Doe",
            "email": "john.doe@example.com",
            "phone": "555-123-4567",
            "date_of_birth": datetime.date(1980, 1, 15),
            "gender": "MALE",
            "address": "123 Main St, Anytown, USA",
            "vip_status": True,
            "registration_date": datetime.date(2023, 1, 1),
            "last_visit_date": datetime.date(2023, 3, 15),
            "notes": "High roller, prefers blackjack",
            "id_photo_url": "https://storage.example.com/photos/12345-id.jpg",
            "avg_bet": 100.0,
            "total_visits": 25,
            "total_hours": 75.5,
            "visit_frequency": 2.5,
            "avg_session_length": 3.0,
            "table_game_ratio": 0.8,
            "slot_machine_ratio": 0.2,
            "win_loss_ratio": 1.2,
            "jackpot_frequency": 0.05,
            "consumption_per_hour": 25.0,
            "evening_preference": 0.7
        }
    
    def test_create_player(self):
        """Test creating a new player."""
        # Setup
        player_data = PlayerProfile(**self.sample_player)
        self.db_mock.player_collection.insert_one.return_value.inserted_id = "12345"
        
        # Execute
        result = asyncio.run(self.player_repo.create_player(player_data))
        
        # Assert
        self.assertEqual(result, "12345")
        self.db_mock.player_collection.insert_one.assert_called_once()
    
    def test_get_player_by_id(self):
        """Test retrieving a player by ID."""
        # Setup
        self.db_mock.player_collection.find_one.return_value = self.sample_player
        
        # Execute
        result = asyncio.run(self.player_repo.get_player_by_id("12345"))
        
        # Assert
        self.assertIsNotNone(result)
        self.assertEqual(result.id, "12345")
        self.assertEqual(result.first_name, "John")
        self.assertEqual(result.last_name, "Doe")
        self.db_mock.player_collection.find_one.assert_called_once_with({"id": "12345"})
    
    def test_get_player_by_casino_id(self):
        """Test retrieving a player by casino guest ID."""
        # Setup
        self.db_mock.player_collection.find_one.return_value = self.sample_player
        
        # Execute
        result = asyncio.run(self.player_repo.get_player_by_casino_id("CG-12345"))
        
        # Assert
        self.assertIsNotNone(result)
        self.assertEqual(result.casino_guest_id, "CG-12345")
        self.db_mock.player_collection.find_one.assert_called_once_with({"casino_guest_id": "CG-12345"})
    
    def test_update_player(self):
        """Test updating a player."""
        # Setup
        player_data = PlayerProfile(**self.sample_player)
        player_data.first_name = "Jane"
        self.db_mock.player_collection.update_one.return_value.modified_count = 1
        
        # Execute
        result = asyncio.run(self.player_repo.update_player("12345", player_data))
        
        # Assert
        self.assertTrue(result)
        self.db_mock.player_collection.update_one.assert_called_once()
    
    def test_delete_player(self):
        """Test deleting a player."""
        # Setup
        self.db_mock.player_collection.delete_one.return_value.deleted_count = 1
        
        # Execute
        result = asyncio.run(self.player_repo.delete_player("12345"))
        
        # Assert
        self.assertTrue(result)
        self.db_mock.player_collection.delete_one.assert_called_once_with({"id": "12345"})
    
    def test_search_players(self):
        """Test searching for players."""
        # Setup
        self.db_mock.player_collection.find.return_value.to_list.return_value = [self.sample_player]
        
        # Execute
        result = asyncio.run(self.player_repo.search_players("John", "name"))
        
        # Assert
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].first_name, "John")
        self.db_mock.player_collection.find.assert_called_once()
    
    def test_get_all_players(self):
        """Test retrieving all players."""
        # Setup
        self.db_mock.player_collection.find.return_value.to_list.return_value = [self.sample_player]
        
        # Execute
        result = asyncio.run(self.player_repo.get_all_players())
        
        # Assert
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].first_name, "John")
        self.db_mock.player_collection.find.assert_called_once_with({})
    
    def test_get_player_with_features(self):
        """Test retrieving a player with features for AI processing."""
        # Setup
        self.db_mock.player_collection.find_one.return_value = self.sample_player
        
        # Execute
        result = asyncio.run(self.player_repo.get_player_with_features("12345"))
        
        # Assert
        self.assertIsNotNone(result)
        self.assertEqual(result["id"], "12345")
        self.assertEqual(result["avg_bet"], 100.0)
        self.assertEqual(result["total_hours"], 75.5)
        self.db_mock.player_collection.find_one.assert_called_once_with({"id": "12345"})
    
    def test_get_all_players_with_features(self):
        """Test retrieving all players with features for AI processing."""
        # Setup
        self.db_mock.player_collection.find.return_value.to_list.return_value = [self.sample_player]
        
        # Execute
        result = asyncio.run(self.player_repo.get_all_players_with_features())
        
        # Assert
        self.assertEqual(len(result), 1)
        self.assertEqual(result.iloc[0]["id"], "12345")
        self.assertEqual(result.iloc[0]["avg_bet"], 100.0)
        self.db_mock.player_collection.find.assert_called_once_with({})

if __name__ == '__main__':
    unittest.main()
