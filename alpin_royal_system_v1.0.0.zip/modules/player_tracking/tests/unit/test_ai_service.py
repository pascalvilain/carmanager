"""
Casino Management System - AI Service Unit Tests
This module provides unit tests for the AI service.
"""

import unittest
import asyncio
from unittest.mock import MagicMock, patch
import sys
import os
import datetime
import pandas as pd
import numpy as np

# Add parent directory to path to import modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../..')))

from modules.player_tracking.ai.services.ai_service import AIService

class TestAIService(unittest.TestCase):
    """Test cases for AIService class."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Mock the AI models
        self.behavior_model_mock = MagicMock()
        self.predictive_model_mock = MagicMock()
        self.recommendation_engine_mock = MagicMock()
        
        # Create AI service with mocked models
        self.ai_service = AIService()
        self.ai_service.behavior_model = self.behavior_model_mock
        self.ai_service.predictive_model = self.predictive_model_mock
        self.ai_service.recommendation_engine = self.recommendation_engine_mock
        
        # Sample player data
        self.sample_player_data = pd.DataFrame([{
            "id": "P12345",
            "casino_guest_id": "CG-12345",
            "first_name": "John",
            "last_name": "Doe",
            "email": "john.doe@example.com",
            "phone": "555-123-4567",
            "date_of_birth": datetime.date(1980, 1, 15),
            "gender": "MALE",
            "vip_status": True,
            "avg_bet": 100.0,
            "total_hours": 75.5,
            "visit_frequency": 2.5,
            "avg_session_length": 3.0,
            "table_game_ratio": 0.8,
            "slot_machine_ratio": 0.2,
            "win_loss_ratio": 1.2,
            "jackpot_frequency": 0.05,
            "consumption_per_hour": 25.0,
            "evening_preference": 0.7
        }])
        
        # Sample session data
        self.sample_session_data = pd.DataFrame([{
            "id": "S12345",
            "player_id": "P12345",
            "session_type": "TABLE_GAME",
            "start_time": datetime.datetime(2023, 3, 15, 18, 30, 0),
            "end_time": datetime.datetime(2023, 3, 15, 21, 45, 0),
            "duration_minutes": 195,
            "game_type": "Blackjack",
            "avg_bet": 100.0,
            "win_loss": 250.0
        }])
        
        # Sample transaction data
        self.sample_transaction_data = pd.DataFrame([{
            "id": "T12345",
            "player_id": "P12345",
            "transaction_type": "BUY_IN",
            "amount": 1000.0,
            "timestamp": datetime.datetime(2023, 3, 15, 18, 30, 0)
        }, {
            "id": "T12346",
            "player_id": "P12345",
            "transaction_type": "CASH_OUT",
            "amount": 1250.0,
            "timestamp": datetime.datetime(2023, 3, 15, 21, 45, 0)
        }])
        
        # Sample consumption data
        self.sample_consumption_data = pd.DataFrame([{
            "id": "C12345",
            "player_id": "P12345",
            "item_type": "DRINK",
            "item_name": "Whiskey",
            "quantity": 2,
            "price": 30.0,
            "timestamp": datetime.datetime(2023, 3, 15, 19, 30, 0)
        }])
        
        # Sample offer data
        self.sample_offer_data = pd.DataFrame([{
            "offer_id": "O12345",
            "offer_type": "DRINK_OFFER",
            "offer_name": "Free Drink",
            "offer_value": 15.0,
            "target_vip_level": True
        }])
    
    @patch('modules.player_tracking.ai.services.ai_service.os.path.exists')
    @patch('modules.player_tracking.ai.services.ai_service.joblib.dump')
    async def test_train_models(self, mock_dump, mock_exists):
        """Test training AI models."""
        # Setup
        mock_exists.return_value = False
        self.behavior_model_mock.train_clustering_model.return_value = (
            [0, 1, 0], {"0": {"size": 2}, "1": {"size": 1}}
        )
        self.behavior_model_mock.train_anomaly_model.return_value = [False, False, True]
        
        self.predictive_model_mock.prediction_targets = {
            "next_visit_date": "regression",
            "expected_bet_amount": "regression"
        }
        self.predictive_model_mock.train_model.return_value = {"test_r2": 0.85}
        
        self.recommendation_engine_mock.train_model.return_value = {
            "player_features": (1, 10),
            "item_features": (1, 5)
        }
        
        # Execute
        result = await self.ai_service.train_models(
            self.sample_player_data,
            self.sample_session_data,
            self.sample_transaction_data,
            self.sample_consumption_data,
            self.sample_offer_data
        )
        
        # Assert
        self.assertIn('behavior_model', result)
        self.assertIn('predictive_model', result)
        self.assertIn('recommendation_engine', result)
        self.behavior_model_mock.train_clustering_model.assert_called_once()
        self.behavior_model_mock.train_anomaly_model.assert_called_once()
        self.behavior_model_mock.save_model.assert_called_once()
        self.recommendation_engine_mock.train_model.assert_called_once()
    
    async def test_get_player_segment(self):
        """Test getting player segment."""
        # Setup
        self.behavior_model_mock.predict_cluster.return_value = (2, 0.85)
        
        # Execute
        result = await self.ai_service.get_player_segment("P12345", self.sample_player_data)
        
        # Assert
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["player_id"], "P12345")
        self.assertEqual(result["segment"], 2)
        self.assertEqual(result["confidence"], 0.85)
        self.behavior_model_mock.predict_cluster.assert_called_once()
    
    async def test_detect_unusual_behavior(self):
        """Test detecting unusual behavior."""
        # Setup
        self.behavior_model_mock.detect_anomalies.return_value = (True, -0.75)
        
        # Execute
        result = await self.ai_service.detect_unusual_behavior("P12345", self.sample_player_data)
        
        # Assert
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["player_id"], "P12345")
        self.assertTrue(result["is_unusual"])
        self.assertEqual(result["anomaly_score"], -0.75)
        self.behavior_model_mock.detect_anomalies.assert_called_once()
    
    async def test_predict_player_behavior(self):
        """Test predicting player behavior."""
        # Setup
        self.predictive_model_mock.models = {"next_visit_date": MagicMock()}
        self.predictive_model_mock.predict.return_value = (
            datetime.datetime(2023, 4, 1), 0.9
        )
        
        # Execute
        result = await self.ai_service.predict_player_behavior(
            "P12345", "next_visit_date", self.sample_player_data
        )
        
        # Assert
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["player_id"], "P12345")
        self.assertEqual(result["prediction_target"], "next_visit_date")
        self.assertEqual(result["confidence"], 0.9)
        self.predictive_model_mock.predict.assert_called_once()
    
    async def test_get_personalized_recommendations(self):
        """Test getting personalized recommendations."""
        # Setup
        self.recommendation_engine_mock.get_personalized_offers.return_value = [
            {"offer_id": "O12345", "score": 0.95}
        ]
        
        # Execute
        result = await self.ai_service.get_personalized_recommendations(
            "P12345", self.sample_offer_data, self.sample_player_data
        )
        
        # Assert
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["player_id"], "P12345")
        self.assertEqual(len(result["recommendations"]), 1)
        self.assertEqual(result["recommendations"][0]["offer_id"], "O12345")
        self.recommendation_engine_mock.get_personalized_offers.assert_called_once()
    
    def test_prepare_behavior_features(self):
        """Test preparing behavior features."""
        # Execute
        result = self.ai_service._prepare_behavior_features(
            self.sample_player_data,
            self.sample_session_data,
            self.sample_transaction_data,
            self.sample_consumption_data
        )
        
        # Assert
        self.assertIsInstance(result, pd.DataFrame)
        self.assertEqual(result.shape[0], 1)
        self.assertIn("avg_bet", result.columns)
        self.assertIn("win_loss_ratio", result.columns)
    
    def test_prepare_predictive_features(self):
        """Test preparing predictive features."""
        # Execute
        result = self.ai_service._prepare_predictive_features(
            self.sample_player_data,
            self.sample_session_data,
            self.sample_transaction_data,
            self.sample_consumption_data
        )
        
        # Assert
        self.assertIsInstance(result, pd.DataFrame)
        self.assertEqual(result.shape[0], 1)
        self.assertIn("avg_bet", result.columns)
        self.assertIn("win_loss_ratio", result.columns)

if __name__ == '__main__':
    unittest.main()
