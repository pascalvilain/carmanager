"""
Casino Management System - Player Tracking Module Initialization
This module initializes the player tracking module and registers it with the module system.
"""

import logging
from fastapi import FastAPI

from base_layer.module_system.module_registry import ModuleRegistry
from modules.player_tracking.api.player_tracking_api import router as player_tracking_router

logger = logging.getLogger(__name__)

def init_player_tracking_module(app: FastAPI):
    """
    Initialize the player tracking module.
    
    Args:
        app: The FastAPI application
    """
    try:
        # Register API routes
        app.include_router(player_tracking_router)
        
        # Register module with module registry
        ModuleRegistry.register_module(
            name="player_tracking",
            display_name="Player Tracking",
            description="Track player activities, gaming sessions, financial transactions, and consumption",
            version="1.0.0",
            api_prefix="/player-tracking",
            enabled=True
        )
        
        logger.info("Player tracking module initialized successfully")
    except Exception as e:
        logger.error(f"Error initializing player tracking module: {str(e)}")
        raise
