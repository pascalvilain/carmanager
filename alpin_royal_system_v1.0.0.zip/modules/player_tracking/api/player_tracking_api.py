"""
Casino Management System - Player Tracking API
This module provides API endpoints for player tracking operations.
"""

import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, date
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, Path
from fastapi.responses import JSONResponse, FileResponse

from modules.player_tracking.services.player_tracking_service import PlayerTrackingService
from base_layer.auth.auth_manager import get_current_user

from modules.player_tracking.models.player import (
    Player, PlayerCreate, PlayerUpdate, PlayerSearch,
    PlayerPhoto, PlayerPhotoCreate, PlayerPhotoUpdate
)
from modules.player_tracking.models.gaming_session import (
    GamingSession, GamingSessionCreate, GamingSessionUpdate,
    TableGameActivity, TableGameActivityCreate, TableGameActivityUpdate,
    SlotMachineActivity, SlotMachineActivityCreate, SlotMachineActivityUpdate
)
from modules.player_tracking.models.financial import (
    FinancialTransaction, FinancialTransactionCreate, FinancialTransactionUpdate,
    JackpotHandPay, JackpotHandPayCreate, JackpotHandPayUpdate
)
from modules.player_tracking.models.consumption import (
    ConsumptionItem, ConsumptionItemCreate, ConsumptionItemUpdate,
    PlayerConsumption, PlayerConsumptionCreate, PlayerConsumptionUpdate,
    CigaretteInventory, CigaretteInventoryCreate, CigaretteInventoryUpdate,
    CigaretteInventoryTransaction, CigaretteInventoryTransactionCreate,
    CigaretteInventoryTransactionUpdate, ConsumptionSummary
)
from modules.player_tracking.models.dashboard import (
    Dashboard, DashboardCreate, DashboardUpdate,
    DashboardWidget, DashboardWidgetCreate, DashboardWidgetUpdate,
    ReportTemplate, ReportTemplateCreate, ReportTemplateUpdate,
    Report, ReportCreate, ReportUpdate, PlayerReportData,
    TimeRange
)

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/player-tracking", tags=["player-tracking"])

# Initialize service
player_tracking_service = PlayerTrackingService()

# Player management endpoints

@router.post("/players", response_model=Player, status_code=201)
async def create_player(
    player: PlayerCreate,
    current_user: Dict = Depends(get_current_user)
):
    """Create a new player."""
    try:
        return await player_tracking_service.create_player(player)
    except Exception as e:
        logger.error(f"Error creating player: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/players/{player_id}", response_model=Player)
async def get_player(
    player_id: int = Path(..., description="The player ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a player by ID."""
    try:
        player = await player_tracking_service.get_player(player_id)
        if not player:
            raise HTTPException(status_code=404, detail=f"Player {player_id} not found")
        return player
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting player {player_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/players/casino-id/{casino_guest_id}", response_model=Player)
async def get_player_by_casino_id(
    casino_guest_id: str = Path(..., description="The casino guest ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a player by casino guest ID."""
    try:
        player = await player_tracking_service.get_player_by_casino_id(casino_guest_id)
        if not player:
            raise HTTPException(status_code=404, detail=f"Player with casino guest ID {casino_guest_id} not found")
        return player
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting player with casino guest ID {casino_guest_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/players/{player_id}", response_model=Player)
async def update_player(
    player_update: PlayerUpdate,
    player_id: int = Path(..., description="The player ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a player."""
    try:
        player = await player_tracking_service.update_player(player_id, player_update)
        if not player:
            raise HTTPException(status_code=404, detail=f"Player {player_id} not found")
        return player
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating player {player_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/players/search", response_model=List[Player])
async def search_players(
    search: PlayerSearch,
    limit: int = Query(20, description="Maximum number of results"),
    offset: int = Query(0, description="Result offset"),
    current_user: Dict = Depends(get_current_user)
):
    """Search for players."""
    try:
        return await player_tracking_service.search_players(search, limit, offset)
    except Exception as e:
        logger.error(f"Error searching players: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/players/{player_id}/photos", response_model=PlayerPhoto)
async def upload_player_photo(
    player_id: int = Path(..., description="The player ID"),
    photo_type: str = Form(..., description="Photo type (id, reception, profile)"),
    photo: UploadFile = File(..., description="The photo file"),
    current_user: Dict = Depends(get_current_user)
):
    """Upload a player photo."""
    try:
        # Read photo data
        photo_data = await photo.read()
        
        # Create photo
        photo_create = PlayerPhotoCreate(
            photo_type=photo_type,
            photo_data=photo_data,
            file_path=""  # Will be set by service
        )
        
        return await player_tracking_service.upload_player_photo(player_id, photo_create)
    except Exception as e:
        logger.error(f"Error uploading photo for player {player_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/players/{player_id}/photos", response_model=List[PlayerPhoto])
async def get_player_photos(
    player_id: int = Path(..., description="The player ID"),
    photo_type: Optional[str] = Query(None, description="Filter by photo type"),
    current_user: Dict = Depends(get_current_user)
):
    """Get photos for a player."""
    try:
        return await player_tracking_service.get_player_photos(player_id, photo_type)
    except Exception as e:
        logger.error(f"Error getting photos for player {player_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Gaming session endpoints

@router.post("/gaming-sessions", response_model=GamingSession, status_code=201)
async def create_gaming_session(
    session: GamingSessionCreate,
    current_user: Dict = Depends(get_current_user)
):
    """Create a new gaming session."""
    try:
        return await player_tracking_service.create_gaming_session(session)
    except Exception as e:
        logger.error(f"Error creating gaming session: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/gaming-sessions/{session_id}", response_model=GamingSession)
async def get_gaming_session(
    session_id: int = Path(..., description="The session ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a gaming session by ID."""
    try:
        session = await player_tracking_service.get_gaming_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail=f"Gaming session {session_id} not found")
        return session
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting gaming session {session_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/gaming-sessions/{session_id}", response_model=GamingSession)
async def update_gaming_session(
    session_update: GamingSessionUpdate,
    session_id: int = Path(..., description="The session ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a gaming session."""
    try:
        session = await player_tracking_service.update_gaming_session(session_id, session_update)
        if not session:
            raise HTTPException(status_code=404, detail=f"Gaming session {session_id} not found")
        return session
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating gaming session {session_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/gaming-sessions/{session_id}/end", response_model=GamingSession)
async def end_gaming_session(
    session_id: int = Path(..., description="The session ID"),
    current_user: Dict = Depends(get_current_user)
):
    """End a gaming session."""
    try:
        session = await player_tracking_service.end_gaming_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail=f"Gaming session {session_id} not found")
        return session
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ending gaming session {session_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/players/{player_id}/gaming-sessions", response_model=List[GamingSession])
async def get_player_gaming_sessions(
    player_id: int = Path(..., description="The player ID"),
    limit: int = Query(20, description="Maximum number of results"),
    offset: int = Query(0, description="Result offset"),
    current_user: Dict = Depends(get_current_user)
):
    """Get gaming sessions for a player."""
    try:
        return await player_tracking_service.get_player_gaming_sessions(player_id, limit, offset)
    except Exception as e:
        logger.error(f"Error getting gaming sessions for player {player_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/gaming-sessions/active", response_model=List[GamingSession])
async def get_active_gaming_sessions(
    current_user: Dict = Depends(get_current_user)
):
    """Get all active gaming sessions."""
    try:
        return await player_tracking_service.get_active_gaming_sessions()
    except Exception as e:
        logger.error(f"Error getting active gaming sessions: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/table-game-activities", response_model=TableGameActivity, status_code=201)
async def create_table_game_activity(
    activity: TableGameActivityCreate,
    current_user: Dict = Depends(get_current_user)
):
    """Create a new table game activity."""
    try:
        return await player_tracking_service.create_table_game_activity(activity)
    except Exception as e:
        logger.error(f"Error creating table game activity: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/table-game-activities/{activity_id}", response_model=TableGameActivity)
async def update_table_game_activity(
    activity_update: TableGameActivityUpdate,
    activity_id: int = Path(..., description="The activity ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a table game activity."""
    try:
        activity = await player_tracking_service.update_table_game_activity(activity_id, activity_update)
        if not activity:
            raise HTTPException(status_code=404, detail=f"Table game activity {activity_id} not found")
        return activity
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating table game activity {activity_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/table-game-activities/{activity_id}/end", response_model=TableGameActivity)
async def end_table_game_activity(
    activity_id: int = Path(..., description="The activity ID"),
    cash_out: float = Query(..., description="Cash out amount"),
    win_loss: float = Query(..., description="Win/loss amount"),
    current_user: Dict = Depends(get_current_user)
):
    """End a table game activity."""
    try:
        activity = await player_tracking_service.end_table_game_activity(activity_id, cash_out, win_loss)
        if not activity:
            raise HTTPException(status_code=404, detail=f"Table game activity {activity_id} not found")
        return activity
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ending table game activity {activity_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/slot-machine-activities", response_model=SlotMachineActivity, status_code=201)
async def create_slot_machine_activity(
    activity: SlotMachineActivityCreate,
    current_user: Dict = Depends(get_current_user)
):
    """Create a new slot machine activity."""
    try:
        return await player_tracking_service.create_slot_machine_activity(activity)
    except Exception as e:
        logger.error(f"Error creating slot machine activity: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/slot-machine-activities/{activity_id}", response_model=SlotMachineActivity)
async def update_slot_machine_activity(
    activity_update: SlotMachineActivityUpdate,
    activity_id: int = Path(..., description="The activity ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a slot machine activity."""
    try:
        activity = await player_tracking_service.update_slot_machine_activity(activity_id, activity_update)
        if not activity:
            raise HTTPException(status_code=404, detail=f"Slot machine activity {activity_id} not found")
        return activity
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating slot machine activity {activity_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/slot-machine-activities/{activity_id}/end", response_model=SlotMachineActivity)
async def end_slot_machine_activity(
    activity_id: int = Path(..., description="The activity ID"),
    ticket_out: float = Query(..., description="Ticket out amount"),
    hand_pay: float = Query(0, description="Hand pay amount"),
    jackpot: float = Query(0, description="Jackpot amount"),
    current_user: Dict = Depends(get_current_user)
):
    """End a slot machine activity."""
    try:
        activity = await player_tracking_service.end_slot_machine_activity(activity_id, ticket_out, hand_pay, jackpot)
        if not activity:
            raise HTTPException(status_code=404, detail=f"Slot machine activity {activity_id} not found")
        return activity
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ending slot machine activity {activity_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Financial management endpoints

@router.post("/financial-transactions", response_model=FinancialTransaction, status_code=201)
async def create_financial_transaction(
    transaction: FinancialTransactionCreate,
    current_user: Dict = Depends(get_current_user)
):
    """Create a new financial transaction."""
    try:
        return await player_tracking_service.create_financial_transaction(transaction)
    except Exception as e:
        logger.error(f"Error creating financial transaction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/financial-transactions/{transaction_id}", response_model=FinancialTransaction)
async def get_financial_transaction(
    transaction_id: int = Path(..., description="The transaction ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a financial transaction by ID."""
    try:
        transaction = await player_tracking_service.get_fin<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>