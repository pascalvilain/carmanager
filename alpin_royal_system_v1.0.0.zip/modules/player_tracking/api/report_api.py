"""
Casino Management System - Report API
This module provides API endpoints for report generation and management.
"""

import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, date
from fastapi import APIRouter, Depends, HTTPException, Query, Path, Response
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
import io

from modules.player_tracking.reports.report_service import ReportService
from modules.player_tracking.repositories.dashboard_repository import DashboardRepository
from base_layer.auth.auth_manager import get_current_user

from modules.player_tracking.models.dashboard import (
    Dashboard, DashboardCreate, DashboardUpdate,
    DashboardWidget, DashboardWidgetCreate, DashboardWidgetUpdate,
    ReportTemplate, ReportTemplateCreate, ReportTemplateUpdate,
    Report, ReportCreate, ReportUpdate, PlayerReportData,
    TimeRange
)

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/player-tracking/reports", tags=["player-tracking-reports"])

# Initialize services
report_service = ReportService()
dashboard_repository = DashboardRepository()

# Report template endpoints

@router.post("/templates", response_model=ReportTemplate, status_code=201)
async def create_report_template(
    template: ReportTemplateCreate,
    current_user: Dict = Depends(get_current_user)
):
    """Create a new report template."""
    try:
        return await report_service.create_report_template(template)
    except Exception as e:
        logger.error(f"Error creating report template: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/templates/{template_id}", response_model=ReportTemplate)
async def get_report_template(
    template_id: int = Path(..., description="The template ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a report template by ID."""
    try:
        template = await dashboard_repository.get_report_template(template_id)
        if not template:
            raise HTTPException(status_code=404, detail=f"Report template {template_id} not found")
        return template
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting report template {template_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/templates/{template_id}", response_model=ReportTemplate)
async def update_report_template(
    template_update: ReportTemplateUpdate,
    template_id: int = Path(..., description="The template ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a report template."""
    try:
        template = await dashboard_repository.update_report_template(template_id, template_update)
        if not template:
            raise HTTPException(status_code=404, detail=f"Report template {template_id} not found")
        return template
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating report template {template_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/templates", response_model=List[ReportTemplate])
async def get_report_templates(
    report_type: Optional[str] = Query(None, description="Filter by report type"),
    owner_id: Optional[int] = Query(None, description="Filter by owner ID"),
    is_public: Optional[bool] = Query(None, description="Filter by public status"),
    is_active: bool = Query(True, description="Filter by active status"),
    current_user: Dict = Depends(get_current_user)
):
    """Get report templates."""
    try:
        return await dashboard_repository.get_report_templates(report_type, owner_id, is_public, is_active)
    except Exception as e:
        logger.error(f"Error getting report templates: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Report generation endpoints

@router.post("/generate/player/{player_id}")
async def generate_player_report(
    player_id: int = Path(..., description="The player ID"),
    template_id: int = Query(..., description="The report template ID"),
    time_range: str = Query(..., description="Time range (TODAY, YESTERDAY, THIS_WEEK, LAST_WEEK, THIS_MONTH, LAST_MONTH, THIS_QUARTER, LAST_QUARTER, THIS_YEAR, LAST_YEAR, CUSTOM)"),
    custom_start_date: Optional[date] = Query(None, description="Custom start date (required for CUSTOM time range)"),
    custom_end_date: Optional[date] = Query(None, description="Custom end date (required for CUSTOM time range)"),
    current_user: Dict = Depends(get_current_user)
):
    """Generate a PDF report for a player."""
    try:
        # Convert time_range string to enum
        time_range_enum = TimeRange(time_range)
        
        # Generate PDF
        pdf_content = await report_service.generate_player_report_pdf(
            player_id,
            template_id,
            time_range_enum,
            custom_start_date,
            custom_end_date
        )
        
        # Return PDF as streaming response
        return StreamingResponse(
            io.BytesIO(pdf_content),
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=player_report_{player_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
            }
        )
    except ValueError as e:
        logger.error(f"Invalid time range: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Invalid time range: {str(e)}")
    except Exception as e:
        logger.error(f"Error generating player report: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/reports/{report_id}/download")
async def download_report(
    report_id: int = Path(..., description="The report ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Download a report file."""
    try:
        # Get report
        report = await dashboard_repository.get_report(report_id)
        if not report:
            raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
        
        # Get file content
        file_content = await report_service.get_report_file(report_id)
        if not file_content:
            raise HTTPException(status_code=404, detail=f"Report file not found")
        
        # Return file as streaming response
        return StreamingResponse(
            io.BytesIO(file_content),
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=report_{report_id}.pdf"
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading report {report_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/reports/{report_id}/regenerate")
async def regenerate_report(
    report_id: int = Path(..., description="The report ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Regenerate a report."""
    try:
        # Regenerate report
        pdf_content = await report_service.regenerate_report(report_id)
        
        # Return PDF as streaming response
        return StreamingResponse(
            io.BytesIO(pdf_content),
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=report_{report_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
            }
        )
    except ValueError as e:
        logger.error(f"Error regenerating report: {str(e)}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error regenerating report {report_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/reports", response_model=List[Report])
async def get_reports(
    template_id: Optional[int] = Query(None, description="Filter by template ID"),
    player_id: Optional[int] = Query(None, description="Filter by player ID"),
    is_archived: Optional[bool] = Query(None, description="Filter by archived status"),
    limit: int = Query(50, description="Maximum number of results"),
    offset: int = Query(0, description="Result offset"),
    current_user: Dict = Depends(get_current_user)
):
    """Get reports."""
    try:
        return await dashboard_repository.get_reports(template_id, player_id, is_archived, limit, offset)
    except Exception as e:
        logger.error(f"Error getting reports: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/reports/{report_id}", response_model=Report)
async def get_report(
    report_id: int = Path(..., description="The report ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a report by ID."""
    try:
        report = await dashboard_repository.get_report(report_id)
        if not report:
            raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
        return report
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting report {report_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/reports/{report_id}", response_model=Report)
async def update_report(
    report_update: ReportUpdate,
    report_id: int = Path(..., description="The report ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a report."""
    try:
        report = await dashboard_repository.update_report(report_id, report_update)
        if not report:
            raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
        return report
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating report {report_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Dashboard endpoints

@router.post("/dashboards", response_model=Dashboard, status_code=201)
async def create_dashboard(
    dashboard: DashboardCreate,
    current_user: Dict = Depends(get_current_user)
):
    """Create a new dashboard."""
    try:
        return await dashboard_repository.create_dashboard(dashboard)
    except Exception as e:
        logger.error(f"Error creating dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/dashboards/{dashboard_id}", response_model=Dashboard)
async def get_dashboard(
    dashboard_id: int = Path(..., description="The dashboard ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a dashboard by ID."""
    try:
        dashboard = await dashboard_repository.get_dashboard(dashboard_id)
        if not dashboard:
            raise HTTPException(status_code=404, detail=f"Dashboard {dashboard_id} not found")
        return dashboard
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dashboard {dashboard_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/dashboards/{dashboard_id}", response_model=Dashboard)
async def update_dashboard(
    dashboard_update: DashboardUpdate,
    dashboard_id: int = Path(..., description="The dashboard ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a dashboard."""
    try:
        dashboard = await dashboard_repository.update_dashboard(dashboard_id, dashboard_update)
        if not dashboard:
            raise HTTPException(status_code=404, detail=f"Dashboard {dashboard_id} not found")
        return dashboard
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating dashboard {dashboard_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/dashboards/{dashboard_id}")
async def delete_dashboard(
    dashboard_id: int = Path(..., description="The dashboard ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Delete a dashboard (mark as inactive)."""
    try:
        success = await dashboard_repository.delete_dashboard(dashboard_id)
        if not success:
            raise HTTPException(status_code=404, detail=f"Dashboard {dashboard_id} not found")
        return {"message": f"Dashboard {dashboard_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting dashboard {dashboard_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/dashboards", response_model=List[Dashboard])
async def get_dashboards(
    owner_id: Optional[int] = Query(None, description="Filter by owner ID"),
    is_public: Optional[bool] = Query(None, description="Filter by public status"),
    is_active: bool = Query(True, description="Filter by active status"),
    current_user: Dict = Depends(get_current_user)
):
    """Get dashboards."""
    try:
        return await dashboard_repository.get_dashboards(owner_id, is_public, is_active)
    except Exception as e:
        logger.error(f"Error getting dashboards: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/dashboards/{dashboard_id}/content")
async def get_dashboard_content(
    dashboard_id: int = Path(..., description="The dashboard ID"),
    player_id: Optional[int] = Query(None, description="Optional player ID for player-specific dashboards"),
    current_user: Dict = Depends(get_current_user)
):
    """Get dashboard content with generated widgets."""
    try:
        dashboard_content = await report_service.generate_dashboard_content(dashboard_id, player_id)
        return dashboard_content
    except ValueError as e:
        logger.error(f"Error getting dashboard content: {str(e)}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error getting dashboard content for dashboard {dashboard_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/dashboards/{dashboard_id}/widgets", response_model=DashboardWidget, status_code=201)
async def create_dashboard_widget(
    widget: DashboardWidgetCreate,
    dashboard_id: int = Path(..., description="The dashboard ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Create a new dashboard widget."""
    try:
        return await dashboard_repository.create_dashboard_widget(dashboard_id, widget)
    except Exception as e:
        logger.error(f"Error creating dashboard widget: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/widgets/{widget_id}", response_model=DashboardWidget)
async def update_dashboard_widget(
    widget_update: DashboardWidgetUpdate,
    widget_id: int = Path(..., description="The widget ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Update a dashboard widget."""
    try:
        widget = await dashboard_repository.update_dashboard_widget(widget_id, widget_update)
        if not widget:
            raise HTTPException(status_code=404, detail=f"Dashboard widget {widget_id} not found")
        return widget
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating dashboard widget {widget_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/widgets/{widget_id}", response_model=DashboardWidget)
async def get_dashboard_widget(
    widget_id: int = Path(..., description="The widget ID"),
    current_user: Dict = Depends(get_current_user)
):
    """Get a dashboard widget by ID."""
    try:
        widget = await dashboard_repository.get_dashboard_widget(widget_id)
        if not widget:
            raise HTTPException(status_code=404, detail=f"Dashboard widget {widget_id} not found")
        return widget
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dashboard widget {widget_id}: {str(e)}")
        raise HTTP<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>