"""
Alpin Royal Casino Management System - Player Tracking API
This module provides API endpoints for player tracking operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form, Query, Path
from sqlalchemy.ext.asyncio import AsyncSession

from modules.player_tracking.models.player import (
    Player, PlayerCreate, PlayerUpdate, PlayerSummary, 
    PlayerSearch, PlayerPhoto, PlayerPhotoCreate, PhotoType
)
from modules.player_tracking.models.gaming_session import (
    GamingSession, GamingSessionCreate, GamingSessionUpdate, GamingSessionSearch,
    TableGame, TableGameCreate, TableGameUpdate,
    SlotMachine, SlotMachineCreate, SlotMachineUpdate,
    TableGameActivity, TableGameActivityCreate, TableGameActivityUpdate,
    SlotMachineActivity, SlotMachineActivityCreate, SlotMachineActivityUpdate,
    SessionStatus
)
from modules.player_tracking.models.financial import (
    FinancialTransaction, FinancialTransactionCreate, FinancialTransactionUpdate,
    JackpotHandPay, JackpotHandPayCreate, JackpotHandPayUpdate,
    FinancialSummary, FinancialSearch, TransactionType
)
from modules.player_tracking.models.consumption import (
    ConsumptionItem, ConsumptionItemCreate, ConsumptionItemUpdate,
    PlayerConsumption, PlayerConsumptionCreate, PlayerConsumptionUpdate,
    ConsumptionSummary, ConsumptionSearch, ItemType,
    CigaretteInventory, CigaretteInventoryCreate, CigaretteInventoryUpdate,
    CigaretteTransaction, CigaretteTransactionCreate, CigaretteTransactionType
)
from modules.player_tracking.models.dashboard import (
    PlayerDashboard, GamingDashboard, FinancialDashboard, ConsumptionDashboard, CigaretteDashboard
)

from modules.player_tracking.services.player_service import PlayerService
from modules.player_tracking.services.gaming_session_service import GamingSessionService
from modules.player_tracking.services.financial_service import FinancialService
from modules.player_tracking.services.consumption_service import ConsumptionService
from modules.player_tracking.services.cigarette_inventory_service import CigaretteInventoryService

from base_layer.utils.database import get_db_session

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/player-tracking", tags=["player-tracking"])

# Initialize services
player_service = PlayerService()
gaming_session_service = GamingSessionService()
financial_service = FinancialService()
consumption_service = ConsumptionService()
cigarette_inventory_service = CigaretteInventoryService()

# Player endpoints

@router.post("/players", response_model=Player, status_code=status.HTTP_201_CREATED)
async def create_player(
    player_data: PlayerCreate,
    db: AsyncSession = Depends(get_db_session)
):
    """Create a new player"""
    return await player_service.create_player(player_data, db)

@router.get("/players/{player_id}", response_model=Player)
async def get_player(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a player by ID"""
    player = await player_service.get_player_by_id(player_id, db)
    if not player:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Player with ID {player_id} not found"
        )
    return player

@router.get("/players/guest-id/{casino_guest_id}", response_model=Player)
async def get_player_by_guest_id(
    casino_guest_id: str = Path(..., description="Casino guest ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a player by casino guest ID"""
    player = await player_service.get_player_by_casino_guest_id(casino_guest_id, db)
    if not player:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Player with casino guest ID {casino_guest_id} not found"
        )
    return player

@router.put("/players/{player_id}", response_model=Player)
async def update_player(
    player_data: PlayerUpdate,
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Update a player"""
    player = await player_service.update_player(player_id, player_data, db)
    if not player:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Player with ID {player_id} not found"
        )
    return player

@router.delete("/players/{player_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_player(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Delete a player (soft delete)"""
    success = await player_service.delete_player(player_id, db)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Player with ID {player_id} not found"
        )
    return None

@router.post("/players/search", response_model=List[PlayerSummary])
async def search_players(
    search_params: PlayerSearch,
    db: AsyncSession = Depends(get_db_session)
):
    """Search for players based on various criteria"""
    return await player_service.search_players(search_params, db)

@router.post("/players/{player_id}/photos", response_model=PlayerPhoto)
async def add_player_photo(
    player_id: int = Path(..., description="Player ID"),
    photo_type: PhotoType = Form(..., description="Photo type"),
    photo: UploadFile = File(..., description="Photo file"),
    notes: Optional[str] = Form(None, description="Optional notes"),
    db: AsyncSession = Depends(get_db_session)
):
    """Add a photo to a player"""
    return await player_service.add_player_photo(player_id, photo_type, photo, notes, db)

@router.get("/players/{player_id}/photos", response_model=List[PlayerPhoto])
async def get_player_photos(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get all photos for a player"""
    return await player_service.get_player_photos(player_id, db)

# Gaming Session endpoints

@router.post("/sessions", response_model=GamingSession, status_code=status.HTTP_201_CREATED)
async def start_gaming_session(
    player_id: int = Query(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Start a new gaming session for a player"""
    return await gaming_session_service.start_gaming_session(player_id, db)

@router.put("/sessions/{session_id}/end", response_model=GamingSession)
async def end_gaming_session(
    session_id: int = Path(..., description="Gaming session ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """End a gaming session"""
    session = await gaming_session_service.end_gaming_session(session_id, None, db)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Gaming session with ID {session_id} not found"
        )
    return session

@router.get("/sessions/{session_id}", response_model=GamingSession)
async def get_gaming_session(
    session_id: int = Path(..., description="Gaming session ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a gaming session by ID"""
    session = await gaming_session_service.get_gaming_session_by_id(session_id, db)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Gaming session with ID {session_id} not found"
        )
    return session

@router.get("/players/{player_id}/active-session", response_model=Optional[GamingSession])
async def get_active_session_for_player(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get the active gaming session for a player"""
    return await gaming_session_service.get_active_session_for_player(player_id, db)

@router.post("/sessions/search", response_model=List[GamingSession])
async def search_gaming_sessions(
    search_params: GamingSessionSearch,
    db: AsyncSession = Depends(get_db_session)
):
    """Search for gaming sessions based on various criteria"""
    return await gaming_session_service.search_gaming_sessions(search_params, db)

@router.get("/players/{player_id}/session-stats", response_model=Dict[str, Any])
async def get_player_session_stats(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get statistics about a player's gaming sessions"""
    return await gaming_session_service.get_player_session_stats(player_id, db)

# Table Game endpoints

@router.post("/table-games", response_model=TableGame, status_code=status.HTTP_201_CREATED)
async def create_table_game(
    table_data: TableGameCreate,
    db: AsyncSession = Depends(get_db_session)
):
    """Create a new table game"""
    return await gaming_session_service.create_table_game(table_data, db)

@router.get("/table-games/{table_id}", response_model=TableGame)
async def get_table_game(
    table_id: int = Path(..., description="Table game ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a table game by ID"""
    table = await gaming_session_service.get_table_game_by_id(table_id, db)
    if not table:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Table game with ID {table_id} not found"
        )
    return table

@router.get("/table-games", response_model=List[TableGame])
async def get_all_table_games(
    db: AsyncSession = Depends(get_db_session)
):
    """Get all table games"""
    return await gaming_session_service.get_all_table_games(db)

# Slot Machine endpoints

@router.post("/slot-machines", response_model=SlotMachine, status_code=status.HTTP_201_CREATED)
async def create_slot_machine(
    machine_data: SlotMachineCreate,
    db: AsyncSession = Depends(get_db_session)
):
    """Create a new slot machine"""
    return await gaming_session_service.create_slot_machine(machine_data, db)

@router.get("/slot-machines/{machine_id}", response_model=SlotMachine)
async def get_slot_machine(
    machine_id: int = Path(..., description="Slot machine ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a slot machine by ID"""
    machine = await gaming_session_service.get_slot_machine_by_id(machine_id, db)
    if not machine:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Slot machine with ID {machine_id} not found"
        )
    return machine

@router.get("/slot-machines", response_model=List[SlotMachine])
async def get_all_slot_machines(
    db: AsyncSession = Depends(get_db_session)
):
    """Get all slot machines"""
    return await gaming_session_service.get_all_slot_machines(db)

# Table Game Activity endpoints

@router.post("/table-activities", response_model=TableGameActivity, status_code=status.HTTP_201_CREATED)
async def start_table_game_activity(
    session_id: int = Query(..., description="Gaming session ID"),
    table_id: int = Query(..., description="Table game ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Start a new table game activity"""
    return await gaming_session_service.start_table_game_activity(session_id, table_id, db)

@router.put("/table-activities/{activity_id}/end", response_model=TableGameActivity)
async def end_table_game_activity(
    activity_data: TableGameActivityUpdate,
    activity_id: int = Path(..., description="Table game activity ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """End a table game activity"""
    activity = await gaming_session_service.end_table_game_activity(activity_id, activity_data, db)
    if not activity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Table game activity with ID {activity_id} not found"
        )
    return activity

# Slot Machine Activity endpoints

@router.post("/slot-activities", response_model=SlotMachineActivity, status_code=status.HTTP_201_CREATED)
async def start_slot_machine_activity(
    session_id: int = Query(..., description="Gaming session ID"),
    machine_id: int = Query(..., description="Slot machine ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Start a new slot machine activity"""
    return await gaming_session_service.start_slot_machine_activity(session_id, machine_id, db)

@router.put("/slot-activities/{activity_id}/end", response_model=SlotMachineActivity)
async def end_slot_machine_activity(
    activity_data: SlotMachineActivityUpdate,
    activity_id: int = Path(..., description="Slot machine activity ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """End a slot machine activity"""
    activity = await gaming_session_service.end_slot_machine_activity(activity_id, activity_data, db)
    if not activity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Slot machine activity with ID {activity_id} not found"
        )
    return activity

# Financial Transaction endpoints

@router.post("/transactions", response_model=FinancialTransaction, status_code=status.HTTP_201_CREATED)
async def create_transaction(
    transaction_data: FinancialTransactionCreate,
    db: AsyncSession = Depends(get_db_session)
):
    """Create a new financial transaction"""
    return await financial_service.create_transaction(transaction_data, db)

@router.get("/transactions/{transaction_id}", response_model=FinancialTransaction)
async def get_transaction(
    transaction_id: int = Path(..., description="Financial transaction ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a financial transaction by ID"""
    transaction = await financial_service.get_transaction_by_id(transaction_id, db)
    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Financial transaction with ID {transaction_id} not found"
        )
    return transaction

@router.post("/transactions/search", response_model=List[FinancialTransaction])
async def search_transactions(
    search_params: FinancialSearch,
    db: AsyncSession = Depends(get_db_session)
):
    """Search for financial transactions based on various criteria"""
    return await financial_service.search_transactions(search_params, db)

@router.get("/players/{player_id}/financial-summary", response_model=FinancialSummary)
async def get_player_financial_summary(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a summary of a player's financial transactions"""
    return await financial_service.get_player_financial_summary(player_id, db)

# Jackpot and Hand Pay endpoints

@router.post("/jackpots", response_model=JackpotHandPay, status_code=status.HTTP_201_CREATED)
async def record_jackpot_hand_pay(
    jackpot_data: JackpotHandPayCreate = Depends(),
    photo: Optional[UploadFile] = File(None, description="Optional photo of the jackpot or hand pay"),
    db: AsyncSession = Depends(get_db_session)
):
    """Record a new jackpot or hand pay"""
    return await financial_service.record_jackpot_hand_pay(jackpot_data, photo, db)

@router.get("/jackpots/{jackpot_id}", response_model=JackpotHandPay)
async def get_jackpot_hand_pay(
    jackpot_id: int = Path(..., description="Jackpot or hand pay ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a jackpot or hand pay record by ID"""
    jackpot = await financial_service.get_jackpot_hand_pay_by_id(jackpot_id, db)
    if not jackpot:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Jackpot or hand pay with ID {jackpot_id} not found"
        )
    return jackpot

@router.get("/players/{player_id}/jackpots", response_model=List[JackpotHandPay])
async def get_player_jackpots_hand_pays(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get all jackpots and hand pays for a player"""
    return await financial_service.get_player_jackpots_hand_pays(player_id, db)

# Consumption Item endpoints

@router.post("/consumption-items", response_model=ConsumptionItem, status_code=status.HTTP_201_CREATED)
async def create_consumption_item(
    item_data: ConsumptionItemCreate,
    db: AsyncSession = Depends(get_db_session)
):
    """Create a new consumption item"""
    return await consumption_service.create_consumption_item(item_data, db)

@router.get("/consumption-items/{item_id}", response_model=ConsumptionItem)
async def get_consumption_item(
    item_id: int = Path(..., description="Consumption item ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a consumption item by ID"""
    item = await consumption_service.get_consumption_item_by_id(item_id, db)
    if not item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Consumption item with ID {item_id} not found"
        )
    return item

@router.get("/consumption-items", response_model=List[ConsumptionItem])
async def get_all_consumption_items(
    item_type: Optional[ItemType] = Query(None, description="Filter by item type"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get all consumption items, optionally filtered by type"""
    return await consumption_service.get_all_consumption_items(item_type, db)

# Player Consumption endpoints

@router.post("/player-consumptions", response_model=PlayerConsumption, status_code=status.HTTP_201_CREATED)
async def record_player_consumption(
    consumption_data: PlayerConsumptionCreate,
    db: AsyncSession = Depends(get_db_session)
):
    """Record a new player consumption"""
    return await consumption_service.record_player_consumption(consumption_data, db)

@router.get("/player-consumptions/{consumption_id}", response_model=PlayerConsumption)
async def get_player_consumption(
    consumption_id: int = Path(..., description="Player consumption ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a player consumption record by ID"""
    consumption = await consumption_service.get_player_consumption_by_id(consumption_id, db)
    if not consumption:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Player consumption with ID {consumption_id} not found"
        )
    return consumption

@router.post("/player-consumptions/search", response_model=List[PlayerConsumption])
async def search_player_consumptions(
    search_params: ConsumptionSearch,
    db: AsyncSession = Depends(get_db_session)
):
    """Search for player consumption records based on various criteria"""
    return await consumption_service.search_player_consumptions(search_params, db)

@router.get("/players/{player_id}/consumption-summary", response_model=ConsumptionSummary)
async def get_player_consumption_summary(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a summary of a player's consumption records"""
    return await consumption_service.get_player_consumption_summary(player_id, db)

# Cigarette Inventory endpoints

@router.post("/cigarette-inventory", response_model=CigaretteInventory, status_code=status.HTTP_201_CREATED)
async def create_cigarette_inventory_item(
    inventory_data: CigaretteInventoryCreate,
    db: AsyncSession = Depends(get_db_session)
):
    """Create a new cigarette inventory item"""
    return await cigarette_inventory_service.create_inventory_item(inventory_data, db)

@router.get("/cigarette-inventory/{inventory_id}", response_model=CigaretteInventory)
async def get_cigarette_inventory_item(
    inventory_id: int = Path(..., description="Cigarette inventory ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get a cigarette inventory item by ID"""
    inventory = await cigarette_inventory_service.get_inventory_item_by_id(inventory_id, db)
    if not inventory:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Cigarette inventory item with ID {inventory_id} not found"
        )
    return inventory

@router.get("/cigarette-inventory", response_model=List[CigaretteInventory])
async def get_all_cigarette_inventory_items(
    db: AsyncSession = Depends(get_db_session)
):
    """Get all cigarette inventory items"""
    return await cigarette_inventory_service.get_all_inventory_items(db)

@router.get("/cigarette-inventory/low-stock", response_model=List[CigaretteInventory])
async def get_low_stock_cigarette_items(
    db: AsyncSession = Depends(get_db_session)
):
    """Get cigarette inventory items with low stock"""
    return await cigarette_inventory_service.get_low_stock_items(db)

@router.post("/cigarette-inventory/{inventory_id}/purchase", response_model=CigaretteInventory)
async def record_cigarette_purchase(
    inventory_id: int = Path(..., description="Cigarette inventory ID"),
    quantity: int = Query(..., description="Quantity purchased", gt=0),
    staff_id: int = Query(..., description="Staff ID"),
    notes: Optional[str] = Query(None, description="Optional notes"),
    db: AsyncSession = Depends(get_db_session)
):
    """Record a purchase of cigarettes"""
    _, updated_inventory = await cigarette_inventory_service.record_purchase(
        inventory_id, quantity, staff_id, notes, db
    )
    return updated_inventory

@router.post("/cigarette-inventory/{inventory_id}/dispense", response_model=CigaretteInventory)
async def dispense_cigarettes_to_player(
    inventory_id: int = Path(..., description="Cigarette inventory ID"),
    player_id: int = Query(..., description="Player ID"),
    quantity: int = Query(..., description="Quantity dispensed", gt=0),
    staff_id: int = Query(..., description="Staff ID"),
    session_id: Optional[int] = Query(None, description="Optional gaming session ID"),
    notes: Optional[str] = Query(None, description="Optional notes"),
    db: AsyncSession = Depends(get_db_session)
):
    """Dispense cigarettes to a player"""
    _, updated_inventory = await cigarette_inventory_service.dispense_to_player(
        inventory_id, player_id, quantity, staff_id, session_id, notes, db
    )
    return updated_inventory

@router.post("/cigarette-inventory/{inventory_id}/adjust", response_model=CigaretteInventory)
async def adjust_cigarette_inventory(
    inventory_id: int = Path(..., description="Cigarette inventory ID"),
    quantity_change: int = Query(..., description="Change in quantity (positive for increase, negative for decrease)"),
    staff_id: int = Query(..., description="Staff ID"),
    notes: str = Query(..., description="Notes explaining the adjustment"),
    db: AsyncSession = Depends(get_db_session)
):
    """Record an inventory adjustment"""
    _, updated_inventory = await cigarette_inventory_service.record_inventory_adjustment(
        inventory_id, quantity_change, staff_id, notes, db
    )
    return updated_inventory

@router.get("/cigarette-inventory/summary", response_model=Dict[str, Any])
async def get_cigarette_inventory_summary(
    db: AsyncSession = Depends(get_db_session)
):
    """Get a summary of cigarette inventory"""
    return await cigarette_inventory_service.get_inventory_summary(db)

# Dashboard endpoints

@router.get("/dashboard/player/{player_id}", response_model=PlayerDashboard)
async def get_player_dashboard(
    player_id: int = Path(..., description="Player ID"),
    db: AsyncSession = Depends(get_db_session)
):
    """Get dashboard data for a player"""
    # Get player
    player = await player_service.get_player_by_id(player_id, db)
    if not player:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Player with ID {player_id} not found"
        )
    
    # Get session stats
    session_stats = await gaming_session_service.get_player_session_stats(player_id, db)
    
    # Get financial summary
    financial_summary = await financial_service.get_player_financial_summary(player_id, db)
    
    # Get consumption summary
    consumption_summary = await consumption_service.get_player_consumption_summary(player_id, db)
    
    # Get jackpots and hand pays
    jackpots_hand_pays = await financial_service.get_player_jackpots_hand_pays(player_id, db)
    
    # Compile dashboard data
    dashboard = PlayerDashboard(
        player=player,
        session_stats=session_stats,
        financial_summary=financial_summary,
        consumption_summary=consumption_summary,
        recent_jackpots=jackpots_hand_pays[:5] if jackpots_hand_pays else []
    )
    
    return dashboard

@router.get("/dashboard/gaming", response_model=GamingDashboard)
async def get_gaming_dashboard(
    db: AsyncSession = Depends(get_db_session)
):
    """Get dashboard data for gaming"""
    # This would typically aggregate data from various sources
    # Placeholder implementation
    dashboard = GamingDashboard(
        active_sessions=0,  # Would be calculated from actual data
        total_tables=0,     # Would be calculated from actual data
        total_slots=0,      # Would be calculated from actual data
        # Additional data would be added here
    )
    
    return dashboard

@router.get("/dashboard/financial", response_model=FinancialDashboard)
async def get_financial_dashboard(
    db: AsyncSession = Depends(get_db_session)
):
    """Get dashboard data for financial transactions"""
    # This would typically aggregate data from various sources
    # Placeholder implementation
    dashboard = FinancialDashboard(
        total_buy_ins=0,    # Would be calculated from actual data
        total_cash_outs=0,  # Would be calculated from actual data
        total_jackpots=0,   # Would be calculated from actual data
        # Additional data would be added here
    )
    
    return dashboard

@router.get("/dashboard/consumption", response_model=ConsumptionDashboard)
async def get_consumption_dashboard(
    db: AsyncSession = Depends(get_db_session)
):
    """Get dashboard data for consumption"""
    # Get consumption dashboard data
    dashboard_data = await consumption_service.get_consumption_dashboard_data(db)
    
    # Compile dashboard
    dashboard = ConsumptionDashboard(
        total_items=dashboard_data["total_items"],
        items_by_type=dashboard_data["items_by_type"],
        # Additional data would be added here
    )
    
    return dashboard

@router.get("/dashboard/cigarette", response_model=CigaretteDashboard)
async def get_cigarette_dashboard(
    db: AsyncSession = Depends(get_db_session)
):
    """Get dashboard data for cigarette inventory"""
    # Get cigarette dashboard data
    dashboard_data = await cigarette_inventory_service.get_dashboard_data(db)
    
    # Compile dashboard
    dashboard = CigaretteDashboard(
        total_items=dashboard_data["total_items"],
        total_quantity=dashboard_data["total_quantity"],
        low_stock_count=dashboard_data["low_stock_count"],
        low_stock_percentage=dashboard_data["low_stock_percentage"],
        healthy_stock_percentage=dashboard_data["healthy_stock_percentage"],
        most_popular_brand=dashboard_data["most_popular_brand"],
        low_stock_items=dashboard_data["low_stock_items"],
        recent_transactions=dashboard_data["recent_transactions"]
    )
    
    return dashboard

# Export endpoints for reporting

@router.get("/reports/player/{player_id}")
async def export_player_report(
    player_id: int = Path(..., description="Player ID"),
    format: str = Query("pdf", description="Export format (pdf, excel, csv)"),
    db: AsyncSession = Depends(get_db_session)
):
    """Export a player report"""
    # This would generate a report in the requested format
    # Placeholder implementation
    return {"message": f"Player report for player ID {player_id} in {format} format would be generated here"}

@router.get("/reports/sessions")
async def export_sessions_report(
    start_date: datetime = Query(..., description="Start date"),
    end_date: datetime = Query(..., description="End date"),
    format: str = Query("pdf", description="Export format (pdf, excel, csv)"),
    db: AsyncSession = Depends(get_db_session)
):
    """Export a sessions report"""
    # This would generate a report in the requested format
    # Placeholder implementation
    return {"message": f"Sessions report from {start_date} to {end_date} in {format} format would be generated here"}

@router.get("/reports/financial")
async def export_financial_report(
    start_date: datetime = Query(..., description="Start date"),
    end_date: datetime = Query(..., description="End date"),
    transaction_type: Optional[TransactionType] = Query(None, description="Filter by transaction type"),
    format: str = Query("pdf", description="Export format (pdf, excel, csv)"),
    db: AsyncSession = Depends(get_db_session)
):
    """Export a financial report"""
    # This would generate a report in the requested format
    # Placeholder implementation
    return {"message": f"Financial report from {start_date} to {end_date} in {format} format would be generated here"}

@router.get("/reports/consumption")
async def export_consumption_report(
    start_date: datetime = Query(..., description="Start date"),
    end_date: datetime = Query(..., description="End date"),
    item_type: Optional[ItemType] = Query(None, description="Filter by item type"),
    format: str = Query("pdf", description="Export format (pdf, excel, csv)"),
    db: AsyncSession = Depends(get_db_session)
):
    """Export a consumption report"""
    # This would generate a report in the requested format
    # Placeholder implementation
    return {"message": f"Consumption report from {start_date} to {end_date} in {format} format would be generated here"}

@router.get("/reports/cigarette-inventory")
async def export_cigarette_inventory_report(
    format: str = Query("pdf", description="Export format (pdf, excel, csv)"),
    db: AsyncSession = Depends(get_db_session)
):
    """Export a cigarette inventory report"""
    # This would generate a report in the requested format
    # Placeholder implementation
    return {"message": f"Cigarette inventory report in {format} format would be generated here"}
