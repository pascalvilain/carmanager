"""
Casino Management System - Dashboard Generator
This module provides functionality for generating dashboard widgets and visualizations.
"""

import logging
import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime, date, timedelta

import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import io
import base64

from modules.player_tracking.models.dashboard import (
    Dashboard, DashboardWidget, WidgetType, PlayerReportData, TimeRange
)

logger = logging.getLogger(__name__)

class DashboardGenerator:
    """Class for generating dashboard widgets and visualizations."""
    
    def __init__(self):
        """Initialize the dashboard generator."""
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.output_dir = os.path.join(self.base_dir, "output")
        
        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Set matplotlib style
        plt.style.use('ggplot')
    
    def _create_chart_image(self, plt_figure) -> str:
        """
        Create a base64-encoded image from a matplotlib figure.
        
        Args:
            plt_figure: Matplotlib figure
            
        Returns:
            Base64-encoded image data
        """
        # Save figure to in-memory buffer
        buf = io.BytesIO()
        plt_figure.savefig(buf, format='png', dpi=100, bbox_inches='tight')
        buf.seek(0)
        
        # Encode as base64
        img_data = base64.b64encode(buf.getvalue()).decode('utf-8')
        
        # Close figure to free memory
        plt.close(plt_figure)
        
        return f"data:image/png;base64,{img_data}"
    
    def generate_visits_chart(self, visit_data: List[Dict[str, Any]], time_range: TimeRange) -> str:
        """
        Generate a chart showing player visits over time.
        
        Args:
            visit_data: List of visit data (date and count)
            time_range: Time range
            
        Returns:
            Base64-encoded image data
        """
        # Extract dates and counts
        dates = [datetime.strptime(item['date'], '%Y-%m-%d').date() for item in visit_data]
        counts = [item['count'] for item in visit_data]
        
        # Create figure
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot data
        ax.bar(dates, counts, color='#4CAF50', width=0.8)
        
        # Set title and labels
        ax.set_title('Player Visits', fontsize=16)
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Number of Visits', fontsize=12)
        
        # Format x-axis based on time range
        if time_range in [TimeRange.TODAY, TimeRange.YESTERDAY]:
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        elif time_range in [TimeRange.THIS_WEEK, TimeRange.LAST_WEEK]:
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%a'))
        elif time_range in [TimeRange.THIS_MONTH, TimeRange.LAST_MONTH]:
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%d'))
        else:
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)
        
        # Add grid
        ax.grid(True, linestyle='--', alpha=0.7)
        
        # Tight layout
        fig.tight_layout()
        
        # Create image
        return self._create_chart_image(fig)
    
    def generate_gaming_activity_chart(self, table_data: List[Dict[str, Any]], slot_data: List[Dict[str, Any]]) -> str:
        """
        Generate a chart showing table games vs slot machine activity.
        
        Args:
            table_data: List of table game data (game and hours)
            slot_data: List of slot machine data (machine and hours)
            
        Returns:
            Base64-encoded image data
        """
        # Extract data
        table_games = [item['game'] for item in table_data]
        table_hours = [item['hours'] for item in table_data]
        
        slot_machines = [item['machine'] for item in slot_data]
        slot_hours = [item['hours'] for item in slot_data]
        
        # Create figure with two subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))
        
        # Plot table games
        if table_games:
            ax1.bar(table_games, table_hours, color='#2196F3')
            ax1.set_title('Table Games', fontsize=14)
            ax1.set_xlabel('Game', fontsize=12)
            ax1.set_ylabel('Hours Played', fontsize=12)
            ax1.tick_params(axis='x', rotation=45)
        else:
            ax1.text(0.5, 0.5, 'No Table Game Data', 
                    horizontalalignment='center', verticalalignment='center',
                    transform=ax1.transAxes, fontsize=14)
        
        # Plot slot machines
        if slot_machines:
            ax2.bar(slot_machines, slot_hours, color='#FF9800')
            ax2.set_title('Slot Machines', fontsize=14)
            ax2.set_xlabel('Machine', fontsize=12)
            ax2.set_ylabel('Hours Played', fontsize=12)
            ax2.tick_params(axis='x', rotation=45)
        else:
            ax2.text(0.5, 0.5, 'No Slot Machine Data', 
                    horizontalalignment='center', verticalalignment='center',
                    transform=ax2.transAxes, fontsize=14)
        
        # Tight layout
        fig.tight_layout()
        
        # Create image
        return self._create_chart_image(fig)
    
    def generate_win_loss_chart(self, win_loss_data: List[Dict[str, Any]]) -> str:
        """
        Generate a chart showing win/loss over time.
        
        Args:
            win_loss_data: List of win/loss data (date and amount)
            
        Returns:
            Base64-encoded image data
        """
        # Extract dates and amounts
        dates = [datetime.strptime(item['date'], '%Y-%m-%d').date() for item in win_loss_data]
        amounts = [item['amount'] for item in win_loss_data]
        
        # Create figure
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot data with different colors for positive and negative values
        for i, amount in enumerate(amounts):
            color = '#4CAF50' if amount >= 0 else '#F44336'
            ax.bar(dates[i], amount, color=color, width=0.8)
        
        # Set title and labels
        ax.set_title('Win/Loss Over Time', fontsize=16)
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Amount ($)', fontsize=12)
        
        # Format x-axis
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)
        
        # Add grid
        ax.grid(True, linestyle='--', alpha=0.7)
        
        # Add zero line
        ax.axhline(y=0, color='k', linestyle='-', alpha=0.3)
        
        # Tight layout
        fig.tight_layout()
        
        # Create image
        return self._create_chart_image(fig)
    
    def generate_consumption_pie_chart(self, consumption_data: List[Dict[str, Any]], title: str) -> str:
        """
        Generate a pie chart showing consumption breakdown.
        
        Args:
            consumption_data: List of consumption data (name and count)
            title: Chart title
            
        Returns:
            Base64-encoded image data
        """
        # Extract names and counts
        names = [item['name'] for item in consumption_data]
        counts = [item['count'] for item in consumption_data]
        
        # Create figure
        fig, ax = plt.subplots(figsize=(8, 8))
        
        # Plot data
        if sum(counts) > 0:
            # Define colors
            colors = plt.cm.tab10.colors
            
            # Create pie chart
            wedges, texts, autotexts = ax.pie(
                counts, 
                labels=names, 
                autopct='%1.1f%%',
                startangle=90,
                colors=colors
            )
            
            # Equal aspect ratio ensures that pie is drawn as a circle
            ax.axis('equal')
            
            # Set title
            ax.set_title(title, fontsize=16)
            
            # Style text elements
            for text in texts:
                text.set_fontsize(12)
            
            for autotext in autotexts:
                autotext.set_fontsize(10)
                autotext.set_color('white')
        else:
            ax.text(0.5, 0.5, 'No Data Available', 
                   horizontalalignment='center', verticalalignment='center',
                   transform=ax.transAxes, fontsize=14)
            ax.axis('off')
        
        # Tight layout
        fig.tight_layout()
        
        # Create image
        return self._create_chart_image(fig)
    
    def generate_dashboard_widget(self, widget_type: WidgetType, widget_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a dashboard widget.
        
        Args:
            widget_type: Widget type
            widget_data: Widget data
            
        Returns:
            Widget content
        """
        try:
            if widget_type == WidgetType.VISITS_CHART:
                image_data = self.generate_visits_chart(
                    widget_data.get('visit_data', []),
                    TimeRange(widget_data.get('time_range', 'THIS_MONTH'))
                )
                return {
                    'type': 'chart',
                    'image': image_data
                }
            
            elif widget_type == WidgetType.GAMING_ACTIVITY_CHART:
                image_data = self.generate_gaming_activity_chart(
                    widget_data.get('table_data', []),
                    widget_data.get('slot_data', [])
                )
                return {
                    'type': 'chart',
                    'image': image_data
                }
            
            elif widget_type == WidgetType.WIN_LOSS_CHART:
                image_data = self.generate_win_loss_chart(
                    widget_data.get('win_loss_data', [])
                )
                return {
                    'type': 'chart',
                    'image': image_data
                }
            
            elif widget_type == WidgetType.CONSUMPTION_PIE_CHART:
                image_data = self.generate_consumption_pie_chart(
                    widget_data.get('consumption_data', []),
                    widget_data.get('title', 'Consumption Breakdown')
                )
                return {
                    'type': 'chart',
                    'image': image_data
                }
            
            elif widget_type == WidgetType.PLAYER_STATS:
                return {
                    'type': 'stats',
                    'stats': widget_data.get('stats', {})
                }
            
            elif widget_type == WidgetType.RECENT_ACTIVITY:
                return {
                    'type': 'activity',
                    'activities': widget_data.get('activities', [])
                }
            
            elif widget_type == WidgetType.TOP_PLAYERS:
                return {
                    'type': 'top_players',
                    'players': widget_data.get('players', [])
                }
            
            elif widget_type == WidgetType.CIGARETTE_INVENTORY:
                return {
                    'type': 'inventory',
                    'inventory': widget_data.get('inventory', [])
                }
            
            else:
                logger.warning(f"Unknown widget type: {widget_type}")
                return {
                    'type': 'error',
                    'message': f"Unknown widget type: {widget_type}"
                }
        
        except Exception as e:
            logger.error(f"Error generating dashboard widget: {str(e)}")
            return {
                'type': 'error',
                'message': f"Error generating widget: {str(e)}"
            }
    
    def generate_dashboard(self, dashboard: Dashboard, widgets_data: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate a complete dashboard.
        
        Args:
            dashboard: Dashboard model
            widgets_data: Data for each widget
            
        Returns:
            Dashboard content
        """
        dashboard_content = {
            'id': dashboard.id,
            'name': dashboard.name,
            'description': dashboard.description,
            'owner_id': dashboard.owner_id,
            'is_public': dashboard.is_public,
            'created_at': dashboard.created_at.isoformat() if dashboard.created_at else None,
            'updated_at': dashboard.updated_at.isoformat() if dashboard.updated_at else None,
            'widgets': []
        }
        
        # Generate each widget
        for widget in dashboard.widgets:
            if widget.id in widgets_data:
                widget_content = self.generate_dashboard_widget(
                    widget.widget_type,
                    widgets_data[widget.id]
                )
                
                dashboard_content['widgets'].append({
                    'id': widget.id,
                    'name': widget.name,
                    'widget_type': widget.widget_type.value,
                    'position_x': widget.position_x,
                    'position_y': widget.position_y,
                    'width': widget.width,
                    'height': widget.height,
                    'content': widget_content
                })
        
        return dashboard_content
    
    def save_dashboard_to_file(self, dashboard_content: Dict[str, Any], filename: str) -> str:
        """
        Save dashboard content to a file.
        
        Args:
            dashboard_content: Dashboard content
            filename: Output filename
            
        Returns:
            File path
        """
        file_path = os.path.join(self.output_dir, filename)
        
        with open(file_path, 'w') as f:
            json.dump(dashboard_content, f, indent=2)
        
        return file_path
