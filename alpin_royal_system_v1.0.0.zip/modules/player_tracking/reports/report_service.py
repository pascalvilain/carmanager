"""
Casino Management System - Report Service
This module provides services for generating and managing reports.
"""

import logging
import os
from typing import Dict, Any, List, Optional, BinaryIO
from datetime import datetime, date, timedelta

from modules.player_tracking.models.dashboard import (
    ReportTemplate, ReportTemplateCreate, ReportTemplateUpdate,
    Report, ReportCreate, ReportUpdate, PlayerReportData,
    TimeRange
)
from modules.player_tracking.repositories.dashboard_repository import DashboardRepository
from modules.player_tracking.reports.pdf_generator import PDFReportGenerator
from modules.player_tracking.reports.dashboard_generator import DashboardGenerator

from base_layer.utils.storage import StorageManager

logger = logging.getLogger(__name__)

class ReportService:
    """Service for generating and managing reports."""
    
    def __init__(self):
        """Initialize the report service."""
        self.dashboard_repository = DashboardRepository()
        self.pdf_generator = PDFReportGenerator()
        self.dashboard_generator = DashboardGenerator()
        self.storage_manager = StorageManager()
        
        # Ensure reports directory exists
        self.reports_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
        os.makedirs(self.reports_dir, exist_ok=True)
    
    async def generate_player_report_pdf(self, player_id: int, template_id: int, 
                                       time_range: TimeRange, 
                                       custom_start_date: Optional[date] = None, 
                                       custom_end_date: Optional[date] = None) -> bytes:
        """
        Generate a PDF report for a player.
        
        Args:
            player_id: The player ID
            template_id: The report template ID
            time_range: The time range
            custom_start_date: Custom start date (for CUSTOM time range)
            custom_end_date: Custom end date (for CUSTOM time range)
            
        Returns:
            PDF file content as bytes
        """
        try:
            # Get template
            template = await self.dashboard_repository.get_report_template(template_id)
            
            if not template:
                raise ValueError(f"Report template {template_id} not found")
            
            # Get time range dates
            start_date, end_date = await self.dashboard_repository.get_time_range_dates(
                time_range, custom_start_date, custom_end_date
            )
            
            # Get player data
            player_data = await self.dashboard_repository.get_player_data(player_id)
            
            if not player_data:
                raise ValueError(f"Player {player_id} not found")
            
            # Get report data
            report_data = await self.dashboard_repository.get_player_report_data(player_id, start_date, end_date)
            
            # Generate PDF
            pdf_content = self.pdf_generator.generate_player_report_pdf(
                player_data, report_data, template, time_range, start_date, end_date
            )
            
            # Create report record
            report_create = ReportCreate(
                template_id=template_id,
                player_id=player_id,
                name=f"Player Report - {player_data['full_name']} - {time_range.value}",
                description=f"Player activity report for {player_data['full_name']} ({time_range.value})",
                parameters={
                    "time_range": time_range.value,
                    "start_date": start_date.isoformat() if start_date else None,
                    "end_date": end_date.isoformat() if end_date else None
                },
                is_archived=False
            )
            
            report = await self.dashboard_repository.create_report(report_create)
            
            # Save PDF to storage
            file_path = f"reports/player_{player_id}/{report.id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.pdf"
            
            await self.storage_manager.save_file(
                file_path, 
                pdf_content,
                content_type="application/pdf"
            )
            
            # Update report with file path
            await self.dashboard_repository.update_report(
                report.id,
                ReportUpdate(file_path=file_path)
            )
            
            return pdf_content
        except Exception as e:
            logger.error(f"Error generating player report PDF: {str(e)}")
            raise
    
    async def generate_dashboard_content(self, dashboard_id: int, player_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Generate dashboard content.
        
        Args:
            dashboard_id: The dashboard ID
            player_id: Optional player ID for player-specific dashboards
            
        Returns:
            Dashboard content
        """
        try:
            # Get dashboard
            dashboard = await self.dashboard_repository.get_dashboard(dashboard_id)
            
            if not dashboard:
                raise ValueError(f"Dashboard {dashboard_id} not found")
            
            # Get widgets data
            widgets_data = {}
            
            for widget in dashboard.widgets:
                # Get widget data based on widget type
                widget_data = await self.dashboard_repository.get_widget_data(widget.id, player_id)
                widgets_data[widget.id] = widget_data
            
            # Generate dashboard
            dashboard_content = self.dashboard_generator.generate_dashboard(dashboard, widgets_data)
            
            return dashboard_content
        except Exception as e:
            logger.error(f"Error generating dashboard content: {str(e)}")
            raise
    
    async def save_dashboard_to_file(self, dashboard_id: int, player_id: Optional[int] = None) -> str:
        """
        Save dashboard content to a file.
        
        Args:
            dashboard_id: The dashboard ID
            player_id: Optional player ID for player-specific dashboards
            
        Returns:
            File path
        """
        try:
            # Generate dashboard content
            dashboard_content = await self.generate_dashboard_content(dashboard_id, player_id)
            
            # Create filename
            filename = f"dashboard_{dashboard_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.json"
            
            if player_id:
                filename = f"player_{player_id}_" + filename
            
            # Save to file
            file_path = self.dashboard_generator.save_dashboard_to_file(dashboard_content, filename)
            
            return file_path
        except Exception as e:
            logger.error(f"Error saving dashboard to file: {str(e)}")
            raise
    
    async def create_report_template(self, template: ReportTemplateCreate) -> ReportTemplate:
        """
        Create a new report template.
        
        Args:
            template: The template data
            
        Returns:
            The created template
        """
        try:
            # Create template in database
            report_template = await self.dashboard_repository.create_report_template(template)
            
            # Create template file if HTML content is provided
            if template.html_content:
                template_path = self.pdf_generator.create_report_template(
                    f"template_{report_template.id}",
                    template.html_content
                )
                
                # Update template with file path
                await self.dashboard_repository.update_report_template(
                    report_template.id,
                    ReportTemplateUpdate(file_path=template_path)
                )
            
            return report_template
        except Exception as e:
            logger.error(f"Error creating report template: {str(e)}")
            raise
    
    async def get_report_file(self, report_id: int) -> Optional[bytes]:
        """
        Get a report file.
        
        Args:
            report_id: The report ID
            
        Returns:
            Report file content or None if not found
        """
        try:
            # Get report
            report = await self.dashboard_repository.get_report(report_id)
            
            if not report or not report.file_path:
                return None
            
            # Get file from storage
            file_content = await self.storage_manager.get_file(report.file_path)
            
            return file_content
        except Exception as e:
            logger.error(f"Error getting report file: {str(e)}")
            raise
    
    async def regenerate_report(self, report_id: int) -> bytes:
        """
        Regenerate a report.
        
        Args:
            report_id: The report ID
            
        Returns:
            Regenerated report file content
        """
        try:
            # Get report
            report = await self.dashboard_repository.get_report(report_id)
            
            if not report:
                raise ValueError(f"Report {report_id} not found")
            
            # Extract parameters
            time_range = TimeRange(report.parameters.get("time_range", "THIS_MONTH"))
            
            start_date_str = report.parameters.get("start_date")
            end_date_str = report.parameters.get("end_date")
            
            start_date = date.fromisoformat(start_date_str) if start_date_str else None
            end_date = date.fromisoformat(end_date_str) if end_date_str else None
            
            # Generate report
            pdf_content = await self.generate_player_report_pdf(
                report.player_id,
                report.template_id,
                time_range,
                start_date,
                end_date
            )
            
            return pdf_content
        except Exception as e:
            logger.error(f"Error regenerating report: {str(e)}")
            raise
