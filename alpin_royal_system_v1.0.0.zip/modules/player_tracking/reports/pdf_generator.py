"""
Casino Management System - PDF Report Generator
This module provides functionality for generating PDF reports.
"""

import logging
import os
from datetime import datetime, date
from typing import Dict, Any, List, Optional
import tempfile

from weasyprint import HTML, CSS
from weasyprint.text.fonts import FontConfiguration

from modules.player_tracking.models.dashboard import (
    ReportTemplate, Report, PlayerReportData, TimeRange
)

logger = logging.getLogger(__name__)

class PDFReportGenerator:
    """Class for generating PDF reports."""
    
    def __init__(self):
        """Initialize the PDF report generator."""
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.templates_dir = os.path.join(self.base_dir, "templates")
        self.css_dir = os.path.join(self.base_dir, "css")
        
        # Ensure directories exist
        os.makedirs(self.templates_dir, exist_ok=True)
        os.makedirs(self.css_dir, exist_ok=True)
        
        # Default CSS
        self.default_css = self._get_default_css()
        
        # Font configuration
        self.font_config = FontConfiguration()
    
    def _get_default_css(self) -> str:
        """
        Get default CSS for reports.
        
        Returns:
            Default CSS string
        """
        default_css_path = os.path.join(self.css_dir, "default.css")
        
        # Create default CSS if it doesn't exist
        if not os.path.exists(default_css_path):
            default_css = """
            @page {
                size: letter;
                margin: 2cm;
                @top-center {
                    content: "Casino Management System";
                    font-family: "Noto Sans CJK SC", "WenQuanYi Zen Hei", sans-serif;
                    font-size: 10pt;
                }
                @bottom-center {
                    content: "Page " counter(page) " of " counter(pages);
                    font-family: "Noto Sans CJK SC", "WenQuanYi Zen Hei", sans-serif;
                    font-size: 10pt;
                }
            }
            
            body {
                font-family: "Noto Sans CJK SC", "WenQuanYi Zen Hei", sans-serif;
                font-size: 12pt;
                line-height: 1.5;
            }
            
            h1, h2, h3, h4, h5, h6 {
                font-family: "Noto Sans CJK SC", "WenQuanYi Zen Hei", sans-serif;
                margin-top: 1em;
                margin-bottom: 0.5em;
                page-break-after: avoid;
            }
            
            h1 {
                font-size: 24pt;
                color: #333;
                border-bottom: 1px solid #ccc;
                padding-bottom: 0.3em;
            }
            
            h2 {
                font-size: 18pt;
                color: #444;
            }
            
            h3 {
                font-size: 16pt;
                color: #555;
            }
            
            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 1em;
                page-break-inside: avoid;
            }
            
            table, th, td {
                border: 1px solid #ddd;
            }
            
            th {
                background-color: #f2f2f2;
                padding: 8px;
                text-align: left;
                font-weight: bold;
            }
            
            td {
                padding: 8px;
                text-align: left;
            }
            
            tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            
            .header {
                text-align: center;
                margin-bottom: 2em;
            }
            
            .logo {
                max-width: 200px;
                margin-bottom: 1em;
            }
            
            .report-title {
                font-size: 28pt;
                font-weight: bold;
                margin-bottom: 0.5em;
            }
            
            .report-subtitle {
                font-size: 16pt;
                color: #666;
                margin-bottom: 0.5em;
            }
            
            .report-date {
                font-size: 12pt;
                color: #888;
            }
            
            .section {
                margin-bottom: 2em;
                page-break-inside: avoid;
            }
            
            .footer {
                text-align: center;
                font-size: 10pt;
                color: #888;
                margin-top: 2em;
                border-top: 1px solid #eee;
                padding-top: 1em;
            }
            
            .chart {
                width: 100%;
                max-width: 800px;
                margin: 1em auto;
                page-break-inside: avoid;
            }
            
            .summary-box {
                border: 1px solid #ddd;
                padding: 1em;
                margin-bottom: 1em;
                background-color: #f9f9f9;
                border-radius: 5px;
                page-break-inside: avoid;
            }
            
            .summary-title {
                font-weight: bold;
                font-size: 14pt;
                margin-bottom: 0.5em;
                color: #555;
            }
            
            .summary-value {
                font-size: 24pt;
                font-weight: bold;
                color: #333;
                margin-bottom: 0.2em;
            }
            
            .summary-label {
                font-size: 10pt;
                color: #888;
            }
            
            .summary-row {
                display: flex;
                justify-content: space-between;
                margin-bottom: 1em;
            }
            
            .summary-item {
                flex: 1;
                text-align: center;
                padding: 0.5em;
            }
            
            .positive {
                color: green;
            }
            
            .negative {
                color: red;
            }
            
            .neutral {
                color: #888;
            }
            
            @media print {
                .page-break {
                    page-break-before: always;
                }
            }
            """
            
            with open(default_css_path, "w") as f:
                f.write(default_css)
        
        # Read default CSS
        with open(default_css_path, "r") as f:
            return f.read()
    
    def _get_template_html(self, template_name: str) -> str:
        """
        Get HTML template for a report.
        
        Args:
            template_name: The template name
            
        Returns:
            Template HTML string
        """
        template_path = os.path.join(self.templates_dir, f"{template_name}.html")
        
        if not os.path.exists(template_path):
            raise ValueError(f"Template {template_name} not found")
        
        with open(template_path, "r") as f:
            return f.read()
    
    def _create_player_report_html(self, player_data: Dict[str, Any], report_data: PlayerReportData, 
                                  template: ReportTemplate, time_range: TimeRange,
                                  start_date: Optional[date] = None, end_date: Optional[date] = None) -> str:
        """
        Create HTML for a player report.
        
        Args:
            player_data: Player data
            report_data: Report data
            template: Report template
            time_range: Time range
            start_date: Start date (for custom time range)
            end_date: End date (for custom time range)
            
        Returns:
            Report HTML string
        """
        # Get time range description
        time_range_desc = self._get_time_range_description(time_range, start_date, end_date)
        
        # Create HTML
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Player Report - {player_data['full_name']}</title>
            <style>
                {self.default_css}
            </style>
        </head>
        <body>
            <div class="header">
                <h1 class="report-title">Player Activity Report</h1>
                <div class="report-subtitle">{player_data['full_name']} (ID: {player_data['casino_guest_id']})</div>
                <div class="report-date">Period: {time_range_desc}</div>
                <div class="report-date">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
            </div>
            
            <div class="section">
                <h2>Player Summary</h2>
                <div class="summary-box">
                    <div class="summary-row">
                        <div class="summary-item">
                            <div class="summary-label">Total Visits</div>
                            <div class="summary-value">{report_data.total_visits}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Total Hours</div>
                            <div class="summary-value">{report_data.total_hours:.1f}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Avg. Visit Duration</div>
                            <div class="summary-value">{report_data.avg_visit_duration_minutes / 60:.1f}h</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <h2>Gaming Activity</h2>
                <div class="summary-box">
                    <div class="summary-row">
                        <div class="summary-item">
                            <div class="summary-label">Table Games</div>
                            <div class="summary-value">{report_data.table_game_sessions}</div>
                            <div class="summary-label">Sessions</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Slot Machines</div>
                            <div class="summary-value">{report_data.slot_machine_sessions}</div>
                            <div class="summary-label">Sessions</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Avg. Bet</div>
                            <div class="summary-value">${report_data.avg_bet:.2f}</div>
                        </div>
                    </div>
                </div>
                
                <h3>Table Games</h3>
                <table>
                    <tr>
                        <th>Game</th>
                        <th>Sessions</th>
                        <th>Hours</th>
                        <th>Avg. Bet</th>
                        <th>Win/Loss</th>
                    </tr>
                    """
        
        # Add table game rows
        for game in report_data.table_games_summary:
            win_loss_class = "positive" if game.win_loss > 0 else "negative" if game.win_loss < 0 else "neutral"
            win_loss_sign = "+" if game.win_loss > 0 else ""
            
            html += f"""
                    <tr>
                        <td>{game.game_name}</td>
                        <td>{game.sessions}</td>
                        <td>{game.total_hours:.1f}</td>
                        <td>${game.avg_bet:.2f}</td>
                        <td class="{win_loss_class}">{win_loss_sign}${abs(game.win_loss):.2f}</td>
                    </tr>
                    """
        
        html += """
                </table>
                
                <h3>Slot Machines</h3>
                <table>
                    <tr>
                        <th>Machine</th>
                        <th>Sessions</th>
                        <th>Hours</th>
                        <th>Money In</th>
                        <th>Win/Loss</th>
                    </tr>
                    """
        
        # Add slot machine rows
        for machine in report_data.slot_machines_summary:
            win_loss_class = "positive" if machine.win_loss > 0 else "negative" if machine.win_loss < 0 else "neutral"
            win_loss_sign = "+" if machine.win_loss > 0 else ""
            
            html += f"""
                    <tr>
                        <td>{machine.machine_name}</td>
                        <td>{machine.sessions}</td>
                        <td>{machine.total_hours:.1f}</td>
                        <td>${machine.total_money_in:.2f}</td>
                        <td class="{win_loss_class}">{win_loss_sign}${abs(machine.win_loss):.2f}</td>
                    </tr>
                    """
        
        html += """
                </table>
            </div>
            
            <div class="page-break"></div>
            
            <div class="section">
                <h2>Financial Summary</h2>
                <div class="summary-box">
                    <div class="summary-row">
                        <div class="summary-item">
                            <div class="summary-label">Total Buy-ins</div>
                            <div class="summary-value">${report_data.financial_summary.total_buy_ins:.2f}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Total Cash-outs</div>
                            <div class="summary-value">${report_data.financial_summary.total_cash_outs:.2f}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Net Win/Loss</div>
                            <div class="summary-value ${report_data.financial_summary.net_win_loss > 0 and 'positive' or 'negative'}">${report_data.financial_summary.net_win_loss > 0 and '+' or ''}${report_data.financial_summary.net_win_loss:.2f}</div>
                        </div>
                    </div>
                </div>
                
                <h3>Jackpots & Hand Pays</h3>
                <table>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Machine/Game</th>
                        <th>Amount</th>
                    </tr>
                    """
        
        # Add jackpot rows
        for jackpot in report_data.jackpots:
            html += f"""
                    <tr>
                        <td>{jackpot.timestamp.strftime('%Y-%m-%d %H:%M')}</td>
                        <td>{jackpot.type}</td>
                        <td>{jackpot.source}</td>
                        <td>${jackpot.amount:.2f}</td>
                    </tr>
                    """
        
        html += """
                </table>
            </div>
            
            <div class="section">
                <h2>Consumption Summary</h2>
                <div class="summary-box">
                    <div class="summary-row">
                        <div class="summary-item">
                            <div class="summary-label">Food Items</div>
                            <div class="summary-value">{report_data.consumption_summary.food_items}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Drinks</div>
                            <div class="summary-value">{report_data.consumption_summary.drink_items}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Cigarette Packs</div>
                            <div class="summary-v<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>