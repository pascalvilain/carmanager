"""
Alpin Royal Casino Management System - Cigarette Inventory Repository
This module provides data access for cigarette inventory operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, update, delete, func, or_, and_
from sqlalchemy.orm import selectinload

from modules.player_tracking.models.consumption import (
    CigaretteInventory, CigaretteInventoryCreate, CigaretteInventoryUpdate,
    CigaretteTransaction, CigaretteTransactionCreate, CigaretteTransactionUpdate,
    CigaretteTransactionType
)
from base_layer.utils.database import get_db_session

logger = logging.getLogger(__name__)

class CigaretteInventoryRepository:
    """Repository for cigarette inventory-related database operations"""
    
    async def create_inventory_item(self, inventory_data: CigaretteInventoryCreate, db: AsyncSession) -> CigaretteInventory:
        """
        Create a new cigarette inventory item.
        
        Args:
            inventory_data: Cigarette inventory data
            db: Database session
            
        Returns:
            CigaretteInventory: Created cigarette inventory item
        """
        # Create cigarette inventory item
        now = datetime.now()
        inventory_dict = inventory_data.dict()
        inventory_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(CigaretteInventory).values(**inventory_dict).returning(CigaretteInventory)
        result = await db.execute(stmt)
        inventory = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created cigarette inventory item with ID {inventory.inventory_id}")
        
        return inventory
    
    async def update_inventory_item(self, inventory_id: int, inventory_data: CigaretteInventoryUpdate, db: AsyncSession) -> Optional[CigaretteInventory]:
        """
        Update a cigarette inventory item.
        
        Args:
            inventory_id: Cigarette inventory ID
            inventory_data: Cigarette inventory data to update
            db: Database session
            
        Returns:
            Optional[CigaretteInventory]: Updated cigarette inventory item or None if not found
        """
        # Check if cigarette inventory item exists
        inventory = await self.get_inventory_item_by_id(inventory_id, db)
        if not inventory:
            return None
        
        # Update cigarette inventory item
        update_data = inventory_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        stmt = (
            update(CigaretteInventory)
            .where(CigaretteInventory.inventory_id == inventory_id)
            .values(**update_data)
            .returning(CigaretteInventory)
        )
        result = await db.execute(stmt)
        updated_inventory = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated cigarette inventory item with ID {inventory_id}")
        
        return updated_inventory
    
    async def get_inventory_item_by_id(self, inventory_id: int, db: AsyncSession) -> Optional[CigaretteInventory]:
        """
        Get a cigarette inventory item by ID.
        
        Args:
            inventory_id: Cigarette inventory ID
            db: Database session
            
        Returns:
            Optional[CigaretteInventory]: Cigarette inventory item if found, None otherwise
        """
        stmt = select(CigaretteInventory).where(CigaretteInventory.inventory_id == inventory_id)
        result = await db.execute(stmt)
        inventory = result.scalar_one_or_none()
        
        return inventory
    
    async def get_inventory_item_by_brand_variant(self, brand: str, variant: Optional[str], db: AsyncSession) -> Optional[CigaretteInventory]:
        """
        Get a cigarette inventory item by brand and variant.
        
        Args:
            brand: Cigarette brand
            variant: Cigarette variant
            db: Database session
            
        Returns:
            Optional[CigaretteInventory]: Cigarette inventory item if found, None otherwise
        """
        if variant:
            stmt = select(CigaretteInventory).where(
                and_(
                    CigaretteInventory.brand == brand,
                    CigaretteInventory.variant == variant
                )
            )
        else:
            stmt = select(CigaretteInventory).where(
                and_(
                    CigaretteInventory.brand == brand,
                    CigaretteInventory.variant.is_(None)
                )
            )
        
        result = await db.execute(stmt)
        inventory = result.scalar_one_or_none()
        
        return inventory
    
    async def get_all_inventory_items(self, db: AsyncSession) -> List[CigaretteInventory]:
        """
        Get all cigarette inventory items.
        
        Args:
            db: Database session
            
        Returns:
            List[CigaretteInventory]: List of all cigarette inventory items
        """
        stmt = select(CigaretteInventory).order_by(CigaretteInventory.brand, CigaretteInventory.variant)
        result = await db.execute(stmt)
        inventory_items = result.scalars().all()
        
        return inventory_items
    
    async def get_low_stock_items(self, db: AsyncSession) -> List[CigaretteInventory]:
        """
        Get cigarette inventory items with low stock.
        
        Args:
            db: Database session
            
        Returns:
            List[CigaretteInventory]: List of cigarette inventory items with low stock
        """
        stmt = select(CigaretteInventory).where(
            CigaretteInventory.quantity <= CigaretteInventory.reorder_level
        ).order_by(CigaretteInventory.quantity)
        
        result = await db.execute(stmt)
        low_stock_items = result.scalars().all()
        
        return low_stock_items
    
    async def create_transaction(self, transaction_data: CigaretteTransactionCreate, db: AsyncSession) -> Tuple[CigaretteTransaction, CigaretteInventory]:
        """
        Create a new cigarette transaction and update inventory.
        
        Args:
            transaction_data: Cigarette transaction data
            db: Database session
            
        Returns:
            Tuple[CigaretteTransaction, CigaretteInventory]: Created transaction and updated inventory
        """
        # Get inventory item
        inventory = await self.get_inventory_item_by_id(transaction_data.inventory_id, db)
        if not inventory:
            raise ValueError(f"Inventory item with ID {transaction_data.inventory_id} not found")
        
        # Create transaction
        now = datetime.now()
        transaction_dict = transaction_data.dict()
        transaction_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(CigaretteTransaction).values(**transaction_dict).returning(CigaretteTransaction)
        result = await db.execute(stmt)
        transaction = result.scalar_one()
        
        # Update inventory quantity
        new_quantity = inventory.quantity
        if transaction.transaction_type == CigaretteTransactionType.PURCHASE:
            new_quantity += transaction.quantity
        elif transaction.transaction_type == CigaretteTransactionType.DISPENSED:
            new_quantity -= transaction.quantity
        elif transaction.transaction_type == CigaretteTransactionType.ADJUSTMENT:
            new_quantity = max(0, new_quantity + transaction.quantity)  # Prevent negative quantity
        elif transaction.transaction_type == CigaretteTransactionType.RETURN:
            new_quantity += transaction.quantity
        
        # Ensure quantity doesn't go below 0
        new_quantity = max(0, new_quantity)
        
        # Update inventory
        inventory_stmt = (
            update(CigaretteInventory)
            .where(CigaretteInventory.inventory_id == inventory.inventory_id)
            .values(quantity=new_quantity, updated_at=now)
            .returning(CigaretteInventory)
        )
        inventory_result = await db.execute(inventory_stmt)
        updated_inventory = inventory_result.scalar_one()
        
        await db.commit()
        logger.info(f"Created cigarette transaction with ID {transaction.transaction_id} and updated inventory")
        
        return transaction, updated_inventory
    
    async def get_transaction_by_id(self, transaction_id: int, db: AsyncSession) -> Optional[CigaretteTransaction]:
        """
        Get a cigarette transaction by ID.
        
        Args:
            transaction_id: Cigarette transaction ID
            db: Database session
            
        Returns:
            Optional[CigaretteTransaction]: Cigarette transaction if found, None otherwise
        """
        stmt = select(CigaretteTransaction).where(CigaretteTransaction.transaction_id == transaction_id)
        result = await db.execute(stmt)
        transaction = result.scalar_one_or_none()
        
        return transaction
    
    async def get_transactions_by_inventory_id(self, inventory_id: int, db: AsyncSession) -> List[CigaretteTransaction]:
        """
        Get all transactions for a cigarette inventory item.
        
        Args:
            inventory_id: Cigarette inventory ID
            db: Database session
            
        Returns:
            List[CigaretteTransaction]: List of cigarette transactions
        """
        stmt = (
            select(CigaretteTransaction)
            .where(CigaretteTransaction.inventory_id == inventory_id)
            .order_by(CigaretteTransaction.transaction_time.desc())
        )
        result = await db.execute(stmt)
        transactions = result.scalars().all()
        
        return transactions
    
    async def get_transactions_by_player_id(self, player_id: int, db: AsyncSession) -> List[CigaretteTransaction]:
        """
        Get all transactions for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            List[CigaretteTransaction]: List of cigarette transactions
        """
        stmt = (
            select(CigaretteTransaction)
            .where(CigaretteTransaction.player_id == player_id)
            .order_by(CigaretteTransaction.transaction_time.desc())
        )
        result = await db.execute(stmt)
        transactions = result.scalars().all()
        
        return transactions
    
    async def get_inventory_summary(self, db: AsyncSession) -> Dict[str, Any]:
        """
        Get a summary of cigarette inventory.
        
        Args:
            db: Database session
            
        Returns:
            Dict[str, Any]: Inventory summary
        """
        # Get total inventory items
        total_stmt = select(func.count(CigaretteInventory.inventory_id))
        total_result = await db.execute(total_stmt)
        total_items = total_result.scalar_one()
        
        # Get total quantity
        quantity_stmt = select(func.sum(CigaretteInventory.quantity))
        quantity_result = await db.execute(quantity_stmt)
        total_quantity = quantity_result.scalar_one() or 0
        
        # Get low stock count
        low_stock_stmt = select(func.count(CigaretteInventory.inventory_id)).where(
            CigaretteInventory.quantity <= CigaretteInventory.reorder_level
        )
        low_stock_result = await db.execute(low_stock_stmt)
        low_stock_count = low_stock_result.scalar_one()
        
        # Get most popular brand (by dispensed quantity)
        popular_stmt = (
            select(CigaretteInventory.brand, func.sum(CigaretteTransaction.quantity).label("total_dispensed"))
            .join(CigaretteTransaction, CigaretteInventory.inventory_id == CigaretteTransaction.inventory_id)
            .where(CigaretteTransaction.transaction_type == CigaretteTransactionType.DISPENSED)
            .group_by(CigaretteInventory.brand)
            .order_by(func.sum(CigaretteTransaction.quantity).desc())
            .limit(1)
        )
        popular_result = await db.execute(popular_stmt)
        popular_row = popular_result.first()
        most_popular_brand = popular_row[0] if popular_row else None
        
        # Get recent transactions
        recent_stmt = (
            select(CigaretteTransaction)
            .order_by(CigaretteTransaction.transaction_time.desc())
            .limit(10)
        )
        recent_result = await db.execute(recent_stmt)
        recent_transactions = recent_result.scalars().all()
        
        # Compile summary
        summary = {
            "total_items": total_items,
            "total_quantity": total_quantity,
            "low_stock_count": low_stock_count,
            "most_popular_brand": most_popular_brand,
            "recent_transactions": recent_transactions
        }
        
        return summary
