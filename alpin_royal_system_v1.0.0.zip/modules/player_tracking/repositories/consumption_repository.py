"""
Alpin Royal Casino Management System - Consumption Repository
This module provides data access for consumption-related operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, update, delete, func, or_, and_
from sqlalchemy.orm import selectinload

from modules.player_tracking.models.consumption import (
    ConsumptionItem, ConsumptionItemCreate, ConsumptionItemUpdate,
    PlayerConsumption, PlayerConsumptionCreate, PlayerConsumptionUpdate,
    ConsumptionSummary, ConsumptionSearch, ItemType
)
from base_layer.utils.database import get_db_session

logger = logging.getLogger(__name__)

class ConsumptionRepository:
    """Repository for consumption-related database operations"""
    
    async def create_consumption_item(self, item_data: ConsumptionItemCreate, db: AsyncSession) -> ConsumptionItem:
        """
        Create a new consumption item.
        
        Args:
            item_data: Consumption item data
            db: Database session
            
        Returns:
            ConsumptionItem: Created consumption item
        """
        # Create consumption item
        now = datetime.now()
        item_dict = item_data.dict()
        item_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(ConsumptionItem).values(**item_dict).returning(ConsumptionItem)
        result = await db.execute(stmt)
        item = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created consumption item with ID {item.item_id}")
        
        return item
    
    async def update_consumption_item(self, item_id: int, item_data: ConsumptionItemUpdate, db: AsyncSession) -> Optional[ConsumptionItem]:
        """
        Update a consumption item.
        
        Args:
            item_id: Consumption item ID
            item_data: Consumption item data to update
            db: Database session
            
        Returns:
            Optional[ConsumptionItem]: Updated consumption item or None if not found
        """
        # Check if consumption item exists
        item = await self.get_consumption_item_by_id(item_id, db)
        if not item:
            return None
        
        # Update consumption item
        update_data = item_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        stmt = (
            update(ConsumptionItem)
            .where(ConsumptionItem.item_id == item_id)
            .values(**update_data)
            .returning(ConsumptionItem)
        )
        result = await db.execute(stmt)
        updated_item = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated consumption item with ID {item_id}")
        
        return updated_item
    
    async def get_consumption_item_by_id(self, item_id: int, db: AsyncSession) -> Optional[ConsumptionItem]:
        """
        Get a consumption item by ID.
        
        Args:
            item_id: Consumption item ID
            db: Database session
            
        Returns:
            Optional[ConsumptionItem]: Consumption item if found, None otherwise
        """
        stmt = select(ConsumptionItem).where(ConsumptionItem.item_id == item_id)
        result = await db.execute(stmt)
        item = result.scalar_one_or_none()
        
        return item
    
    async def get_all_consumption_items(self, db: AsyncSession, item_type: Optional[ItemType] = None) -> List[ConsumptionItem]:
        """
        Get all consumption items, optionally filtered by type.
        
        Args:
            db: Database session
            item_type: Optional filter by item type
            
        Returns:
            List[ConsumptionItem]: List of consumption items
        """
        query = select(ConsumptionItem)
        
        if item_type:
            query = query.where(ConsumptionItem.item_type == item_type)
        
        # Only return active items
        query = query.where(ConsumptionItem.is_active == True)
        
        # Order by name
        query = query.order_by(ConsumptionItem.item_name)
        
        result = await db.execute(query)
        items = result.scalars().all()
        
        return items
    
    async def create_player_consumption(self, consumption_data: PlayerConsumptionCreate, db: AsyncSession) -> PlayerConsumption:
        """
        Create a new player consumption record.
        
        Args:
            consumption_data: Player consumption data
            db: Database session
            
        Returns:
            PlayerConsumption: Created player consumption record
        """
        # Create player consumption record
        now = datetime.now()
        consumption_dict = consumption_data.dict()
        consumption_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(PlayerConsumption).values(**consumption_dict).returning(PlayerConsumption)
        result = await db.execute(stmt)
        consumption = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created player consumption record with ID {consumption.consumption_id} for player {consumption.player_id}")
        
        return consumption
    
    async def update_player_consumption(self, consumption_id: int, consumption_data: PlayerConsumptionUpdate, db: AsyncSession) -> Optional[PlayerConsumption]:
        """
        Update a player consumption record.
        
        Args:
            consumption_id: Player consumption ID
            consumption_data: Player consumption data to update
            db: Database session
            
        Returns:
            Optional[PlayerConsumption]: Updated player consumption record or None if not found
        """
        # Check if player consumption record exists
        consumption = await self.get_player_consumption_by_id(consumption_id, db)
        if not consumption:
            return None
        
        # Update player consumption record
        update_data = consumption_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        stmt = (
            update(PlayerConsumption)
            .where(PlayerConsumption.consumption_id == consumption_id)
            .values(**update_data)
            .returning(PlayerConsumption)
        )
        result = await db.execute(stmt)
        updated_consumption = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated player consumption record with ID {consumption_id}")
        
        return updated_consumption
    
    async def get_player_consumption_by_id(self, consumption_id: int, db: AsyncSession) -> Optional[PlayerConsumption]:
        """
        Get a player consumption record by ID.
        
        Args:
            consumption_id: Player consumption ID
            db: Database session
            
        Returns:
            Optional[PlayerConsumption]: Player consumption record if found, None otherwise
        """
        stmt = (
            select(PlayerConsumption)
            .options(selectinload(PlayerConsumption.item))
            .where(PlayerConsumption.consumption_id == consumption_id)
        )
        result = await db.execute(stmt)
        consumption = result.scalar_one_or_none()
        
        return consumption
    
    async def search_player_consumptions(self, search_params: ConsumptionSearch, db: AsyncSession) -> List[PlayerConsumption]:
        """
        Search for player consumption records based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[PlayerConsumption]: List of matching player consumption records
        """
        query = (
            select(PlayerConsumption)
            .options(selectinload(PlayerConsumption.item))
        )
        
        # Apply filters
        filters = []
        if search_params.player_id is not None:
            filters.append(PlayerConsumption.player_id == search_params.player_id)
        
        if search_params.session_id is not None:
            filters.append(PlayerConsumption.session_id == search_params.session_id)
        
        if search_params.item_id is not None:
            filters.append(PlayerConsumption.item_id == search_params.item_id)
        
        if search_params.item_type is not None:
            # This requires a join with ConsumptionItem
            query = query.join(ConsumptionItem)
            filters.append(ConsumptionItem.item_type == search_params.item_type)
        
        if search_params.min_consumption_time is not None:
            filters.append(PlayerConsumption.consumption_time >= search_params.min_consumption_time)
        
        if search_params.max_consumption_time is not None:
            filters.append(PlayerConsumption.consumption_time <= search_params.max_consumption_time)
        
        if search_params.staff_id is not None:
            filters.append(PlayerConsumption.staff_id == search_params.staff_id)
        
        if filters:
            query = query.where(and_(*filters))
        
        # Apply pagination
        offset = (search_params.page - 1) * search_params.page_size
        query = query.offset(offset).limit(search_params.page_size)
        
        # Order by consumption time descending
        query = query.order_by(PlayerConsumption.consumption_time.desc())
        
        # Execute query
        result = await db.execute(query)
        consumptions = result.scalars().all()
        
        return consumptions
    
    async def get_player_consumption_summary(self, player_id: int, db: AsyncSession) -> ConsumptionSummary:
        """
        Get a summary of a player's consumption records.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            ConsumptionSummary: Summary of consumption records
        """
        # Initialize summary
        summary = ConsumptionSummary()
        
        # Get consumption counts by type
        # Food items
        food_stmt = (
            select(func.sum(PlayerConsumption.quantity))
            .join(ConsumptionItem)
            .where(
                and_(
                    PlayerConsumption.player_id == player_id,
                    ConsumptionItem.item_type == ItemType.FOOD
                )
            )
        )
        food_result = await db.execute(food_stmt)
        summary.total_food_items = food_result.scalar_one() or 0
        
        # Beverage items
        beverage_stmt = (
            select(func.sum(PlayerConsumption.quantity))
            .join(ConsumptionItem)
            .where(
                and_(
                    PlayerConsumption.player_id == player_id,
                    ConsumptionItem.item_type == ItemType.BEVERAGE
                )
            )
        )
        beverage_result = await db.execute(beverage_stmt)
        summary.total_beverage_items = beverage_result.scalar_one() or 0
        
        # Cigarette packs
        cigarette_stmt = (
            select(func.sum(PlayerConsumption.quantity))
            .join(ConsumptionItem)
            .where(
                and_(
                    PlayerConsumption.player_id == player_id,
                    ConsumptionItem.item_type == ItemType.CIGARETTE
                )
            )
        )
        cigarette_result = await db.execute(cigarette_stmt)
        summary.total_cigarette_packs = cigarette_result.scalar_one() or 0
        
        # Other items
        other_stmt = (
            select(func.sum(PlayerConsumption.quantity))
            .join(ConsumptionItem)
            .where(
                and_(
                    PlayerConsumption.player_id == player_id,
                    ConsumptionItem.item_type == ItemType.OTHER
                )
            )
        )
        other_result = await db.execute(other_stmt)
        summary.total_other_items = other_result.scalar_one() or 0
        
        # Get total value
        value_stmt = (
            select(func.sum(ConsumptionItem.price * PlayerConsumption.quantity))
            .join(ConsumptionItem)
            .where(PlayerConsumption.player_id == player_id)
        )
        value_result = await db.execute(value_stmt)
        summary.total_value = value_result.scalar_one() or 0
        
        # Get favorite food
        favorite_food_stmt = (
            select(ConsumptionItem.item_name)
            .join(PlayerConsumption)
            .where(
                and_(
                    PlayerConsumption.player_id == player_id,
                    ConsumptionItem.item_type == ItemType.FOOD
                )
            )
            .group_by(ConsumptionItem.item_id, ConsumptionItem.item_name)
            .order_by(func.sum(PlayerConsumption.quantity).desc())
            .limit(1)
        )
        favorite_food_result = await db.execute(favorite_food_stmt)
        summary.favorite_food = favorite_food_result.scalar_one_or_none()
        
        # Get favorite beverage
        favorite_beverage_stmt = (
            select(ConsumptionItem.item_name)
            .join(PlayerConsumption)
            .where(
                and_(
                    PlayerConsumption.player_id == player_id,
                    ConsumptionItem.item_type == ItemType.BEVERAGE
                )
            )
            .group_by(ConsumptionItem.item_id, ConsumptionItem.item_name)
            .order_by(func.sum(PlayerConsumption.quantity).desc())
            .limit(1)
        )
        favorite_beverage_result = await db.execute(favorite_beverage_stmt)
        summary.favorite_beverage = favorite_beverage_result.scalar_one_or_none()
        
        # Get favorite cigarette
        favorite_cigarette_stmt = (
            select(ConsumptionItem.item_name)
            .join(PlayerConsumption)
            .where(
                and_(
                    PlayerConsumption.player_id == player_id,
                    ConsumptionItem.item_type == ItemType.CIGARETTE
                )
            )
            .group_by(ConsumptionItem.item_id, ConsumptionItem.item_name)
            .order_by(func.sum(PlayerConsumption.quantity).desc())
            .limit(1)
        )
        favorite_cigarette_result = await db.execute(favorite_cigarette_stmt)
        summary.favorite_cigarette = favorite_cigarette_result.scalar_one_or_none()
        
        # Get last consumption time
        last_stmt = (
            select(PlayerConsumption.consumption_time)
            .where(PlayerConsumption.player_id == player_id)
            .order_by(PlayerConsumption.consumption_time.desc())
            .limit(1)
        )
        last_result = await db.execute(last_stmt)
        summary.last_consumption_time = last_result.scalar_one_or_none()
        
        return summary
