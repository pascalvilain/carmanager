"""
Alpin Royal Casino Management System - Player Repository
This module provides data access for player-related operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, update, delete, func, or_, and_
from sqlalchemy.orm import selectinload

from modules.player_tracking.models.player import (
    Player, PlayerCreate, PlayerUpdate, PlayerSummary, 
    PlayerSearch, PlayerPhoto, PlayerPhotoCreate
)
from base_layer.utils.database import get_db_session, get_elasticsearch_client

logger = logging.getLogger(__name__)

class PlayerRepository:
    """Repository for player-related database operations"""
    
    async def create_player(self, player_data: PlayerCreate, db: AsyncSession) -> Player:
        """
        Create a new player.
        
        Args:
            player_data: Player data
            db: Database session
            
        Returns:
            Player: Created player
        """
        # Generate casino guest ID
        casino_guest_id = await self._generate_casino_guest_id(db)
        
        # Create player
        now = datetime.now()
        player_dict = player_data.dict()
        player_dict.update({
            "casino_guest_id": casino_guest_id,
            "registration_date": now,
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(Player).values(**player_dict).returning(Player)
        result = await db.execute(stmt)
        player = result.scalar_one()
        
        # Index in Elasticsearch for search
        await self._index_player(player)
        
        await db.commit()
        logger.info(f"Created player with ID {player.player_id}")
        
        return player
    
    async def update_player(self, player_id: int, player_data: PlayerUpdate, db: AsyncSession) -> Optional[Player]:
        """
        Update a player.
        
        Args:
            player_id: Player ID
            player_data: Player data to update
            db: Database session
            
        Returns:
            Optional[Player]: Updated player or None if not found
        """
        # Check if player exists
        player = await self.get_player_by_id(player_id, db)
        if not player:
            return None
        
        # Update player
        update_data = player_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        stmt = (
            update(Player)
            .where(Player.player_id == player_id)
            .values(**update_data)
            .returning(Player)
        )
        result = await db.execute(stmt)
        updated_player = result.scalar_one()
        
        # Update in Elasticsearch
        await self._update_player_index(updated_player)
        
        await db.commit()
        logger.info(f"Updated player with ID {player_id}")
        
        return updated_player
    
    async def delete_player(self, player_id: int, db: AsyncSession) -> bool:
        """
        Delete a player (soft delete by setting is_active to False).
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            bool: True if player was deleted, False if not found
        """
        # Check if player exists
        player = await self.get_player_by_id(player_id, db)
        if not player:
            return False
        
        # Soft delete player
        stmt = (
            update(Player)
            .where(Player.player_id == player_id)
            .values(is_active=False, updated_at=datetime.now())
        )
        await db.execute(stmt)
        
        # Update in Elasticsearch
        es = get_elasticsearch_client()
        await es.update(
            index="players",
            id=str(player_id),
            body={"doc": {"is_active": False}}
        )
        
        await db.commit()
        logger.info(f"Soft deleted player with ID {player_id}")
        
        return True
    
    async def get_player_by_id(self, player_id: int, db: AsyncSession) -> Optional[Player]:
        """
        Get a player by ID.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            Optional[Player]: Player if found, None otherwise
        """
        stmt = (
            select(Player)
            .options(selectinload(Player.photos))
            .where(Player.player_id == player_id)
        )
        result = await db.execute(stmt)
        player = result.scalar_one_or_none()
        
        return player
    
    async def get_player_by_casino_guest_id(self, casino_guest_id: str, db: AsyncSession) -> Optional[Player]:
        """
        Get a player by casino guest ID.
        
        Args:
            casino_guest_id: Casino guest ID
            db: Database session
            
        Returns:
            Optional[Player]: Player if found, None otherwise
        """
        stmt = (
            select(Player)
            .options(selectinload(Player.photos))
            .where(Player.casino_guest_id == casino_guest_id)
        )
        result = await db.execute(stmt)
        player = result.scalar_one_or_none()
        
        return player
    
    async def search_players(self, search_params: PlayerSearch, db: AsyncSession) -> List[PlayerSummary]:
        """
        Search for players based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[PlayerSummary]: List of matching players
        """
        # If there's a text query, use Elasticsearch
        if search_params.query:
            return await self._search_players_elasticsearch(search_params)
        
        # Otherwise, use SQL
        query = select(Player)
        
        # Apply filters
        filters = []
        if search_params.casino_guest_id:
            filters.append(Player.casino_guest_id.ilike(f"%{search_params.casino_guest_id}%"))
        
        if search_params.first_name:
            filters.append(Player.first_name.ilike(f"%{search_params.first_name}%"))
        
        if search_params.last_name:
            filters.append(Player.last_name.ilike(f"%{search_params.last_name}%"))
        
        if search_params.vip_status:
            filters.append(Player.vip_status == search_params.vip_status)
        
        if search_params.is_active is not None:
            filters.append(Player.is_active == search_params.is_active)
        
        if search_params.min_registration_date:
            filters.append(Player.registration_date >= search_params.min_registration_date)
        
        if search_params.max_registration_date:
            filters.append(Player.registration_date <= search_params.max_registration_date)
        
        if search_params.min_last_visit_date:
            filters.append(Player.last_visit_date >= search_params.min_last_visit_date)
        
        if search_params.max_last_visit_date:
            filters.append(Player.last_visit_date <= search_params.max_last_visit_date)
        
        if filters:
            query = query.where(and_(*filters))
        
        # Apply pagination
        offset = (search_params.page - 1) * search_params.page_size
        query = query.offset(offset).limit(search_params.page_size)
        
        # Execute query
        result = await db.execute(query)
        players = result.scalars().all()
        
        # Convert to summary model
        return [PlayerSummary.from_orm(player) for player in players]
    
    async def _search_players_elasticsearch(self, search_params: PlayerSearch) -> List[PlayerSummary]:
        """
        Search for players using Elasticsearch.
        
        Args:
            search_params: Search parameters
            
        Returns:
            List[PlayerSummary]: List of matching players
        """
        es = get_elasticsearch_client()
        
        # Build query
        query = {
            "bool": {
                "must": [
                    {
                        "multi_match": {
                            "query": search_params.query,
                            "fields": [
                                "first_name^2",
                                "last_name^2",
                                "casino_guest_id^3",
                                "email",
                                "phone_number",
                                "address_line1",
                                "city",
                                "country"
                            ],
                            "fuzziness": "AUTO"
                        }
                    }
                ],
                "filter": []
            }
        }
        
        # Apply filters
        if search_params.vip_status:
            query["bool"]["filter"].append({"term": {"vip_status": search_params.vip_status}})
        
        if search_params.is_active is not None:
            query["bool"]["filter"].append({"term": {"is_active": search_params.is_active}})
        
        if search_params.min_registration_date:
            query["bool"]["filter"].append({
                "range": {
                    "registration_date": {"gte": search_params.min_registration_date.isoformat()}
                }
            })
        
        if search_params.max_registration_date:
            query["bool"]["filter"].append({
                "range": {
                    "registration_date": {"lte": search_params.max_registration_date.isoformat()}
                }
            })
        
        if search_params.min_last_visit_date:
            query["bool"]["filter"].append({
                "range": {
                    "last_visit_date": {"gte": search_params.min_last_visit_date.isoformat()}
                }
            })
        
        if search_params.max_last_visit_date:
            query["bool"]["filter"].append({
                "range": {
                    "last_visit_date": {"lte": search_params.max_last_visit_date.isoformat()}
                }
            })
        
        # Execute search
        from_ = (search_params.page - 1) * search_params.page_size
        size = search_params.page_size
        
        response = await es.search(
            index="players",
            body={
                "query": query,
                "from": from_,
                "size": size,
                "sort": [
                    {"_score": {"order": "desc"}},
                    {"last_visit_date": {"order": "desc", "missing": "_last"}}
                ]
            }
        )
        
        # Process results
        hits = response["hits"]["hits"]
        player_summaries = []
        
        for hit in hits:
            source = hit["_source"]
            player_summary = PlayerSummary(
                player_id=source["player_id"],
                casino_guest_id=source["casino_guest_id"],
                first_name=source["first_name"],
                last_name=source["last_name"],
                vip_status=source["vip_status"],
                last_visit_date=source.get("last_visit_date"),
                is_active=source["is_active"]
            )
            player_summaries.append(player_summary)
        
        return player_summaries
    
    async def _index_player(self, player: Player) -> None:
        """
        Index a player in Elasticsearch.
        
        Args:
            player: Player to index
        """
        es = get_elasticsearch_client()
        
        # Prepare document
        doc = {
            "player_id": player.player_id,
            "casino_guest_id": player.casino_guest_id,
            "first_name": player.first_name,
            "last_name": player.last_name,
            "date_of_birth": player.date_of_birth.isoformat() if player.date_of_birth else None,
            "gender": player.gender,
            "nationality": player.nationality,
            "email": player.email,
            "phone_number": player.phone_number,
            "address_line1": player.address_line1,
            "address_line2": player.address_line2,
            "city": player.city,
            "state_province": player.state_province,
            "postal_code": player.postal_code,
            "country": player.country,
            "vip_status": player.vip_status,
            "registration_date": player.registration_date.isoformat(),
            "last_visit_date": player.last_visit_date.isoformat() if player.last_visit_date else None,
            "preferred_cigarette_brand": player.preferred_cigarette_brand,
            "is_active": player.is_active
        }
        
        # Index document
        await es.index(
            index="players",
            id=str(player.player_id),
            body=doc
        )
    
    async def _update_player_index(self, player: Player) -> None:
        """
        Update a player in Elasticsearch.
        
        Args:
            player: Player to update
        """
        es = get_elasticsearch_client()
        
        # Prepare document
        doc = {
            "first_name": player.first_name,
            "last_name": player.last_name,
            "date_of_birth": player.date_of_birth.isoformat() if player.date_of_birth else None,
            "gender": player.gender,
            "nationality": player.nationality,
            "email": player.email,
            "phone_number": player.phone_number,
            "address_line1": player.address_line1,
            "address_line2": player.address_line2,
            "city": player.city,
            "state_province": player.state_province,
            "postal_code": player.postal_code,
            "country": player.country,
            "vip_status": player.vip_status,
            "last_visit_date": player.last_visit_date.isoformat() if player.last_visit_date else None,
            "preferred_cigarette_brand": player.preferred_cigarette_brand,
            "is_active": player.is_active
        }
        
        # Update document
        await es.update(
            index="players",
            id=str(player.player_id),
            body={"doc": doc}
        )
    
    async def _generate_casino_guest_id(self, db: AsyncSession) -> str:
        """
        Generate a unique casino guest ID.
        
        Args:
            db: Database session
            
        Returns:
            str: Unique casino guest ID
        """
        # Get the current highest ID
        stmt = select(func.max(Player.player_id))
        result = await db.execute(stmt)
        max_id = result.scalar_one_or_none() or 0
        
        # Generate new ID with prefix AR (Alpin Royal)
        new_id = max_id + 1
        casino_guest_id = f"AR{new_id:06d}"
        
        return casino_guest_id
    
    async def add_player_photo(self, photo_data: PlayerPhotoCreate, storage_path: str, db: AsyncSession) -> PlayerPhoto:
        """
        Add a photo to a player.
        
        Args:
            photo_data: Photo data
            storage_path: Path where the photo is stored
            db: Database session
            
        Returns:
            PlayerPhoto: Created photo
        """
        # Create photo
        now = datetime.now()
        photo_dict = photo_data.dict()
        photo_dict.update({
            "storage_path": storage_path,
            "upload_date": now,
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(PlayerPhoto).values(**photo_dict).returning(PlayerPhoto)
        result = await db.execute(stmt)
        photo = result.scalar_one()
        
        await db.commit()
        logger.info(f"Added photo {photo.photo_id} to player {photo_data.player_id}")
        
        return photo
    
    async def get_player_photos(self, player_id: int, db: AsyncSession) -> List[PlayerPhoto]:
        """
        Get all photos for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            List[PlayerPhoto]: List of player photos
        """
        stmt = select(PlayerPhoto).where(PlayerPhoto.player_id == player_id)
        result = await db.execute(stmt)
        photos = result.scalars().all()
        
        return photos
    
    async def update_last_visit_date(self, player_id: int, visit_date: datetime, db: AsyncSession) -> bool:
        """
        Update the last visit date for a player.
        
        Args:
            player_id: Player ID
            visit_date: Visit date
            db: Database session
            
        Returns:
            bool: True if player was updated, False if not found
        """
        # Check if player exists
        player = await self.get_player_by_id(player_id, db)
        if not player:
            return False
        
        # Update last visit date
        stmt = (
            update(Player)
            .where(Player.player_id == player_id)
            .values(last_visit_date=visit_date, updated_at=datetime.now())
        )
        await db.execute(stmt)
        
        # Update in Elasticsearch
        es = get_elasticsearch_client()
        await es.update(
            index="players",
            id=str(player_id),
            body={"doc": {"last_visit_date": visit_date.isoformat()}}
        )
        
        await db.commit()
        logger.info(f"Updated last visit date for player {player_id}")
        
        return True
