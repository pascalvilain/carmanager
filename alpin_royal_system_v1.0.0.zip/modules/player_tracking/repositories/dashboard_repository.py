"""
Casino Management System - Dashboard Repository
This module provides data access for dashboard and reporting operations.
"""

import logging
from typing import List, Optional, Dict, Any
from datetime import datetime, date, timedelta

from base_layer.utils.database import get_postgres_connection, get_mongodb_collection, get_redis_client

from modules.player_tracking.models.dashboard import (
    Dashboard, DashboardCreate, DashboardUpdate,
    DashboardWidget, DashboardWidgetCreate, DashboardWidgetUpdate,
    ReportTemplate, ReportTemplateCreate, ReportTemplateUpdate,
    Report, ReportCreate, ReportUpdate, PlayerReportData,
    TimeRange
)

logger = logging.getLogger(__name__)

class DashboardRepository:
    """Repository for dashboard and reporting data access."""
    
    async def create_dashboard(self, dashboard: DashboardCreate) -> Dashboard:
        """
        Create a new dashboard.
        
        Args:
            dashboard: The dashboard data
            
        Returns:
            The created dashboard
        """
        try:
            # Get database connection
            conn = await get_postgres_connection()
            
            # Start transaction
            async with conn.transaction():
                # Create dashboard
                query = """
                    INSERT INTO dashboards (
                        name, description, is_default, is_public, owner_id,
                        layout_config, is_active
                    ) VALUES (
                        $1, $2, $3, $4, $5, $6, $7
                    ) RETURNING 
                        dashboard_id, name, description, is_default, is_public,
                        owner_id, layout_config, is_active, created_at, updated_at
                """
                
                values = (
                    dashboard.name, dashboard.description, dashboard.is_default,
                    dashboard.is_public, dashboard.owner_id, dashboard.layout_config,
                    dashboard.is_active
                )
                
                row = await conn.fetchrow(query, *values)
                
                # Create widgets if provided
                widgets = []
                if dashboard.widgets:
                    for widget in dashboard.widgets:
                        widget_query = """
                            INSERT INTO dashboard_widgets (
                                dashboard_id, title, chart_type, time_range,
                                custom_start_date, custom_end_date, refresh_interval_minutes,
                                position_x, position_y, width, height, config, is_active
                            ) VALUES (
                                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13
                            ) RETURNING 
                                widget_id, dashboard_id, title, chart_type, time_range,
                                custom_start_date, custom_end_date, refresh_interval_minutes,
                                position_x, position_y, width, height, config, is_active,
                                created_at, updated_at
                        """
                        
                        widget_values = (
                            row["dashboard_id"], widget.title, widget.chart_type.value,
                            widget.time_range.value, widget.custom_start_date,
                            widget.custom_end_date, widget.refresh_interval_minutes,
                            widget.position_x, widget.position_y, widget.width,
                            widget.height, widget.config, widget.is_active
                        )
                        
                        widget_row = await conn.fetchrow(widget_query, *widget_values)
                        
                        # Convert row to DashboardWidget model
                        widgets.append(DashboardWidget(
                            widget_id=widget_row["widget_id"],
                            title=widget_row["title"],
                            chart_type=widget_row["chart_type"],
                            time_range=widget_row["time_range"],
                            custom_start_date=widget_row["custom_start_date"],
                            custom_end_date=widget_row["custom_end_date"],
                            refresh_interval_minutes=widget_row["refresh_interval_minutes"],
                            position_x=widget_row["position_x"],
                            position_y=widget_row["position_y"],
                            width=widget_row["width"],
                            height=widget_row["height"],
                            config=widget_row["config"],
                            is_active=widget_row["is_active"],
                            created_at=widget_row["created_at"],
                            updated_at=widget_row["updated_at"]
                        ))
            
            # Convert row to Dashboard model
            return Dashboard(
                dashboard_id=row["dashboard_id"],
                name=row["name"],
                description=row["description"],
                is_default=row["is_default"],
                is_public=row["is_public"],
                owner_id=row["owner_id"],
                layout_config=row["layout_config"],
                is_active=row["is_active"],
                widgets=widgets,
                created_at=row["created_at"],
                updated_at=row["updated_at"]
            )
            
        except Exception as e:
            logger.error(f"Error creating dashboard: {str(e)}")
            raise
        finally:
            # Release connection
            if 'conn' in locals():
                await conn.close()
    
    async def get_dashboard(self, dashboard_id: int) -> Optional[Dashboard]:
        """
        Get a dashboard by ID.
        
        Args:
            dashboard_id: The dashboard ID
            
        Returns:
            The dashboard or None if not found
        """
        try:
            # Get database connection
            conn = await get_postgres_connection()
            
            # Get dashboard
            query = """
                SELECT 
                    dashboard_id, name, description, is_default, is_public,
                    owner_id, layout_config, is_active, created_at, updated_at
                FROM dashboards
                WHERE dashboard_id = $1
            """
            
            row = await conn.fetchrow(query, dashboard_id)
            
            if not row:
                return None
            
            # Get widgets
            widget_query = """
                SELECT 
                    widget_id, dashboard_id, title, chart_type, time_range,
                    custom_start_date, custom_end_date, refresh_interval_minutes,
                    position_x, position_y, width, height, config, is_active,
                    created_at, updated_at
                FROM dashboard_widgets
                WHERE dashboard_id = $1
                ORDER BY position_y, position_x
            """
            
            widget_rows = await conn.fetch(widget_query, dashboard_id)
            
            # Convert rows to DashboardWidget models
            widgets = []
            for widget_row in widget_rows:
                widgets.append(DashboardWidget(
                    widget_id=widget_row["widget_id"],
                    title=widget_row["title"],
                    chart_type=widget_row["chart_type"],
                    time_range=widget_row["time_range"],
                    custom_start_date=widget_row["custom_start_date"],
                    custom_end_date=widget_row["custom_end_date"],
                    refresh_interval_minutes=widget_row["refresh_interval_minutes"],
                    position_x=widget_row["position_x"],
                    position_y=widget_row["position_y"],
                    width=widget_row["width"],
                    height=widget_row["height"],
                    config=widget_row["config"],
                    is_active=widget_row["is_active"],
                    created_at=widget_row["created_at"],
                    updated_at=widget_row["updated_at"]
                ))
                
            # Convert row to Dashboard model
            return Dashboard(
                dashboard_id=row["dashboard_id"],
                name=row["name"],
                description=row["description"],
                is_default=row["is_default"],
                is_public=row["is_public"],
                owner_id=row["owner_id"],
                layout_config=row["layout_config"],
                is_active=row["is_active"],
                widgets=widgets,
                created_at=row["created_at"],
                updated_at=row["updated_at"]
            )
            
        except Exception as e:
            logger.error(f"Error getting dashboard {dashboard_id}: {str(e)}")
            raise
        finally:
            # Release connection
            if 'conn' in locals():
                await conn.close()
    
    async def update_dashboard(self, dashboard_id: int, dashboard_update: DashboardUpdate) -> Optional[Dashboard]:
        """
        Update a dashboard.
        
        Args:
            dashboard_id: The dashboard ID
            dashboard_update: The dashboard update data
            
        Returns:
            The updated dashboard or None if not found
        """
        try:
            # Get database connection
            conn = await get_postgres_connection()
            
            # Build update query
            update_fields = []
            update_values = []
            update_index = 1
            
            # Add fields that are not None
            for field, value in dashboard_update.dict(exclude_unset=True).items():
                if value is not None:
                    update_fields.append(f"{field} = ${update_index}")
                    update_values.append(value)
                    update_index += 1
            
            # Add updated_at field
            update_fields.append(f"updated_at = ${update_index}")
            update_values.append(datetime.utcnow())
            update_index += 1
            
            # If no fields to update, return current dashboard
            if not update_fields:
                return await self.get_dashboard(dashboard_id)
            
            # Build query
            query = f"""
                UPDATE dashboards
                SET {", ".join(update_fields)}
                WHERE dashboard_id = ${update_index}
                RETURNING 
                    dashboard_id, name, description, is_default, is_public,
                    owner_id, layout_config, is_active, created_at, updated_at
            """
            
            # Add dashboard_id to values
            update_values.append(dashboard_id)
            
            # Execute query
            row = await conn.fetchrow(query, *update_values)
            
            if not row:
                return None
            
            # Get widgets
            widget_query = """
                SELECT 
                    widget_id, dashboard_id, title, chart_type, time_range,
                    custom_start_date, custom_end_date, refresh_interval_minutes,
                    position_x, position_y, width, height, config, is_active,
                    created_at, updated_at
                FROM dashboard_widgets
                WHERE dashboard_id = $1
                ORDER BY position_y, position_x
            """
            
            widget_rows = await conn.fetch(widget_query, dashboard_id)
            
            # Convert rows to DashboardWidget models
            widgets = []
            for widget_row in widget_rows:
                widgets.append(DashboardWidget(
                    widget_id=widget_row["widget_id"],
                    title=widget_row["title"],
                    chart_type=widget_row["chart_type"],
                    time_range=widget_row["time_range"],
                    custom_start_date=widget_row["custom_start_date"],
                    custom_end_date=widget_row["custom_end_date"],
                    refresh_interval_minutes=widget_row["refresh_interval_minutes"],
                    position_x=widget_row["position_x"],
                    position_y=widget_row["position_y"],
                    width=widget_row["width"],
                    height=widget_row["height"],
                    config=widget_row["config"],
                    is_active=widget_row["is_active"],
                    created_at=widget_row["created_at"],
                    updated_at=widget_row["updated_at"]
                ))
            
            # Convert row to Dashboard model
            return Dashboard(
                dashboard_id=row["dashboard_id"],
                name=row["name"],
                description=row["description"],
                is_default=row["is_default"],
                is_public=row["is_public"],
                owner_id=row["owner_id"],
                layout_config=row["layout_config"],
                is_active=row["is_active"],
                widgets=widgets,
                created_at=row["created_at"],
                updated_at=row["updated_at"]
            )
            
        except Exception as e:
            logger.error(f"Error updating dashboard {dashboard_id}: {str(e)}")
            raise
        finally:
            # Release connection
            if 'conn' in locals():
                await conn.close()
    
    async def delete_dashboard(self, dashboard_id: int) -> bool:
        """
        Delete a dashboard (mark as inactive).
        
        Args:
            dashboard_id: The dashboard ID
            
        Returns:
            True if the dashboard was deleted, False otherwise
        """
        try:
            # Get database connection
            conn = await get_postgres_connection()
            
            # Mark dashboard as inactive
            query = """
                UPDATE dashboards
                SET is_active = FALSE, updated_at = $1
                WHERE dashboard_id = $2
                RETURNING dashboard_id
            """
            
            row = await conn.fetchrow(query, datetime.utcnow(), dashboard_id)
            
            return row is not None
            
        except Exception as e:
            logger.error(f"Error deleting dashboard {dashboard_id}: {str(e)}")
            raise
        finally:
            # Release connection
            if 'conn' in locals():
                await conn.close()
    
    async def get_dashboards(self, owner_id: Optional[int] = None, is_public: Optional[bool] = None, is_active: bool = True) -> List[Dashboard]:
        """
        Get dashboards.
        
        Args:
            owner_id: Filter by owner ID
            is_public: Filter by public status
            is_active: Filter by active status
            
        Returns:
            List of dashboards
        """
        try:
            # Get database connection
            conn = await get_postgres_connection()
            
            # Build where clause
            where_clauses = ["is_active = $1"]
            where_values = [is_active]
            where_index = 2
            
            if owner_id is not None:
                where_clauses.append(f"owner_id = ${where_index}")
                where_values.append(owner_id)
                where_index += 1
                
            if is_public is not None:
                where_clauses.append(f"is_public = ${where_index}")
                where_values.append(is_public)
                where_index += 1
            
            # Build query
            query = f"""
                SELECT 
                    dashboard_id, name, description, is_default, is_public,
                    owner_id, layout_config, i<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>