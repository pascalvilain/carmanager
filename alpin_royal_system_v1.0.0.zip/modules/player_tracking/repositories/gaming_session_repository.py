"""
Alpin Royal Casino Management System - Gaming Session Repository
This module provides data access for gaming session-related operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, update, delete, func, or_, and_
from sqlalchemy.orm import selectinload

from modules.player_tracking.models.gaming_session import (
    GamingSession, GamingSessionCreate, GamingSessionUpdate, GamingSessionSearch,
    TableGame, TableGameCreate, TableGameUpdate,
    SlotMachine, SlotMachineCreate, SlotMachineUpdate,
    TableGameActivity, TableGameActivityCreate, TableGameActivityUpdate,
    SlotMachineActivity, SlotMachineActivityCreate, SlotMachineActivityUpdate,
    SessionStatus
)
from base_layer.utils.database import get_db_session

logger = logging.getLogger(__name__)

class GamingSessionRepository:
    """Repository for gaming session-related database operations"""
    
    async def create_gaming_session(self, session_data: GamingSessionCreate, db: AsyncSession) -> GamingSession:
        """
        Create a new gaming session.
        
        Args:
            session_data: Gaming session data
            db: Database session
            
        Returns:
            GamingSession: Created gaming session
        """
        # Create gaming session
        now = datetime.now()
        session_dict = session_data.dict()
        session_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(GamingSession).values(**session_dict).returning(GamingSession)
        result = await db.execute(stmt)
        session = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created gaming session with ID {session.session_id} for player {session.player_id}")
        
        return session
    
    async def update_gaming_session(self, session_id: int, session_data: GamingSessionUpdate, db: AsyncSession) -> Optional[GamingSession]:
        """
        Update a gaming session.
        
        Args:
            session_id: Gaming session ID
            session_data: Gaming session data to update
            db: Database session
            
        Returns:
            Optional[GamingSession]: Updated gaming session or None if not found
        """
        # Check if gaming session exists
        session = await self.get_gaming_session_by_id(session_id, db)
        if not session:
            return None
        
        # Update gaming session
        update_data = session_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        # Calculate duration if end_time is provided but duration_minutes is not
        if "end_time" in update_data and "duration_minutes" not in update_data and update_data["end_time"] is not None:
            duration = (update_data["end_time"] - session.start_time).total_seconds() / 60
            update_data["duration_minutes"] = int(duration)
        
        stmt = (
            update(GamingSession)
            .where(GamingSession.session_id == session_id)
            .values(**update_data)
            .returning(GamingSession)
        )
        result = await db.execute(stmt)
        updated_session = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated gaming session with ID {session_id}")
        
        return updated_session
    
    async def end_gaming_session(self, session_id: int, end_time: Optional[datetime] = None, db: AsyncSession) -> Optional[GamingSession]:
        """
        End a gaming session.
        
        Args:
            session_id: Gaming session ID
            end_time: End time, defaults to current time
            db: Database session
            
        Returns:
            Optional[GamingSession]: Updated gaming session or None if not found
        """
        # Check if gaming session exists
        session = await self.get_gaming_session_by_id(session_id, db)
        if not session:
            return None
        
        # Set end time if not provided
        if end_time is None:
            end_time = datetime.now()
        
        # Calculate duration
        duration = (end_time - session.start_time).total_seconds() / 60
        
        # Update gaming session
        update_data = {
            "end_time": end_time,
            "duration_minutes": int(duration),
            "status": SessionStatus.COMPLETED,
            "updated_at": datetime.now()
        }
        
        stmt = (
            update(GamingSession)
            .where(GamingSession.session_id == session_id)
            .values(**update_data)
            .returning(GamingSession)
        )
        result = await db.execute(stmt)
        updated_session = result.scalar_one()
        
        await db.commit()
        logger.info(f"Ended gaming session with ID {session_id}")
        
        return updated_session
    
    async def get_gaming_session_by_id(self, session_id: int, db: AsyncSession) -> Optional[GamingSession]:
        """
        Get a gaming session by ID.
        
        Args:
            session_id: Gaming session ID
            db: Database session
            
        Returns:
            Optional[GamingSession]: Gaming session if found, None otherwise
        """
        stmt = select(GamingSession).where(GamingSession.session_id == session_id)
        result = await db.execute(stmt)
        session = result.scalar_one_or_none()
        
        return session
    
    async def get_active_session_for_player(self, player_id: int, db: AsyncSession) -> Optional[GamingSession]:
        """
        Get the active gaming session for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            Optional[GamingSession]: Active gaming session if found, None otherwise
        """
        stmt = (
            select(GamingSession)
            .where(
                and_(
                    GamingSession.player_id == player_id,
                    GamingSession.status == SessionStatus.ACTIVE
                )
            )
        )
        result = await db.execute(stmt)
        session = result.scalar_one_or_none()
        
        return session
    
    async def search_gaming_sessions(self, search_params: GamingSessionSearch, db: AsyncSession) -> List[GamingSession]:
        """
        Search for gaming sessions based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[GamingSession]: List of matching gaming sessions
        """
        query = select(GamingSession)
        
        # Apply filters
        filters = []
        if search_params.player_id is not None:
            filters.append(GamingSession.player_id == search_params.player_id)
        
        if search_params.status is not None:
            filters.append(GamingSession.status == search_params.status)
        
        if search_params.min_start_time is not None:
            filters.append(GamingSession.start_time >= search_params.min_start_time)
        
        if search_params.max_start_time is not None:
            filters.append(GamingSession.start_time <= search_params.max_start_time)
        
        if search_params.min_end_time is not None:
            filters.append(GamingSession.end_time >= search_params.min_end_time)
        
        if search_params.max_end_time is not None:
            filters.append(GamingSession.end_time <= search_params.max_end_time)
        
        if filters:
            query = query.where(and_(*filters))
        
        # Apply pagination
        offset = (search_params.page - 1) * search_params.page_size
        query = query.offset(offset).limit(search_params.page_size)
        
        # Order by start time descending
        query = query.order_by(GamingSession.start_time.desc())
        
        # Execute query
        result = await db.execute(query)
        sessions = result.scalars().all()
        
        return sessions
    
    async def get_player_session_stats(self, player_id: int, db: AsyncSession) -> Dict[str, Any]:
        """
        Get statistics about a player's gaming sessions.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            Dict[str, Any]: Session statistics
        """
        # Get total sessions
        total_stmt = (
            select(func.count(GamingSession.session_id))
            .where(GamingSession.player_id == player_id)
        )
        total_result = await db.execute(total_stmt)
        total_sessions = total_result.scalar_one()
        
        # Get total time spent
        time_stmt = (
            select(func.sum(GamingSession.duration_minutes))
            .where(GamingSession.player_id == player_id)
        )
        time_result = await db.execute(time_stmt)
        total_minutes = time_result.scalar_one() or 0
        
        # Get average session duration
        avg_stmt = (
            select(func.avg(GamingSession.duration_minutes))
            .where(
                and_(
                    GamingSession.player_id == player_id,
                    GamingSession.duration_minutes.isnot(None)
                )
            )
        )
        avg_result = await db.execute(avg_stmt)
        avg_duration = avg_result.scalar_one() or 0
        
        # Get last session
        last_stmt = (
            select(GamingSession)
            .where(GamingSession.player_id == player_id)
            .order_by(GamingSession.start_time.desc())
            .limit(1)
        )
        last_result = await db.execute(last_stmt)
        last_session = last_result.scalar_one_or_none()
        
        # Compile statistics
        stats = {
            "total_sessions": total_sessions,
            "total_hours": round(total_minutes / 60, 1),
            "avg_session_hours": round(avg_duration / 60, 1),
            "last_session_date": last_session.start_time if last_session else None,
            "current_session": await self.get_active_session_for_player(player_id, db)
        }
        
        return stats
    
    # Table Game methods
    
    async def create_table_game(self, table_data: TableGameCreate, db: AsyncSession) -> TableGame:
        """
        Create a new table game.
        
        Args:
            table_data: Table game data
            db: Database session
            
        Returns:
            TableGame: Created table game
        """
        # Create table game
        now = datetime.now()
        table_dict = table_data.dict()
        table_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(TableGame).values(**table_dict).returning(TableGame)
        result = await db.execute(stmt)
        table = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created table game with ID {table.table_id}")
        
        return table
    
    async def get_table_game_by_id(self, table_id: int, db: AsyncSession) -> Optional[TableGame]:
        """
        Get a table game by ID.
        
        Args:
            table_id: Table game ID
            db: Database session
            
        Returns:
            Optional[TableGame]: Table game if found, None otherwise
        """
        stmt = select(TableGame).where(TableGame.table_id == table_id)
        result = await db.execute(stmt)
        table = result.scalar_one_or_none()
        
        return table
    
    async def get_all_table_games(self, db: AsyncSession) -> List[TableGame]:
        """
        Get all table games.
        
        Args:
            db: Database session
            
        Returns:
            List[TableGame]: List of all table games
        """
        stmt = select(TableGame)
        result = await db.execute(stmt)
        tables = result.scalars().all()
        
        return tables
    
    # Slot Machine methods
    
    async def create_slot_machine(self, machine_data: SlotMachineCreate, db: AsyncSession) -> SlotMachine:
        """
        Create a new slot machine.
        
        Args:
            machine_data: Slot machine data
            db: Database session
            
        Returns:
            SlotMachine: Created slot machine
        """
        # Create slot machine
        now = datetime.now()
        machine_dict = machine_data.dict()
        machine_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(SlotMachine).values(**machine_dict).returning(SlotMachine)
        result = await db.execute(stmt)
        machine = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created slot machine with ID {machine.machine_id}")
        
        return machine
    
    async def get_slot_machine_by_id(self, machine_id: int, db: AsyncSession) -> Optional[SlotMachine]:
        """
        Get a slot machine by ID.
        
        Args:
            machine_id: Slot machine ID
            db: Database session
            
        Returns:
            Optional[SlotMachine]: Slot machine if found, None otherwise
        """
        stmt = select(SlotMachine).where(SlotMachine.machine_id == machine_id)
        result = await db.execute(stmt)
        machine = result.scalar_one_or_none()
        
        return machine
    
    async def get_all_slot_machines(self, db: AsyncSession) -> List[SlotMachine]:
        """
        Get all slot machines.
        
        Args:
            db: Database session
            
        Returns:
            List[SlotMachine]: List of all slot machines
        """
        stmt = select(SlotMachine)
        result = await db.execute(stmt)
        machines = result.scalars().all()
        
        return machines
    
    # Table Game Activity methods
    
    async def create_table_game_activity(self, activity_data: TableGameActivityCreate, db: AsyncSession) -> TableGameActivity:
        """
        Create a new table game activity.
        
        Args:
            activity_data: Table game activity data
            db: Database session
            
        Returns:
            TableGameActivity: Created table game activity
        """
        # Create table game activity
        now = datetime.now()
        activity_dict = activity_data.dict()
        activity_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(TableGameActivity).values(**activity_dict).returning(TableGameActivity)
        result = await db.execute(stmt)
        activity = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created table game activity with ID {activity.activity_id}")
        
        return activity
    
    async def update_table_game_activity(self, activity_id: int, activity_data: TableGameActivityUpdate, db: AsyncSession) -> Optional[TableGameActivity]:
        """
        Update a table game activity.
        
        Args:
            activity_id: Table game activity ID
            activity_data: Table game activity data to update
            db: Database session
            
        Returns:
            Optional[TableGameActivity]: Updated table game activity or None if not found
        """
        # Check if table game activity exists
        activity = await self.get_table_game_activity_by_id(activity_id, db)
        if not activity:
            return None
        
        # Update table game activity
        update_data = activity_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        # Calculate duration if end_time is provided but duration_minutes is not
        if "end_time" in update_data and "duration_minutes" not in update_data and update_data["end_time"] is not None:
            duration = (update_data["end_time"] - activity.start_time).total_seconds() / 60
            update_data["duration_minutes"] = int(duration)
        
        # Calculate win/loss if not provided
        if "win_loss" not in update_data and "chips_in" in update_data and "chips_out" in update_data:
            chips_in = update_data.get("chips_in", activity.chips_in or 0)
            chips_out = update_data.get("chips_out", activity.chips_out or 0)
            update_data["win_loss"] = chips_out - chips_in
        
        stmt = (
            update(TableGameActivity)
            .where(TableGameActivity.activity_id == activity_id)
            .values(**update_data)
            .returning(TableGameActivity)
        )
        result = await db.execute(stmt)
        updated_activity = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated table game activity with ID {activity_id}")
        
        return updated_activity
    
    async def get_table_game_activity_by_id(self, activity_id: int, db: AsyncSession) -> Optional[TableGameActivity]:
        """
        Get a table game activity by ID.
        
        Args:
            activity_id: Table game activity ID
            db: Database session
            
        Returns:
            Optional[TableGameActivity]: Table game activity if found, None otherwise
        """
        stmt = select(TableGameActivity).where(TableGameActivity.activity_id == activity_id)
        result = await db.execute(stmt)
        activity = result.scalar_one_or_none()
        
        return activity
    
    async def get_table_game_activities_by_session(self, session_id: int, db: AsyncSession) -> List[TableGameActivity]:
        """
        Get all table game activities for a gaming session.
        
        Args:
            session_id: Gaming session ID
            db: Database session
            
        Returns:
            List[TableGameActivity]: List of table game activities
        """
        stmt = (
            select(TableGameActivity)
            .where(TableGameActivity.session_id == session_id)
            .order_by(TableGameActivity.start_time)
        )
        result = await db.execute(stmt)
        activities = result.scalars().all()
        
        return activities
    
    # Slot Machine Activity methods
    
    async def create_slot_machine_activity(self, activity_data: SlotMachineActivityCreate, db: AsyncSession) -> SlotMachineActivity:
        """
        Create a new slot machine activity.
        
        Args:
            activity_data: Slot machine activity data
            db: Database session
            
        Returns:
            SlotMachineActivity: Created slot machine activity
        """
        # Create slot machine activity
        now = datetime.now()
        activity_dict = activity_data.dict()
        activity_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(SlotMachineActivity).values(**activity_dict).returning(SlotMachineActivity)
        result = await db.execute(stmt)
        activity = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created slot machine activity with ID {activity.activity_id}")
        
        return activity
    
    async def update_slot_machine_activity(self, activity_id: int, activity_data: SlotMachineActivityUpdate, db: AsyncSession) -> Optional[SlotMachineActivity]:
        """
        Update a slot machine activity.
        
        Args:
            activity_id: Slot machine activity ID
            activity_data: Slot machine activity data to update
            db: Database session
            
        Returns:
            Optional[SlotMachineActivity]: Updated slot machine activity or None if not found
        """
        # Check if slot machine activity exists
        activity = await self.get_slot_machine_activity_by_id(activity_id, db)
        if not activity:
            return None
        
        # Update slot machine activity
        update_data = activity_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        # Calculate duration if end_time is provided but duration_minutes is not
        if "end_time" in update_data and "duration_minutes" not in update_data and update_data["end_time"] is not None:
            duration = (update_data["end_time"] - activity.start_time).total_seconds() / 60
            update_data["duration_minutes"] = int(duration)
        
        # Calculate win/loss if not provided
        if "win_loss" not in update_data:
            money_in = update_data.get("money_in", activity.money_in or 0)
            ticket_in = update_data.get("ticket_in", activity.ticket_in or 0)
            ticket_out = update_data.get("ticket_out", activity.ticket_out or 0)
            hand_pay = update_data.get("hand_pay", activity.hand_pay or 0)
            jackpot = update_data.get("jackpot", activity.jackpot or 0)
            
            total_in = money_in + ticket_in
            total_out = ticket_out + hand_pay + jackpot
            update_data["win_loss"] = total_out - total_in
        
        stmt = (
            update(SlotMachineActivity)
            .where(SlotMachineActivity.activity_id == activity_id)
            .values(**update_data)
            .returning(SlotMachineActivity)
        )
        result = await db.execute(stmt)
        updated_activity = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated slot machine activity with ID {activity_id}")
        
        return updated_activity
    
    async def get_slot_machine_activity_by_id(self, activity_id: int, db: AsyncSession) -> Optional[SlotMachineActivity]:
        """
        Get a slot machine activity by ID.
        
        Args:
            activity_id: Slot machine activity ID
            db: Database session
            
        Returns:
            Optional[SlotMachineActivity]: Slot machine activity if found, None otherwise
        """
        stmt = select(SlotMachineActivity).where(SlotMachineActivity.activity_id == activity_id)
        result = await db.execute(stmt)
        activity = result.scalar_one_or_none()
        
        return activity
    
    async def get_slot_machine_activities_by_session(self, session_id: int, db: AsyncSession) -> List[SlotMachineActivity]:
        """
        Get all slot machine activities for a gaming session.
        
        Args:
            session_id: Gaming session ID
            db: Database session
            
        Returns:
            List[SlotMachineActivity]: List of slot machine activities
        """
        stmt = (
            select(SlotMachineActivity)
            .where(SlotMachineActivity.session_id == session_id)
            .order_by(SlotMachineActivity.start_time)
        )
        result = await db.execute(stmt)
        activities = result.scalars().all()
        
        return activities
