"""
Alpin Royal Casino Management System - Financial Repository
This module provides data access for financial transaction operations.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, update, delete, func, or_, and_
from sqlalchemy.orm import selectinload

from modules.player_tracking.models.financial import (
    FinancialTransaction, FinancialTransactionCreate, FinancialTransactionUpdate,
    JackpotHandPay, JackpotHandPayCreate, JackpotHandPayUpdate,
    FinancialSummary, FinancialSearch, TransactionType
)
from base_layer.utils.database import get_db_session

logger = logging.getLogger(__name__)

class FinancialRepository:
    """Repository for financial transaction-related database operations"""
    
    async def create_transaction(self, transaction_data: FinancialTransactionCreate, db: AsyncSession) -> FinancialTransaction:
        """
        Create a new financial transaction.
        
        Args:
            transaction_data: Financial transaction data
            db: Database session
            
        Returns:
            FinancialTransaction: Created financial transaction
        """
        # Create financial transaction
        now = datetime.now()
        transaction_dict = transaction_data.dict()
        transaction_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(FinancialTransaction).values(**transaction_dict).returning(FinancialTransaction)
        result = await db.execute(stmt)
        transaction = result.scalar_one()
        
        await db.commit()
        logger.info(f"Created financial transaction with ID {transaction.transaction_id} for player {transaction.player_id}")
        
        return transaction
    
    async def update_transaction(self, transaction_id: int, transaction_data: FinancialTransactionUpdate, db: AsyncSession) -> Optional[FinancialTransaction]:
        """
        Update a financial transaction.
        
        Args:
            transaction_id: Financial transaction ID
            transaction_data: Financial transaction data to update
            db: Database session
            
        Returns:
            Optional[FinancialTransaction]: Updated financial transaction or None if not found
        """
        # Check if financial transaction exists
        transaction = await self.get_transaction_by_id(transaction_id, db)
        if not transaction:
            return None
        
        # Update financial transaction
        update_data = transaction_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        stmt = (
            update(FinancialTransaction)
            .where(FinancialTransaction.transaction_id == transaction_id)
            .values(**update_data)
            .returning(FinancialTransaction)
        )
        result = await db.execute(stmt)
        updated_transaction = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated financial transaction with ID {transaction_id}")
        
        return updated_transaction
    
    async def get_transaction_by_id(self, transaction_id: int, db: AsyncSession) -> Optional[FinancialTransaction]:
        """
        Get a financial transaction by ID.
        
        Args:
            transaction_id: Financial transaction ID
            db: Database session
            
        Returns:
            Optional[FinancialTransaction]: Financial transaction if found, None otherwise
        """
        stmt = select(FinancialTransaction).where(FinancialTransaction.transaction_id == transaction_id)
        result = await db.execute(stmt)
        transaction = result.scalar_one_or_none()
        
        return transaction
    
    async def search_transactions(self, search_params: FinancialSearch, db: AsyncSession) -> List[FinancialTransaction]:
        """
        Search for financial transactions based on various criteria.
        
        Args:
            search_params: Search parameters
            db: Database session
            
        Returns:
            List[FinancialTransaction]: List of matching financial transactions
        """
        query = select(FinancialTransaction)
        
        # Apply filters
        filters = []
        if search_params.player_id is not None:
            filters.append(FinancialTransaction.player_id == search_params.player_id)
        
        if search_params.session_id is not None:
            filters.append(FinancialTransaction.session_id == search_params.session_id)
        
        if search_params.transaction_type is not None:
            filters.append(FinancialTransaction.transaction_type == search_params.transaction_type)
        
        if search_params.min_amount is not None:
            filters.append(FinancialTransaction.amount >= search_params.min_amount)
        
        if search_params.max_amount is not None:
            filters.append(FinancialTransaction.amount <= search_params.max_amount)
        
        if search_params.min_transaction_time is not None:
            filters.append(FinancialTransaction.transaction_time >= search_params.min_transaction_time)
        
        if search_params.max_transaction_time is not None:
            filters.append(FinancialTransaction.transaction_time <= search_params.max_transaction_time)
        
        if search_params.payment_method is not None:
            filters.append(FinancialTransaction.payment_method == search_params.payment_method)
        
        if search_params.staff_id is not None:
            filters.append(FinancialTransaction.staff_id == search_params.staff_id)
        
        if filters:
            query = query.where(and_(*filters))
        
        # Apply pagination
        offset = (search_params.page - 1) * search_params.page_size
        query = query.offset(offset).limit(search_params.page_size)
        
        # Order by transaction time descending
        query = query.order_by(FinancialTransaction.transaction_time.desc())
        
        # Execute query
        result = await db.execute(query)
        transactions = result.scalars().all()
        
        return transactions
    
    async def get_player_financial_summary(self, player_id: int, db: AsyncSession) -> FinancialSummary:
        """
        Get a summary of a player's financial transactions.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            FinancialSummary: Summary of financial transactions
        """
        # Initialize summary
        summary = FinancialSummary()
        
        # Get total buy-ins
        buy_in_stmt = (
            select(func.sum(FinancialTransaction.amount))
            .where(
                and_(
                    FinancialTransaction.player_id == player_id,
                    FinancialTransaction.transaction_type == TransactionType.BUY_IN
                )
            )
        )
        buy_in_result = await db.execute(buy_in_stmt)
        summary.total_buy_in = buy_in_result.scalar_one() or 0
        
        # Get total cash-outs
        cash_out_stmt = (
            select(func.sum(FinancialTransaction.amount))
            .where(
                and_(
                    FinancialTransaction.player_id == player_id,
                    FinancialTransaction.transaction_type == TransactionType.CASH_OUT
                )
            )
        )
        cash_out_result = await db.execute(cash_out_stmt)
        summary.total_cash_out = cash_out_result.scalar_one() or 0
        
        # Get total jackpots
        jackpot_stmt = (
            select(func.sum(FinancialTransaction.amount))
            .where(
                and_(
                    FinancialTransaction.player_id == player_id,
                    FinancialTransaction.transaction_type == TransactionType.JACKPOT
                )
            )
        )
        jackpot_result = await db.execute(jackpot_stmt)
        summary.total_jackpots = jackpot_result.scalar_one() or 0
        
        # Get total hand pays
        hand_pay_stmt = (
            select(func.sum(FinancialTransaction.amount))
            .where(
                and_(
                    FinancialTransaction.player_id == player_id,
                    FinancialTransaction.transaction_type == TransactionType.HAND_PAY
                )
            )
        )
        hand_pay_result = await db.execute(hand_pay_stmt)
        summary.total_hand_pays = hand_pay_result.scalar_one() or 0
        
        # Get total comps
        comp_stmt = (
            select(func.sum(FinancialTransaction.amount))
            .where(
                and_(
                    FinancialTransaction.player_id == player_id,
                    FinancialTransaction.transaction_type == TransactionType.COMP
                )
            )
        )
        comp_result = await db.execute(comp_stmt)
        summary.total_comps = comp_result.scalar_one() or 0
        
        # Calculate net win/loss
        summary.net_win_loss = (summary.total_cash_out + summary.total_jackpots + summary.total_hand_pays) - summary.total_buy_in
        
        # Get transaction count
        count_stmt = (
            select(func.count(FinancialTransaction.transaction_id))
            .where(FinancialTransaction.player_id == player_id)
        )
        count_result = await db.execute(count_stmt)
        summary.transaction_count = count_result.scalar_one() or 0
        
        # Get last transaction time
        last_stmt = (
            select(FinancialTransaction.transaction_time)
            .where(FinancialTransaction.player_id == player_id)
            .order_by(FinancialTransaction.transaction_time.desc())
            .limit(1)
        )
        last_result = await db.execute(last_stmt)
        summary.last_transaction_time = last_result.scalar_one_or_none()
        
        return summary
    
    # Jackpot and Hand Pay methods
    
    async def create_jackpot_hand_pay(self, jackpot_data: JackpotHandPayCreate, db: AsyncSession) -> JackpotHandPay:
        """
        Create a new jackpot or hand pay record.
        
        Args:
            jackpot_data: Jackpot or hand pay data
            db: Database session
            
        Returns:
            JackpotHandPay: Created jackpot or hand pay record
        """
        # Create jackpot or hand pay record
        now = datetime.now()
        jackpot_dict = jackpot_data.dict()
        jackpot_dict.update({
            "created_at": now,
            "updated_at": now
        })
        
        stmt = insert(JackpotHandPay).values(**jackpot_dict).returning(JackpotHandPay)
        result = await db.execute(stmt)
        jackpot = result.scalar_one()
        
        # Also create a financial transaction for this jackpot/hand pay
        transaction_data = FinancialTransactionCreate(
            player_id=jackpot.player_id,
            session_id=jackpot.session_id,
            transaction_type=(
                TransactionType.JACKPOT 
                if jackpot.jackpot_type in ["progressive", "bonus"] 
                else TransactionType.HAND_PAY
            ),
            amount=jackpot.amount,
            transaction_time=jackpot.jackpot_time,
            staff_id=jackpot.staff_id,
            notes=f"Jackpot/Hand Pay ID: {jackpot.jackpot_id}. {jackpot.notes or ''}"
        )
        await self.create_transaction(transaction_data, db)
        
        await db.commit()
        logger.info(f"Created jackpot/hand pay with ID {jackpot.jackpot_id} for player {jackpot.player_id}")
        
        return jackpot
    
    async def update_jackpot_hand_pay(self, jackpot_id: int, jackpot_data: JackpotHandPayUpdate, db: AsyncSession) -> Optional[JackpotHandPay]:
        """
        Update a jackpot or hand pay record.
        
        Args:
            jackpot_id: Jackpot or hand pay ID
            jackpot_data: Jackpot or hand pay data to update
            db: Database session
            
        Returns:
            Optional[JackpotHandPay]: Updated jackpot or hand pay record or None if not found
        """
        # Check if jackpot or hand pay record exists
        jackpot = await self.get_jackpot_hand_pay_by_id(jackpot_id, db)
        if not jackpot:
            return None
        
        # Update jackpot or hand pay record
        update_data = jackpot_data.dict(exclude_unset=True)
        update_data["updated_at"] = datetime.now()
        
        stmt = (
            update(JackpotHandPay)
            .where(JackpotHandPay.jackpot_id == jackpot_id)
            .values(**update_data)
            .returning(JackpotHandPay)
        )
        result = await db.execute(stmt)
        updated_jackpot = result.scalar_one()
        
        await db.commit()
        logger.info(f"Updated jackpot/hand pay with ID {jackpot_id}")
        
        return updated_jackpot
    
    async def get_jackpot_hand_pay_by_id(self, jackpot_id: int, db: AsyncSession) -> Optional[JackpotHandPay]:
        """
        Get a jackpot or hand pay record by ID.
        
        Args:
            jackpot_id: Jackpot or hand pay ID
            db: Database session
            
        Returns:
            Optional[JackpotHandPay]: Jackpot or hand pay record if found, None otherwise
        """
        stmt = select(JackpotHandPay).where(JackpotHandPay.jackpot_id == jackpot_id)
        result = await db.execute(stmt)
        jackpot = result.scalar_one_or_none()
        
        return jackpot
    
    async def get_player_jackpots_hand_pays(self, player_id: int, db: AsyncSession) -> List[JackpotHandPay]:
        """
        Get all jackpots and hand pays for a player.
        
        Args:
            player_id: Player ID
            db: Database session
            
        Returns:
            List[JackpotHandPay]: List of jackpots and hand pays
        """
        stmt = (
            select(JackpotHandPay)
            .where(JackpotHandPay.player_id == player_id)
            .order_by(JackpotHandPay.jackpot_time.desc())
        )
        result = await db.execute(stmt)
        jackpots = result.scalars().all()
        
        return jackpots
