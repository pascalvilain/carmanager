"""
Alpin Royal Casino Management System - Network Design Module Repository
This module provides data access for network design and planning.
"""

from sqlalchemy import select, update, delete, and_, or_, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from typing import List, Optional, Dict, Any, Tuple
import datetime

from modules.network_design.models.network import (
    FloorPlan, NetworkDevice, Cable, DeviceType, ConnectionType,
    FloorPlanCreate, FloorPlanUpdate, NetworkDeviceCreate, 
    NetworkDeviceUpdate, CableCreate, CableUpdate, NetworkDeviceSearch
)

class FloorPlanRepository:
    """Repository for floor plan data access"""
    
    @staticmethod
    async def create(session: AsyncSession, floor_plan_data: FloorPlanCreate) -> FloorPlan:
        """Create a new floor plan"""
        floor_plan = FloorPlan(**floor_plan_data.__dict__)
        session.add(floor_plan)
        await session.commit()
        await session.refresh(floor_plan)
        return floor_plan
    
    @staticmethod
    async def get_by_id(session: AsyncSession, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan by ID"""
        query = select(FloorPlan).where(FloorPlan.floor_plan_id == floor_plan_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[FloorPlan]:
        """Get all floor plans"""
        query = select(FloorPlan).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, floor_plan_id: int, floor_plan_data: FloorPlanUpdate) -> Optional[FloorPlan]:
        """Update a floor plan"""
        # Filter out None values
        update_data = {k: v for k, v in floor_plan_data.__dict__.items() if v is not None}
        
        if not update_data:
            # Nothing to update
            return await FloorPlanRepository.get_by_id(session, floor_plan_id)
        
        # Add updated_at timestamp
        update_data["updated_at"] = datetime.datetime.utcnow()
        
        # Update the floor plan
        query = update(FloorPlan).where(FloorPlan.floor_plan_id == floor_plan_id).values(**update_data)
        await session.execute(query)
        await session.commit()
        
        # Return the updated floor plan
        return await FloorPlanRepository.get_by_id(session, floor_plan_id)
    
    @staticmethod
    async def delete(session: AsyncSession, floor_plan_id: int) -> bool:
        """Delete a floor plan"""
        query = delete(FloorPlan).where(FloorPlan.floor_plan_id == floor_plan_id)
        result = await session.execute(query)
        await session.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def get_by_building_floor(session: AsyncSession, building: str, floor_number: int) -> List[FloorPlan]:
        """Get floor plans by building and floor number"""
        query = select(FloorPlan).where(
            and_(
                FloorPlan.building == building,
                FloorPlan.floor_number == floor_number
            )
        )
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_with_devices(session: AsyncSession, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan with its devices"""
        query = select(FloorPlan).where(FloorPlan.floor_plan_id == floor_plan_id).options(
            selectinload(FloorPlan.devices)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_cables(session: AsyncSession, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan with its cables"""
        query = select(FloorPlan).where(FloorPlan.floor_plan_id == floor_plan_id).options(
            selectinload(FloorPlan.cables)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_devices_and_cables(session: AsyncSession, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan with its devices and cables"""
        query = select(FloorPlan).where(FloorPlan.floor_plan_id == floor_plan_id).options(
            selectinload(FloorPlan.devices),
            selectinload(FloorPlan.cables)
        )
        result = await session.execute(query)
        return result.scalars().first()

class NetworkDeviceRepository:
    """Repository for network device data access"""
    
    @staticmethod
    async def create(session: AsyncSession, device_data: NetworkDeviceCreate) -> NetworkDevice:
        """Create a new network device"""
        device = NetworkDevice(**device_data.__dict__)
        session.add(device)
        await session.commit()
        await session.refresh(device)
        return device
    
    @staticmethod
    async def get_by_id(session: AsyncSession, device_id: int) -> Optional[NetworkDevice]:
        """Get a network device by ID"""
        query = select(NetworkDevice).where(NetworkDevice.device_id == device_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[NetworkDevice]:
        """Get all network devices"""
        query = select(NetworkDevice).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, device_id: int, device_data: NetworkDeviceUpdate) -> Optional[NetworkDevice]:
        """Update a network device"""
        # Filter out None values
        update_data = {k: v for k, v in device_data.__dict__.items() if v is not None}
        
        if not update_data:
            # Nothing to update
            return await NetworkDeviceRepository.get_by_id(session, device_id)
        
        # Add updated_at timestamp
        update_data["updated_at"] = datetime.datetime.utcnow()
        
        # Update the device
        query = update(NetworkDevice).where(NetworkDevice.device_id == device_id).values(**update_data)
        await session.execute(query)
        await session.commit()
        
        # Return the updated device
        return await NetworkDeviceRepository.get_by_id(session, device_id)
    
    @staticmethod
    async def delete(session: AsyncSession, device_id: int) -> bool:
        """Delete a network device"""
        query = delete(NetworkDevice).where(NetworkDevice.device_id == device_id)
        result = await session.execute(query)
        await session.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def get_by_floor_plan(session: AsyncSession, floor_plan_id: int) -> List[NetworkDevice]:
        """Get network devices by floor plan ID"""
        query = select(NetworkDevice).where(NetworkDevice.floor_plan_id == floor_plan_id)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_type(session: AsyncSession, device_type: DeviceType) -> List[NetworkDevice]:
        """Get network devices by type"""
        query = select(NetworkDevice).where(NetworkDevice.device_type == device_type)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_ip_address(session: AsyncSession, ip_address: str) -> Optional[NetworkDevice]:
        """Get a network device by IP address"""
        query = select(NetworkDevice).where(NetworkDevice.ip_address == ip_address)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_by_mac_address(session: AsyncSession, mac_address: str) -> Optional[NetworkDevice]:
        """Get a network device by MAC address"""
        query = select(NetworkDevice).where(NetworkDevice.mac_address == mac_address)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_cables(session: AsyncSession, device_id: int) -> Optional[NetworkDevice]:
        """Get a network device with its cables"""
        query = select(NetworkDevice).where(NetworkDevice.device_id == device_id).options(
            selectinload(NetworkDevice.source_cables),
            selectinload(NetworkDevice.target_cables)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def search(session: AsyncSession, search_params: NetworkDeviceSearch, skip: int = 0, limit: int = 100) -> List[NetworkDevice]:
        """Search for network devices based on various criteria"""
        conditions = []
        
        if search_params.floor_plan_id is not None:
            conditions.append(NetworkDevice.floor_plan_id == search_params.floor_plan_id)
        
        if search_params.device_type is not None:
            conditions.append(NetworkDevice.device_type == search_params.device_type)
        
        if search_params.name is not None:
            conditions.append(NetworkDevice.name.ilike(f"%{search_params.name}%"))
        
        if search_params.ip_address is not None:
            conditions.append(NetworkDevice.ip_address.ilike(f"%{search_params.ip_address}%"))
        
        if search_params.mac_address is not None:
            conditions.append(NetworkDevice.mac_address.ilike(f"%{search_params.mac_address}%"))
        
        if search_params.is_active is not None:
            conditions.append(NetworkDevice.is_active == search_params.is_active)
        
        if conditions:
            query = select(NetworkDevice).where(and_(*conditions)).offset(skip).limit(limit)
        else:
            query = select(NetworkDevice).offset(skip).limit(limit)
        
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_device_counts_by_type(session: AsyncSession) -> Dict[str, int]:
        """Get counts of devices by type"""
        query = select(NetworkDevice.device_type, func.count(NetworkDevice.device_id)).group_by(NetworkDevice.device_type)
        result = await session.execute(query)
        return {device_type.value: count for device_type, count in result.all()}
    
    @staticmethod
    async def get_device_counts_by_floor(session: AsyncSession) -> Dict[Tuple[str, int], int]:
        """Get counts of devices by building and floor"""
        query = select(
            FloorPlan.building, 
            FloorPlan.floor_number, 
            func.count(NetworkDevice.device_id)
        ).join(
            FloorPlan, 
            NetworkDevice.floor_plan_id == FloorPlan.floor_plan_id
        ).group_by(
            FloorPlan.building, 
            FloorPlan.floor_number
        )
        result = await session.execute(query)
        return {(building, floor): count for building, floor, count in result.all()}

class CableRepository:
    """Repository for cable data access"""
    
    @staticmethod
    async def create(session: AsyncSession, cable_data: CableCreate) -> Cable:
        """Create a new cable"""
        cable = Cable(**cable_data.__dict__)
        session.add(cable)
        await session.commit()
        await session.refresh(cable)
        return cable
    
    @staticmethod
    async def get_by_id(session: AsyncSession, cable_id: int) -> Optional[Cable]:
        """Get a cable by ID"""
        query = select(Cable).where(Cable.cable_id == cable_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[Cable]:
        """Get all cables"""
        query = select(Cable).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, cable_id: int, cable_data: CableUpdate) -> Optional[Cable]:
        """Update a cable"""
        # Filter out None values
        update_data = {k: v for k, v in cable_data.__dict__.items() if v is not None}
        
        if not update_data:
            # Nothing to update
            return await CableRepository.get_by_id(session, cable_id)
        
        # Add updated_at timestamp
        update_data["updated_at"] = datetime.datetime.utcnow()
        
        # Update the cable
        query = update(Cable).where(Cable.cable_id == cable_id).values(**update_data)
        await session.execute(query)
        await session.commit()
        
        # Return the updated cable
        return await CableRepository.get_by_id(session, cable_id)
    
    @staticmethod
    async def delete(session: AsyncSession, cable_id: int) -> bool:
        """Delete a cable"""
        query = delete(Cable).where(Cable.cable_id == cable_id)
        result = await session.execute(query)
        await session.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def get_by_floor_plan(session: AsyncSession, floor_plan_id: int) -> List[Cable]:
        """Get cables by floor plan ID"""
        query = select(Cable).where(Cable.floor_plan_id == floor_plan_id)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_device(session: AsyncSession, device_id: int) -> List[Cable]:
        """Get cables connected to a device"""
        query = select(Cable).where(
            or_(
                Cable.source_device_id == device_id,
                Cable.target_device_id == device_id
            )
        )
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_cable_number(session: AsyncSession, cable_number: str) -> Optional[Cable]:
        """Get a cable by cable number"""
        query = select(Cable).where(Cable.cable_number == cable_number)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_devices(session: AsyncSession, cable_id: int) -> Optional[Cable]:
        """Get a cable with its connected devices"""
        query = select(Cable).where(Cable.cable_id == cable_id).options(
            selectinload(Cable.source_device),
            selectinload(Cable.target_device)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_cable_counts_by_type(session: AsyncSession) -> Dict[str, int]:
        """Get counts of cables by type"""
        query = select(Cable.cable_type, func.count(Cable.cable_id)).group_by(Cable.cable_type)
        result = await session.execute(query)
        return {cable_type.value: count for cable_type, count in result.all()}
