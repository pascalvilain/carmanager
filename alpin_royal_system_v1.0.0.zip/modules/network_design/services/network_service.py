"""
Alpin Royal Casino Management System - Network Design Module Services
This module provides business logic for network design and planning.
"""

from typing import List, Optional, Dict, Any, Tuple
import datetime
import os
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import UploadFile, HTTPException

from modules.network_design.models.network import (
    FloorPlan, NetworkDevice, Cable, DeviceType, ConnectionType,
    FloorPlanCreate, FloorPlanUpdate, NetworkDeviceCreate, 
    NetworkDeviceUpdate, CableCreate, CableUpdate, NetworkDeviceSearch,
    NetworkDashboard
)
from modules.network_design.repositories.network_repository import (
    FloorPlanRepository, NetworkDeviceRepository, CableRepository
)
from base_layer.utils.storage import StorageManager
from base_layer.utils.event_bus import EventBus
from base_layer.config.settings import get_settings

class NetworkDesignService:
    """Service for network design and planning"""
    
    def __init__(self, session: AsyncSession, storage_manager: StorageManager, event_bus: EventBus):
        """Initialize the service"""
        self.session = session
        self.storage_manager = storage_manager
        self.event_bus = event_bus
        self.settings = get_settings()
    
    # Floor Plan Services
    
    async def create_floor_plan(self, floor_plan_data: FloorPlanCreate, floor_plan_file: Optional[UploadFile] = None) -> FloorPlan:
        """Create a new floor plan"""
        # If a file is provided, upload it to storage
        if floor_plan_file:
            # Generate a unique filename
            file_extension = os.path.splitext(floor_plan_file.filename)[1]
            unique_filename = f"floor_plan_{uuid.uuid4()}{file_extension}"
            
            # Upload the file
            file_path = await self.storage_manager.upload_file(
                floor_plan_file.file,
                f"floor_plans/{unique_filename}",
                content_type=floor_plan_file.content_type
            )
            
            # Update the floor plan data with the file path
            floor_plan_data.file_path = file_path
        
        # Create the floor plan
        return await FloorPlanRepository.create(self.session, floor_plan_data)
    
    async def get_floor_plan(self, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan by ID"""
        return await FloorPlanRepository.get_by_id(self.session, floor_plan_id)
    
    async def get_all_floor_plans(self, skip: int = 0, limit: int = 100) -> List[FloorPlan]:
        """Get all floor plans"""
        return await FloorPlanRepository.get_all(self.session, skip, limit)
    
    async def update_floor_plan(self, floor_plan_id: int, floor_plan_data: FloorPlanUpdate, floor_plan_file: Optional[UploadFile] = None) -> Optional[FloorPlan]:
        """Update a floor plan"""
        # Check if the floor plan exists
        existing_floor_plan = await FloorPlanRepository.get_by_id(self.session, floor_plan_id)
        if not existing_floor_plan:
            return None
        
        # If a file is provided, upload it to storage
        if floor_plan_file:
            # Generate a unique filename
            file_extension = os.path.splitext(floor_plan_file.filename)[1]
            unique_filename = f"floor_plan_{uuid.uuid4()}{file_extension}"
            
            # Upload the file
            file_path = await self.storage_manager.upload_file(
                floor_plan_file.file,
                f"floor_plans/{unique_filename}",
                content_type=floor_plan_file.content_type
            )
            
            # Update the floor plan data with the file path
            floor_plan_data.file_path = file_path
            
            # Delete the old file if it exists
            if existing_floor_plan.file_path:
                try:
                    await self.storage_manager.delete_file(existing_floor_plan.file_path)
                except Exception as e:
                    # Log the error but continue
                    print(f"Error deleting old floor plan file: {e}")
        
        # Update the floor plan
        return await FloorPlanRepository.update(self.session, floor_plan_id, floor_plan_data)
    
    async def delete_floor_plan(self, floor_plan_id: int) -> bool:
        """Delete a floor plan"""
        # Get the floor plan to check if it has a file
        floor_plan = await FloorPlanRepository.get_by_id(self.session, floor_plan_id)
        if not floor_plan:
            return False
        
        # Delete the file if it exists
        if floor_plan.file_path:
            try:
                await self.storage_manager.delete_file(floor_plan.file_path)
            except Exception as e:
                # Log the error but continue
                print(f"Error deleting floor plan file: {e}")
        
        # Delete the floor plan
        return await FloorPlanRepository.delete(self.session, floor_plan_id)
    
    async def get_floor_plan_with_devices(self, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan with its devices"""
        return await FloorPlanRepository.get_with_devices(self.session, floor_plan_id)
    
    async def get_floor_plan_with_cables(self, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan with its cables"""
        return await FloorPlanRepository.get_with_cables(self.session, floor_plan_id)
    
    async def get_floor_plan_with_devices_and_cables(self, floor_plan_id: int) -> Optional[FloorPlan]:
        """Get a floor plan with its devices and cables"""
        return await FloorPlanRepository.get_with_devices_and_cables(self.session, floor_plan_id)
    
    # Network Device Services
    
    async def create_network_device(self, device_data: NetworkDeviceCreate) -> NetworkDevice:
        """Create a new network device"""
        # Check if the floor plan exists
        floor_plan = await FloorPlanRepository.get_by_id(self.session, device_data.floor_plan_id)
        if not floor_plan:
            raise HTTPException(status_code=404, detail="Floor plan not found")
        
        # Check if the IP address is already in use
        if device_data.ip_address:
            existing_device = await NetworkDeviceRepository.get_by_ip_address(self.session, device_data.ip_address)
            if existing_device:
                raise HTTPException(status_code=400, detail="IP address already in use")
        
        # Check if the MAC address is already in use
        if device_data.mac_address:
            existing_device = await NetworkDeviceRepository.get_by_mac_address(self.session, device_data.mac_address)
            if existing_device:
                raise HTTPException(status_code=400, detail="MAC address already in use")
        
        # Create the device
        device = await NetworkDeviceRepository.create(self.session, device_data)
        
        # Publish an event
        await self.event_bus.publish("network.device.created", {
            "device_id": device.device_id,
            "name": device.name,
            "device_type": device.device_type.value,
            "floor_plan_id": device.floor_plan_id
        })
        
        return device
    
    async def get_network_device(self, device_id: int) -> Optional[NetworkDevice]:
        """Get a network device by ID"""
        return await NetworkDeviceRepository.get_by_id(self.session, device_id)
    
    async def get_all_network_devices(self, skip: int = 0, limit: int = 100) -> List[NetworkDevice]:
        """Get all network devices"""
        return await NetworkDeviceRepository.get_all(self.session, skip, limit)
    
    async def update_network_device(self, device_id: int, device_data: NetworkDeviceUpdate) -> Optional[NetworkDevice]:
        """Update a network device"""
        # Check if the device exists
        existing_device = await NetworkDeviceRepository.get_by_id(self.session, device_id)
        if not existing_device:
            return None
        
        # Check if the floor plan exists if it's being updated
        if device_data.floor_plan_id is not None:
            floor_plan = await FloorPlanRepository.get_by_id(self.session, device_data.floor_plan_id)
            if not floor_plan:
                raise HTTPException(status_code=404, detail="Floor plan not found")
        
        # Check if the IP address is already in use
        if device_data.ip_address and device_data.ip_address != existing_device.ip_address:
            existing_ip_device = await NetworkDeviceRepository.get_by_ip_address(self.session, device_data.ip_address)
            if existing_ip_device and existing_ip_device.device_id != device_id:
                raise HTTPException(status_code=400, detail="IP address already in use")
        
        # Check if the MAC address is already in use
        if device_data.mac_address and device_data.mac_address != existing_device.mac_address:
            existing_mac_device = await NetworkDeviceRepository.get_by_mac_address(self.session, device_data.mac_address)
            if existing_mac_device and existing_mac_device.device_id != device_id:
                raise HTTPException(status_code=400, detail="MAC address already in use")
        
        # Update the device
        device = await NetworkDeviceRepository.update(self.session, device_id, device_data)
        
        # Publish an event
        await self.event_bus.publish("network.device.updated", {
            "device_id": device.device_id,
            "name": device.name,
            "device_type": device.device_type.value,
            "floor_plan_id": device.floor_plan_id
        })
        
        return device
    
    async def delete_network_device(self, device_id: int) -> bool:
        """Delete a network device"""
        # Check if the device exists
        device = await NetworkDeviceRepository.get_by_id(self.session, device_id)
        if not device:
            return False
        
        # Delete the device
        result = await NetworkDeviceRepository.delete(self.session, device_id)
        
        # Publish an event
        if result:
            await self.event_bus.publish("network.device.deleted", {
                "device_id": device_id,
                "name": device.name,
                "device_type": device.device_type.value,
                "floor_plan_id": device.floor_plan_id
            })
        
        return result
    
    async def get_network_devices_by_floor_plan(self, floor_plan_id: int) -> List[NetworkDevice]:
        """Get network devices by floor plan ID"""
        return await NetworkDeviceRepository.get_by_floor_plan(self.session, floor_plan_id)
    
    async def get_network_devices_by_type(self, device_type: DeviceType) -> List[NetworkDevice]:
        """Get network devices by type"""
        return await NetworkDeviceRepository.get_by_type(self.session, device_type)
    
    async def get_network_device_with_cables(self, device_id: int) -> Optional[NetworkDevice]:
        """Get a network device with its cables"""
        return await NetworkDeviceRepository.get_with_cables(self.session, device_id)
    
    async def search_network_devices(self, search_params: NetworkDeviceSearch, skip: int = 0, limit: int = 100) -> List[NetworkDevice]:
        """Search for network devices based on various criteria"""
        return await NetworkDeviceRepository.search(self.session, search_params, skip, limit)
    
    # Cable Services
    
    async def create_cable(self, cable_data: CableCreate) -> Cable:
        """Create a new cable"""
        # Check if the floor plan exists
        floor_plan = await FloorPlanRepository.get_by_id(self.session, cable_data.floor_plan_id)
        if not floor_plan:
            raise HTTPException(status_code=404, detail="Floor plan not found")
        
        # Check if the source device exists
        source_device = await NetworkDeviceRepository.get_by_id(self.session, cable_data.source_device_id)
        if not source_device:
            raise HTTPException(status_code=404, detail="Source device not found")
        
        # Check if the target device exists
        target_device = await NetworkDeviceRepository.get_by_id(self.session, cable_data.target_device_id)
        if not target_device:
            raise HTTPException(status_code=404, detail="Target device not found")
        
        # Check if the cable number is already in use
        existing_cable = await CableRepository.get_by_cable_number(self.session, cable_data.cable_number)
        if existing_cable:
            raise HTTPException(status_code=400, detail="Cable number already in use")
        
        # Create the cable
        cable = await CableRepository.create(self.session, cable_data)
        
        # Publish an event
        await self.event_bus.publish("network.cable.created", {
            "cable_id": cable.cable_id,
            "cable_number": cable.cable_number,
            "cable_type": cable.cable_type.value,
            "floor_plan_id": cable.floor_plan_id,
            "source_device_id": cable.source_device_id,
            "target_device_id": cable.target_device_id
        })
        
        return cable
    
    async def get_cable(self, cable_id: int) -> Optional[Cable]:
        """Get a cable by ID"""
        return await CableRepository.get_by_id(self.session, cable_id)
    
    async def get_all_cables(self, skip: int = 0, limit: int = 100) -> List[Cable]:
        """Get all cables"""
        return await CableRepository.get_all(self.session, skip, limit)
    
    async def update_cable(self, cable_id: int, cable_data: CableUpdate) -> Optional[Cable]:
        """Update a cable"""
        # Check if the cable exists
        existing_cable = await CableRepository.get_by_id(self.session, cable_id)
        if not existing_cable:
            return None
        
        # Check if the floor plan exists if it's being updated
        if cable_data.floor_plan_id is not None:
            floor_plan = await FloorPlanRepository.get_by_id(self.session, cable_data.floor_plan_id)
            if not floor_plan:
                raise HTTPException(status_code=404, detail="Floor plan not found")
        
        # Check if the source device exists if it's being updated
        if cable_data.source_device_id is not None:
            source_device = await NetworkDeviceRepository.get_by_id(self.session, cable_data.source_device_id)
            if not source_device:
                raise HTTPException(status_code=404, detail="Source device not found")
        
        # Check if the target device exists if it's being updated
        if cable_data.target_device_id is not None:
            target_device = await NetworkDeviceRepository.get_by_id(self.session, cable_data.target_device_id)
            if not target_device:
                raise HTTPException(status_code=404, detail="Target device not found")
        
        # Check if the cable number is already in use
        if cable_data.cable_number and cable_data.cable_number != existing_cable.cable_number:
            existing_cable_number = await CableRepository.get_by_cable_number(self.session, cable_data.cable_number)
            if existing_cable_number and existing_cable_number.cable_id != cable_id:
                raise HTTPException(status_code=400, detail="Cable number already in use")
        
        # Update the cable
        cable = await CableRepository.update(self.session, cable_id, cable_data)
        
        # Publish an event
        await self.event_bus.publish("network.cable.updated", {
            "cable_id": cable.cable_id,
            "cable_number": cable.cable_number,
            "cable_type": cable.cable_type.value,
            "floor_plan_id": cable.floor_plan_id,
            "source_device_id": cable.source_device_id,
            "target_device_id": cable.target_device_id
        })
        
        return cable
    
    async def delete_cable(self, cable_id: int) -> bool:
        """Delete a cable"""
        # Check if the cable exists
        cable = await CableRepository.get_by_id(self.session, cable_id)
        if not cable:
            return False
        
        # Delete the cable
        result = await CableRepository.delete(self.session, cable_id)
        
        # Publish an event
        if result:
            await self.event_bus.publish("network.cable.deleted", {
                "cable_id": cable_id,
                "cable_number": cable.cable_number,
                "cable_type": cable.cable_type.value,
                "floor_plan_id": cable.floor_plan_id,
                "source_device_id": cable.source_device_id,
                "target_device_id": cable.target_device_id
            })
        
        return result
    
    async def get_cables_by_floor_plan(self, floor_plan_id: int) -> List[Cable]:
        """Get cables by floor plan ID"""
        return await CableRepository.get_by_floor_plan(self.session, floor_plan_id)
    
    async def get_cables_by_device(self, device_id: int) -> List[Cable]:
        """Get cables connected to a device"""
        return await CableRepository.get_by_device(self.session, device_id)
    
    async def get_cable_with_devices(self, cable_id: int) -> Optional[Cable]:
        """Get a cable with its connected devices"""
        return await CableRepository.get_with_devices(self.session, cable_id)
    
    # Dashboard Services
    
    async def get_network_dashboard(self) -> NetworkDashboard:
        """Get network dashboard data"""
        # Get device counts
        total_devices_query = await self.session.execute("SELECT COUNT(*) FROM network_devices")
        total_devices = total_devices_query.scalar()
        
        active_devices_query = await self.session.execute("SELECT COUNT(*) FROM network_devices WHERE is_active = TRUE")
        active_devices = active_devices_query.scalar()
        
        inactive_devices = total_devices - active_devices
        
        # Get device counts by type
        devices_by_type = await NetworkDeviceRepository.get_device_counts_by_type(self.session)
        
        # Get device counts by floor
        devices_by_floor_raw = await NetworkDeviceRepository.get_device_counts_by_floor(self.session)
        devices_by_floor = {f"{building} - Floor {floor}": count for (building, floor), count in devices_by_floor_raw.items()}
        
        # Get cable counts
        total_cables_query = await self.session.execute("SELECT COUNT(*) FROM cables")
        total_cables = total_cables_query.scalar()
        
        # Get cable counts by type
        cables_by_type = await CableRepository.get_cable_counts_by_type(self.session)
        
        # Get recent changes
        recent_devices_query = await self.session.execute(
            "SELECT device_id, name, device_type, updated_at FROM network_devices ORDER BY updated_at DESC LIMIT 5"
        )
        recent_devices = [
            {
                "id": row[0],
                "name": row[1],
                "type": row[2],
                "updated_at": row[3],
                "entity_type": "device"
            }
            for row in recent_devices_query.fetchall()
        ]
        
        recent_cables_query = await self.session.execute(
            "SELECT cable_id, cable_number, cable_type, updated_at FROM cables ORDER BY updated_at DESC LIMIT 5"
        )
        recent_cables = [
            {
                "id": row[0],
                "name": row[1],
                "type": row[2],
                "updated_at": row[3],
                "entity_type": "cable"
            }
            for row in recent_cables_query.fetchall()
        ]
        
        # Combine and sort recent changes
        recent_changes = sorted(
            recent_devices + recent_cables,
            key=lambda x: x["updated_at"],
            reverse=True
        )[:5]
        
        # Create dashboard data
        dashboard = NetworkDashboard(
            total_devices=total_devices,
            devices_by_type=devices_by_type,
            total_cables=total_cables,
            cables_by_type=cables_by_type,
            active_devices=active_devices,
            inactive_devices=inactive_devices,
            devices_by_floor=devices_by_floor,
            recent_changes=recent_changes
        )
        
        return dashboard
    
    # Export Services
    
    async def export_network_data(self, floor_plan_id: Optional[int] = None) -> Dict[str, Any]:
        """Export network data for a floor plan or the entire network"""
        if floor_plan_id:
            # Export data for a specific floor plan
            floor_plan = await FloorPlanRepository.get_by_id(self.session, floor_plan_id)
            if not floor_plan:
                raise HTTPException(status_code=404, detail="Floor plan not found")
            
            devices = await NetworkDeviceRepository.get_by_floor_plan(self.session, floor_plan_id)
            cables = await CableRepository.get_by_floor_plan(self.session, floor_plan_id)
            
            return {
                "floor_plan": {
                    "floor_plan_id": floor_plan.floor_plan_id,
                    "name": floor_plan.name,
                    "description": floor_plan.description,
                    "file_path": floor_plan.file_path,
                    "width": floor_plan.width,
                    "height": floor_plan.height,
                    "scale": floor_plan.scale,
                    "floor_number": floor_plan.floor_number,
                    "building": floor_plan.building
                },
                "devices": [
                    {
                        "device_id": device.device_id,
                        "name": device.name,
                        "device_type": device.device_type.value,
                        "x_position": device.x_position,
                        "y_position": device.y_position,
                        "rotation": device.rotation,
                        "ip_address": device.ip_address,
                        "mac_address": device.mac_address,
                        "manufacturer": device.manufacturer,
                        "model": device.model,
                        "serial_number": device.serial_number,
                        "fov_direction": device.fov_direction,
                        "fov_angle": device.fov_angle,
                        "camera_number": device.camera_number,
                        "properties": device.properties
                    }
                    for device in devices
                ],
                "cables": [
                    {
                        "cable_id": cable.cable_id,
                        "cable_number": cable.cable_number,
                        "cable_type": cable.cable_type.value,
                        "source_device_id": cable.source_device_id,
                        "target_device_id": cable.target_device_id,
                        "source_port": cable.source_port,
                        "target_port": cable.target_port,
                        "length": cable.length,
                        "color": cable.color,
                        "path_points": cable.path_points
                    }
                    for cable in cables
                ]
            }
        else:
            # Export data for the entire network
            floor_plans = await FloorPlanRepository.get_all(self.session)
            devices = await NetworkDeviceRepository.get_all(self.session)
            cables = await CableRepository.get_all(self.session)
            
            return {
                "floor_plans": [
                    {
                        "floor_plan_id": floor_plan.floor_plan_id,
                        "name": floor_plan.name,
                        "description": floor_plan.description,
                        "file_path": floor_plan.file_path,
                        "width": floor_plan.width,
                        "height": floor_plan.height,
                        "scale": floor_plan.scale,
                        "floor_number": floor_plan.floor_number,
                        "building": floor_plan.building
                    }
                    for floor_plan in floor_plans
                ],
                "devices": [
                    {
                        "device_id": device.device_id,
                        "name": device.name,
                        "device_type": device.device_type.value,
                        "floor_plan_id": device.floor_plan_id,
                        "x_position": device.x_position,
                        "y_position": device.y_position,
                        "rotation": device.rotation,
                        "ip_address": device.ip_address,
                        "mac_address": device.mac_address,
                        "manufacturer": device.manufacturer,
                        "model": device.model,
                        "serial_number": device.serial_number,
                        "fov_direction": device.fov_direction,
                        "fov_angle": device.fov_angle,
                        "camera_number": device.camera_number,
                        "properties": device.properties
                    }
                    for device in devices
                ],
                "cables": [
                    {
                        "cable_id": cable.cable_id,
                        "cable_number": cable.cable_number,
                        "cable_type": cable.cable_type.value,
                        "floor_plan_id": cable.floor_plan_id,
                        "source_device_id": cable.source_device_id,
                        "target_device_id": cable.target_device_id,
                        "source_port": cable.source_port,
                        "target_port": cable.target_port,
                        "length": cable.length,
                        "color": cable.color,
                        "path_points": cable.path_points
                    }
                    for cable in cables
                ]
            }
