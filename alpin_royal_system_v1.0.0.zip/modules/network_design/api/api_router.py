"""
Alpin Royal Casino Management System - Network Design Module API
This module provides API endpoints for network design and planning.
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, Path
from sqlalchemy.ext.asyncio import AsyncSession

from modules.network_design.models.network import (
    FloorPlan, NetworkDevice, Cable, DeviceType, ConnectionType,
    FloorPlanCreate, FloorPlanUpdate, NetworkDeviceCreate, 
    NetworkDeviceUpdate, CableCreate, CableUpdate, NetworkDeviceSearch,
    NetworkDashboard
)
from modules.network_design.services.network_service import NetworkDesignService
from base_layer.utils.database import get_db_session
from base_layer.utils.storage import get_storage_manager
from base_layer.utils.event_bus import get_event_bus
from base_layer.auth.auth_manager import get_current_user, User

router = APIRouter(prefix="/api/network", tags=["network"])

# Helper function to get the network service
async def get_network_service(
    session: AsyncSession = Depends(get_db_session),
    storage_manager = Depends(get_storage_manager),
    event_bus = Depends(get_event_bus)
) -> NetworkDesignService:
    """Get the network design service"""
    return NetworkDesignService(session, storage_manager, event_bus)

# Floor Plan Endpoints

@router.post("/floor-plans", response_model=FloorPlan)
async def create_floor_plan(
    name: str = Form(...),
    description: str = Form(None),
    width: int = Form(0),
    height: int = Form(0),
    scale: float = Form(None),
    floor_number: int = Form(None),
    building: str = Form(None),
    file: UploadFile = File(None),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new floor plan"""
    floor_plan_data = FloorPlanCreate(
        name=name,
        description=description,
        width=width,
        height=height,
        scale=scale,
        floor_number=floor_number,
        building=building
    )
    return await service.create_floor_plan(floor_plan_data, file)

@router.get("/floor-plans", response_model=List[FloorPlan])
async def get_all_floor_plans(
    skip: int = 0,
    limit: int = 100,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get all floor plans"""
    return await service.get_all_floor_plans(skip, limit)

@router.get("/floor-plans/{floor_plan_id}", response_model=FloorPlan)
async def get_floor_plan(
    floor_plan_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get a floor plan by ID"""
    floor_plan = await service.get_floor_plan(floor_plan_id)
    if not floor_plan:
        raise HTTPException(status_code=404, detail="Floor plan not found")
    return floor_plan

@router.put("/floor-plans/{floor_plan_id}", response_model=FloorPlan)
async def update_floor_plan(
    floor_plan_id: int = Path(...),
    name: str = Form(None),
    description: str = Form(None),
    width: int = Form(None),
    height: int = Form(None),
    scale: float = Form(None),
    floor_number: int = Form(None),
    building: str = Form(None),
    is_active: bool = Form(None),
    file: UploadFile = File(None),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Update a floor plan"""
    floor_plan_data = FloorPlanUpdate(
        name=name,
        description=description,
        width=width,
        height=height,
        scale=scale,
        floor_number=floor_number,
        building=building,
        is_active=is_active
    )
    floor_plan = await service.update_floor_plan(floor_plan_id, floor_plan_data, file)
    if not floor_plan:
        raise HTTPException(status_code=404, detail="Floor plan not found")
    return floor_plan

@router.delete("/floor-plans/{floor_plan_id}", response_model=Dict[str, bool])
async def delete_floor_plan(
    floor_plan_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Delete a floor plan"""
    result = await service.delete_floor_plan(floor_plan_id)
    if not result:
        raise HTTPException(status_code=404, detail="Floor plan not found")
    return {"success": True}

@router.get("/floor-plans/{floor_plan_id}/devices", response_model=List[NetworkDevice])
async def get_floor_plan_devices(
    floor_plan_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get devices for a floor plan"""
    return await service.get_network_devices_by_floor_plan(floor_plan_id)

@router.get("/floor-plans/{floor_plan_id}/cables", response_model=List[Cable])
async def get_floor_plan_cables(
    floor_plan_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get cables for a floor plan"""
    return await service.get_cables_by_floor_plan(floor_plan_id)

@router.get("/floor-plans/{floor_plan_id}/export", response_model=Dict[str, Any])
async def export_floor_plan_data(
    floor_plan_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Export network data for a floor plan"""
    return await service.export_network_data(floor_plan_id)

# Network Device Endpoints

@router.post("/devices", response_model=NetworkDevice)
async def create_network_device(
    device_data: NetworkDeviceCreate,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new network device"""
    return await service.create_network_device(device_data)

@router.get("/devices", response_model=List[NetworkDevice])
async def get_all_network_devices(
    skip: int = 0,
    limit: int = 100,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get all network devices"""
    return await service.get_all_network_devices(skip, limit)

@router.get("/devices/{device_id}", response_model=NetworkDevice)
async def get_network_device(
    device_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get a network device by ID"""
    device = await service.get_network_device(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Network device not found")
    return device

@router.put("/devices/{device_id}", response_model=NetworkDevice)
async def update_network_device(
    device_id: int,
    device_data: NetworkDeviceUpdate,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Update a network device"""
    device = await service.update_network_device(device_id, device_data)
    if not device:
        raise HTTPException(status_code=404, detail="Network device not found")
    return device

@router.delete("/devices/{device_id}", response_model=Dict[str, bool])
async def delete_network_device(
    device_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Delete a network device"""
    result = await service.delete_network_device(device_id)
    if not result:
        raise HTTPException(status_code=404, detail="Network device not found")
    return {"success": True}

@router.get("/devices/{device_id}/cables", response_model=List[Cable])
async def get_device_cables(
    device_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get cables connected to a device"""
    return await service.get_cables_by_device(device_id)

@router.get("/devices/search", response_model=List[NetworkDevice])
async def search_network_devices(
    floor_plan_id: Optional[int] = None,
    device_type: Optional[DeviceType] = None,
    name: Optional[str] = None,
    ip_address: Optional[str] = None,
    mac_address: Optional[str] = None,
    is_active: Optional[bool] = None,
    skip: int = 0,
    limit: int = 100,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Search for network devices based on various criteria"""
    search_params = NetworkDeviceSearch(
        floor_plan_id=floor_plan_id,
        device_type=device_type,
        name=name,
        ip_address=ip_address,
        mac_address=mac_address,
        is_active=is_active
    )
    return await service.search_network_devices(search_params, skip, limit)

@router.get("/devices/type/{device_type}", response_model=List[NetworkDevice])
async def get_devices_by_type(
    device_type: DeviceType = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get network devices by type"""
    return await service.get_network_devices_by_type(device_type)

# Cable Endpoints

@router.post("/cables", response_model=Cable)
async def create_cable(
    cable_data: CableCreate,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new cable"""
    return await service.create_cable(cable_data)

@router.get("/cables", response_model=List[Cable])
async def get_all_cables(
    skip: int = 0,
    limit: int = 100,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get all cables"""
    return await service.get_all_cables(skip, limit)

@router.get("/cables/{cable_id}", response_model=Cable)
async def get_cable(
    cable_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get a cable by ID"""
    cable = await service.get_cable(cable_id)
    if not cable:
        raise HTTPException(status_code=404, detail="Cable not found")
    return cable

@router.put("/cables/{cable_id}", response_model=Cable)
async def update_cable(
    cable_id: int,
    cable_data: CableUpdate,
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Update a cable"""
    cable = await service.update_cable(cable_id, cable_data)
    if not cable:
        raise HTTPException(status_code=404, detail="Cable not found")
    return cable

@router.delete("/cables/{cable_id}", response_model=Dict[str, bool])
async def delete_cable(
    cable_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Delete a cable"""
    result = await service.delete_cable(cable_id)
    if not result:
        raise HTTPException(status_code=404, detail="Cable not found")
    return {"success": True}

@router.get("/cables/{cable_id}/devices", response_model=Cable)
async def get_cable_with_devices(
    cable_id: int = Path(...),
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get a cable with its connected devices"""
    cable = await service.get_cable_with_devices(cable_id)
    if not cable:
        raise HTTPException(status_code=404, detail="Cable not found")
    return cable

# Dashboard Endpoints

@router.get("/dashboard", response_model=NetworkDashboard)
async def get_network_dashboard(
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Get network dashboard data"""
    return await service.get_network_dashboard()

# Export Endpoints

@router.get("/export", response_model=Dict[str, Any])
async def export_network_data(
    service: NetworkDesignService = Depends(get_network_service),
    current_user: User = Depends(get_current_user)
):
    """Export all network data"""
    return await service.export_network_data()
