import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Grid, 
  Button, 
  TextField, 
  Select, 
  MenuItem, 
  FormControl, 
  InputLabel,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  Tooltip,
  CircularProgress,
  Snackbar,
  Alert,
  Card,
  CardContent,
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Upload as UploadIcon,
  Download as DownloadIcon,
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Router as RouterIcon,
  Videocam as CameraIcon,
  Computer as ComputerIcon,
  Tv as TvIcon,
  Casino as SlotMachineIcon,
  ConfirmationNumber as TicketIcon,
  Storage as ServerIcon,
  DeviceHub as SwitchIcon,
  ViewModule as PatchPanelIcon,
  Cable as CableIcon,
  ZoomIn as ZoomInIcon,
  ZoomOut as ZoomOutIcon,
  PanTool as PanIcon
} from '@mui/icons-material';
import { Stage, Layer, Image, Circle, Rect, Line, Arrow, Group, Text, Transformer } from 'react-konva';

// Network Design Dashboard Component
export const NetworkDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch dashboard data from API
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        // In a real implementation, this would be an API call
        // const response = await fetch('/api/network/dashboard');
        // const data = await response.json();
        
        // Mock data for demonstration
        const mockData = {
          total_devices: 156,
          devices_by_type: {
            CAMERA_FIXED: 42,
            CAMERA_PTZ: 18,
            ROUTER: 8,
            WIRELESS_ROUTER: 12,
            SWITCH: 15,
            PATCH_PANEL: 10,
            SERVER: 5,
            WORKSTATION: 20,
            TV: 15,
            RASPBERRY_PI: 5,
            SLOT_MACHINE: 5,
            TICKET_KIOSK: 1
          },
          total_cables: 245,
          cables_by_type: {
            ETHERNET: 180,
            FIBER: 35,
            HDMI: 20,
            OTHER: 10
          },
          active_devices: 148,
          inactive_devices: 8,
          devices_by_floor: {
            "Main Building - Floor 1": 65,
            "Main Building - Floor 2": 45,
            "Main Building - Floor 3": 30,
            "Annex - Floor 1": 16
          },
          recent_changes: [
            {
              id: 1,
              name: "Security Camera 12",
              type: "CAMERA_PTZ",
              updated_at: "2025-03-25T14:32:15",
              entity_type: "device"
            },
            {
              id: 2,
              name: "Switch-Core-01",
              type: "SWITCH",
              updated_at: "2025-03-25T11:15:42",
              entity_type: "device"
            },
            {
              id: 3,
              name: "CAB-0123",
              type: "ETHERNET",
              updated_at: "2025-03-24T16:45:30",
              entity_type: "cable"
            }
          ]
        };
        
        setDashboardData(mockData);
        setLoading(false);
      } catch (err) {
        setError('Failed to load dashboard data');
        setLoading(false);
        console.error(err);
      }
    };

    fetchDashboardData();
  }, []);

  // Helper function to get icon for device type
  const getDeviceIcon = (deviceType) => {
    switch (deviceType) {
      case 'CAMERA_FIXED':
      case 'CAMERA_PTZ':
        return <CameraIcon />;
      case 'ROUTER':
      case 'WIRELESS_ROUTER':
        return <RouterIcon />;
      case 'SWITCH':
        return <SwitchIcon />;
      case 'PATCH_PANEL':
        return <PatchPanelIcon />;
      case 'SERVER':
        return <ServerIcon />;
      case 'WORKSTATION':
        return <ComputerIcon />;
      case 'TV':
        return <TvIcon />;
      case 'SLOT_MACHINE':
        return <SlotMachineIcon />;
      case 'TICKET_KIOSK':
        return <TicketIcon />;
      default:
        return <DeviceHub />;
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Network Design Dashboard
      </Typography>
      
      <Grid container spacing={3}>
        {/* Summary Cards */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="primary">Total Devices</Typography>
              <Typography variant="h3">{dashboardData.total_devices}</Typography>
              <Box sx={{ mt: 1, display: 'flex', alignItems: 'center' }}>
                <Chip 
                  label={`Active: ${dashboardData.active_devices}`} 
                  color="success" 
                  size="small" 
                  sx={{ mr: 1 }} 
                />
                <Chip 
                  label={`Inactive: ${dashboardData.inactive_devices}`} 
                  color="error" 
                  size="small" 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="primary">Total Cables</Typography>
              <Typography variant="h3">{dashboardData.total_cables}</Typography>
              <Box sx={{ mt: 1 }}>
                <Chip 
                  label={`Ethernet: ${dashboardData.cables_by_type.ETHERNET || 0}`} 
                  color="primary" 
                  size="small" 
                  sx={{ mr: 1 }} 
                />
                <Chip 
                  label={`Fiber: ${dashboardData.cables_by_type.FIBER || 0}`} 
                  color="secondary" 
                  size="small" 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="primary">Recent Changes</Typography>
              <List dense>
                {dashboardData.recent_changes.map((change) => (
                  <ListItem key={`${change.entity_type}-${change.id}`}>
                    <ListItemIcon>
                      {change.entity_type === 'device' 
                        ? getDeviceIcon(change.type) 
                        : <CableIcon />}
                    </ListItemIcon>
                    <ListItemText 
                      primary={change.name} 
                      secondary={`${change.entity_type === 'device' ? 'Device' : 'Cable'} - ${new Date(change.updated_at).toLocaleString()}`} 
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Device Distribution by Type */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title="Devices by Type" />
            <CardContent>
              <Box sx={{ height: 300, overflowY: 'auto' }}>
                {Object.entries(dashboardData.devices_by_type).map(([type, count]) => (
                  <Box key={type} sx={{ mb: 1, display: 'flex', alignItems: 'center' }}>
                    <Box sx={{ mr: 2, width: 30 }}>{getDeviceIcon(type)}</Box>
                    <Box sx={{ flexGrow: 1 }}>
                      <Typography variant="body2">{type.replace('_', ' ')}</Typography>
                      <Box sx={{ width: '100%', bgcolor: 'background.paper', borderRadius: 1 }}>
                        <Box 
                          sx={{ 
                            height: 10, 
                            bgcolor: 'primary.main', 
                            borderRadius: 1,
                            width: `${(count / dashboardData.total_devices) * 100}%`
                          }} 
                        />
                      </Box>
                    </Box>
                    <Typography variant="body2" sx={{ ml: 2, minWidth: 30 }}>{count}</Typography>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Device Distribution by Floor */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title="Devices by Location" />
            <CardContent>
              <Box sx={{ height: 300, overflowY: 'auto' }}>
                {Object.entries(dashboardData.devices_by_floor).map(([location, count]) => (
                  <Box key={location} sx={{ mb: 1 }}>
                    <Typography variant="body2">{location}</Typography>
                    <Box sx={{ width: '100%', bgcolor: 'background.paper', borderRadius: 1 }}>
                      <Box 
                        sx={{ 
                          height: 10, 
                          bgcolor: 'secondary.main', 
                          borderRadius: 1,
                          width: `${(count / dashboardData.total_devices) * 100}%`
                        }} 
                      />
                    </Box>
                    <Typography variant="body2" align="right">{count}</Typography>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Action Buttons */}
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
            <Button 
              variant="contained" 
              startIcon={<AddIcon />} 
              sx={{ mr: 1 }}
              onClick={() => window.location.href = '/network/floor-plans/new'}
            >
              New Floor Plan
            </Button>
            <Button 
              variant="outlined" 
              startIcon={<SearchIcon />}
              onClick={() => window.location.href = '/network/devices/search'}
            >
              Search Devices
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

// Floor Plan Editor Component
export const FloorPlanEditor = () => {
  const [floorPlan, setFloorPlan] = useState(null);
  const [devices, setDevices] = useState([]);
  const [cables, setCables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [selectedType, setSelectedType] = useState(null); // 'device' or 'cable'
  const [mode, setMode] = useState('select'); // 'select', 'add', 'connect', 'pan'
  const [deviceToAdd, setDeviceToAdd] = useState(null);
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [showDeviceDialog, setShowDeviceDialog] = useState(false);
  const [showCableDialog, setShowCableDialog] = useState(false);
  const [deviceFormData, setDeviceFormData] = useState({});
  const [cableFormData, setCableFormData] = useState({});
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
  
  const stageRef = useRef(null);
  const transformerRef = useRef(null);
  
  // Mock floor plan ID for demonstration
  const floorPlanId = 1;
  
  useEffect(() => {
    // Fetch floor plan data from API
    const fetchFloorPlanData = async () => {
      try {
        setLoading(true);
        // In a real implementation, these would be API calls
        // const floorPlanResponse = await fetch(`/api/network/floor-plans/${floorPlanId}`);
        // const devicesResponse = await fetch(`/api/network/floor-plans/${floorPlanId}/devices`);
        // const cablesResponse = await fetch(`/api/network/floor-plans/${floorPlanId}/cables`);
        
        // const floorPlanData = await floorPlanResponse.json();
        // const devicesData = await devicesResponse.json();
        // const cablesData = await cablesResponse.json();
        
        // Mock data for demonstration
        const mockFloorPlan = {
          floor_plan_id: 1,
          name: "Main Casino Floor",
          description: "First floor of the main casino building",
          file_path: "/floor_plans/main_casino_floor.jpg",
          width: 1200,
          height: 800,
          scale: 0.1, // meters per pixel
          floor_number: 1,
          building: "Main Building"
        };
        
        const mockDevices = [
          {
            device_id: 1,
            name: "Security Camera 1",
            device_type: "CAMERA_PTZ",
            x_position: 200,
            y_position: 150,
            rotation: 45,
            ip_address: "192.168.1.101",
            mac_address: "00:1A:2B:3C:4D:5E",
            fov_direction: 45,
            fov_angle: 90,
            camera_number: 1
          },
          {
            device_id: 2,
            name: "Core Switch",
            device_type: "SWITCH",
            x_position: 500,
            y_position: 300,
            rotation: 0,
            ip_address: "192.168.1.1",
            mac_address: "00:1A:2B:3C:4D:5F"
          },
          {
            device_id: 3,
            name: "Wireless AP 1",
            device_type: "WIRELESS_ROUTER",
            x_position: 800,
            y_position: 200,
            rotation: 0,
            ip_address: "192.168.1.2",
            mac_address: "00:1A:2B:3C:4D:60"
          }
        ];
        
        const mockCables = [
          {
            cable_id: 1,
            cable_number: "CAB-0001",
            cable_type: "ETHERNET",
            source_device_id: 2,
            target_device_id: 1,
            source_port: "Gi1/0/1",
            target_port: "LAN1",
            length: 15,
            color: "blue",
            path_points: [
              [500, 300],
              [350, 300],
              [350, 150],
              [200, 150]
            ]
          },
          {
            cable_id: 2,
            cable_number: "CAB-0002",
            cable_type: "ETHERNET",
            source_device_id: 2,
            target_device_id: 3,
            source_port: "Gi1/0/2",
            target_port: "LAN1",
            length: 20,
            color: "blue",
            path_points: [
              [500, 300],
              [650, 300],
              [650, 200],
              [800, 200]
            ]
          }
        ];
        
        setFloorPlan(mockFloorPlan);
        setDevices(mockDevices);
        setCables(mockCables);
        setLoading(false);
      } catch (err) {
        setError('Failed to load floor plan data');
        setLoading(false);
        console.error(err);
      }
    };

    fetchFloorPlanData();
  }, [floorPlanId]);
  
  useEffect(() => {
    // Update transformer when selection changes
    if (selectedId && selectedType === 'device' && transformerRef.current) {
      // Find the Konva node by name
      const stage = stageRef.current;
      const selectedNode = stage.findOne(`.device-${selectedId}`);
      
      if (selectedNode) {
        // Attach transformer to the selected node
        transformerRef.current.nodes([selectedNode]);
        transformerRef.current.getLayer().batchDraw();
      }
    } else if (transformerRef.current) {
      // Clear transformer
      transformerRef.current.nodes([]);
      transformerRef.current.getLayer().batchDraw();
    }
  }, [selectedId, selectedType]);
  
  // Handle device selection
  const handleSelectDevice = (deviceId) => {
    if (mode === 'select') {
      setSelectedId(deviceId);
      setSelectedType('device');
    } else if (mode === 'connect' && selectedId && selectedType === 'device') {
      // Create a new cable between the previously selected device and this one
      handleCreateCable(selectedId, deviceId);
    }
  };
  
  // Handle cable selection
  const handleSelectCable = (cableId) => {
    if (mode === 'select') {
      setSelectedId(cableId);
      setSelectedType('cable');
    }
  };
  
  // Handle stage click (background)
  const handleStageClick = (e) => {
    // If clicking on the background, deselect
    if (e.target === e.currentTarget) {
      setSelectedId(null);
      setSelectedType(null);
    }
    
    // If in add mode, add a device at the clicked position
    if (mode === 'add' && deviceToAdd) {
      const pointerPosition = stageRef.current.getPointerPosition();
      const stagePosition = stageRef.current.position();
      const stageScale = stageRef.current.scaleX();
      
      // Calculate the actual position on the floor plan
      const x = (pointerPosition.x - stagePosition.x) / stageScale;
      const y = (pointerPosition.y - stagePosition.y) / stageScale;
      
      handleAddDevice(x, y);
    }
  };
  
  // Handle device drag
  const handleDeviceDrag = (deviceId, newX, newY) => {
    setDevices(devices.map(device => 
      device.device_id === deviceId 
        ? { ...device, x_position: newX, y_position: newY } 
        : device
    ));
    
    // Update connected cables
    setCables(cables.map(cable => {
      if (cable.source_device_id === deviceId || cable.target_device_id === deviceId) {
        let newPathPoints = [...(cable.path_points || [])];
        
        if (cable.source_device_id === deviceId && newPathPoints.length > 0) {
          newPathPoints[0] = [newX, newY];
        }
        
        if (cable.target_device_id === deviceId && newPathPoints.length > 0) {
          newPathPoints[newPathPoints.length - 1] = [newX, newY];
        }
        
        return { ...cable, path_points: newPathPoints };
      }
      return cable;
    }));
  };
  
  // Handle device rotation
  const handleDeviceRotate = (deviceId, newRotation) => {
    setDevices(devices.map(device => 
      device.device_id === deviceId 
        ? { ...device, rotation: newRotation } 
        : device
    ));
  };
  
  // Handle adding a new device
  const handleAddDevice = (x, y) => {
    // Open the device dialog with initial position
    setDeviceFormData({
      name: '',
      device_type: deviceToAdd,
      x_position: x,
      y_position: y,
      rotation: 0,
      ip_address: '',
      mac_address: '',
      fov_direction: deviceToAdd.includes('CAMERA') ? 0 : null,
      fov_angle: deviceToAdd.includes('CAMERA') ? 90 : null,
      camera_number: deviceToAdd.includes('CAMERA') ? null : null
    });
    setShowDeviceDialog(true);
  };
  
  // Handle creating a new cable
  const handleCreateCable = (sourceDeviceId, targetDeviceId) => {
    // Find the source and target devices
    const sourceDevice = devices.find(d => d.device_id === sourceDeviceId);
    const targetDevice = devices.find(d => d.device_id === targetDeviceId);
    
    if (!sourceDevice || !targetDevice) {
      setNotification({
        open: true,
        message: 'Source or target device not found',
        severity: 'error'
      });
      return;
    }
    
    // Open the cable dialog with initial data
    setCableFormData({
      cable_number: '',
      cable_type: 'ETHERNET',
      source_device_id: sourceDeviceId,
      target_device_id: targetDeviceId,
      source_port: '',
      target_port: '',
      length: null,
      color: 'blue',
      path_points: [
        [sourceDevice.x_position, sourceDevice.y_position],
        [targetDevice.x_position, targetDevice.y_position]
      ]
    });
    setShowCableDialog(true);
    
    // Reset the mode and selection
    setMode('select');
    setSelectedId(null);
    setSelectedType(null);
  };
  
  // Handle saving a new device
  const handleSaveDevice = () => {
    // In a real implementation, this would be an API call
    // const response = await fetch('/api/network/devices', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ ...deviceFormData, floor_plan_id: floorPlanId })
    // });
    
    // Mock implementation
    const newDevice = {
      ...deviceFormData,
      device_id: devices.length + 1,
      floor_plan_id: floorPlanId
    };
    
    setDevices([...devices, newDevice]);
    setShowDeviceDialog(false);
    setDeviceFormData({});
    setMode('select');
    setDeviceToAdd(null);
    
    setNotification({
      open: true,
      message: 'Device added successfully',
      severity: 'success'
    });
  };
  
  // Handle saving a new cable
  const handleSaveCable = () => {
    // In a real implementation, this would be an API call
    // const response = await fetch('/api/network/cables', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ ...cableFormData, floor_plan_id: floorPlanId })
    // });
    
    // Mock implementation
    const newCable = {
      ...cableFormData,
      cable_id: cables.length + 1,
      floor_plan_id: floorPlanId
    };
    
    setCables([...cables, newCable]);
    setShowCableDialog(false);
    setCableFormData({});
    
    setNotification({
      open: true,
      message: 'Cable added successfully',
      severity: 'success'
    });
  };
  
  // Handle deleting a device or cable
  const handleDelete = () => {
    if (!selectedId || !selectedType) return;
    
    if (selectedType === 'device') {
      // Check if device has connected cables
      const connectedCables = cables.filter(
        cable => cable.source_device_id === selectedId || cable.target_device_id === selectedId
      );
      
      if (connectedCables.length > 0) {
        setNotification({
          open: true,
          message: 'Cannot delete device with connected cables',
          severity: 'error'
        });
        return;
      }
      
      // In a real implementation, this would be an API call
      // await fetch(`/api/network/devices/${selectedId}`, { method: 'DELETE' });
      
      // Mock implementation
      setDevices(devices.filter(device => device.device_id !== selectedId));
      
      setNotification({
        open: true,
        message: 'Device deleted successfully',
        severity: 'success'
      });
    } else if (selectedType === 'cable') {
      // In a real implementation, this would be an API call
      // await fetch(`/api/network/cables/${selectedId}`, { method: 'DELETE' });
      
      // Mock implementation
      setCables(cables.filter(cable => cable.cable_id !== selectedId));
      
      setNotification({
        open: true,
        message: 'Cable deleted successfully',
        severity: 'success'
      });
    }
    
    setSelectedId(null);
    setSelectedType(null);
  };
  
  // Handle zoom in
  const handleZoomIn = () => {
    setScale(scale * 1.2);
  };
  
  // Handle zoom out
  const handleZoomOut = () => {
    setScale(scale / 1.2);
  };
  
  // Handle pan mode
  const handlePanStart = () => {
    setMode('pan');
  };
  
  // Get device icon component based on device type
  const getDeviceComponent = (device) => {
    const { device_id, device_type, x_position, y_position, rotation, fov_direction, fov_angle } = device;
    
    // Base properties for all device types
    const baseProps = {
      x: x_position,
      y: y_position,
      rotation: rotation || 0,
      draggable: mode === 'select',
      onClick: () => handleSelectDevice(device_id),
      onDragEnd: (e) => handleDeviceDrag(device_id, e.target.x(), e.target.y()),
      onTransformEnd: (e) => {
        const node = e.target;
        handleDeviceRotate(device_id, node.rotation());
      },
      name: `device-${device_id}`,
      id: `device-${device_id}`
    };
    
    // Determine color based on device type
    let fill = '#3f51b5'; // Default blue
    
    switch (device_type) {
      case 'CAMERA_FIXED':
      case 'CAMERA_PTZ':
        fill = '#f44336'; // Red for cameras
        break;
      case 'ROUTER':
      case 'WIRELESS_ROUTER':
        fill = '#ff9800'; // Orange for routers
        break;
      case 'SWITCH':
        fill = '#2196f3'; // Blue for switches
        break;
      case 'PATCH_PANEL':
        fill = '#9c27b0'; // Purple for patch panels
        break;
      case 'SERVER':
        fill = '#4caf50'; // Green for servers
        break;
      case 'WORKSTATION':
      case 'TV':
        fill = '#607d8b'; // Gray for endpoints
        break;
      case 'SLOT_MACHINE':
      case 'TICKET_KIOSK':
        fill = '#ffeb3b'; // Yellow for casino equipment
        break;
    }
    
    // Create different shapes based on device type
    if (device_type.includes('CAMERA')) {
      // Camera with field of view
      return (
        <Group {...baseProps}>
          <Circle radius={10} fill={fill} stroke="black" strokeWidth={1} />
          {fov_direction !== null && fov_angle !== null && (
            <Group rotation={fov_direction || 0}>
              <Line
                points={[0, 0, 50, -25, 50, 25, 0, 0]}
                fill="rgba(244, 67, 54, 0.2)"
                stroke="rgba(244, 67, 54, 0.5)"
                strokeWidth={1}
                closed={true}
              />
            </Group>
          )}
          <Text 
            text={device.name}
            x={-50}
            y={15}
            width={100}
            align="center"
            fontSize={10}
          />
        </Group>
      );
    } else if (device_type === 'SWITCH' || device_type === 'PATCH_PANEL') {
      // Rectangle for switches and patch panels
      return (
        <Group {...baseProps}>
          <Rect
            width={30}
            height={20}
            fill={fill}
            stroke="black"
            strokeWidth={1}
            offsetX={15}
            offsetY={10}
          />
          <Text 
            text={device.name}
            x={-50}
            y={15}
            width={100}
            align="center"
            fontSize={10}
          />
        </Group>
      );
    } else {
      // Circle for other devices
      return (
        <Group {...baseProps}>
          <Circle radius={10} fill={fill} stroke="black" strokeWidth={1} />
          <Text 
            text={device.name}
            x={-50}
            y={15}
            width={100}
            align="center"
            fontSize={10}
          />
        </Group>
      );
    }
  };
  
  // Get cable component
  const getCableComponent = (cable) => {
    const { cable_id, path_points, cable_type } = cable;
    
    // Determine color based on cable type
    let stroke = '#2196f3'; // Default blue for Ethernet
    let strokeWidth = 1;
    
    switch (cable_type) {
      case 'FIBER':
        stroke = '#ff9800'; // Orange for fiber
        strokeWidth = 2;
        break;
      case 'HDMI':
        stroke = '#9c27b0'; // Purple for HDMI
        break;
      case 'WIFI':
        stroke = '#4caf50'; // Green for wireless
        strokeWidth = 1;
        stroke = 'dashed';
        break;
    }
    
    // If path points are defined, use them
    if (path_points && path_points.length >= 2) {
      // Flatten the array of points
      const flatPoints = path_points.flat();
      
      return (
        <Line
          points={flatPoints}
          stroke={stroke}
          strokeWidth={strokeWidth}
          onClick={() => handleSelectCable(cable_id)}
          name={`cable-${cable_id}`}
          id={`cable-${cable_id}`}
          dash={cable_type === 'WIFI' ? [5, 5] : undefined}
        />
      );
    }
    
    // Fallback: direct line between source and target
    const sourceDevice = devices.find(d => d.device_id === cable.source_device_id);
    const targetDevice = devices.find(d => d.device_id === cable.target_device_id);
    
    if (!sourceDevice || !targetDevice) return null;
    
    return (
      <Line
        points={[sourceDevice.x_position, sourceDevice.y_position, targetDevice.x_position, targetDevice.y_position]}
        stroke={stroke}
        strokeWidth={strokeWidth}
        onClick={() => handleSelectCable(cable_id)}
        name={`cable-${cable_id}`}
        id={`cable-${cable_id}`}
        dash={cable_type === 'WIFI' ? [5, 5] : undefined}
      />
    );
  };
  
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }
  
  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }
  
  return (
    <Box sx={{ p: 3, height: 'calc(100vh - 100px)', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="h4">{floorPlan.name}</Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<SaveIcon />} 
            sx={{ mr: 1 }}
            onClick={() => {
              setNotification({
                open: true,
                message: 'Floor plan saved successfully',
                severity: 'success'
              });
            }}
          >
            Save
          </Button>
          <Button 
            variant="outlined" 
            startIcon={<DownloadIcon />}
            onClick={() => {
              setNotification({
                open: true,
                message: 'Floor plan exported successfully',
                severity: 'success'
              });
            }}
          >
            Export
          </Button>
        </Box>
      </Box>
      
      <Box sx={{ display: 'flex', mb: 2 }}>
        <Box sx={{ mr: 2 }}>
          <Typography variant="subtitle1">Tools</Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <Tooltip title="Select Mode">
              <IconButton 
                color={mode === 'select' ? 'primary' : 'default'} 
                onClick={() => { 
                  setMode('select'); 
                  setDeviceToAdd(null); 
                }}
              >
                <SearchIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Pan Mode">
              <IconButton 
                color={mode === 'pan' ? 'primary' : 'default'} 
                onClick={handlePanStart}
              >
                <PanIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Zoom In">
              <IconButton onClick={handleZoomIn}>
                <ZoomInIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Zoom Out">
              <IconButton onClick={handleZoomOut}>
                <ZoomOutIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Delete Selected">
              <IconButton 
                color="error" 
                onClick={handleDelete}
                disabled={!selectedId}
              >
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
        
        <Box sx={{ mr: 2 }}>
          <Typography variant="subtitle1">Add Devices</Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <Tooltip title="Add Camera">
              <IconButton 
                color={mode === 'add' && deviceToAdd === 'CAMERA_PTZ' ? 'primary' : 'default'} 
                onClick={() => { 
                  setMode('add'); 
                  setDeviceToAdd('CAMERA_PTZ'); 
                }}
              >
                <CameraIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Add Switch">
              <IconButton 
                color={mode === 'add' && deviceToAdd === 'SWITCH' ? 'primary' : 'default'} 
                onClick={() => { 
                  setMode('add'); 
                  setDeviceToAdd('SWITCH'); 
                }}
              >
                <SwitchIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Add Router">
              <IconButton 
                color={mode === 'add' && deviceToAdd === 'ROUTER' ? 'primary' : 'default'} 
                onClick={() => { 
                  setMode('add'); 
                  setDeviceToAdd('ROUTER'); 
                }}
              >
                <RouterIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Add Server">
              <IconButton 
                color={mode === 'add' && deviceToAdd === 'SERVER' ? 'primary' : 'default'} 
                onClick={() => { 
                  setMode('add'); 
                  setDeviceToAdd('SERVER'); 
                }}
              >
                <ServerIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Add Workstation">
              <IconButton 
                color={mode === 'add' && deviceToAdd === 'WORKSTATION' ? 'primary' : 'default'} 
                onClick={() => { 
                  setMode('add'); 
                  setDeviceToAdd('WORKSTATION'); 
                }}
              >
                <ComputerIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
        
        <Box>
          <Typography variant="subtitle1">Connect</Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <Tooltip title="Connect Devices">
              <IconButton 
                color={mode === 'connect' ? 'primary' : 'default'} 
                onClick={() => { 
                  setMode('connect'); 
                  setSelectedId(null);
                  setSelectedType(null);
                }}
              >
                <CableIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
        
        <Box sx={{ flexGrow: 1 }} />
        
        <Box>
          <Typography variant="subtitle1">Selected Device</Typography>
          {selectedId && selectedType === 'device' ? (
            <Box>
              {(() => {
                const device = devices.find(d => d.device_id === selectedId);
                if (!device) return <Typography>No device selected</Typography>;
                
                return (
                  <Box>
                    <Typography variant="body2"><strong>Name:</strong> {device.name}</Typography>
                    <Typography variant="body2"><strong>Type:</strong> {device.device_type}</Typography>
                    <Typography variant="body2"><strong>IP:</strong> {device.ip_address || 'N/A'}</Typography>
                    <Typography variant="body2"><strong>MAC:</strong> {device.mac_address || 'N/A'}</Typography>
                    <Button 
                      size="small" 
                      variant="outlined" 
                      startIcon={<EditIcon />}
                      onClick={() => {
                        setDeviceFormData(device);
                        setShowDeviceDialog(true);
                      }}
                    >
                      Edit
                    </Button>
                  </Box>
                );
              })()}
            </Box>
          ) : selectedId && selectedType === 'cable' ? (
            <Box>
              {(() => {
                const cable = cables.find(c => c.cable_id === selectedId);
                if (!cable) return <Typography>No cable selected</Typography>;
                
                const sourceDevice = devices.find(d => d.device_id === cable.source_device_id);
                const targetDevice = devices.find(d => d.device_id === cable.target_device_id);
                
                return (
                  <Box>
                    <Typography variant="body2"><strong>Number:</strong> {cable.cable_number}</Typography>
                    <Typography variant="body2"><strong>Type:</strong> {cable.cable_type}</Typography>
                    <Typography variant="body2"><strong>From:</strong> {sourceDevice?.name || 'Unknown'}</Typography>
                    <Typography variant="body2"><strong>To:</strong> {targetDevice?.name || 'Unknown'}</Typography>
                    <Typography variant="body2"><strong>Length:</strong> {cable.length ? `${cable.length}m` : 'N/A'}</Typography>
                    <Button 
                      size="small" 
                      variant="outlined" 
                      startIcon={<EditIcon />}
                      onClick={() => {
                        setCableFormData(cable);
                        setShowCableDialog(true);
                      }}
                    >
                      Edit
                    </Button>
                  </Box>
                );
              })()}
            </Box>
          ) : (
            <Typography>No item selected</Typography>
          )}
        </Box>
      </Box>
      
      <Paper 
        elevation={3} 
        sx={{ 
          flexGrow: 1, 
          overflow: 'hidden',
          position: 'relative',
          cursor: mode === 'pan' ? 'grab' : mode === 'add' ? 'crosshair' : 'default'
        }}
      >
        <Stage
          width={window.innerWidth - 100}
          height={window.innerHeight - 250}
          ref={stageRef}
          scaleX={scale}
          scaleY={scale}
          x={position.x}
          y={position.y}
          onMouseDown={(e) => {
            if (mode === 'pan') {
              e.evt.preventDefault();
              stageRef.current.container().style.cursor = 'grabbing';
            }
          }}
          onMouseUp={(e) => {
            if (mode === 'pan') {
              stageRef.current.container().style.cursor = 'grab';
            }
          }}
          onMouseMove={(e) => {
            if (mode === 'pan' && e.evt.buttons === 1) {
              const dx = e.evt.movementX;
              const dy = e.evt.movementY;
              setPosition({
                x: position.x + dx,
                y: position.y + dy
              });
            }
          }}
          onClick={handleStageClick}
        >
          <Layer>
            {/* Floor plan background image */}
            {/* <Image 
              image={floorPlanImage} 
              width={floorPlan.width} 
              height={floorPlan.height} 
            /> */}
            
            {/* Cables */}
            {cables.map(cable => getCableComponent(cable))}
            
            {/* Devices */}
            {devices.map(device => getDeviceComponent(device))}
            
            {/* Transformer for selected device */}
            <Transformer
              ref={transformerRef}
              rotationSnaps={[0, 45, 90, 135, 180, 225, 270, 315]}
              rotateEnabled={true}
              resizeEnabled={false}
              borderDash={[3, 3]}
              borderStroke="#00a3ff"
              anchorStroke="#00a3ff"
              anchorFill="#fff"
              anchorSize={8}
              visible={selectedId && selectedType === 'device'}
            />
          </Layer>
        </Stage>
      </Paper>
      
      {/* Device Dialog */}
      <Dialog open={showDeviceDialog} onClose={() => setShowDeviceDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {deviceFormData.device_id ? 'Edit Device' : 'Add New Device'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Name"
                fullWidth
                value={deviceFormData.name || ''}
                onChange={(e) => setDeviceFormData({ ...deviceFormData, name: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Device Type</InputLabel>
                <Select
                  value={deviceFormData.device_type || ''}
                  label="Device Type"
                  onChange={(e) => setDeviceFormData({ ...deviceFormData, device_type: e.target.value })}
                >
                  <MenuItem value="CAMERA_FIXED">Fixed Camera</MenuItem>
                  <MenuItem value="CAMERA_PTZ">PTZ Camera</MenuItem>
                  <MenuItem value="ROUTER">Router</MenuItem>
                  <MenuItem value="WIRELESS_ROUTER">Wireless Router</MenuItem>
                  <MenuItem value="SWITCH">Switch</MenuItem>
                  <MenuItem value="PATCH_PANEL">Patch Panel</MenuItem>
                  <MenuItem value="SERVER">Server</MenuItem>
                  <MenuItem value="WORKSTATION">Workstation</MenuItem>
                  <MenuItem value="TV">TV</MenuItem>
                  <MenuItem value="RASPBERRY_PI">Raspberry Pi</MenuItem>
                  <MenuItem value="SLOT_MACHINE">Slot Machine</MenuItem>
                  <MenuItem value="TICKET_KIOSK">Ticket Kiosk</MenuItem>
                  <MenuItem value="OTHER">Other</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="IP Address"
                fullWidth
                value={deviceFormData.ip_address || ''}
                onChange={(e) => setDeviceFormData({ ...deviceFormData, ip_address: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="MAC Address"
                fullWidth
                value={deviceFormData.mac_address || ''}
                onChange={(e) => setDeviceFormData({ ...deviceFormData, mac_address: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                label="X Position"
                type="number"
                fullWidth
                value={deviceFormData.x_position || 0}
                onChange={(e) => setDeviceFormData({ ...deviceFormData, x_position: Number(e.target.value) })}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                label="Y Position"
                type="number"
                fullWidth
                value={deviceFormData.y_position || 0}
                onChange={(e) => setDeviceFormData({ ...deviceFormData, y_position: Number(e.target.value) })}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                label="Rotation"
                type="number"
                fullWidth
                value={deviceFormData.rotation || 0}
                onChange={(e) => setDeviceFormData({ ...deviceFormData, rotation: Number(e.target.value) })}
              />
            </Grid>
            
            {/* Camera-specific fields */}
            {deviceFormData.device_type && deviceFormData.device_type.includes('CAMERA') && (
              <>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="FOV Direction"
                    type="number"
                    fullWidth
                    value={deviceFormData.fov_direction || 0}
                    onChange={(e) => setDeviceFormData({ ...deviceFormData, fov_direction: Number(e.target.value) })}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="FOV Angle"
                    type="number"
                    fullWidth
                    value={deviceFormData.fov_angle || 90}
                    onChange={(e) => setDeviceFormData({ ...deviceFormData, fov_angle: Number(e.target.value) })}
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <TextField
                    label="Camera Number"
                    type="number"
                    fullWidth
                    value={deviceFormData.camera_number || ''}
                    onChange={(e) => setDeviceFormData({ ...deviceFormData, camera_number: e.target.value ? Number(e.target.value) : null })}
                  />
                </Grid>
              </>
            )}
            
            <Grid item xs={12}>
              <TextField
                label="Notes"
                fullWidth
                multiline
                rows={3}
                value={deviceFormData.notes || ''}
                onChange={(e) => setDeviceFormData({ ...deviceFormData, notes: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowDeviceDialog(false)}>Cancel</Button>
          <Button onClick={handleSaveDevice} variant="contained" color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Cable Dialog */}
      <Dialog open={showCableDialog} onClose={() => setShowCableDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {cableFormData.cable_id ? 'Edit Cable' : 'Add New Cable'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Cable Number"
                fullWidth
                value={cableFormData.cable_number || ''}
                onChange={(e) => setCableFormData({ ...cableFormData, cable_number: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Cable Type</InputLabel>
                <Select
                  value={cableFormData.cable_type || 'ETHERNET'}
                  label="Cable Type"
                  onChange={(e) => setCableFormData({ ...cableFormData, cable_type: e.target.value })}
                >
                  <MenuItem value="ETHERNET">Ethernet</MenuItem>
                  <MenuItem value="FIBER">Fiber</MenuItem>
                  <MenuItem value="WIFI">Wireless</MenuItem>
                  <MenuItem value="HDMI">HDMI</MenuItem>
                  <MenuItem value="VGA">VGA</MenuItem>
                  <MenuItem value="SERIAL">Serial</MenuItem>
                  <MenuItem value="USB">USB</MenuItem>
                  <MenuItem value="OTHER">Other</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Source Device</InputLabel>
                <Select
                  value={cableFormData.source_device_id || ''}
                  label="Source Device"
                  onChange={(e) => setCableFormData({ ...cableFormData, source_device_id: Number(e.target.value) })}
                >
                  {devices.map(device => (
                    <MenuItem key={`source-${device.device_id}`} value={device.device_id}>
                      {device.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Target Device</InputLabel>
                <Select
                  value={cableFormData.target_device_id || ''}
                  label="Target Device"
                  onChange={(e) => setCableFormData({ ...cableFormData, target_device_id: Number(e.target.value) })}
                >
                  {devices.map(device => (
                    <MenuItem key={`target-${device.device_id}`} value={device.device_id}>
                      {device.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Source Port"
                fullWidth
                value={cableFormData.source_port || ''}
                onChange={(e) => setCableFormData({ ...cableFormData, source_port: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Target Port"
                fullWidth
                value={cableFormData.target_port || ''}
                onChange={(e) => setCableFormData({ ...cableFormData, target_port: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Length (meters)"
                type="number"
                fullWidth
                value={cableFormData.length || ''}
                onChange={(e) => setCableFormData({ ...cableFormData, length: e.target.value ? Number(e.target.value) : null })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Color</InputLabel>
                <Select
                  value={cableFormData.color || 'blue'}
                  label="Color"
                  onChange={(e) => setCableFormData({ ...cableFormData, color: e.target.value })}
                >
                  <MenuItem value="blue">Blue</MenuItem>
                  <MenuItem value="orange">Orange</MenuItem>
                  <MenuItem value="green">Green</MenuItem>
                  <MenuItem value="brown">Brown</MenuItem>
                  <MenuItem value="gray">Gray</MenuItem>
                  <MenuItem value="white">White</MenuItem>
                  <MenuItem value="black">Black</MenuItem>
                  <MenuItem value="red">Red</MenuItem>
                  <MenuItem value="yellow">Yellow</MenuItem>
                  <MenuItem value="purple">Purple</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Notes"
                fullWidth
                multiline
                rows={3}
                value={cableFormData.notes || ''}
                onChange={(e) => setCableFormData({ ...cableFormData, notes: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowCableDialog(false)}>Cancel</Button>
          <Button onClick={handleSaveCable} variant="contained" color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Notification Snackbar */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={() => setNotification({ ...notification, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert 
          onClose={() => setNotification({ ...notification, open: false })} 
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

// Export all components
export default {
  NetworkDashboard,
  FloorPlanEditor
};
