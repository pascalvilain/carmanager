"""
Alpin Royal Casino Management System - Network Design Module
This module provides models for network design and planning.
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, DateTime, Text, JSON, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum
import uuid

from base_layer.utils.database import Base

class DeviceType(str, enum.Enum):
    """Enum for device types"""
    CAMERA_FIXED = "CAMERA_FIXED"
    CAMERA_PTZ = "CAMERA_PTZ"
    ROUTER = "ROUTER"
    WIRELESS_ROUTER = "WIRELESS_ROUTER"
    SWITCH = "SWITCH"
    PATCH_PANEL = "PATCH_PANEL"
    SERVER = "SERVER"
    WORKSTATION = "WORKSTATION"
    TV = "TV"
    RASPBERRY_PI = "RASPBERRY_PI"
    SLOT_MACHINE = "SLOT_MACHINE"
    TICKET_KIOSK = "TICKET_KIOSK"
    OTHER = "OTHER"

class ConnectionType(str, enum.Enum):
    """Enum for connection types"""
    ETHERNET = "ETHERNET"
    FIBER = "FIBER"
    WIFI = "WIFI"
    BLUETOOTH = "BLUETOOTH"
    SERIAL = "SERIAL"
    USB = "USB"
    HDMI = "HDMI"
    VGA = "VGA"
    OTHER = "OTHER"

class FloorPlan(Base):
    """Floor plan model"""
    __tablename__ = "floor_plans"
    
    floor_plan_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    file_path = Column(String(255), nullable=False)
    width = Column(Integer, nullable=False)  # Width in pixels
    height = Column(Integer, nullable=False)  # Height in pixels
    scale = Column(Float, nullable=True)  # Scale in meters per pixel
    floor_number = Column(Integer, nullable=True)
    building = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    devices = relationship("NetworkDevice", back_populates="floor_plan", cascade="all, delete-orphan")
    cables = relationship("Cable", back_populates="floor_plan", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<FloorPlan {self.name}>"

class NetworkDevice(Base):
    """Network device model"""
    __tablename__ = "network_devices"
    
    device_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    device_type = Column(Enum(DeviceType), nullable=False)
    floor_plan_id = Column(Integer, ForeignKey("floor_plans.floor_plan_id"), nullable=False)
    x_position = Column(Float, nullable=False)  # X position on floor plan
    y_position = Column(Float, nullable=False)  # Y position on floor plan
    rotation = Column(Float, default=0)  # Rotation in degrees
    ip_address = Column(String(45), nullable=True)  # IPv4 or IPv6
    mac_address = Column(String(17), nullable=True)  # MAC address
    manufacturer = Column(String(100), nullable=True)
    model = Column(String(100), nullable=True)
    serial_number = Column(String(100), nullable=True)
    firmware_version = Column(String(50), nullable=True)
    installation_date = Column(DateTime, nullable=True)
    last_maintenance_date = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)
    properties = Column(JSON, nullable=True)  # Additional device-specific properties
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Camera-specific fields
    fov_direction = Column(Float, nullable=True)  # Field of view direction in degrees
    fov_angle = Column(Float, nullable=True)  # Field of view angle in degrees
    camera_number = Column(Integer, nullable=True)
    
    # Relationships
    floor_plan = relationship("FloorPlan", back_populates="devices")
    source_cables = relationship("Cable", foreign_keys="[Cable.source_device_id]", back_populates="source_device")
    target_cables = relationship("Cable", foreign_keys="[Cable.target_device_id]", back_populates="target_device")
    
    def __repr__(self):
        return f"<NetworkDevice {self.name} ({self.device_type})>"

class Cable(Base):
    """Cable model"""
    __tablename__ = "cables"
    
    cable_id = Column(Integer, primary_key=True, index=True)
    cable_number = Column(String(50), nullable=False)
    cable_type = Column(Enum(ConnectionType), nullable=False)
    floor_plan_id = Column(Integer, ForeignKey("floor_plans.floor_plan_id"), nullable=False)
    source_device_id = Column(Integer, ForeignKey("network_devices.device_id"), nullable=False)
    target_device_id = Column(Integer, ForeignKey("network_devices.device_id"), nullable=False)
    source_port = Column(String(50), nullable=True)
    target_port = Column(String(50), nullable=True)
    length = Column(Float, nullable=True)  # Length in meters
    color = Column(String(20), nullable=True)
    is_active = Column(Boolean, default=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Path points for cable visualization (array of [x, y] coordinates)
    path_points = Column(JSON, nullable=True)
    
    # Relationships
    floor_plan = relationship("FloorPlan", back_populates="cables")
    source_device = relationship("NetworkDevice", foreign_keys=[source_device_id], back_populates="source_cables")
    target_device = relationship("NetworkDevice", foreign_keys=[target_device_id], back_populates="target_cables")
    
    def __repr__(self):
        return f"<Cable {self.cable_number}>"

# Models for API requests and responses

class FloorPlanCreate:
    """Schema for creating a floor plan"""
    def __init__(
        self,
        name: str,
        description: str = None,
        file_path: str = None,
        width: int = 0,
        height: int = 0,
        scale: float = None,
        floor_number: int = None,
        building: str = None
    ):
        self.name = name
        self.description = description
        self.file_path = file_path
        self.width = width
        self.height = height
        self.scale = scale
        self.floor_number = floor_number
        self.building = building

class FloorPlanUpdate:
    """Schema for updating a floor plan"""
    def __init__(
        self,
        name: str = None,
        description: str = None,
        file_path: str = None,
        width: int = None,
        height: int = None,
        scale: float = None,
        floor_number: int = None,
        building: str = None,
        is_active: bool = None
    ):
        self.name = name
        self.description = description
        self.file_path = file_path
        self.width = width
        self.height = height
        self.scale = scale
        self.floor_number = floor_number
        self.building = building
        self.is_active = is_active

class NetworkDeviceCreate:
    """Schema for creating a network device"""
    def __init__(
        self,
        name: str,
        device_type: DeviceType,
        floor_plan_id: int,
        x_position: float,
        y_position: float,
        rotation: float = 0,
        ip_address: str = None,
        mac_address: str = None,
        manufacturer: str = None,
        model: str = None,
        serial_number: str = None,
        firmware_version: str = None,
        installation_date: datetime = None,
        notes: str = None,
        properties: dict = None,
        fov_direction: float = None,
        fov_angle: float = None,
        camera_number: int = None
    ):
        self.name = name
        self.device_type = device_type
        self.floor_plan_id = floor_plan_id
        self.x_position = x_position
        self.y_position = y_position
        self.rotation = rotation
        self.ip_address = ip_address
        self.mac_address = mac_address
        self.manufacturer = manufacturer
        self.model = model
        self.serial_number = serial_number
        self.firmware_version = firmware_version
        self.installation_date = installation_date
        self.notes = notes
        self.properties = properties
        self.fov_direction = fov_direction
        self.fov_angle = fov_angle
        self.camera_number = camera_number

class NetworkDeviceUpdate:
    """Schema for updating a network device"""
    def __init__(
        self,
        name: str = None,
        device_type: DeviceType = None,
        floor_plan_id: int = None,
        x_position: float = None,
        y_position: float = None,
        rotation: float = None,
        ip_address: str = None,
        mac_address: str = None,
        manufacturer: str = None,
        model: str = None,
        serial_number: str = None,
        firmware_version: str = None,
        installation_date: datetime = None,
        last_maintenance_date: datetime = None,
        notes: str = None,
        properties: dict = None,
        is_active: bool = None,
        fov_direction: float = None,
        fov_angle: float = None,
        camera_number: int = None
    ):
        self.name = name
        self.device_type = device_type
        self.floor_plan_id = floor_plan_id
        self.x_position = x_position
        self.y_position = y_position
        self.rotation = rotation
        self.ip_address = ip_address
        self.mac_address = mac_address
        self.manufacturer = manufacturer
        self.model = model
        self.serial_number = serial_number
        self.firmware_version = firmware_version
        self.installation_date = installation_date
        self.last_maintenance_date = last_maintenance_date
        self.notes = notes
        self.properties = properties
        self.is_active = is_active
        self.fov_direction = fov_direction
        self.fov_angle = fov_angle
        self.camera_number = camera_number

class CableCreate:
    """Schema for creating a cable"""
    def __init__(
        self,
        cable_number: str,
        cable_type: ConnectionType,
        floor_plan_id: int,
        source_device_id: int,
        target_device_id: int,
        source_port: str = None,
        target_port: str = None,
        length: float = None,
        color: str = None,
        notes: str = None,
        path_points: list = None
    ):
        self.cable_number = cable_number
        self.cable_type = cable_type
        self.floor_plan_id = floor_plan_id
        self.source_device_id = source_device_id
        self.target_device_id = target_device_id
        self.source_port = source_port
        self.target_port = target_port
        self.length = length
        self.color = color
        self.notes = notes
        self.path_points = path_points

class CableUpdate:
    """Schema for updating a cable"""
    def __init__(
        self,
        cable_number: str = None,
        cable_type: ConnectionType = None,
        floor_plan_id: int = None,
        source_device_id: int = None,
        target_device_id: int = None,
        source_port: str = None,
        target_port: str = None,
        length: float = None,
        color: str = None,
        is_active: bool = None,
        notes: str = None,
        path_points: list = None
    ):
        self.cable_number = cable_number
        self.cable_type = cable_type
        self.floor_plan_id = floor_plan_id
        self.source_device_id = source_device_id
        self.target_device_id = target_device_id
        self.source_port = source_port
        self.target_port = target_port
        self.length = length
        self.color = color
        self.is_active = is_active
        self.notes = notes
        self.path_points = path_points

class NetworkDeviceSearch:
    """Schema for searching network devices"""
    def __init__(
        self,
        floor_plan_id: int = None,
        device_type: DeviceType = None,
        name: str = None,
        ip_address: str = None,
        mac_address: str = None,
        is_active: bool = None
    ):
        self.floor_plan_id = floor_plan_id
        self.device_type = device_type
        self.name = name
        self.ip_address = ip_address
        self.mac_address = mac_address
        self.is_active = is_active

class NetworkDashboard:
    """Schema for network dashboard data"""
    def __init__(
        self,
        total_devices: int = 0,
        devices_by_type: dict = None,
        total_cables: int = 0,
        cables_by_type: dict = None,
        active_devices: int = 0,
        inactive_devices: int = 0,
        devices_by_floor: dict = None,
        recent_changes: list = None
    ):
        self.total_devices = total_devices
        self.devices_by_type = devices_by_type or {}
        self.total_cables = total_cables
        self.cables_by_type = cables_by_type or {}
        self.active_devices = active_devices
        self.inactive_devices = inactive_devices
        self.devices_by_floor = devices_by_floor or {}
        self.recent_changes = recent_changes or []
