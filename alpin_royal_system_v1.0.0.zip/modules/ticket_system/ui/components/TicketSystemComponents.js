import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  TextField, 
  Select, 
  MenuItem, 
  FormControl, 
  InputLabel,
  Tabs,
  Tab,
  IconButton,
  Chip,
  Avatar,
  Divider,
  Card,
  CardContent,
  CardActions,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  ListItemSecondaryAction,
  Tooltip,
  CircularProgress,
  Badge,
  Drawer,
  AppBar,
  Toolbar,
  Collapse,
  Snackbar,
  Alert,
  Autocomplete,
  ToggleButton,
  ToggleButtonGroup,
  Pagination,
  Breadcrumbs,
  Link,
  Menu,
  Fade
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { 
  Dashboard as DashboardIcon,
  Assignment as AssignmentIcon,
  Search as SearchIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
  FilterList as FilterListIcon,
  Sort as SortIcon,
  MoreVert as MoreVertIcon,
  AttachFile as AttachFileIcon,
  Comment as CommentIcon,
  History as HistoryIcon,
  Link as LinkIcon,
  LocationOn as LocationOnIcon,
  Person as PersonIcon,
  Category as CategoryIcon,
  Flag as FlagIcon,
  Schedule as ScheduleIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Close as CloseIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  Visibility as VisibilityIcon,
  Save as SaveIcon,
  Print as PrintIcon,
  GetApp as GetAppIcon,
  Send as SendIcon,
  Image as ImageIcon,
  Description as DescriptionIcon,
  PictureAsPdf as PdfIcon,
  InsertDriveFile as FileIcon,
  Map as MapIcon
} from '@mui/icons-material';
import { 
  PieChart, 
  Pie, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { Stage, Layer, Rect, Circle, Line as KonvaLine, Text as KonvaText, Image as KonvaImage } from 'react-konva';
import { format, parseISO, isAfter, isBefore } from 'date-fns';

// Styled components
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  borderRadius: 12,
  boxShadow: '0 4px 20px 0 rgba(0,0,0,0.1)',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: '0 8px 25px 0 rgba(0,0,0,0.15)',
  },
}));

const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  borderRadius: 12,
  boxShadow: '0 4px 20px 0 rgba(0,0,0,0.1)',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: '0 8px 25px 0 rgba(0,0,0,0.15)',
  },
}));

const StatusChip = styled(Chip)(({ theme, status }) => {
  let color;
  switch (status) {
    case 'OPEN':
      color = theme.palette.info.main;
      break;
    case 'IN_PROGRESS':
      color = theme.palette.warning.main;
      break;
    case 'PENDING':
      color = theme.palette.warning.light;
      break;
    case 'RESOLVED':
      color = theme.palette.success.main;
      break;
    case 'CLOSED':
      color = theme.palette.success.dark;
      break;
    case 'REOPENED':
      color = theme.palette.error.main;
      break;
    default:
      color = theme.palette.grey[500];
  }
  return {
    backgroundColor: color,
    color: theme.palette.getContrastText(color),
    fontWeight: 'bold',
  };
});

const PriorityChip = styled(Chip)(({ theme, priority }) => {
  let color;
  switch (priority) {
    case 'LOW':
      color = theme.palette.success.light;
      break;
    case 'MEDIUM':
      color = theme.palette.warning.light;
      break;
    case 'HIGH':
      color = theme.palette.warning.main;
      break;
    case 'CRITICAL':
      color = theme.palette.error.main;
      break;
    default:
      color = theme.palette.grey[500];
  }
  return {
    backgroundColor: color,
    color: theme.palette.getContrastText(color),
    fontWeight: 'bold',
  };
});

const CategoryChip = styled(Chip)(({ theme }) => ({
  backgroundColor: theme.palette.primary.light,
  color: theme.palette.primary.contrastText,
  fontWeight: 'bold',
}));

const DepartmentChip = styled(Chip)(({ theme }) => ({
  backgroundColor: theme.palette.secondary.light,
  color: theme.palette.secondary.contrastText,
  fontWeight: 'bold',
}));

const StyledBadge = styled(Badge)(({ theme }) => ({
  '& .MuiBadge-badge': {
    right: -3,
    top: 13,
    border: `2px solid ${theme.palette.background.paper}`,
    padding: '0 4px',
  },
}));

// Mock data for demonstration
const MOCK_TICKETS = [
  {
    ticket_id: 1,
    title: 'Slot machine #123 not powering on',
    description: 'The slot machine on the main floor is not turning on. We have tried resetting the power but it still does not work.',
    category: 'HARDWARE',
    priority: 'HIGH',
    status: 'OPEN',
    department: 'MAINTENANCE',
    created_by: 1,
    assigned_to: 2,
    location_id: 1,
    floor_plan_id: 1,
    x_position: 150,
    y_position: 200,
    created_at: '2025-03-20T10:30:00Z',
    updated_at: '2025-03-20T10:30:00Z',
    creator_name: 'John Smith',
    assignee_name: 'Jane Doe',
    location_name: 'Main Floor - Section A',
    comments_count: 3,
    attachments_count: 2,
    related_items_count: 1
  },
  {
    ticket_id: 2,
    title: 'Network switch in server room needs replacement',
    description: 'The network switch in the server room is showing intermittent connectivity issues. We need to replace it as soon as possible.',
    category: 'NETWORK',
    priority: 'CRITICAL',
    status: 'IN_PROGRESS',
    department: 'IT',
    created_by: 3,
    assigned_to: 4,
    location_id: 2,
    floor_plan_id: 1,
    x_position: 300,
    y_position: 150,
    created_at: '2025-03-19T14:15:00Z',
    updated_at: '2025-03-20T09:45:00Z',
    creator_name: 'Robert Johnson',
    assignee_name: 'Michael Brown',
    location_name: 'Server Room',
    comments_count: 5,
    attachments_count: 1,
    related_items_count: 2
  },
  {
    ticket_id: 3,
    title: 'Surveillance camera #15 not recording',
    description: 'The surveillance camera in the VIP area is powered on but not recording to the system.',
    category: 'SURVEILLANCE',
    priority: 'MEDIUM',
    status: 'PENDING',
    department: 'SECURITY',
    created_by: 2,
    assigned_to: 5,
    location_id: 3,
    floor_plan_id: 1,
    x_position: 450,
    y_position: 300,
    created_at: '2025-03-18T16:20:00Z',
    updated_at: '2025-03-19T11:10:00Z',
    creator_name: 'Jane Doe',
    assignee_name: 'David Wilson',
    location_name: 'VIP Area',
    comments_count: 2,
    attachments_count: 3,
    related_items_count: 1
  },
  {
    ticket_id: 4,
    title: 'Software update needed for POS terminals',
    description: 'All point of sale terminals need to be updated to the latest software version to fix security vulnerabilities.',
    category: 'SOFTWARE',
    priority: 'MEDIUM',
    status: 'RESOLVED',
    department: 'IT',
    created_by: 4,
    assigned_to: 1,
    location_id: 4,
    floor_plan_id: 1,
    x_position: 200,
    y_position: 400,
    created_at: '2025-03-17T09:00:00Z',
    updated_at: '2025-03-18T14:30:00Z',
    resolved_at: '2025-03-18T14:30:00Z',
    creator_name: 'Michael Brown',
    assignee_name: 'John Smith',
    location_name: 'Cashier Area',
    comments_count: 4,
    attachments_count: 0,
    related_items_count: 5
  },
  {
    ticket_id: 5,
    title: 'Blackjack table #3 has damaged felt',
    description: 'The felt on blackjack table #3 is torn and needs to be replaced.',
    category: 'GAMING',
    priority: 'LOW',
    status: 'CLOSED',
    department: 'GAMING',
    created_by: 5,
    assigned_to: 3,
    location_id: 5,
    floor_plan_id: 1,
    x_position: 350,
    y_position: 250,
    created_at: '2025-03-16T11:45:00Z',
    updated_at: '2025-03-17T10:20:00Z',
    resolved_at: '2025-03-17T10:15:00Z',
    closed_at: '2025-03-17T10:20:00Z',
    creator_name: 'David Wilson',
    assignee_name: 'Robert Johnson',
    location_name: 'Table Games Area',
    comments_count: 1,
    attachments_count: 2,
    related_items_count: 1
  }
];

const MOCK_COMMENTS = [
  {
    comment_id: 1,
    ticket_id: 1,
    user_id: 2,
    content: 'I checked the power supply and it seems to be faulty. We need to order a replacement part.',
    is_internal: false,
    created_at: '2025-03-20T11:15:00Z',
    updated_at: '2025-03-20T11:15:00Z',
    user_name: 'Jane Doe',
    attachments: []
  },
  {
    comment_id: 2,
    ticket_id: 1,
    user_id: 1,
    content: 'I have ordered the replacement power supply. It should arrive tomorrow.',
    is_internal: true,
    created_at: '2025-03-20T13:30:00Z',
    updated_at: '2025-03-20T13:30:00Z',
    user_name: 'John Smith',
    attachments: [
      {
        attachment_id: 1,
        file_name: 'order_confirmation.pdf',
        file_size: 125000,
        file_type: 'application/pdf',
        created_at: '2025-03-20T13:30:00Z'
      }
    ]
  },
  {
    comment_id: 3,
    ticket_id: 1,
    user_id: 3,
    content: 'The slot machine is still under warranty. I have contacted the manufacturer for support.',
    is_internal: false,
    created_at: '2025-03-20T15:45:00Z',
    updated_at: '2025-03-20T15:45:00Z',
    user_name: 'Robert Johnson',
    attachments: []
  }
];

const MOCK_ATTACHMENTS = [
  {
    attachment_id: 1,
    ticket_id: 1,
    comment_id: 2,
    user_id: 1,
    file_name: 'order_confirmation.pdf',
    file_path: '/attachments/tickets/1/order_confirmation.pdf',
    file_size: 125000,
    file_type: 'application/pdf',
    created_at: '2025-03-20T13:30:00Z',
    user_name: 'John Smith'
  },
  {
    attachment_id: 2,
    ticket_id: 1,
    comment_id: null,
    user_id: 2,
    file_name: 'slot_machine_photo.jpg',
    file_path: '/attachments/tickets/1/slot_machine_photo.jpg',
    file_size: 2500000,
    file_type: 'image/jpeg',
    created_at: '2025-03-20T11:10:00Z',
    user_name: 'Jane Doe'
  }
];

const MOCK_ACTIVITIES = [
  {
    activity_id: 1,
    ticket_id: 1,
    user_id: 1,
    activity_type: 'CREATED',
    description: 'Ticket created',
    created_at: '2025-03-20T10:30:00Z',
    user_name: 'John Smith'
  },
  {
    activity_id: 2,
    ticket_id: 1,
    user_id: 1,
    activity_type: 'UPDATED',
    description: 'Assignee changed from unassigned to Jane Doe',
    created_at: '2025-03-20T10:35:00Z',
    user_name: 'John Smith'
  },
  {
    activity_id: 3,
    ticket_id: 1,
    user_id: 2,
    activity_type: 'COMMENT_ADDED',
    description: 'Comment added to ticket',
    created_at: '2025-03-20T11:15:00Z',
    user_name: 'Jane Doe'
  },
  {
    activity_id: 4,
    ticket_id: 1,
    user_id: 2,
    activity_type: 'ATTACHMENT_ADDED',
    description: 'File \'slot_machine_photo.jpg\' attached to ticket',
    created_at: '2025-03-20T11:10:00Z',
    user_name: 'Jane Doe'
  },
  {
    activity_id: 5,
    ticket_id: 1,
    user_id: 1,
    activity_type: 'COMMENT_ADDED',
    description: 'Comment added to ticket',
    created_at: '2025-03-20T13:30:00Z',
    user_name: 'John Smith'
  },
  {
    activity_id: 6,
    ticket_id: 1,
    user_id: 1,
    activity_type: 'ATTACHMENT_ADDED',
    description: 'File \'order_confirmation.pdf\' attached to ticket',
    created_at: '2025-03-20T13:30:00Z',
    user_name: 'John Smith'
  },
  {
    activity_id: 7,
    ticket_id: 1,
    user_id: 3,
    activity_type: 'COMMENT_ADDED',
    description: 'Comment added to ticket',
    created_at: '2025-03-20T15:45:00Z',
    user_name: 'Robert Johnson'
  }
];

const MOCK_RELATED_ITEMS = [
  {
    ticket_item_id: 1,
    ticket_id: 1,
    item_id: 123,
    item_name: 'Slot Machine #123',
    item_category: 'SLOT_MACHINE',
    item_status: 'OUT_OF_ORDER'
  }
];

const MOCK_DASHBOARD_DATA = {
  total_tickets: 125,
  open_tickets: 42,
  in_progress_tickets: 28,
  pending_tickets: 15,
  resolved_tickets: 20,
  closed_tickets: 20,
  tickets_by_priority: {
    LOW: 30,
    MEDIUM: 45,
    HIGH: 35,
    CRITICAL: 15
  },
  tickets_by_category: {
    HARDWARE: 40,
    SOFTWARE: 25,
    NETWORK: 20,
    SECURITY: 15,
    GAMING: 15,
    SURVEILLANCE: 10,
    MAINTENANCE: 0,
    OTHER: 0
  },
  tickets_by_department: {
    IT: 60,
    MAINTENANCE: 25,
    SECURITY: 20,
    GAMING: 15,
    OPERATIONS: 5,
    MANAGEMENT: 0
  },
  tickets_by_assignee: {
    1: 25,
    2: 30,
    3: 20,
    4: 15,
    5: 10
  },
  recent_tickets: MOCK_TICKETS.slice(0, 3),
  overdue_tickets: [MOCK_TICKETS[0], MOCK_TICKETS[2]],
  high_priority_tickets: [MOCK_TICKETS[0], MOCK_TICKETS[1]]
};

// Mock floor plan data
const MOCK_FLOOR_PLAN = {
  floor_plan_id: 1,
  name: 'Main Casino Floor',
  width: 800,
  height: 600,
  image_url: null
};

// Component for the ticket dashboard
const TicketDashboard = () => {
  const [dashboardData, setDashboardData] = useState(MOCK_DASHBOARD_DATA);
  const [loading, setLoading] = useState(false);

  // In a real implementation, you would fetch the dashboard data from the API
  useEffect(() => {
    // Simulating API call
    setLoading(true);
    setTimeout(() => {
      setDashboardData(MOCK_DASHBOARD_DATA);
      setLoading(false);
    }, 1000);
  }, []);

  // Prepare data for charts
  const priorityChartData = Object.entries(dashboardData.tickets_by_priority).map(([priority, count]) => ({
    name: priority,
    value: count
  }));

  const categoryChartData = Object.entries(dashboardData.tickets_by_category)
    .filter(([_, count]) => count > 0)
    .map(([category, count]) => ({
      name: category,
      value: count
    }));

  const departmentChartData = Object.entries(dashboardData.tickets_by_department)
    .filter(([_, count]) => count > 0)
    .map(([department, count]) => ({
      name: department,
      value: count
    }));

  const statusChartData = [
    { name: 'OPEN', value: dashboardData.open_tickets },
    { name: 'IN_PROGRESS', value: dashboardData.in_progress_tickets },
    { name: 'PENDING', value: dashboardData.pending_tickets },
    { name: 'RESOLVED', value: dashboardData.resolved_tickets },
    { name: 'CLOSED', value: dashboardData.closed_tickets }
  ];

  // Colors for charts
  const PRIORITY_COLORS = {
    LOW: '#4caf50',
    MEDIUM: '#ff9800',
    HIGH: '#f57c00',
    CRITICAL: '#f44336'
  };

  const STATUS_COLORS = {
    OPEN: '#2196f3',
    IN_PROGRESS: '#ff9800',
    PENDING: '#ffca28',
    RESOLVED: '#4caf50',
    CLOSED: '#388e3c',
    REOPENED: '#f44336'
  };

  const CATEGORY_COLORS = [
    '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39'
  ];

  const DEPARTMENT_COLORS = [
    '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4'
  ];

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Ticket System Dashboard
      </Typography>
      
      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={4} lg={2}>
          <StyledPaper>
            <Typography variant="h6" color="textSecondary" gutterBottom>
              Total Tickets
            </Typography>
            <Typography variant="h3" component="div">
              {dashboardData.total_tickets}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={2}>
          <StyledPaper>
            <Typography variant="h6" color="textSecondary" gutterBottom>
              Open
            </Typography>
            <Typography variant="h3" component="div" color="info.main">
              {dashboardData.open_tickets}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={2}>
          <StyledPaper>
            <Typography variant="h6" color="textSecondary" gutterBottom>
              In Progress
            </Typography>
            <Typography variant="h3" component="div" color="warning.main">
              {dashboardData.in_progress_tickets}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={2}>
          <StyledPaper>
            <Typography variant="h6" color="textSecondary" gutterBottom>
              Pending
            </Typography>
            <Typography variant="h3" component="div" color="warning.light">
              {dashboardData.pending_tickets}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={2}>
          <StyledPaper>
            <Typography variant="h6" color="textSecondary" gutterBottom>
              Resolved
            </Typography>
            <Typography variant="h3" component="div" color="success.main">
              {dashboardData.resolved_tickets}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={2}>
          <StyledPaper>
            <Typography variant="h6" color="textSecondary" gutterBottom>
              Closed
            </Typography>
            <Typography variant="h3" component="div" color="success.dark">
              {dashboardData.closed_tickets}
            </Typography>
          </StyledPaper>
        </Grid>
      </Grid>
      
      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Tickets by Status
            </Typography>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {statusChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={STATUS_COLORS[entry.name]} />
                  ))}
                </Pie>
                <RechartsTooltip formatter={(value, name) => [`${value} tickets`, name]} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Tickets by Priority
            </Typography>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={priorityChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {priorityChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PRIORITY_COLORS[entry.name]} />
                  ))}
                </Pie>
                <RechartsTooltip formatter={(value, name) => [`${value} tickets`, name]} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Tickets by Category
            </Typography>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={categoryChartData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <RechartsTooltip formatter={(value, name, props) => [`${value} tickets`, props.payload.name]} />
                <Bar dataKey="value" name="Tickets">
                  {categoryChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[index % CATEGORY_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Tickets by Department
            </Typography>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={departmentChartData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <RechartsTooltip formatter={(value, name, props) => [`${value} tickets`, props.payload.name]} />
                <Bar dataKey="value" name="Tickets">
                  {departmentChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={DEPARTMENT_COLORS[index % DEPARTMENT_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>
      </Grid>
      
      {/* Recent Tickets */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12}>
          <StyledPaper>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">
                Recent Tickets
              </Typography>
              <Button
                variant="outlined"
                startIcon={<AssignmentIcon />}
                href="/tickets"
              >
                View All Tickets
              </Button>
            </Box>
            <List>
              {dashboardData.recent_tickets.map((ticket) => (
                <ListItem
                  key={ticket.ticket_id}
                  divider
                  button
                  component="a"
                  href={`/tickets/${ticket.ticket_id}`}
                  sx={{ borderRadius: 1, mb: 1 }}
                >
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: STATUS_COLORS[ticket.status] }}>
                      <AssignmentIcon />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={ticket.title}
                    secondary={
                      <>
                        <Typography component="span" variant="body2" color="text.primary">
                          {ticket.creator_name}
                        </Typography>
                        {` — ${format(parseISO(ticket.created_at), 'PPpp')}`}
                      </>
                    }
                  />
                  <ListItemSecondaryAction>
                    <Box display="flex" alignItems="center">
                      <StatusChip
                        label={ticket.status}
                        status={ticket.status}
                        size="small"
                        sx={{ mr: 1 }}
                      />
                      <PriorityChip
                        label={ticket.priority}
                        priority={ticket.priority}
                        size="small"
                      />
                    </Box>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          </StyledPaper>
        </Grid>
      </Grid>
      
      {/* High Priority and Overdue Tickets */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              High Priority Tickets
            </Typography>
            <List>
              {dashboardData.high_priority_tickets.map((ticket) => (
                <ListItem
                  key={ticket.ticket_id}
                  divider
                  button
                  component="a"
                  href={`/tickets/${ticket.ticket_id}`}
                  sx={{ borderRadius: 1, mb: 1 }}
                >
                  <ListItemText
                    primary={ticket.title}
                    secondary={`Assigned to: ${ticket.assignee_name || 'Unassigned'}`}
                  />
                  <ListItemSecondaryAction>
                    <PriorityChip
                      label={ticket.priority}
                      priority={ticket.priority}
                      size="small"
                    />
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography variant="h6" gutterBottom>
              Overdue Tickets
            </Typography>
            <List>
              {dashboardData.overdue_tickets.map((ticket) => (
                <ListItem
                  key={ticket.ticket_id}
                  divider
                  button
                  component="a"
                  href={`/tickets/${ticket.ticket_id}`}
                  sx={{ borderRadius: 1, mb: 1 }}
                >
                  <ListItemText
                    primary={ticket.title}
                    secondary={`Assigned to: ${ticket.assignee_name || 'Unassigned'}`}
                  />
                  <ListItemSecondaryAction>
                    <StatusChip
                      label={ticket.status}
                      status={ticket.status}
                      size="small"
                    />
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          </StyledPaper>
        </Grid>
      </Grid>
    </Container>
  );
};

// Component for the ticket list
const TicketList = () => {
  const [tickets, setTickets] = useState(MOCK_TICKETS);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [openCreateDialog, setOpenCreateDialog] = useState(false);

  // In a real implementation, you would fetch the tickets from the API
  useEffect(() => {
    // Simulating API call
    setLoading(true);
    setTimeout(() => {
      setTickets(MOCK_TICKETS);
      setLoading(false);
    }, 1000);
  }, []);

  // Filter tickets based on search term and filters
  const filteredTickets = tickets.filter((ticket) => {
    const matchesSearch = searchTerm === '' || 
      ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === '' || ticket.status === statusFilter;
    const matchesPriority = priorityFilter === '' || ticket.priority === priorityFilter;
    const matchesCategory = categoryFilter === '' || ticket.category === categoryFilter;
    const matchesDepartment = departmentFilter === '' || ticket.department === departmentFilter;
    
    return matchesSearch && matchesStatus && matchesPriority && matchesCategory && matchesDepartment;
  });

  // Pagination
  const paginatedTickets = filteredTickets.slice(
    (page - 1) * rowsPerPage,
    (page - 1) * rowsPerPage + rowsPerPage
  );

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(1);
  };

  const handleCreateTicket = () => {
    setOpenCreateDialog(true);
  };

  const handleCloseCreateDialog = () => {
    setOpenCreateDialog(false);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          Tickets
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={handleCreateTicket}
        >
          Create Ticket
        </Button>
      </Box>
      
      {/* Search and Filters */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6} md={4}>
            <TextField
              fullWidth
              label="Search Tickets"
              variant="outlined"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: <SearchIcon color="action" sx={{ mr: 1 }} />,
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={2}>
            <FormControl fullWidth variant="outlined">
              <InputLabel>Status</InputLabel>
              <Select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                label="Status"
              >
                <MenuItem value="">All</MenuItem>
                <MenuItem value="OPEN">Open</MenuItem>
                <MenuItem value="IN_PROGRESS">In Progress</MenuItem>
                <MenuItem value="PENDING">Pending</MenuItem>
                <MenuItem value="RESOLVED">Resolved</MenuItem>
                <MenuItem value="CLOSED">Closed</MenuItem>
                <MenuItem value="REOPENED">Reopened</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={2}>
            <FormControl fullWidth variant="outlined">
              <InputLabel>Priority</InputLabel>
              <Select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
                label="Priority"
              >
                <MenuItem value="">All</MenuItem>
                <MenuItem value="LOW">Low</MenuItem>
                <MenuItem value="MEDIUM">Medium</MenuItem>
                <MenuItem value="HIGH">High</MenuItem>
                <MenuItem value="CRITICAL">Critical</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={2}>
            <FormControl fullWidth variant="outlined">
              <InputLabel>Category</InputLabel>
              <Select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                label="Category"
              >
                <MenuItem value="">All</MenuItem>
                <MenuItem value="HARDWARE">Hardware</MenuItem>
                <MenuItem value="SOFTWARE">Software</MenuItem>
                <MenuItem value="NETWORK">Network</MenuItem>
                <MenuItem value="SECURITY">Security</MenuItem>
                <MenuItem value="GAMING">Gaming</MenuItem>
                <MenuItem value="SURVEILLANCE">Surveillance</MenuItem>
                <MenuItem value="MAINTENANCE">Maintenance</MenuItem>
                <MenuItem value="OTHER">Other</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={2}>
            <FormControl fullWidth variant="outlined">
              <InputLabel>Department</InputLabel>
              <Select
                value={departmentFilter}
                onChange={(e) => setDepartmentFilter(e.target.value)}
                label="Department"
              >
                <MenuItem value="">All</MenuItem>
                <MenuItem value="IT">IT</MenuItem>
                <MenuItem value="MAINTENANCE">Maintenance</MenuItem>
                <MenuItem value="SECURITY">Security</MenuItem>
                <MenuItem value="GAMING">Gaming</MenuItem>
                <MenuItem value="OPERATIONS">Operations</MenuItem>
                <MenuItem value="MANAGEMENT">Management</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>
      
      {/* Ticket List */}
      <Paper sx={{ width: '100%', mb: 2 }}>
        <Box p={2}>
          <Typography variant="h6" id="tableTitle" component="div">
            {filteredTickets.length} Tickets Found
          </Typography>
        </Box>
        <Divider />
        <List>
          {paginatedTickets.map((ticket) => (
            <ListItem
              key={ticket.ticket_id}
              divider
              button
              component="a"
              href={`/tickets/${ticket.ticket_id}`}
              sx={{ borderRadius: 1, mb: 1 }}
            >
              <ListItemAvatar>
                <Avatar sx={{ bgcolor: STATUS_COLORS[ticket.status] }}>
                  <AssignmentIcon />
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary={
                  <Typography variant="subtitle1" fontWeight="bold">
                    {ticket.title}
                  </Typography>
                }
                secondary={
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      {ticket.description.length > 100 
                        ? `${ticket.description.substring(0, 100)}...` 
                        : ticket.description}
                    </Typography>
                    <Box display="flex" alignItems="center" mt={1}>
                      <Tooltip title="Created by">
                        <Box display="flex" alignItems="center" mr={2}>
                          <PersonIcon fontSize="small" color="action" sx={{ mr: 0.5 }} />
                          <Typography variant="body2" color="text.secondary">
                            {ticket.creator_name}
                          </Typography>
                        </Box>
                      </Tooltip>
                      <Tooltip title="Created at">
                        <Box display="flex" alignItems="center" mr={2}>
                          <ScheduleIcon fontSize="small" color="action" sx={{ mr: 0.5 }} />
                          <Typography variant="body2" color="text.secondary">
                            {format(parseISO(ticket.created_at), 'PPp')}
                          </Typography>
                        </Box>
                      </Tooltip>
                      <Tooltip title="Location">
                        <Box display="flex" alignItems="center">
                          <LocationOnIcon fontSize="small" color="action" sx={{ mr: 0.5 }} />
                          <Typography variant="body2" color="text.secondary">
                            {ticket.location_name}
                          </Typography>
                        </Box>
                      </Tooltip>
                    </Box>
                  </Box>
                }
              />
              <Box display="flex" flexDirection="column" alignItems="flex-end" minWidth={200}>
                <Box display="flex" mb={1}>
                  <StatusChip
                    label={ticket.status}
                    status={ticket.status}
                    size="small"
                    sx={{ mr: 1 }}
                  />
                  <PriorityChip
                    label={ticket.priority}
                    priority={ticket.priority}
                    size="small"
                  />
                </Box>
                <Box display="flex" alignItems="center">
                  <CategoryChip
                    label={ticket.category}
                    size="small"
                    sx={{ mr: 1 }}
                  />
                  <DepartmentChip
                    label={ticket.department}
                    size="small"
                  />
                </Box>
                <Box display="flex" alignItems="center" mt={1}>
                  <Tooltip title="Comments">
                    <Box display="flex" alignItems="center" mr={2}>
                      <StyledBadge badgeContent={ticket.comments_count} color="primary">
                        <CommentIcon color="action" />
                      </StyledBadge>
                    </Box>
                  </Tooltip>
                  <Tooltip title="Attachments">
                    <Box display="flex" alignItems="center" mr={2}>
                      <StyledBadge badgeContent={ticket.attachments_count} color="secondary">
                        <AttachFileIcon color="action" />
                      </StyledBadge>
                    </Box>
                  </Tooltip>
                  <Tooltip title="Related Items">
                    <Box display="flex" alignItems="center">
                      <StyledBadge badgeContent={ticket.related_items_count} color="info">
                        <LinkIcon color="action" />
                      </StyledBadge>
                    </Box>
                  </Tooltip>
                </Box>
              </Box>
            </ListItem>
          ))}
        </List>
        {paginatedTickets.length === 0 && (
          <Box display="flex" justifyContent="center" alignItems="center" p={4}>
            <Typography variant="body1" color="text.secondary">
              No tickets found matching the current filters.
            </Typography>
          </Box>
        )}
        <Box display="flex" justifyContent="flex-end" p={2}>
          <Pagination
            count={Math.ceil(filteredTickets.length / rowsPerPage)}
            page={page}
            onChange={handleChangePage}
            color="primary"
          />
        </Box>
      </Paper>
      
      {/* Create Ticket Dialog */}
      <Dialog
        open={openCreateDialog}
        onClose={handleCloseCreateDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Create New Ticket</DialogTitle>
        <DialogContent>
          <CreateTicketForm onClose={handleCloseCreateDialog} />
        </DialogContent>
      </Dialog>
    </Container>
  );
};

// Component for the ticket detail view
const TicketDetail = ({ ticketId }) => {
  // In a real implementation, you would fetch the ticket from the API
  const [ticket, setTicket] = useState(null);
  const [comments, setComments] = useState([]);
  const [attachments, setAttachments] = useState([]);
  const [activities, setActivities] = useState([]);
  const [relatedItems, setRelatedItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [openAddCommentDialog, setOpenAddCommentDialog] = useState(false);
  const [openAddAttachmentDialog, setOpenAddAttachmentDialog] = useState(false);
  const [openFloorPlanDialog, setOpenFloorPlanDialog] = useState(false);

  // Simulating API call to get ticket details
  useEffect(() => {
    setLoading(true);
    
    // Find the ticket in the mock data
    const foundTicket = MOCK_TICKETS.find(t => t.ticket_id === parseInt(ticketId));
    
    if (foundTicket) {
      setTicket(foundTicket);
      setComments(MOCK_COMMENTS.filter(c => c.ticket_id === parseInt(ticketId)));
      setAttachments(MOCK_ATTACHMENTS.filter(a => a.ticket_id === parseInt(ticketId)));
      setActivities(MOCK_ACTIVITIES.filter(a => a.ticket_id === parseInt(ticketId)));
      setRelatedItems(MOCK_RELATED_ITEMS.filter(r => r.ticket_id === parseInt(ticketId)));
    }
    
    setLoading(false);
  }, [ticketId]);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleEditTicket = () => {
    setOpenEditDialog(true);
  };

  const handleCloseEditDialog = () => {
    setOpenEditDialog(false);
  };

  const handleDeleteTicket = () => {
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setOpenDeleteDialog(false);
  };

  const handleAddComment = () => {
    setOpenAddCommentDialog(true);
  };

  const handleCloseAddCommentDialog = () => {
    setOpenAddCommentDialog(false);
  };

  const handleAddAttachment = () => {
    setOpenAddAttachmentDialog(true);
  };

  const handleCloseAddAttachmentDialog = () => {
    setOpenAddAttachmentDialog(false);
  };

  const handleViewFloorPlan = () => {
    setOpenFloorPlanDialog(true);
  };

  const handleCloseFloorPlanDialog = () => {
    setOpenFloorPlanDialog(false);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
      </Box>
    );
  }

  if (!ticket) {
    return (
      <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h5" color="error">
            Ticket not found
          </Typography>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AssignmentIcon />}
            href="/tickets"
            sx={{ mt: 2 }}
          >
            Back to Tickets
          </Button>
        </Paper>
      </Container>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* Breadcrumbs */}
      <Breadcrumbs sx={{ mb: 2 }}>
        <Link underline="hover" color="inherit" href="/dashboard">
          Dashboard
        </Link>
        <Link underline="hover" color="inherit" href="/tickets">
          Tickets
        </Link>
        <Typography color="text.primary">Ticket #{ticket.ticket_id}</Typography>
      </Breadcrumbs>
      
      {/* Ticket Header */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start">
          <Box>
            <Typography variant="h4" component="h1" gutterBottom>
              {ticket.title}
            </Typography>
            <Box display="flex" alignItems="center" mb={2}>
              <StatusChip
                label={ticket.status}
                status={ticket.status}
                sx={{ mr: 1 }}
              />
              <PriorityChip
                label={ticket.priority}
                priority={ticket.priority}
                sx={{ mr: 1 }}
              />
              <CategoryChip
                label={ticket.category}
                sx={{ mr: 1 }}
              />
              <DepartmentChip
                label={ticket.department}
              />
            </Box>
          </Box>
          <Box>
            <Button
              variant="outlined"
              color="primary"
              startIcon={<EditIcon />}
              onClick={handleEditTicket}
              sx={{ mr: 1 }}
            >
              Edit
            </Button>
            <Button
              variant="outlined"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={handleDeleteTicket}
            >
              Delete
            </Button>
          </Box>
        </Box>
        
        <Divider sx={{ my: 2 }} />
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Typography variant="body1" paragraph>
              {ticket.description}
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle2" gutterBottom>
                Ticket Information
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="body2" color="text.secondary">
                    Created By
                  </Typography>
                  <Typography variant="body1">
                    {ticket.creator_name}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" color="text.secondary">
                    Created At
                  </Typography>
                  <Typography variant="body1">
                    {format(parseISO(ticket.created_at), 'PPpp')}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" color="text.secondary">
                    Assigned To
                  </Typography>
                  <Typography variant="body1">
                    {ticket.assignee_name || 'Unassigned'}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" color="text.secondary">
                    Last Updated
                  </Typography>
                  <Typography variant="body1">
                    {format(parseISO(ticket.updated_at), 'PPpp')}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary">
                    Location
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Typography variant="body1" sx={{ mr: 1 }}>
                      {ticket.location_name}
                    </Typography>
                    {ticket.floor_plan_id && (
                      <Button
                        size="small"
                        startIcon={<MapIcon />}
                        onClick={handleViewFloorPlan}
                      >
                        View on Floor Plan
                      </Button>
                    )}
                  </Box>
                </Grid>
                {ticket.resolved_at && (
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Resolved At
                    </Typography>
                    <Typography variant="body1">
                      {format(parseISO(ticket.resolved_at), 'PPpp')}
                    </Typography>
                  </Grid>
                )}
                {ticket.closed_at && (
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Closed At
                    </Typography>
                    <Typography variant="body1">
                      {format(parseISO(ticket.closed_at), 'PPpp')}
                    </Typography>
                  </Grid>
                )}
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Paper>
      
      {/* Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="fullWidth"
        >
          <Tab label={`Comments (${comments.length})`} icon={<CommentIcon />} iconPosition="start" />
          <Tab label={`Attachments (${attachments.length})`} icon={<AttachFileIcon />} iconPosition="start" />
          <Tab label={`Activity Log (${activities.length})`} icon={<HistoryIcon />} iconPosition="start" />
          <Tab label={`Related Items (${relatedItems.length})`} icon={<LinkIcon />} iconPosition="start" />
        </Tabs>
        
        {/* Comments Tab */}
        <TabPanel value={activeTab} index={0}>
          <Box display="flex" justifyContent="flex-end" mb={2}>
            <Button
              variant="contained"
              color="primary"
              startIcon={<CommentIcon />}
              onClick={handleAddComment}
            >
              Add Comment
            </Button>
          </Box>
          {comments.length === 0 ? (
            <Box display="flex" justifyContent="center" alignItems="center" p={4}>
              <Typography variant="body1" color="text.secondary">
                No comments yet. Be the first to add a comment.
              </Typography>
            </Box>
          ) : (
            <List>
              {comments.map((comment) => (
                <ListItem
                  key={comment.comment_id}
                  alignItems="flex-start"
                  divider
                  sx={{ 
                    backgroundColor: comment.is_internal ? 'rgba(0, 0, 0, 0.03)' : 'transparent',
                    borderLeft: comment.is_internal ? '4px solid #f57c00' : 'none',
                    pl: comment.is_internal ? 2 : 0
                  }}
                >
                  <ListItemAvatar>
                    <Avatar>{comment.user_name.charAt(0)}</Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Box display="flex" alignItems="center">
                        <Typography variant="subtitle1" fontWeight="bold" sx={{ mr: 1 }}>
                          {comment.user_name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {format(parseISO(comment.created_at), 'PPpp')}
                        </Typography>
                        {comment.is_internal && (
                          <Chip
                            label="Internal"
                            size="small"
                            color="warning"
                            sx={{ ml: 1 }}
                          />
                        )}
                      </Box>
                    }
                    secondary={
                      <>
                        <Typography
                          component="span"
                          variant="body1"
                          color="text.primary"
                          sx={{ display: 'block', my: 1 }}
                        >
                          {comment.content}
                        </Typography>
                        {comment.attachments.length > 0 && (
                          <Box mt={1}>
                            <Typography variant="body2" color="text.secondary" gutterBottom>
                              Attachments:
                            </Typography>
                            <Box display="flex" flexWrap="wrap" gap={1}>
                              {comment.attachments.map((attachment) => (
                                <Chip
                                  key={attachment.attachment_id}
                                  icon={
                                    attachment.file_type.includes('image') ? <ImageIcon /> :
                                    attachment.file_type.includes('pdf') ? <PdfIcon /> :
                                    <FileIcon />
                                  }
                                  label={attachment.file_name}
                                  variant="outlined"
                                  component="a"
                                  href={`#attachment-${attachment.attachment_id}`}
                                  clickable
                                />
                              ))}
                            </Box>
                          </Box>
                        )}
                      </>
                    }
                  />
                </ListItem>
              ))}
            </List>
          )}
        </TabPanel>
        
        {/* Attachments Tab */}
        <TabPanel value={activeTab} index={1}>
          <Box display="flex" justifyContent="flex-end" mb={2}>
            <Button
              variant="contained"
              color="primary"
              startIcon={<AttachFileIcon />}
              onClick={handleAddAttachment}
            >
              Add Attachment
            </Button>
          </Box>
          {attachments.length === 0 ? (
            <Box display="flex" justifyContent="center" alignItems="center" p={4}>
              <Typography variant="body1" color="text.secondary">
                No attachments yet. Add files to this ticket.
              </Typography>
            </Box>
          ) : (
            <Grid container spacing={2}>
              {attachments.map((attachment) => (
                <Grid item xs={12} sm={6} md={4} lg={3} key={attachment.attachment_id}>
                  <Card>
                    <CardContent>
                      <Box display="flex" alignItems="center" mb={1}>
                        {attachment.file_type.includes('image') ? (
                          <Avatar sx={{ bgcolor: 'primary.light' }}>
                            <ImageIcon />
                          </Avatar>
                        ) : attachment.file_type.includes('pdf') ? (
                          <Avatar sx={{ bgcolor: 'error.light' }}>
                            <PdfIcon />
                          </Avatar>
                        ) : (
                          <Avatar sx={{ bgcolor: 'info.light' }}>
                            <FileIcon />
                          </Avatar>
                        )}
                        <Box ml={1}>
                          <Typography variant="subtitle2" noWrap>
                            {attachment.file_name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {(attachment.file_size / 1024).toFixed(2)} KB
                          </Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary">
                        Uploaded by {attachment.user_name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {format(parseISO(attachment.created_at), 'PPp')}
                      </Typography>
                    </CardContent>
                    <CardActions>
                      <Button
                        size="small"
                        startIcon={<VisibilityIcon />}
                        href={attachment.file_path}
                        target="_blank"
                      >
                        View
                      </Button>
                      <Button
                        size="small"
                        startIcon={<GetAppIcon />}
                        href={attachment.file_path}
                        download
                      >
                        Download
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
        </TabPanel>
        
        {/* Activity Log Tab */}
        <TabPanel value={activeTab} index={2}>
          {activities.length === 0 ? (
            <Box display="flex" justifyContent="center" alignItems="center" p={4}>
              <Typography variant="body1" color="text.secondary">
                No activity recorded yet.
              </Typography>
            </Box>
          ) : (
            <List>
              {activities.map((activity) => (
                <ListItem
                  key={activity.activity_id}
                  alignItems="flex-start"
                  divider
                >
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: 
                      activity.activity_type === 'CREATED' ? 'success.light' :
                      activity.activity_type === 'UPDATED' ? 'info.light' :
                      activity.activity_type === 'COMMENT_ADDED' ? 'primary.light' :
                      activity.activity_type === 'ATTACHMENT_ADDED' ? 'secondary.light' :
                      'default'
                    }}>
                      {activity.activity_type === 'CREATED' ? <AddIcon /> :
                       activity.activity_type === 'UPDATED' ? <EditIcon /> :
                       activity.activity_type === 'COMMENT_ADDED' ? <CommentIcon /> :
                       activity.activity_type === 'ATTACHMENT_ADDED' ? <AttachFileIcon /> :
                       <HistoryIcon />}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Box display="flex" alignItems="center">
                        <Typography variant="subtitle1" fontWeight="bold" sx={{ mr: 1 }}>
                          {activity.user_name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {format(parseISO(activity.created_at), 'PPpp')}
                        </Typography>
                      </Box>
                    }
                    secondary={
                      <Typography
                        component="span"
                        variant="body1"
                        color="text.primary"
                        sx={{ display: 'block', my: 1 }}
                      >
                        {activity.description}
                      </Typography>
                    }
                  />
                </ListItem>
              ))}
            </List>
          )}
        </TabPanel>
        
        {/* Related Items Tab */}
        <TabPanel value={activeTab} index={3}>
          {relatedItems.length === 0 ? (
            <Box display="flex" justifyContent="center" alignItems="center" p={4}>
              <Typography variant="body1" color="text.secondary">
                No related items linked to this ticket.
              </Typography>
            </Box>
          ) : (
            <List>
              {relatedItems.map((item) => (
                <ListItem
                  key={item.ticket_item_id}
                  alignItems="flex-start"
                  divider
                  button
                  component="a"
                  href={`/inventory/items/${item.item_id}`}
                >
                  <ListItemAvatar>
                    <Avatar>
                      <CategoryIcon />
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={item.item_name}
                    secondary={
                      <Box>
                        <Typography variant="body2" color="text.secondary">
                          Category: {item.item_category}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Status: {item.item_status}
                        </Typography>
                      </Box>
                    }
                  />
                </ListItem>
              ))}
            </List>
          )}
        </TabPanel>
      </Paper>
      
      {/* Edit Ticket Dialog */}
      <Dialog
        open={openEditDialog}
        onClose={handleCloseEditDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Edit Ticket</DialogTitle>
        <DialogContent>
          <EditTicketForm ticket={ticket} onClose={handleCloseEditDialog} />
        </DialogContent>
      </Dialog>
      
      {/* Delete Ticket Dialog */}
      <Dialog
        open={openDeleteDialog}
        onClose={handleCloseDeleteDialog}
      >
        <DialogTitle>Delete Ticket</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this ticket? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeleteDialog}>Cancel</Button>
          <Button color="error" onClick={handleCloseDeleteDialog}>Delete</Button>
        </DialogActions>
      </Dialog>
      
      {/* Add Comment Dialog */}
      <Dialog
        open={openAddCommentDialog}
        onClose={handleCloseAddCommentDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Add Comment</DialogTitle>
        <DialogContent>
          <AddCommentForm ticketId={ticket.ticket_id} onClose={handleCloseAddCommentDialog} />
        </DialogContent>
      </Dialog>
      
      {/* Add Attachment Dialog */}
      <Dialog
        open={openAddAttachmentDialog}
        onClose={handleCloseAddAttachmentDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Add Attachment</DialogTitle>
        <DialogContent>
          <AddAttachmentForm ticketId={ticket.ticket_id} onClose={handleCloseAddAttachmentDialog} />
        </DialogContent>
      </Dialog>
      
      {/* Floor Plan Dialog */}
      <Dialog
        open={openFloorPlanDialog}
        onClose={handleCloseFloorPlanDialog}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>Floor Plan View</DialogTitle>
        <DialogContent>
          <FloorPlanView
            floorPlanId={ticket.floor_plan_id}
            ticketId={ticket.ticket_id}
            x={ticket.x_position}
            y={ticket.y_position}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseFloorPlanDialog}>Close</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

// Helper component for tabs
const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Form components
const CreateTicketForm = ({ onClose }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState('MEDIUM');
  const [department, setDepartment] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [locationId, setLocationId] = useState('');
  const [floorPlanId, setFloorPlanId] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      onClose();
      // In a real implementation, you would redirect to the new ticket
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            required
            fullWidth
            label="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            margin="normal"
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            required
            fullWidth
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
            margin="normal"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Category *</InputLabel>
            <Select
              required
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              label="Category *"
            >
              <MenuItem value="HARDWARE">Hardware</MenuItem>
              <MenuItem value="SOFTWARE">Software</MenuItem>
              <MenuItem value="NETWORK">Network</MenuItem>
              <MenuItem value="SECURITY">Security</MenuItem>
              <MenuItem value="GAMING">Gaming</MenuItem>
              <MenuItem value="SURVEILLANCE">Surveillance</MenuItem>
              <MenuItem value="MAINTENANCE">Maintenance</MenuItem>
              <MenuItem value="OTHER">Other</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Priority</InputLabel>
            <Select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              label="Priority"
            >
              <MenuItem value="LOW">Low</MenuItem>
              <MenuItem value="MEDIUM">Medium</MenuItem>
              <MenuItem value="HIGH">High</MenuItem>
              <MenuItem value="CRITICAL">Critical</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Department *</InputLabel>
            <Select
              required
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              label="Department *"
            >
              <MenuItem value="IT">IT</MenuItem>
              <MenuItem value="MAINTENANCE">Maintenance</MenuItem>
              <MenuItem value="SECURITY">Security</MenuItem>
              <MenuItem value="GAMING">Gaming</MenuItem>
              <MenuItem value="OPERATIONS">Operations</MenuItem>
              <MenuItem value="MANAGEMENT">Management</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Assigned To</InputLabel>
            <Select
              value={assignedTo}
              onChange={(e) => setAssignedTo(e.target.value)}
              label="Assigned To"
            >
              <MenuItem value="">Unassigned</MenuItem>
              <MenuItem value="1">John Smith</MenuItem>
              <MenuItem value="2">Jane Doe</MenuItem>
              <MenuItem value="3">Robert Johnson</MenuItem>
              <MenuItem value="4">Michael Brown</MenuItem>
              <MenuItem value="5">David Wilson</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Location</InputLabel>
            <Select
              value={locationId}
              onChange={(e) => setLocationId(e.target.value)}
              label="Location"
            >
              <MenuItem value="">None</MenuItem>
              <MenuItem value="1">Main Floor - Section A</MenuItem>
              <MenuItem value="2">Server Room</MenuItem>
              <MenuItem value="3">VIP Area</MenuItem>
              <MenuItem value="4">Cashier Area</MenuItem>
              <MenuItem value="5">Table Games Area</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Floor Plan</InputLabel>
            <Select
              value={floorPlanId}
              onChange={(e) => setFloorPlanId(e.target.value)}
              label="Floor Plan"
            >
              <MenuItem value="">None</MenuItem>
              <MenuItem value="1">Main Casino Floor</MenuItem>
              <MenuItem value="2">Back Office</MenuItem>
              <MenuItem value="3">Server Room</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Due Date"
            type="datetime-local"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            InputLabelProps={{
              shrink: true,
            }}
            margin="normal"
          />
        </Grid>
        <Grid item xs={12}>
          <Button
            variant="contained"
            component="label"
            startIcon={<AttachFileIcon />}
            sx={{ mt: 2 }}
          >
            Attach Files
            <input
              type="file"
              multiple
              hidden
              onChange={(e) => setFiles(Array.from(e.target.files))}
            />
          </Button>
          {files.length > 0 && (
            <Box mt={2}>
              <Typography variant="subtitle2" gutterBottom>
                Selected Files:
              </Typography>
              <List dense>
                {files.map((file, index) => (
                  <ListItem key={index}>
                    <ListItemAvatar>
                      <Avatar>
                        {file.type.includes('image') ? <ImageIcon /> :
                         file.type.includes('pdf') ? <PdfIcon /> :
                         <FileIcon />}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={file.name}
                      secondary={`${(file.size / 1024).toFixed(2)} KB`}
                    />
                  </ListItem>
                ))}
              </List>
            </Box>
          )}
        </Grid>
      </Grid>
      <DialogActions sx={{ mt: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          disabled={loading}
          startIcon={loading && <CircularProgress size={20} />}
        >
          Create Ticket
        </Button>
      </DialogActions>
    </form>
  );
};

const EditTicketForm = ({ ticket, onClose }) => {
  const [title, setTitle] = useState(ticket.title);
  const [description, setDescription] = useState(ticket.description);
  const [category, setCategory] = useState(ticket.category);
  const [priority, setPriority] = useState(ticket.priority);
  const [status, setStatus] = useState(ticket.status);
  const [department, setDepartment] = useState(ticket.department);
  const [assignedTo, setAssignedTo] = useState(ticket.assigned_to || '');
  const [locationId, setLocationId] = useState(ticket.location_id || '');
  const [floorPlanId, setFloorPlanId] = useState(ticket.floor_plan_id || '');
  const [dueDate, setDueDate] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (ticket.due_date) {
      setDueDate(ticket.due_date.substring(0, 16)); // Format for datetime-local input
    }
  }, [ticket]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      onClose();
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            required
            fullWidth
            label="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            margin="normal"
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            required
            fullWidth
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
            margin="normal"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Category *</InputLabel>
            <Select
              required
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              label="Category *"
            >
              <MenuItem value="HARDWARE">Hardware</MenuItem>
              <MenuItem value="SOFTWARE">Software</MenuItem>
              <MenuItem value="NETWORK">Network</MenuItem>
              <MenuItem value="SECURITY">Security</MenuItem>
              <MenuItem value="GAMING">Gaming</MenuItem>
              <MenuItem value="SURVEILLANCE">Surveillance</MenuItem>
              <MenuItem value="MAINTENANCE">Maintenance</MenuItem>
              <MenuItem value="OTHER">Other</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Priority</InputLabel>
            <Select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              label="Priority"
            >
              <MenuItem value="LOW">Low</MenuItem>
              <MenuItem value="MEDIUM">Medium</MenuItem>
              <MenuItem value="HIGH">High</MenuItem>
              <MenuItem value="CRITICAL">Critical</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Status</InputLabel>
            <Select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              label="Status"
            >
              <MenuItem value="OPEN">Open</MenuItem>
              <MenuItem value="IN_PROGRESS">In Progress</MenuItem>
              <MenuItem value="PENDING">Pending</MenuItem>
              <MenuItem value="RESOLVED">Resolved</MenuItem>
              <MenuItem value="CLOSED">Closed</MenuItem>
              <MenuItem value="REOPENED">Reopened</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Department *</InputLabel>
            <Select
              required
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              label="Department *"
            >
              <MenuItem value="IT">IT</MenuItem>
              <MenuItem value="MAINTENANCE">Maintenance</MenuItem>
              <MenuItem value="SECURITY">Security</MenuItem>
              <MenuItem value="GAMING">Gaming</MenuItem>
              <MenuItem value="OPERATIONS">Operations</MenuItem>
              <MenuItem value="MANAGEMENT">Management</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Assigned To</InputLabel>
            <Select
              value={assignedTo}
              onChange={(e) => setAssignedTo(e.target.value)}
              label="Assigned To"
            >
              <MenuItem value="">Unassigned</MenuItem>
              <MenuItem value="1">John Smith</MenuItem>
              <MenuItem value="2">Jane Doe</MenuItem>
              <MenuItem value="3">Robert Johnson</MenuItem>
              <MenuItem value="4">Michael Brown</MenuItem>
              <MenuItem value="5">David Wilson</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Location</InputLabel>
            <Select
              value={locationId}
              onChange={(e) => setLocationId(e.target.value)}
              label="Location"
            >
              <MenuItem value="">None</MenuItem>
              <MenuItem value="1">Main Floor - Section A</MenuItem>
              <MenuItem value="2">Server Room</MenuItem>
              <MenuItem value="3">VIP Area</MenuItem>
              <MenuItem value="4">Cashier Area</MenuItem>
              <MenuItem value="5">Table Games Area</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Floor Plan</InputLabel>
            <Select
              value={floorPlanId}
              onChange={(e) => setFloorPlanId(e.target.value)}
              label="Floor Plan"
            >
              <MenuItem value="">None</MenuItem>
              <MenuItem value="1">Main Casino Floor</MenuItem>
              <MenuItem value="2">Back Office</MenuItem>
              <MenuItem value="3">Server Room</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Due Date"
            type="datetime-local"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            InputLabelProps={{
              shrink: true,
            }}
            margin="normal"
          />
        </Grid>
      </Grid>
      <DialogActions sx={{ mt: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          disabled={loading}
          startIcon={loading && <CircularProgress size={20} />}
        >
          Update Ticket
        </Button>
      </DialogActions>
    </form>
  );
};

const AddCommentForm = ({ ticketId, onClose }) => {
  const [content, setContent] = useState('');
  const [isInternal, setIsInternal] = useState(false);
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      onClose();
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        required
        fullWidth
        label="Comment"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        multiline
        rows={4}
        margin="normal"
      />
      <FormControl component="fieldset" margin="normal">
        <Box display="flex" alignItems="center">
          <Checkbox
            checked={isInternal}
            onChange={(e) => setIsInternal(e.target.checked)}
            name="isInternal"
            color="primary"
          />
          <Typography>
            Internal Comment (only visible to staff)
          </Typography>
        </Box>
      </FormControl>
      <Box mt={2}>
        <Button
          variant="contained"
          component="label"
          startIcon={<AttachFileIcon />}
        >
          Attach Files
          <input
            type="file"
            multiple
            hidden
            onChange={(e) => setFiles(Array.from(e.target.files))}
          />
        </Button>
        {files.length > 0 && (
          <Box mt={2}>
            <Typography variant="subtitle2" gutterBottom>
              Selected Files:
            </Typography>
            <List dense>
              {files.map((file, index) => (
                <ListItem key={index}>
                  <ListItemAvatar>
                    <Avatar>
                      {file.type.includes('image') ? <ImageIcon /> :
                       file.type.includes('pdf') ? <PdfIcon /> :
                       <FileIcon />}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={file.name}
                    secondary={`${(file.size / 1024).toFixed(2)} KB`}
                  />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </Box>
      <DialogActions sx={{ mt: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          disabled={loading}
          startIcon={loading && <CircularProgress size={20} />}
        >
          Add Comment
        </Button>
      </DialogActions>
    </form>
  );
};

const AddAttachmentForm = ({ ticketId, onClose }) => {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      onClose();
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Box mt={2} textAlign="center">
        <Button
          variant="contained"
          component="label"
          startIcon={<AttachFileIcon />}
          size="large"
        >
          Select Files
          <input
            type="file"
            multiple
            required
            hidden
            onChange={(e) => setFiles(Array.from(e.target.files))}
          />
        </Button>
        {files.length === 0 && (
          <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
            Please select one or more files to upload
          </Typography>
        )}
        {files.length > 0 && (
          <Box mt={2}>
            <Typography variant="subtitle2" gutterBottom>
              Selected Files:
            </Typography>
            <List>
              {files.map((file, index) => (
                <ListItem key={index}>
                  <ListItemAvatar>
                    <Avatar>
                      {file.type.includes('image') ? <ImageIcon /> :
                       file.type.includes('pdf') ? <PdfIcon /> :
                       <FileIcon />}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={file.name}
                    secondary={`${(file.size / 1024).toFixed(2)} KB`}
                  />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </Box>
      <DialogActions sx={{ mt: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          disabled={loading || files.length === 0}
          startIcon={loading && <CircularProgress size={20} />}
        >
          Upload Attachments
        </Button>
      </DialogActions>
    </form>
  );
};

// Floor Plan View component
const FloorPlanView = ({ floorPlanId, ticketId, x, y }) => {
  const [floorPlan, setFloorPlan] = useState(MOCK_FLOOR_PLAN);
  const [loading, setLoading] = useState(true);
  const [scale, setScale] = useState(1);

  // In a real implementation, you would fetch the floor plan from the API
  useEffect(() => {
    // Simulating API call
    setLoading(true);
    setTimeout(() => {
      setFloorPlan(MOCK_FLOOR_PLAN);
      setLoading(false);
    }, 1000);
  }, [floorPlanId]);

  const handleZoomIn = () => {
    setScale(scale * 1.2);
  };

  const handleZoomOut = () => {
    setScale(scale / 1.2);
  };

  const handleResetZoom = () => {
    setScale(1);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h6">
          {floorPlan.name}
        </Typography>
        <Box>
          <IconButton onClick={handleZoomOut} disabled={scale <= 0.5}>
            <RemoveIcon />
          </IconButton>
          <Button onClick={handleResetZoom}>Reset</Button>
          <IconButton onClick={handleZoomIn} disabled={scale >= 3}>
            <AddIcon />
          </IconButton>
        </Box>
      </Box>
      <Box
        sx={{
          border: '1px solid #ccc',
          borderRadius: 1,
          overflow: 'auto',
          height: '500px',
          position: 'relative',
        }}
      >
        <Stage
          width={floorPlan.width}
          height={floorPlan.height}
          scale={{ x: scale, y: scale }}
        >
          <Layer>
            {/* Background */}
            <Rect
              x={0}
              y={0}
              width={floorPlan.width}
              height={floorPlan.height}
              fill="#f5f5f5"
            />
            
            {/* Sample floor plan elements */}
            <Rect
              x={100}
              y={100}
              width={200}
              height={150}
              fill="#e0e0e0"
              stroke="#bdbdbd"
              strokeWidth={1}
            />
            <Rect
              x={400}
              y={100}
              width={300}
              height={150}
              fill="#e0e0e0"
              stroke="#bdbdbd"
              strokeWidth={1}
            />
            <Rect
              x={100}
              y={300}
              width={600}
              height={200}
              fill="#e0e0e0"
              stroke="#bdbdbd"
              strokeWidth={1}
            />
            
            {/* Ticket marker */}
            <Circle
              x={x}
              y={y}
              radius={15}
              fill="#f44336"
              stroke="#b71c1c"
              strokeWidth={2}
            />
            <KonvaText
              x={x - 5}
              y={y - 5}
              text="#1"
              fill="white"
              fontSize={12}
              fontStyle="bold"
            />
          </Layer>
        </Stage>
      </Box>
      <Box mt={2}>
        <Typography variant="body2" color="text.secondary">
          Ticket #{ticketId} is located at coordinates X: {x}, Y: {y} on the floor plan.
        </Typography>
      </Box>
    </Box>
  );
};

// Main component that combines all the ticket system components
const TicketSystemModule = () => {
  return (
    <div>
      <TicketDashboard />
      {/* Other components would be rendered based on routing */}
      {/* <TicketList /> */}
      {/* <TicketDetail ticketId={1} /> */}
    </div>
  );
};

export default TicketSystemModule;
