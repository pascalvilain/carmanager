"""
Alpin Royal Casino Management System - Ticket System Module API
This module provides API endpoints for the ticket system.
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, Path
from sqlalchemy.ext.asyncio import AsyncSession

from modules.ticket_system.models.ticket import (
    Ticket, TicketComment, TicketAttachment, TicketActivity, TicketItem,
    TicketPriority, TicketStatus, TicketCategory, TicketDepartment,
    TicketCreate, TicketUpdate, TicketCommentCreate, TicketCommentUpdate, TicketSearch,
    TicketResponse, TicketDetailResponse, TicketCommentResponse, TicketAttachmentResponse,
    TicketActivityResponse, TicketItemResponse, TicketDashboard
)
from modules.ticket_system.services.ticket_service import TicketService
from base_layer.utils.database import get_db_session
from base_layer.utils.storage import get_storage_manager
from base_layer.utils.event_bus import get_event_bus
from base_layer.auth.auth_manager import get_current_user, User

router = APIRouter(prefix="/api/tickets", tags=["tickets"])

# Helper function to get the ticket service
async def get_ticket_service(
    session: AsyncSession = Depends(get_db_session),
    storage_manager = Depends(get_storage_manager),
    event_bus = Depends(get_event_bus)
) -> TicketService:
    """Get the ticket service"""
    return TicketService(session, storage_manager, event_bus)

# Ticket Endpoints

@router.post("", response_model=TicketResponse)
async def create_ticket(
    title: str = Form(...),
    description: str = Form(...),
    category: TicketCategory = Form(...),
    priority: TicketPriority = Form(TicketPriority.MEDIUM),
    department: TicketDepartment = Form(...),
    location_id: Optional[int] = Form(None),
    floor_plan_id: Optional[int] = Form(None),
    x_position: Optional[int] = Form(None),
    y_position: Optional[int] = Form(None),
    due_date: Optional[str] = Form(None),
    assigned_to: Optional[int] = Form(None),
    related_item_ids: List[int] = Form([]),
    properties: Optional[str] = Form(None),
    attachments: List[UploadFile] = File([]),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Create a new ticket"""
    import json
    from datetime import datetime
    
    # Parse due date
    due_date_obj = None
    if due_date:
        due_date_obj = datetime.fromisoformat(due_date)
    
    # Parse properties
    properties_obj = None
    if properties:
        try:
            properties_obj = json.loads(properties)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON in properties field")
    
    ticket_data = TicketCreate(
        title=title,
        description=description,
        category=category,
        priority=priority,
        department=department,
        location_id=location_id,
        floor_plan_id=floor_plan_id,
        x_position=x_position,
        y_position=y_position,
        due_date=due_date_obj,
        assigned_to=assigned_to,
        related_item_ids=related_item_ids,
        properties=properties_obj
    )
    
    ticket = await service.create_ticket(ticket_data, current_user.id, attachments)
    
    # Format response
    return (await service._format_tickets_for_response([ticket]))[0]

@router.get("", response_model=List[TicketResponse])
async def get_all_tickets(
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get all tickets"""
    tickets = await service.get_all_tickets(skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/{ticket_id}", response_model=TicketDetailResponse)
async def get_ticket(
    ticket_id: int = Path(...),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get a ticket by ID"""
    ticket = await service.get_full_ticket(ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    return await service._format_ticket_detail_for_response(ticket)

@router.put("/{ticket_id}", response_model=TicketResponse)
async def update_ticket(
    ticket_id: int = Path(...),
    title: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    category: Optional[TicketCategory] = Form(None),
    priority: Optional[TicketPriority] = Form(None),
    status: Optional[TicketStatus] = Form(None),
    department: Optional[TicketDepartment] = Form(None),
    location_id: Optional[int] = Form(None),
    floor_plan_id: Optional[int] = Form(None),
    x_position: Optional[int] = Form(None),
    y_position: Optional[int] = Form(None),
    due_date: Optional[str] = Form(None),
    assigned_to: Optional[int] = Form(None),
    related_item_ids: Optional[List[int]] = Form(None),
    properties: Optional[str] = Form(None),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Update a ticket"""
    import json
    from datetime import datetime
    
    # Parse due date
    due_date_obj = None
    if due_date:
        due_date_obj = datetime.fromisoformat(due_date)
    
    # Parse properties
    properties_obj = None
    if properties:
        try:
            properties_obj = json.loads(properties)
        except json.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON in properties field")
    
    ticket_data = TicketUpdate(
        title=title,
        description=description,
        category=category,
        priority=priority,
        status=status,
        department=department,
        location_id=location_id,
        floor_plan_id=floor_plan_id,
        x_position=x_position,
        y_position=y_position,
        due_date=due_date_obj,
        assigned_to=assigned_to,
        related_item_ids=related_item_ids,
        properties=properties_obj
    )
    
    ticket = await service.update_ticket(ticket_id, ticket_data, current_user.id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    # Format response
    return (await service._format_tickets_for_response([ticket]))[0]

@router.delete("/{ticket_id}", response_model=Dict[str, bool])
async def delete_ticket(
    ticket_id: int = Path(...),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Delete a ticket"""
    result = await service.delete_ticket(ticket_id)
    if not result:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    return {"success": True}

@router.get("/search", response_model=List[TicketResponse])
async def search_tickets(
    title: Optional[str] = None,
    category: Optional[TicketCategory] = None,
    priority: Optional[TicketPriority] = None,
    status: Optional[TicketStatus] = None,
    department: Optional[TicketDepartment] = None,
    created_by: Optional[int] = None,
    assigned_to: Optional[int] = None,
    location_id: Optional[int] = None,
    floor_plan_id: Optional[int] = None,
    created_after: Optional[str] = None,
    created_before: Optional[str] = None,
    due_after: Optional[str] = None,
    due_before: Optional[str] = None,
    item_id: Optional[int] = None,
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Search for tickets based on various criteria"""
    from datetime import datetime
    
    # Parse dates
    created_after_obj = None
    if created_after:
        created_after_obj = datetime.fromisoformat(created_after)
    
    created_before_obj = None
    if created_before:
        created_before_obj = datetime.fromisoformat(created_before)
    
    due_after_obj = None
    if due_after:
        due_after_obj = datetime.fromisoformat(due_after)
    
    due_before_obj = None
    if due_before:
        due_before_obj = datetime.fromisoformat(due_before)
    
    search_params = TicketSearch(
        title=title,
        category=category,
        priority=priority,
        status=status,
        department=department,
        created_by=created_by,
        assigned_to=assigned_to,
        location_id=location_id,
        floor_plan_id=floor_plan_id,
        created_after=created_after_obj,
        created_before=created_before_obj,
        due_after=due_after_obj,
        due_before=due_before_obj,
        item_id=item_id
    )
    
    tickets = await service.search_tickets(search_params, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/status/{status}", response_model=List[TicketResponse])
async def get_tickets_by_status(
    status: TicketStatus = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by status"""
    tickets = await service.get_tickets_by_status(status, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/priority/{priority}", response_model=List[TicketResponse])
async def get_tickets_by_priority(
    priority: TicketPriority = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by priority"""
    tickets = await service.get_tickets_by_priority(priority, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/category/{category}", response_model=List[TicketResponse])
async def get_tickets_by_category(
    category: TicketCategory = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by category"""
    tickets = await service.get_tickets_by_category(category, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/department/{department}", response_model=List[TicketResponse])
async def get_tickets_by_department(
    department: TicketDepartment = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by department"""
    tickets = await service.get_tickets_by_department(department, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/creator/{creator_id}", response_model=List[TicketResponse])
async def get_tickets_by_creator(
    creator_id: int = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by creator"""
    tickets = await service.get_tickets_by_creator(creator_id, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/assignee/{assignee_id}", response_model=List[TicketResponse])
async def get_tickets_by_assignee(
    assignee_id: int = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by assignee"""
    tickets = await service.get_tickets_by_assignee(assignee_id, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/location/{location_id}", response_model=List[TicketResponse])
async def get_tickets_by_location(
    location_id: int = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by location"""
    tickets = await service.get_tickets_by_location(location_id, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/floor-plan/{floor_plan_id}", response_model=List[TicketResponse])
async def get_tickets_by_floor_plan(
    floor_plan_id: int = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by floor plan"""
    tickets = await service.get_tickets_by_floor_plan(floor_plan_id, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/item/{item_id}", response_model=List[TicketResponse])
async def get_tickets_by_item(
    item_id: int = Path(...),
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get tickets by related item"""
    tickets = await service.get_tickets_by_item(item_id, skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/overdue", response_model=List[TicketResponse])
async def get_overdue_tickets(
    skip: int = 0,
    limit: int = 100,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get overdue tickets"""
    tickets = await service.get_overdue_tickets(skip, limit)
    return await service._format_tickets_for_response(tickets)

@router.get("/recent", response_model=List[TicketResponse])
async def get_recent_tickets(
    limit: int = 10,
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get recent tickets"""
    tickets = await service.get_recent_tickets(limit)
    return await service._format_tickets_for_response(tickets)

# Comment Endpoints

@router.post("/{ticket_id}/comments", response_model=TicketCommentResponse)
async def add_comment(
    ticket_id: int = Path(...),
    content: str = Form(...),
    is_internal: bool = Form(False),
    attachments: List[UploadFile] = File([]),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Add a comment to a ticket"""
    comment_data = TicketCommentCreate(
        content=content,
        is_internal=is_internal
    )
    
    comment = await service.add_comment(ticket_id, comment_data, current_user.id, attachments)
    
    # Get comment with user and attachments
    comment_with_user = await service.get_comment(comment.comment_id)
    
    # Format response
    user_name = f"User {current_user.id}"  # In a real implementation, you would use the actual user name
    
    attachments_list = []
    if attachments:
        comment_attachments = await service.get_attachments_by_comment(comment.comment_id)
        for attachment in comment_attachments:
            attachments_list.append({
                "attachment_id": attachment.attachment_id,
                "file_name": attachment.file_name,
                "file_size": attachment.file_size,
                "file_type": attachment.file_type,
                "created_at": attachment.created_at
            })
    
    return TicketCommentResponse(
        comment_id=comment.comment_id,
        ticket_id=comment.ticket_id,
        user_id=comment.user_id,
        content=comment.content,
        is_internal=comment.is_internal,
        created_at=comment.created_at,
        updated_at=comment.updated_at,
        user_name=user_name,
        attachments=attachments_list
    )

@router.get("/{ticket_id}/comments", response_model=List[TicketCommentResponse])
async def get_comments_by_ticket(
    ticket_id: int = Path(...),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get comments by ticket ID"""
    # Check if the ticket exists
    ticket = await service.get_ticket(ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    # Get comments with users
    ticket_with_comments = await service.get_ticket_with_comments(ticket_id)
    
    # Format response
    comments_response = []
    if hasattr(ticket_with_comments, 'comments') and ticket_with_comments.comments:
        for comment in ticket_with_comments.comments:
            user_name = "Unknown"
            if hasattr(comment, 'user') and comment.user:
                user_name = f"{comment.user.first_name} {comment.user.last_name}"
            
            # Get attachments for this comment
            attachments = []
            comment_attachments = await service.get_attachments_by_comment(comment.comment_id)
            for attachment in comment_attachments:
                attachments.append({
                    "attachment_id": attachment.attachment_id,
                    "file_name": attachment.file_name,
                    "file_size": attachment.file_size,
                    "file_type": attachment.file_type,
                    "created_at": attachment.created_at
                })
            
            comments_response.append(TicketCommentResponse(
                comment_id=comment.comment_id,
                ticket_id=comment.ticket_id,
                user_id=comment.user_id,
                content=comment.content,
                is_internal=comment.is_internal,
                created_at=comment.created_at,
                updated_at=comment.updated_at,
                user_name=user_name,
                attachments=attachments
            ))
    
    return comments_response

@router.put("/comments/{comment_id}", response_model=TicketCommentResponse)
async def update_comment(
    comment_id: int = Path(...),
    content: Optional[str] = Form(None),
    is_internal: Optional[bool] = Form(None),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Update a comment"""
    comment_data = TicketCommentUpdate(
        content=content,
        is_internal=is_internal
    )
    
    comment = await service.update_comment(comment_id, comment_data, current_user.id)
    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found")
    
    # Format response
    user_name = f"User {current_user.id}"  # In a real implementation, you would use the actual user name
    
    # Get attachments for this comment
    attachments = []
    comment_attachments = await service.get_attachments_by_comment(comment.comment_id)
    for attachment in comment_attachments:
        attachments.append({
            "attachment_id": attachment.attachment_id,
            "file_name": attachment.file_name,
            "file_size": attachment.file_size,
            "file_type": attachment.file_type,
            "created_at": attachment.created_at
        })
    
    return TicketCommentResponse(
        comment_id=comment.comment_id,
        ticket_id=comment.ticket_id,
        user_id=comment.user_id,
        content=comment.content,
        is_internal=comment.is_internal,
        created_at=comment.created_at,
        updated_at=comment.updated_at,
        user_name=user_name,
        attachments=attachments
    )

@router.delete("/comments/{comment_id}", response_model=Dict[str, bool])
async def delete_comment(
    comment_id: int = Path(...),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Delete a comment"""
    result = await service.delete_comment(comment_id, current_user.id)
    if not result:
        raise HTTPException(status_code=404, detail="Comment not found or you don't have permission to delete it")
    
    return {"success": True}

# Attachment Endpoints

@router.post("/{ticket_id}/attachments", response_model=TicketAttachmentResponse)
async def add_attachment(
    ticket_id: int = Path(...),
    file: UploadFile = File(...),
    comment_id: Optional[int] = Form(None),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Add an attachment to a ticket or comment"""
    attachment = await service.add_attachment(ticket_id, current_user.id, file, comment_id)
    
    # Format response
    user_name = f"User {current_user.id}"  # In a real implementation, you would use the actual user name
    
    return TicketAttachmentResponse(
        attachment_id=attachment.attachment_id,
        ticket_id=attachment.ticket_id,
        comment_id=attachment.comment_id,
        user_id=attachment.user_id,
        file_name=attachment.file_name,
        file_path=attachment.file_path,
        file_size=attachment.file_size,
        file_type=attachment.file_type,
        created_at=attachment.created_at,
        user_name=user_name
    )

@router.get("/{ticket_id}/attachments", response_model=List[TicketAttachmentResponse])
async def get_attachments_by_ticket(
    ticket_id: int = Path(...),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get attachments by ticket ID"""
    # Check if the ticket exists
    ticket = await service.get_ticket(ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    # Get attachments
    attachments = await service.get_attachments_by_ticket(ticket_id)
    
    # Format response
    attachments_response = []
    for attachment in attachments:
        user_name = f"User {attachment.user_id}"  # In a real implementation, you would use the actual user name
        
        attachments_response.append(TicketAttachmentResponse(
            attachment_id=attachment.attachment_id,
            ticket_id=attachment.ticket_id,
            comment_id=attachment.comment_id,
            user_id=attachment.user_id,
            file_name=attachment.file_name,
            file_path=attachment.file_path,
            file_size=attachment.file_size,
            file_type=attachment.file_type,
            created_at=attachment.created_at,
            user_name=user_name
        ))
    
    return attachments_response

@router.delete("/attachments/{attachment_id}", response_model=Dict[str, bool])
async def delete_attachment(
    attachment_id: int = Path(...),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Delete an attachment"""
    result = await service.delete_attachment(attachment_id, current_user.id)
    if not result:
        raise HTTPException(status_code=404, detail="Attachment not found or you don't have permission to delete it")
    
    return {"success": True}

# Activity Endpoints

@router.get("/{ticket_id}/activities", response_model=List[TicketActivityResponse])
async def get_activities_by_ticket(
    ticket_id: int = Path(...),
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get activities by ticket ID"""
    # Check if the ticket exists
    ticket = await service.get_ticket(ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    # Get activities with users
    ticket_with_activities = await service.get_ticket_with_activities(ticket_id)
    
    # Format response
    activities_response = []
    if hasattr(ticket_with_activities, 'activities') and ticket_with_activities.activities:
        for activity in ticket_with_activities.activities:
            user_name = "Unknown"
            if hasattr(activity, 'user') and activity.user:
                user_name = f"{activity.user.first_name} {activity.user.last_name}"
            
            activities_response.append(TicketActivityResponse(
                activity_id=activity.activity_id,
                ticket_id=activity.ticket_id,
                user_id=activity.user_id,
                activity_type=activity.activity_type,
                description=activity.description,
                created_at=activity.created_at,
                properties=activity.properties,
                user_name=user_name
            ))
    
    return activities_response

# Dashboard Endpoint

@router.get("/dashboard", response_model=TicketDashboard)
async def get_ticket_dashboard(
    service: TicketService = Depends(get_ticket_service),
    current_user: User = Depends(get_current_user)
):
    """Get ticket dashboard data"""
    return await service.get_ticket_dashboard()
