"""
Alpin Royal Casino Management System - Ticket System Module Services
This module provides business logic for the ticket system.
"""

from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime
import os
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import UploadFile, HTTPException

from modules.ticket_system.models.ticket import (
    Ticket, TicketComment, TicketAttachment, TicketActivity, TicketItem,
    TicketPriority, TicketStatus, TicketCategory, TicketDepartment,
    TicketCreate, TicketUpdate, TicketCommentCreate, TicketCommentUpdate, TicketSearch,
    TicketResponse, TicketDetailResponse, TicketCommentResponse, TicketAttachmentResponse,
    TicketActivityResponse, TicketItemResponse, TicketDashboard
)
from modules.ticket_system.repositories.ticket_repository import (
    TicketRepository, TicketCommentRepository, TicketAttachmentRepository,
    TicketActivityRepository, TicketItemRepository
)
from base_layer.utils.storage import StorageManager
from base_layer.utils.event_bus import EventBus
from base_layer.config.settings import get_settings

class TicketService:
    """Service for ticket system operations"""
    
    def __init__(self, session: AsyncSession, storage_manager: StorageManager, event_bus: EventBus):
        """Initialize the service"""
        self.session = session
        self.storage_manager = storage_manager
        self.event_bus = event_bus
        self.settings = get_settings()
    
    # Ticket Services
    
    async def create_ticket(self, ticket_data: TicketCreate, created_by: int, attachments: List[UploadFile] = None) -> Ticket:
        """Create a new ticket"""
        # Create the ticket
        ticket = await TicketRepository.create(self.session, ticket_data, created_by)
        
        # Upload attachments if provided
        if attachments:
            for attachment in attachments:
                await self._upload_attachment(ticket.ticket_id, created_by, attachment)
        
        # Publish an event
        await self.event_bus.publish("ticket.created", {
            "ticket_id": ticket.ticket_id,
            "title": ticket.title,
            "category": ticket.category.value,
            "priority": ticket.priority.value,
            "status": ticket.status.value,
            "department": ticket.department.value,
            "created_by": ticket.created_by,
            "assigned_to": ticket.assigned_to
        })
        
        return ticket
    
    async def get_ticket(self, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket by ID"""
        return await TicketRepository.get_by_id(self.session, ticket_id)
    
    async def get_all_tickets(self, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get all tickets"""
        return await TicketRepository.get_all(self.session, skip, limit)
    
    async def update_ticket(self, ticket_id: int, ticket_data: TicketUpdate, user_id: int) -> Optional[Ticket]:
        """Update a ticket"""
        # Check if the ticket exists
        existing_ticket = await TicketRepository.get_by_id(self.session, ticket_id)
        if not existing_ticket:
            return None
        
        # Update the ticket
        ticket = await TicketRepository.update(self.session, ticket_id, ticket_data, user_id)
        
        # Publish an event
        if ticket:
            await self.event_bus.publish("ticket.updated", {
                "ticket_id": ticket.ticket_id,
                "title": ticket.title,
                "category": ticket.category.value,
                "priority": ticket.priority.value,
                "status": ticket.status.value,
                "department": ticket.department.value,
                "assigned_to": ticket.assigned_to
            })
        
        return ticket
    
    async def delete_ticket(self, ticket_id: int) -> bool:
        """Delete a ticket"""
        # Check if the ticket exists
        ticket = await TicketRepository.get_by_id(self.session, ticket_id)
        if not ticket:
            return False
        
        # Delete the ticket
        result = await TicketRepository.delete(self.session, ticket_id)
        
        # Publish an event
        if result:
            await self.event_bus.publish("ticket.deleted", {
                "ticket_id": ticket_id,
                "title": ticket.title
            })
        
        return result
    
    async def search_tickets(self, search_params: TicketSearch, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Search for tickets based on various criteria"""
        return await TicketRepository.search(self.session, search_params, skip, limit)
    
    async def get_tickets_by_status(self, status: TicketStatus, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by status"""
        return await TicketRepository.get_by_status(self.session, status, skip, limit)
    
    async def get_tickets_by_priority(self, priority: TicketPriority, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by priority"""
        return await TicketRepository.get_by_priority(self.session, priority, skip, limit)
    
    async def get_tickets_by_category(self, category: TicketCategory, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by category"""
        return await TicketRepository.get_by_category(self.session, category, skip, limit)
    
    async def get_tickets_by_department(self, department: TicketDepartment, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by department"""
        return await TicketRepository.get_by_department(self.session, department, skip, limit)
    
    async def get_tickets_by_creator(self, creator_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by creator"""
        return await TicketRepository.get_by_creator(self.session, creator_id, skip, limit)
    
    async def get_tickets_by_assignee(self, assignee_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by assignee"""
        return await TicketRepository.get_by_assignee(self.session, assignee_id, skip, limit)
    
    async def get_tickets_by_location(self, location_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by location"""
        return await TicketRepository.get_by_location(self.session, location_id, skip, limit)
    
    async def get_tickets_by_floor_plan(self, floor_plan_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by floor plan"""
        return await TicketRepository.get_by_floor_plan(self.session, floor_plan_id, skip, limit)
    
    async def get_tickets_by_item(self, item_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by related item"""
        return await TicketRepository.get_by_item(self.session, item_id, skip, limit)
    
    async def get_overdue_tickets(self, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get overdue tickets"""
        return await TicketRepository.get_overdue_tickets(self.session, skip, limit)
    
    async def get_recent_tickets(self, limit: int = 10) -> List[Ticket]:
        """Get recent tickets"""
        return await TicketRepository.get_recent_tickets(self.session, limit)
    
    async def get_ticket_with_comments(self, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its comments"""
        return await TicketRepository.get_with_comments(self.session, ticket_id)
    
    async def get_ticket_with_attachments(self, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its attachments"""
        return await TicketRepository.get_with_attachments(self.session, ticket_id)
    
    async def get_ticket_with_activities(self, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its activities"""
        return await TicketRepository.get_with_activities(self.session, ticket_id)
    
    async def get_ticket_with_related_items(self, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its related items"""
        return await TicketRepository.get_with_related_items(self.session, ticket_id)
    
    async def get_full_ticket(self, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with all its related data"""
        return await TicketRepository.get_full_ticket(self.session, ticket_id)
    
    # Comment Services
    
    async def add_comment(self, ticket_id: int, comment_data: TicketCommentCreate, user_id: int, attachments: List[UploadFile] = None) -> TicketComment:
        """Add a comment to a ticket"""
        # Check if the ticket exists
        ticket = await TicketRepository.get_by_id(self.session, ticket_id)
        if not ticket:
            raise HTTPException(status_code=404, detail="Ticket not found")
        
        # Create the comment
        comment = await TicketCommentRepository.create(self.session, ticket_id, comment_data, user_id)
        
        # Upload attachments if provided
        if attachments:
            for attachment in attachments:
                await self._upload_attachment(ticket_id, user_id, attachment, comment.comment_id)
        
        # Publish an event
        await self.event_bus.publish("ticket.comment.added", {
            "ticket_id": ticket_id,
            "comment_id": comment.comment_id,
            "user_id": user_id,
            "is_internal": comment.is_internal
        })
        
        return comment
    
    async def get_comment(self, comment_id: int) -> Optional[TicketComment]:
        """Get a comment by ID"""
        return await TicketCommentRepository.get_by_id(self.session, comment_id)
    
    async def get_comments_by_ticket(self, ticket_id: int) -> List[TicketComment]:
        """Get comments by ticket ID"""
        return await TicketCommentRepository.get_by_ticket(self.session, ticket_id)
    
    async def update_comment(self, comment_id: int, comment_data: TicketCommentUpdate, user_id: int) -> Optional[TicketComment]:
        """Update a comment"""
        # Check if the comment exists
        existing_comment = await TicketCommentRepository.get_by_id(self.session, comment_id)
        if not existing_comment:
            return None
        
        # Update the comment
        comment = await TicketCommentRepository.update(self.session, comment_id, comment_data, user_id)
        
        # Publish an event
        if comment:
            await self.event_bus.publish("ticket.comment.updated", {
                "ticket_id": comment.ticket_id,
                "comment_id": comment.comment_id,
                "user_id": user_id
            })
        
        return comment
    
    async def delete_comment(self, comment_id: int, user_id: int) -> bool:
        """Delete a comment"""
        # Check if the comment exists
        comment = await TicketCommentRepository.get_by_id(self.session, comment_id)
        if not comment:
            return False
        
        # Delete the comment
        result = await TicketCommentRepository.delete(self.session, comment_id, user_id)
        
        # Publish an event
        if result:
            await self.event_bus.publish("ticket.comment.deleted", {
                "ticket_id": comment.ticket_id,
                "comment_id": comment_id,
                "user_id": user_id
            })
        
        return result
    
    # Attachment Services
    
    async def _upload_attachment(self, ticket_id: int, user_id: int, file: UploadFile, comment_id: int = None) -> TicketAttachment:
        """Upload an attachment to a ticket or comment"""
        # Generate a unique filename
        file_extension = os.path.splitext(file.filename)[1]
        unique_filename = f"ticket_{ticket_id}_{uuid.uuid4()}{file_extension}"
        
        # Upload the file
        file_path = await self.storage_manager.upload_file(
            file.file,
            f"tickets/{ticket_id}/{unique_filename}",
            content_type=file.content_type
        )
        
        # Create the attachment record
        attachment = await TicketAttachmentRepository.create(
            self.session,
            ticket_id,
            user_id,
            file.filename,
            file_path,
            file.size,
            file.content_type,
            comment_id
        )
        
        return attachment
    
    async def add_attachment(self, ticket_id: int, user_id: int, file: UploadFile, comment_id: int = None) -> TicketAttachment:
        """Add an attachment to a ticket or comment"""
        # Check if the ticket exists
        ticket = await TicketRepository.get_by_id(self.session, ticket_id)
        if not ticket:
            raise HTTPException(status_code=404, detail="Ticket not found")
        
        # If comment_id is provided, check if the comment exists
        if comment_id:
            comment = await TicketCommentRepository.get_by_id(self.session, comment_id)
            if not comment or comment.ticket_id != ticket_id:
                raise HTTPException(status_code=404, detail="Comment not found or does not belong to this ticket")
        
        # Upload the attachment
        attachment = await self._upload_attachment(ticket_id, user_id, file, comment_id)
        
        # Publish an event
        await self.event_bus.publish("ticket.attachment.added", {
            "ticket_id": ticket_id,
            "attachment_id": attachment.attachment_id,
            "user_id": user_id,
            "comment_id": comment_id
        })
        
        return attachment
    
    async def get_attachment(self, attachment_id: int) -> Optional[TicketAttachment]:
        """Get an attachment by ID"""
        return await TicketAttachmentRepository.get_by_id(self.session, attachment_id)
    
    async def get_attachments_by_ticket(self, ticket_id: int) -> List[TicketAttachment]:
        """Get attachments by ticket ID"""
        return await TicketAttachmentRepository.get_by_ticket(self.session, ticket_id)
    
    async def get_attachments_by_comment(self, comment_id: int) -> List[TicketAttachment]:
        """Get attachments by comment ID"""
        return await TicketAttachmentRepository.get_by_comment(self.session, comment_id)
    
    async def delete_attachment(self, attachment_id: int, user_id: int) -> bool:
        """Delete an attachment"""
        # Check if the attachment exists
        attachment = await TicketAttachmentRepository.get_by_id(self.session, attachment_id)
        if not attachment:
            return False
        
        # Delete the file from storage
        try:
            await self.storage_manager.delete_file(attachment.file_path)
        except Exception as e:
            # Log the error but continue
            print(f"Error deleting attachment file: {e}")
        
        # Delete the attachment record
        result = await TicketAttachmentRepository.delete(self.session, attachment_id, user_id)
        
        # Publish an event
        if result:
            await self.event_bus.publish("ticket.attachment.deleted", {
                "ticket_id": attachment.ticket_id,
                "attachment_id": attachment_id,
                "user_id": user_id
            })
        
        return result
    
    # Activity Services
    
    async def get_activity(self, activity_id: int) -> Optional[TicketActivity]:
        """Get an activity by ID"""
        return await TicketActivityRepository.get_by_id(self.session, activity_id)
    
    async def get_activities_by_ticket(self, ticket_id: int) -> List[TicketActivity]:
        """Get activities by ticket ID"""
        return await TicketActivityRepository.get_by_ticket(self.session, ticket_id)
    
    # Dashboard Services
    
    async def get_ticket_dashboard(self) -> TicketDashboard:
        """Get ticket dashboard data"""
        # Get ticket counts by status
        status_counts = await TicketRepository.get_ticket_counts_by_status(self.session)
        
        # Get ticket counts by priority
        priority_counts = await TicketRepository.get_ticket_counts_by_priority(self.session)
        
        # Get ticket counts by category
        category_counts = await TicketRepository.get_ticket_counts_by_category(self.session)
        
        # Get ticket counts by department
        department_counts = await TicketRepository.get_ticket_counts_by_department(self.session)
        
        # Get ticket counts by assignee
        assignee_counts = await TicketRepository.get_ticket_counts_by_assignee(self.session)
        
        # Get recent tickets
        recent_tickets = await TicketRepository.get_recent_tickets(self.session, 5)
        
        # Get overdue tickets
        overdue_tickets = await TicketRepository.get_overdue_tickets(self.session, 5)
        
        # Get high priority tickets
        high_priority_tickets = await TicketRepository.get_by_priority(self.session, TicketPriority.HIGH, 0, 5)
        
        # Calculate total tickets
        total_tickets = sum(status_counts.values())
        
        # Create dashboard data
        dashboard = TicketDashboard(
            total_tickets=total_tickets,
            open_tickets=status_counts.get(TicketStatus.OPEN.value, 0),
            in_progress_tickets=status_counts.get(TicketStatus.IN_PROGRESS.value, 0),
            pending_tickets=status_counts.get(TicketStatus.PENDING.value, 0),
            resolved_tickets=status_counts.get(TicketStatus.RESOLVED.value, 0),
            closed_tickets=status_counts.get(TicketStatus.CLOSED.value, 0),
            tickets_by_priority=priority_counts,
            tickets_by_category=category_counts,
            tickets_by_department=department_counts,
            tickets_by_assignee=assignee_counts,
            recent_tickets=await self._format_tickets_for_response(recent_tickets),
            overdue_tickets=await self._format_tickets_for_response(overdue_tickets),
            high_priority_tickets=await self._format_tickets_for_response(high_priority_tickets)
        )
        
        return dashboard
    
    # Helper Methods
    
    async def _format_tickets_for_response(self, tickets: List[Ticket]) -> List[TicketResponse]:
        """Format tickets for API response"""
        formatted_tickets = []
        
        for ticket in tickets:
            # Get creator name
            creator_name = "Unknown"
            # In a real implementation, you would fetch the user name from the database
            
            # Get assignee name
            assignee_name = None
            if ticket.assigned_to:
                # In a real implementation, you would fetch the user name from the database
                assignee_name = f"User {ticket.assigned_to}"
            
            # Get location name
            location_name = None
            if ticket.location_id:
                # In a real implementation, you would fetch the location name from the database
                location_name = f"Location {ticket.location_id}"
            
            # Get counts
            comments_count = 0
            attachments_count = 0
            related_items_count = 0
            
            # In a real implementation, you would fetch these counts from the database
            
            formatted_ticket = TicketResponse(
                ticket_id=ticket.ticket_id,
                title=ticket.title,
                description=ticket.description,
                category=ticket.category,
                priority=ticket.priority,
                status=ticket.status,
                department=ticket.department,
                location_id=ticket.location_id,
                floor_plan_id=ticket.floor_plan_id,
                x_position=ticket.x_position,
                y_position=ticket.y_position,
                due_date=ticket.due_date,
                properties=ticket.properties,
                created_by=ticket.created_by,
                assigned_to=ticket.assigned_to,
                created_at=ticket.created_at,
                updated_at=ticket.updated_at,
                resolved_at=ticket.resolved_at,
                closed_at=ticket.closed_at,
                creator_name=creator_name,
                assignee_name=assignee_name,
                location_name=location_name,
                comments_count=comments_count,
                attachments_count=attachments_count,
                related_items_count=related_items_count
            )
            
            formatted_tickets.append(formatted_ticket)
        
        return formatted_tickets
    
    async def _format_ticket_detail_for_response(self, ticket: Ticket) -> TicketDetailResponse:
        """Format ticket detail for API response"""
        # Get basic ticket response
        basic_response = (await self._format_tickets_for_response([ticket]))[0]
        
        # Format comments
        comments = []
        if hasattr(ticket, 'comments') and ticket.comments:
            for comment in ticket.comments:
                user_name = "Unknown"
                if hasattr(comment, 'user') and comment.user:
                    user_name = f"{comment.user.first_name} {comment.user.last_name}"
                
                attachments = []
                if hasattr(comment, 'attachments') and comment.attachments:
                    for attachment in comment.attachments:
                        attachments.append({
                            "attachment_id": attachment.attachment_id,
                            "file_name": attachment.file_name,
                            "file_size": attachment.file_size,
                            "file_type": attachment.file_type,
                            "created_at": attachment.created_at
                        })
                
                comments.append(TicketCommentResponse(
                    comment_id=comment.comment_id,
                    ticket_id=comment.ticket_id,
                    user_id=comment.user_id,
                    content=comment.content,
                    is_internal=comment.is_internal,
                    created_at=comment.created_at,
                    updated_at=comment.updated_at,
                    user_name=user_name,
                    attachments=attachments
                ))
        
        # Format attachments
        attachments = []
        if hasattr(ticket, 'attachments') and ticket.attachments:
            for attachment in ticket.attachments:
                user_name = "Unknown"
                if hasattr(attachment, 'user') and attachment.user:
                    user_name = f"{attachment.user.first_name} {attachment.user.last_name}"
                
                attachments.append(TicketAttachmentResponse(
                    attachment_id=attachment.attachment_id,
                    ticket_id=attachment.ticket_id,
                    comment_id=attachment.comment_id,
                    user_id=attachment.user_id,
                    file_name=attachment.file_name,
                    file_path=attachment.file_path,
                    file_size=attachment.file_size,
                    file_type=attachment.file_type,
                    created_at=attachment.created_at,
                    user_name=user_name
                ))
        
        # Format activities
        activities = []
        if hasattr(ticket, 'activities') and ticket.activities:
            for activity in ticket.activities:
                user_name = "Unknown"
                if hasattr(activity, 'user') and activity.user:
                    user_name = f"{activity.user.first_name} {activity.user.last_name}"
                
                activities.append(TicketActivityResponse(
                    activity_id=activity.activity_id,
                    ticket_id=activity.ticket_id,
                    user_id=activity.user_id,
                    activity_type=activity.activity_type,
                    description=activity.description,
                    created_at=activity.created_at,
                    properties=activity.properties,
                    user_name=user_name
                ))
        
        # Format related items
        related_items = []
        if hasattr(ticket, 'related_items') and ticket.related_items:
            for ticket_item in ticket.related_items:
                item_name = "Unknown Item"
                item_category = "Unknown"
                item_status = "Unknown"
                
                if hasattr(ticket_item, 'item') and ticket_item.item:
                    item = ticket_item.item
                    item_name = item.name
                    item_category = item.category.value if hasattr(item, 'category') and item.category else "Unknown"
                    item_status = item.status.value if hasattr(item, 'status') and item.status else "Unknown"
                
                related_items.append(TicketItemResponse(
                    ticket_item_id=ticket_item.ticket_item_id,
                    ticket_id=ticket_item.ticket_id,
                    item_id=ticket_item.item_id,
                    item_name=item_name,
                    item_category=item_category,
                    item_status=item_status
                ))
        
        # Create detailed response
        detail_response = TicketDetailResponse(
            **basic_response.dict(),
            comments=comments,
            attachments=attachments,
            activities=activities,
            related_items=related_items
        )
        
        return detail_response
