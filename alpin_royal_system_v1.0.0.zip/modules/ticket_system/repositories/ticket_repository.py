"""
Alpin Royal Casino Management System - Ticket System Module Repositories
This module provides data access repositories for the ticket system.
"""

from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime
import json
from sqlalchemy import select, func, or_, and_, desc, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload, selectinload

from modules.ticket_system.models.ticket import (
    Ticket, TicketComment, TicketAttachment, TicketActivity, TicketItem,
    TicketPriority, TicketStatus, TicketCategory, TicketDepartment,
    TicketCreate, TicketUpdate, TicketCommentCreate, TicketCommentUpdate, TicketSearch
)

class TicketRepository:
    """Repository for ticket operations"""
    
    @staticmethod
    async def create(session: AsyncSession, ticket_data: TicketCreate, created_by: int) -> Ticket:
        """Create a new ticket"""
        # Create the ticket
        ticket = Ticket(
            title=ticket_data.title,
            description=ticket_data.description,
            category=ticket_data.category,
            priority=ticket_data.priority,
            status=TicketStatus.OPEN,
            department=ticket_data.department,
            created_by=created_by,
            assigned_to=ticket_data.assigned_to,
            location_id=ticket_data.location_id,
            floor_plan_id=ticket_data.floor_plan_id,
            x_position=ticket_data.x_position,
            y_position=ticket_data.y_position,
            due_date=ticket_data.due_date,
            properties=ticket_data.properties
        )
        
        session.add(ticket)
        await session.flush()
        
        # Create ticket activity for creation
        activity = TicketActivity(
            ticket_id=ticket.ticket_id,
            user_id=created_by,
            activity_type="CREATED",
            description="Ticket created"
        )
        session.add(activity)
        
        # Add related items if provided
        if ticket_data.related_item_ids:
            for item_id in ticket_data.related_item_ids:
                ticket_item = TicketItem(
                    ticket_id=ticket.ticket_id,
                    item_id=item_id
                )
                session.add(ticket_item)
        
        await session.commit()
        await session.refresh(ticket)
        
        return ticket
    
    @staticmethod
    async def get_by_id(session: AsyncSession, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket by ID"""
        query = select(Ticket).where(Ticket.ticket_id == ticket_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_all(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get all tickets with pagination"""
        query = select(Ticket).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, ticket_id: int, ticket_data: TicketUpdate, user_id: int) -> Optional[Ticket]:
        """Update a ticket"""
        # Get the ticket
        ticket = await TicketRepository.get_by_id(session, ticket_id)
        if not ticket:
            return None
        
        # Track changes for activity log
        changes = []
        
        # Update fields if provided
        if ticket_data.title is not None and ticket_data.title != ticket.title:
            changes.append(f"Title changed from '{ticket.title}' to '{ticket_data.title}'")
            ticket.title = ticket_data.title
        
        if ticket_data.description is not None and ticket_data.description != ticket.description:
            changes.append("Description updated")
            ticket.description = ticket_data.description
        
        if ticket_data.category is not None and ticket_data.category != ticket.category:
            changes.append(f"Category changed from '{ticket.category.value}' to '{ticket_data.category.value}'")
            ticket.category = ticket_data.category
        
        if ticket_data.priority is not None and ticket_data.priority != ticket.priority:
            changes.append(f"Priority changed from '{ticket.priority.value}' to '{ticket_data.priority.value}'")
            ticket.priority = ticket_data.priority
        
        if ticket_data.status is not None and ticket_data.status != ticket.status:
            changes.append(f"Status changed from '{ticket.status.value}' to '{ticket_data.status.value}'")
            ticket.status = ticket_data.status
            
            # Update resolved_at or closed_at if status changed to RESOLVED or CLOSED
            if ticket_data.status == TicketStatus.RESOLVED and not ticket.resolved_at:
                ticket.resolved_at = datetime.utcnow()
            elif ticket_data.status == TicketStatus.CLOSED and not ticket.closed_at:
                ticket.closed_at = datetime.utcnow()
        
        if ticket_data.department is not None and ticket_data.department != ticket.department:
            changes.append(f"Department changed from '{ticket.department.value}' to '{ticket_data.department.value}'")
            ticket.department = ticket_data.department
        
        if ticket_data.assigned_to is not None and ticket_data.assigned_to != ticket.assigned_to:
            old_assignee = ticket.assigned_to or "unassigned"
            new_assignee = ticket_data.assigned_to or "unassigned"
            changes.append(f"Assignee changed from '{old_assignee}' to '{new_assignee}'")
            ticket.assigned_to = ticket_data.assigned_to
        
        if ticket_data.location_id is not None and ticket_data.location_id != ticket.location_id:
            changes.append(f"Location changed from '{ticket.location_id}' to '{ticket_data.location_id}'")
            ticket.location_id = ticket_data.location_id
        
        if ticket_data.floor_plan_id is not None and ticket_data.floor_plan_id != ticket.floor_plan_id:
            changes.append(f"Floor plan changed from '{ticket.floor_plan_id}' to '{ticket_data.floor_plan_id}'")
            ticket.floor_plan_id = ticket_data.floor_plan_id
        
        if ticket_data.x_position is not None and ticket_data.x_position != ticket.x_position:
            ticket.x_position = ticket_data.x_position
            if not "Position updated" in changes:
                changes.append("Position updated")
        
        if ticket_data.y_position is not None and ticket_data.y_position != ticket.y_position:
            ticket.y_position = ticket_data.y_position
            if not "Position updated" in changes:
                changes.append("Position updated")
        
        if ticket_data.due_date is not None and ticket_data.due_date != ticket.due_date:
            old_due_date = ticket.due_date.strftime("%Y-%m-%d") if ticket.due_date else "none"
            new_due_date = ticket_data.due_date.strftime("%Y-%m-%d") if ticket_data.due_date else "none"
            changes.append(f"Due date changed from {old_due_date} to {new_due_date}")
            ticket.due_date = ticket_data.due_date
        
        if ticket_data.properties is not None and ticket_data.properties != ticket.properties:
            changes.append("Properties updated")
            ticket.properties = ticket_data.properties
        
        # Update related items if provided
        if ticket_data.related_item_ids is not None:
            # Get current related items
            query = select(TicketItem).where(TicketItem.ticket_id == ticket_id)
            result = await session.execute(query)
            current_items = result.scalars().all()
            current_item_ids = [item.item_id for item in current_items]
            
            # Items to add
            items_to_add = [item_id for item_id in ticket_data.related_item_ids if item_id not in current_item_ids]
            
            # Items to remove
            items_to_remove = [item for item in current_items if item.item_id not in ticket_data.related_item_ids]
            
            # Add new items
            for item_id in items_to_add:
                ticket_item = TicketItem(
                    ticket_id=ticket_id,
                    item_id=item_id
                )
                session.add(ticket_item)
            
            # Remove items
            for item in items_to_remove:
                await session.delete(item)
            
            if items_to_add or items_to_remove:
                changes.append("Related items updated")
        
        # Update the ticket's updated_at timestamp
        ticket.updated_at = datetime.utcnow()
        
        # Create activity log entries for changes
        if changes:
            for change in changes:
                activity = TicketActivity(
                    ticket_id=ticket_id,
                    user_id=user_id,
                    activity_type="UPDATED",
                    description=change
                )
                session.add(activity)
        
        await session.commit()
        await session.refresh(ticket)
        
        return ticket
    
    @staticmethod
    async def delete(session: AsyncSession, ticket_id: int) -> bool:
        """Delete a ticket"""
        ticket = await TicketRepository.get_by_id(session, ticket_id)
        if not ticket:
            return False
        
        await session.delete(ticket)
        await session.commit()
        
        return True
    
    @staticmethod
    async def search(session: AsyncSession, search_params: TicketSearch, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Search for tickets based on various criteria"""
        query = select(Ticket)
        
        # Apply filters
        conditions = []
        
        if search_params.title:
            conditions.append(Ticket.title.ilike(f"%{search_params.title}%"))
        
        if search_params.category:
            conditions.append(Ticket.category == search_params.category)
        
        if search_params.priority:
            conditions.append(Ticket.priority == search_params.priority)
        
        if search_params.status:
            conditions.append(Ticket.status == search_params.status)
        
        if search_params.department:
            conditions.append(Ticket.department == search_params.department)
        
        if search_params.created_by:
            conditions.append(Ticket.created_by == search_params.created_by)
        
        if search_params.assigned_to:
            conditions.append(Ticket.assigned_to == search_params.assigned_to)
        
        if search_params.location_id:
            conditions.append(Ticket.location_id == search_params.location_id)
        
        if search_params.floor_plan_id:
            conditions.append(Ticket.floor_plan_id == search_params.floor_plan_id)
        
        if search_params.created_after:
            conditions.append(Ticket.created_at >= search_params.created_after)
        
        if search_params.created_before:
            conditions.append(Ticket.created_at <= search_params.created_before)
        
        if search_params.due_after:
            conditions.append(Ticket.due_date >= search_params.due_after)
        
        if search_params.due_before:
            conditions.append(Ticket.due_date <= search_params.due_before)
        
        if search_params.item_id:
            # Join with TicketItem to filter by related item
            subquery = select(TicketItem.ticket_id).where(TicketItem.item_id == search_params.item_id).distinct()
            result = await session.execute(subquery)
            ticket_ids = result.scalars().all()
            if ticket_ids:
                conditions.append(Ticket.ticket_id.in_(ticket_ids))
            else:
                # No tickets match this item, return empty list
                return []
        
        if conditions:
            query = query.where(and_(*conditions))
        
        # Apply pagination and ordering
        query = query.order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        
        # Execute query
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_status(session: AsyncSession, status: TicketStatus, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by status"""
        query = select(Ticket).where(Ticket.status == status).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_priority(session: AsyncSession, priority: TicketPriority, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by priority"""
        query = select(Ticket).where(Ticket.priority == priority).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_category(session: AsyncSession, category: TicketCategory, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by category"""
        query = select(Ticket).where(Ticket.category == category).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_department(session: AsyncSession, department: TicketDepartment, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by department"""
        query = select(Ticket).where(Ticket.department == department).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_creator(session: AsyncSession, creator_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by creator"""
        query = select(Ticket).where(Ticket.created_by == creator_id).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_assignee(session: AsyncSession, assignee_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by assignee"""
        query = select(Ticket).where(Ticket.assigned_to == assignee_id).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_location(session: AsyncSession, location_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by location"""
        query = select(Ticket).where(Ticket.location_id == location_id).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_floor_plan(session: AsyncSession, floor_plan_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by floor plan"""
        query = select(Ticket).where(Ticket.floor_plan_id == floor_plan_id).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_item(session: AsyncSession, item_id: int, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get tickets by related item"""
        # Get ticket IDs related to the item
        subquery = select(TicketItem.ticket_id).where(TicketItem.item_id == item_id).distinct()
        result = await session.execute(subquery)
        ticket_ids = result.scalars().all()
        
        if not ticket_ids:
            return []
        
        # Get tickets
        query = select(Ticket).where(Ticket.ticket_id.in_(ticket_ids)).order_by(desc(Ticket.created_at)).offset(skip).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_overdue_tickets(session: AsyncSession, skip: int = 0, limit: int = 100) -> List[Ticket]:
        """Get overdue tickets (due date in the past and not closed/resolved)"""
        now = datetime.utcnow()
        query = select(Ticket).where(
            and_(
                Ticket.due_date < now,
                Ticket.status.not_in([TicketStatus.CLOSED, TicketStatus.RESOLVED])
            )
        ).order_by(Ticket.due_date).offset(skip).limit(limit)
        
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_recent_tickets(session: AsyncSession, limit: int = 10) -> List[Ticket]:
        """Get recent tickets"""
        query = select(Ticket).order_by(desc(Ticket.created_at)).limit(limit)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_with_comments(session: AsyncSession, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its comments"""
        query = select(Ticket).where(Ticket.ticket_id == ticket_id).options(
            selectinload(Ticket.comments).selectinload(TicketComment.user)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_attachments(session: AsyncSession, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its attachments"""
        query = select(Ticket).where(Ticket.ticket_id == ticket_id).options(
            selectinload(Ticket.attachments).selectinload(TicketAttachment.user)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_activities(session: AsyncSession, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its activities"""
        query = select(Ticket).where(Ticket.ticket_id == ticket_id).options(
            selectinload(Ticket.activities).selectinload(TicketActivity.user)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_related_items(session: AsyncSession, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with its related items"""
        query = select(Ticket).where(Ticket.ticket_id == ticket_id).options(
            selectinload(Ticket.related_items).selectinload(TicketItem.item)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_full_ticket(session: AsyncSession, ticket_id: int) -> Optional[Ticket]:
        """Get a ticket with all its related data"""
        query = select(Ticket).where(Ticket.ticket_id == ticket_id).options(
            selectinload(Ticket.comments).selectinload(TicketComment.user),
            selectinload(Ticket.attachments).selectinload(TicketAttachment.user),
            selectinload(Ticket.activities).selectinload(TicketActivity.user),
            selectinload(Ticket.related_items).selectinload(TicketItem.item),
            selectinload(Ticket.creator),
            selectinload(Ticket.assignee),
            selectinload(Ticket.location),
            selectinload(Ticket.floor_plan)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_ticket_counts_by_status(session: AsyncSession) -> Dict[str, int]:
        """Get ticket counts by status"""
        query = select(Ticket.status, func.count(Ticket.ticket_id)).group_by(Ticket.status)
        result = await session.execute(query)
        
        counts = {status.value: 0 for status in TicketStatus}
        for status, count in result:
            counts[status.value] = count
        
        return counts
    
    @staticmethod
    async def get_ticket_counts_by_priority(session: AsyncSession) -> Dict[str, int]:
        """Get ticket counts by priority"""
        query = select(Ticket.priority, func.count(Ticket.ticket_id)).group_by(Ticket.priority)
        result = await session.execute(query)
        
        counts = {priority.value: 0 for priority in TicketPriority}
        for priority, count in result:
            counts[priority.value] = count
        
        return counts
    
    @staticmethod
    async def get_ticket_counts_by_category(session: AsyncSession) -> Dict[str, int]:
        """Get ticket counts by category"""
        query = select(Ticket.category, func.count(Ticket.ticket_id)).group_by(Ticket.category)
        result = await session.execute(query)
        
        counts = {category.value: 0 for category in TicketCategory}
        for category, count in result:
            counts[category.value] = count
        
        return counts
    
    @staticmethod
    async def get_ticket_counts_by_department(session: AsyncSession) -> Dict[str, int]:
        """Get ticket counts by department"""
        query = select(Ticket.department, func.count(Ticket.ticket_id)).group_by(Ticket.department)
        result = await session.execute(query)
        
        counts = {department.value: 0 for department in TicketDepartment}
        for department, count in result:
            counts[department.value] = count
        
        return counts
    
    @staticmethod
    async def get_ticket_counts_by_assignee(session: AsyncSession) -> Dict[int, int]:
        """Get ticket counts by assignee"""
        query = select(Ticket.assigned_to, func.count(Ticket.ticket_id)).where(
            Ticket.assigned_to.is_not(None)
        ).group_by(Ticket.assigned_to)
        result = await session.execute(query)
        
        counts = {}
        for assignee_id, count in result:
            counts[assignee_id] = count
        
        return counts

class TicketCommentRepository:
    """Repository for ticket comment operations"""
    
    @staticmethod
    async def create(session: AsyncSession, ticket_id: int, comment_data: TicketCommentCreate, user_id: int) -> TicketComment:
        """Create a new ticket comment"""
        # Create the comment
        comment = TicketComment(
            ticket_id=ticket_id,
            user_id=user_id,
            content=comment_data.content,
            is_internal=comment_data.is_internal
        )
        
        session.add(comment)
        await session.flush()
        
        # Create ticket activity for comment
        activity = TicketActivity(
            ticket_id=ticket_id,
            user_id=user_id,
            activity_type="COMMENT_ADDED",
            description="Comment added to ticket"
        )
        session.add(activity)
        
        # Update ticket's updated_at timestamp
        ticket_update = update(Ticket).where(Ticket.ticket_id == ticket_id).values(
            updated_at=datetime.utcnow()
        )
        await session.execute(ticket_update)
        
        await session.commit()
        await session.refresh(comment)
        
        return comment
    
    @staticmethod
    async def get_by_id(session: AsyncSession, comment_id: int) -> Optional[TicketComment]:
        """Get a comment by ID"""
        query = select(TicketComment).where(TicketComment.comment_id == comment_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_by_ticket(session: AsyncSession, ticket_id: int) -> List[TicketComment]:
        """Get comments by ticket ID"""
        query = select(TicketComment).where(TicketComment.ticket_id == ticket_id).order_by(TicketComment.created_at)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def update(session: AsyncSession, comment_id: int, comment_data: TicketCommentUpdate, user_id: int) -> Optional[TicketComment]:
        """Update a comment"""
        # Get the comment
        comment = await TicketCommentRepository.get_by_id(session, comment_id)
        if not comment:
            return None
        
        # Check if user is the comment creator
        if comment.user_id != user_id:
            # In a real application, you might want to check for admin privileges here
            return None
        
        # Update fields if provided
        if comment_data.content is not None:
            comment.content = comment_data.content
        
        if comment_data.is_internal is not None:
            comment.is_internal = comment_data.is_internal
        
        # Update the comment's updated_at timestamp
        comment.updated_at = datetime.utcnow()
        
        # Create activity log entry
        activity = TicketActivity(
            ticket_id=comment.ticket_id,
            user_id=user_id,
            activity_type="COMMENT_UPDATED",
            description="Comment updated"
        )
        session.add(activity)
        
        # Update ticket's updated_at timestamp
        ticket_update = update(Ticket).where(Ticket.ticket_id == comment.ticket_id).values(
            updated_at=datetime.utcnow()
        )
        await session.execute(ticket_update)
        
        await session.commit()
        await session.refresh(comment)
        
        return comment
    
    @staticmethod
    async def delete(session: AsyncSession, comment_id: int, user_id: int) -> bool:
        """Delete a comment"""
        # Get the comment
        comment = await TicketCommentRepository.get_by_id(session, comment_id)
        if not comment:
            return False
        
        # Check if user is the comment creator
        if comment.user_id != user_id:
            # In a real application, you might want to check for admin privileges here
            return False
        
        # Store ticket_id for activity log
        ticket_id = comment.ticket_id
        
        # Delete the comment
        await session.delete(comment)
        
        # Create activity log entry
        activity = TicketActivity(
            ticket_id=ticket_id,
            user_id=user_id,
            activity_type="COMMENT_DELETED",
            description="Comment deleted"
        )
        session.add(activity)
        
        # Update ticket's updated_at timestamp
        ticket_update = update(Ticket).where(Ticket.ticket_id == ticket_id).values(
            updated_at=datetime.utcnow()
        )
        await session.execute(ticket_update)
        
        await session.commit()
        
        return True
    
    @staticmethod
    async def get_with_user(session: AsyncSession, comment_id: int) -> Optional[TicketComment]:
        """Get a comment with its user"""
        query = select(TicketComment).where(TicketComment.comment_id == comment_id).options(
            selectinload(TicketComment.user)
        )
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_with_attachments(session: AsyncSession, comment_id: int) -> Optional[TicketComment]:
        """Get a comment with its attachments"""
        query = select(TicketComment).where(TicketComment.comment_id == comment_id).options(
            selectinload(TicketComment.attachments)
        )
        result = await session.execute(query)
        return result.scalars().first()

class TicketAttachmentRepository:
    """Repository for ticket attachment operations"""
    
    @staticmethod
    async def create(
        session: AsyncSession, 
        ticket_id: int, 
        user_id: int, 
        file_name: str, 
        file_path: str, 
        file_size: int, 
        file_type: str,
        comment_id: Optional[int] = None
    ) -> TicketAttachment:
        """Create a new ticket attachment"""
        # Create the attachment
        attachment = TicketAttachment(
            ticket_id=ticket_id,
            comment_id=comment_id,
            user_id=user_id,
            file_name=file_name,
            file_path=file_path,
            file_size=file_size,
            file_type=file_type
        )
        
        session.add(attachment)
        await session.flush()
        
        # Create ticket activity for attachment
        activity = TicketActivity(
            ticket_id=ticket_id,
            user_id=user_id,
            activity_type="ATTACHMENT_ADDED",
            description=f"File '{file_name}' attached to ticket"
        )
        session.add(activity)
        
        # Update ticket's updated_at timestamp
        ticket_update = update(Ticket).where(Ticket.ticket_id == ticket_id).values(
            updated_at=datetime.utcnow()
        )
        await session.execute(ticket_update)
        
        await session.commit()
        await session.refresh(attachment)
        
        return attachment
    
    @staticmethod
    async def get_by_id(session: AsyncSession, attachment_id: int) -> Optional[TicketAttachment]:
        """Get an attachment by ID"""
        query = select(TicketAttachment).where(TicketAttachment.attachment_id == attachment_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_by_ticket(session: AsyncSession, ticket_id: int) -> List[TicketAttachment]:
        """Get attachments by ticket ID"""
        query = select(TicketAttachment).where(TicketAttachment.ticket_id == ticket_id).order_by(TicketAttachment.created_at)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_comment(session: AsyncSession, comment_id: int) -> List[TicketAttachment]:
        """Get attachments by comment ID"""
        query = select(TicketAttachment).where(TicketAttachment.comment_id == comment_id).order_by(TicketAttachment.created_at)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def delete(session: AsyncSession, attachment_id: int, user_id: int) -> bool:
        """Delete an attachment"""
        # Get the attachment
        attachment = await TicketAttachmentRepository.get_by_id(session, attachment_id)
        if not attachment:
            return False
        
        # Check if user is the attachment creator
        if attachment.user_id != user_id:
            # In a real application, you might want to check for admin privileges here
            return False
        
        # Store ticket_id and file_name for activity log
        ticket_id = attachment.ticket_id
        file_name = attachment.file_name
        
        # Delete the attachment
        await session.delete(attachment)
        
        # Create activity log entry
        activity = TicketActivity(
            ticket_id=ticket_id,
            user_id=user_id,
            activity_type="ATTACHMENT_DELETED",
            description=f"File '{file_name}' removed from ticket"
        )
        session.add(activity)
        
        # Update ticket's updated_at timestamp
        ticket_update = update(Ticket).where(Ticket.ticket_id == ticket_id).values(
            updated_at=datetime.utcnow()
        )
        await session.execute(ticket_update)
        
        await session.commit()
        
        return True
    
    @staticmethod
    async def get_with_user(session: AsyncSession, attachment_id: int) -> Optional[TicketAttachment]:
        """Get an attachment with its user"""
        query = select(TicketAttachment).where(TicketAttachment.attachment_id == attachment_id).options(
            selectinload(TicketAttachment.user)
        )
        result = await session.execute(query)
        return result.scalars().first()

class TicketActivityRepository:
    """Repository for ticket activity operations"""
    
    @staticmethod
    async def get_by_id(session: AsyncSession, activity_id: int) -> Optional[TicketActivity]:
        """Get an activity by ID"""
        query = select(TicketActivity).where(TicketActivity.activity_id == activity_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_by_ticket(session: AsyncSession, ticket_id: int) -> List[TicketActivity]:
        """Get activities by ticket ID"""
        query = select(TicketActivity).where(TicketActivity.ticket_id == ticket_id).order_by(TicketActivity.created_at)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_with_user(session: AsyncSession, activity_id: int) -> Optional[TicketActivity]:
        """Get an activity with its user"""
        query = select(TicketActivity).where(TicketActivity.activity_id == activity_id).options(
            selectinload(TicketActivity.user)
        )
        result = await session.execute(query)
        return result.scalars().first()

class TicketItemRepository:
    """Repository for ticket related item operations"""
    
    @staticmethod
    async def get_by_id(session: AsyncSession, ticket_item_id: int) -> Optional[TicketItem]:
        """Get a ticket item by ID"""
        query = select(TicketItem).where(TicketItem.ticket_item_id == ticket_item_id)
        result = await session.execute(query)
        return result.scalars().first()
    
    @staticmethod
    async def get_by_ticket(session: AsyncSession, ticket_id: int) -> List[TicketItem]:
        """Get ticket items by ticket ID"""
        query = select(TicketItem).where(TicketItem.ticket_id == ticket_id)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_by_item(session: AsyncSession, item_id: int) -> List[TicketItem]:
        """Get ticket items by item ID"""
        query = select(TicketItem).where(TicketItem.item_id == item_id)
        result = await session.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_with_item(session: AsyncSession, ticket_item_id: int) -> Optional[TicketItem]:
        """Get a ticket item with its item"""
        query = select(TicketItem).where(TicketItem.ticket_item_id == ticket_item_id).options(
            selectinload(TicketItem.item)
        )
        result = await session.execute(query)
        return result.scalars().first()
