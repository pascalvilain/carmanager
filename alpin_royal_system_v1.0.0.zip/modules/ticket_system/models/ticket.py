"""
Alpin Royal Casino Management System - Ticket System Module Models
This module provides data models for the ticket system.
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean, Enum as SQLAlchemyEnum, JSON
from sqlalchemy.orm import relationship

from base_layer.utils.database import Base

# Enums

class TicketPriority(str, Enum):
    """Ticket priority levels"""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

class TicketStatus(str, Enum):
    """Ticket status values"""
    OPEN = "OPEN"
    IN_PROGRESS = "IN_PROGRESS"
    PENDING = "PENDING"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"
    REOPENED = "REOPENED"

class TicketCategory(str, Enum):
    """Ticket category values"""
    HARDWARE = "HARDWARE"
    SOFTWARE = "SOFTWARE"
    NETWORK = "NETWORK"
    SECURITY = "SECURITY"
    GAMING = "GAMING"
    SURVEILLANCE = "SURVEILLANCE"
    MAINTENANCE = "MAINTENANCE"
    OTHER = "OTHER"

class TicketDepartment(str, Enum):
    """Ticket department values"""
    IT = "IT"
    MAINTENANCE = "MAINTENANCE"
    SECURITY = "SECURITY"
    GAMING = "GAMING"
    OPERATIONS = "OPERATIONS"
    MANAGEMENT = "MANAGEMENT"

# SQLAlchemy Models

class Ticket(Base):
    """Ticket model for database"""
    __tablename__ = "tickets"

    ticket_id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(SQLAlchemyEnum(TicketCategory), nullable=False)
    priority = Column(SQLAlchemyEnum(TicketPriority), nullable=False, default=TicketPriority.MEDIUM)
    status = Column(SQLAlchemyEnum(TicketStatus), nullable=False, default=TicketStatus.OPEN)
    department = Column(SQLAlchemyEnum(TicketDepartment), nullable=False)
    
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    assigned_to = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    location_id = Column(Integer, ForeignKey("inventory_locations.location_id"), nullable=True)
    floor_plan_id = Column(Integer, ForeignKey("floor_plans.floor_plan_id"), nullable=True)
    x_position = Column(Integer, nullable=True)
    y_position = Column(Integer, nullable=True)
    
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    due_date = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    closed_at = Column(DateTime, nullable=True)
    
    properties = Column(JSON, nullable=True)
    
    # Relationships
    creator = relationship("User", foreign_keys=[created_by], back_populates="created_tickets")
    assignee = relationship("User", foreign_keys=[assigned_to], back_populates="assigned_tickets")
    location = relationship("InventoryLocation", back_populates="tickets")
    floor_plan = relationship("FloorPlan", back_populates="tickets")
    comments = relationship("TicketComment", back_populates="ticket", cascade="all, delete-orphan")
    attachments = relationship("TicketAttachment", back_populates="ticket", cascade="all, delete-orphan")
    activities = relationship("TicketActivity", back_populates="ticket", cascade="all, delete-orphan")
    related_items = relationship("TicketItem", back_populates="ticket", cascade="all, delete-orphan")

class TicketComment(Base):
    """Ticket comment model for database"""
    __tablename__ = "ticket_comments"

    comment_id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(Integer, ForeignKey("tickets.ticket_id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_internal = Column(Boolean, nullable=False, default=False)
    
    # Relationships
    ticket = relationship("Ticket", back_populates="comments")
    user = relationship("User", back_populates="ticket_comments")
    attachments = relationship("TicketAttachment", back_populates="comment", cascade="all, delete-orphan")

class TicketAttachment(Base):
    """Ticket attachment model for database"""
    __tablename__ = "ticket_attachments"

    attachment_id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(Integer, ForeignKey("tickets.ticket_id", ondelete="CASCADE"), nullable=False)
    comment_id = Column(Integer, ForeignKey("ticket_comments.comment_id", ondelete="CASCADE"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(512), nullable=False)
    file_size = Column(Integer, nullable=False)
    file_type = Column(String(128), nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    # Relationships
    ticket = relationship("Ticket", back_populates="attachments")
    comment = relationship("TicketComment", back_populates="attachments")
    user = relationship("User", back_populates="ticket_attachments")

class TicketActivity(Base):
    """Ticket activity model for database"""
    __tablename__ = "ticket_activities"

    activity_id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(Integer, ForeignKey("tickets.ticket_id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    activity_type = Column(String(50), nullable=False)
    description = Column(Text, nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    properties = Column(JSON, nullable=True)
    
    # Relationships
    ticket = relationship("Ticket", back_populates="activities")
    user = relationship("User", back_populates="ticket_activities")

class TicketItem(Base):
    """Ticket related item model for database"""
    __tablename__ = "ticket_items"

    ticket_item_id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(Integer, ForeignKey("tickets.ticket_id", ondelete="CASCADE"), nullable=False)
    item_id = Column(Integer, ForeignKey("inventory_items.item_id"), nullable=False)
    
    # Relationships
    ticket = relationship("Ticket", back_populates="related_items")
    item = relationship("InventoryItem", back_populates="tickets")

# Pydantic Models for API

class TicketBase(BaseModel):
    """Base ticket model for API"""
    title: str
    description: str
    category: TicketCategory
    priority: TicketPriority = TicketPriority.MEDIUM
    department: TicketDepartment
    location_id: Optional[int] = None
    floor_plan_id: Optional[int] = None
    x_position: Optional[int] = None
    y_position: Optional[int] = None
    due_date: Optional[datetime] = None
    properties: Optional[Dict[str, Any]] = None

class TicketCreate(TicketBase):
    """Ticket creation model for API"""
    assigned_to: Optional[int] = None
    related_item_ids: Optional[List[int]] = None

class TicketUpdate(BaseModel):
    """Ticket update model for API"""
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[TicketCategory] = None
    priority: Optional[TicketPriority] = None
    status: Optional[TicketStatus] = None
    department: Optional[TicketDepartment] = None
    assigned_to: Optional[int] = None
    location_id: Optional[int] = None
    floor_plan_id: Optional[int] = None
    x_position: Optional[int] = None
    y_position: Optional[int] = None
    due_date: Optional[datetime] = None
    properties: Optional[Dict[str, Any]] = None
    related_item_ids: Optional[List[int]] = None

class TicketCommentBase(BaseModel):
    """Base ticket comment model for API"""
    content: str
    is_internal: bool = False

class TicketCommentCreate(TicketCommentBase):
    """Ticket comment creation model for API"""
    pass

class TicketCommentUpdate(BaseModel):
    """Ticket comment update model for API"""
    content: Optional[str] = None
    is_internal: Optional[bool] = None

class TicketCommentResponse(TicketCommentBase):
    """Ticket comment response model for API"""
    comment_id: int
    ticket_id: int
    user_id: int
    created_at: datetime
    updated_at: datetime
    user_name: str
    attachments: List[Dict[str, Any]] = []

    class Config:
        orm_mode = True

class TicketAttachmentResponse(BaseModel):
    """Ticket attachment response model for API"""
    attachment_id: int
    ticket_id: int
    comment_id: Optional[int] = None
    user_id: int
    file_name: str
    file_path: str
    file_size: int
    file_type: str
    created_at: datetime
    user_name: str

    class Config:
        orm_mode = True

class TicketActivityResponse(BaseModel):
    """Ticket activity response model for API"""
    activity_id: int
    ticket_id: int
    user_id: int
    activity_type: str
    description: str
    created_at: datetime
    properties: Optional[Dict[str, Any]] = None
    user_name: str

    class Config:
        orm_mode = True

class TicketItemResponse(BaseModel):
    """Ticket related item response model for API"""
    ticket_item_id: int
    ticket_id: int
    item_id: int
    item_name: str
    item_category: str
    item_status: str

    class Config:
        orm_mode = True

class TicketResponse(TicketBase):
    """Ticket response model for API"""
    ticket_id: int
    status: TicketStatus
    created_by: int
    assigned_to: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    resolved_at: Optional[datetime] = None
    closed_at: Optional[datetime] = None
    creator_name: str
    assignee_name: Optional[str] = None
    location_name: Optional[str] = None
    comments_count: int = 0
    attachments_count: int = 0
    related_items_count: int = 0

    class Config:
        orm_mode = True

class TicketDetailResponse(TicketResponse):
    """Detailed ticket response model for API"""
    comments: List[TicketCommentResponse] = []
    attachments: List[TicketAttachmentResponse] = []
    activities: List[TicketActivityResponse] = []
    related_items: List[TicketItemResponse] = []

    class Config:
        orm_mode = True

class TicketSearch(BaseModel):
    """Ticket search model for API"""
    title: Optional[str] = None
    category: Optional[TicketCategory] = None
    priority: Optional[TicketPriority] = None
    status: Optional[TicketStatus] = None
    department: Optional[TicketDepartment] = None
    created_by: Optional[int] = None
    assigned_to: Optional[int] = None
    location_id: Optional[int] = None
    floor_plan_id: Optional[int] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None
    due_after: Optional[datetime] = None
    due_before: Optional[datetime] = None
    item_id: Optional[int] = None

class TicketDashboard(BaseModel):
    """Ticket dashboard model for API"""
    total_tickets: int
    open_tickets: int
    in_progress_tickets: int
    pending_tickets: int
    resolved_tickets: int
    closed_tickets: int
    tickets_by_priority: Dict[str, int]
    tickets_by_category: Dict[str, int]
    tickets_by_department: Dict[str, int]
    tickets_by_assignee: Dict[str, int]
    recent_tickets: List[TicketResponse]
    overdue_tickets: List[TicketResponse]
    high_priority_tickets: List[TicketResponse]
