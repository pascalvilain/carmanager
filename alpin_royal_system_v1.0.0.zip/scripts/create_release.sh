#!/bin/bash

# Create a release package for the Alpin Royal Casino Management System
# This script creates a zip file containing all the necessary files for deployment

# Set variables
RELEASE_NAME="alpin_royal_system_v1.0.0"
RELEASE_DIR="/home/ubuntu/releases"
SOURCE_DIR="/home/ubuntu/alpin_royal_system"

# Create release directory if it doesn't exist
mkdir -p $RELEASE_DIR

# Create a temporary directory for the release
TEMP_DIR=$(mktemp -d)
echo "Creating release package in $TEMP_DIR..."

# Copy all files to the temporary directory
cp -r $SOURCE_DIR/* $TEMP_DIR/

# Remove any unnecessary files
find $TEMP_DIR -name "__pycache__" -type d -exec rm -rf {} +
find $TEMP_DIR -name "*.pyc" -delete
find $TEMP_DIR -name ".DS_Store" -delete

# Create the release zip file
cd $TEMP_DIR
zip -r $RELEASE_DIR/$RELEASE_NAME.zip .
cd - > /dev/null

# Clean up
rm -rf $TEMP_DIR

echo "Release package created at $RELEASE_DIR/$RELEASE_NAME.zip"
