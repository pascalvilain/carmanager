#!/bin/bash
# Run test data generation and database loading

# Create directory for test data if it doesn't exist
mkdir -p /home/ubuntu/alpin_royal_system/test_data

# Install required packages
pip install faker requests tqdm pillow

# Run test data generator
echo "Generating test data..."
python /home/ubuntu/alpin_royal_system/scripts/test_data/generate_test_data.py --output-dir /home/ubuntu/alpin_royal_system/test_data

# Run database loader
echo "Loading test data into database..."
python /home/ubuntu/alpin_royal_system/scripts/test_data/load_test_data.py --test-data-dir /home/ubuntu/alpin_royal_system/test_data

echo "Test data generation and loading complete!"
