"""
Alpin Royal Casino Management System - Test Data Generator
This script generates test data for the casino management system.
"""

import os
import sys
import json
import random
import datetime
import uuid
import faker
import requests
import io
import base64
from PIL import Image
from pathlib import Path
import argparse
import logging
from tqdm import tqdm

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("test_data_generator.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("test_data_generator")

# Initialize faker
fake = faker.Faker(['en_US', 'de_CH', 'fr_CH', 'it_CH'])

# Constants
CASINO_GUEST_ID_PREFIX = "AR-"
VIP_STATUSES = ["STANDARD", "SILVER", "GOLD", "PLATINUM"]
VIP_WEIGHTS = [70, 15, 10, 5]  # Weights for random selection
NATIONALITIES = ["Swiss", "German", "French", "Italian", "Austrian", "British", "American", "Russian", "Chinese", "Japanese"]
NATIONALITY_WEIGHTS = [30, 15, 15, 10, 10, 5, 5, 5, 3, 2]  # Weights for random selection

# Gaming constants
SLOT_MACHINE_TYPES = [
    "Classic Slots", "Video Slots", "Progressive Jackpot", "3D Slots", 
    "Fruit Machines", "Multi-line Slots", "Multi-reel Slots", "Bonus Slots"
]
SLOT_MACHINE_MANUFACTURERS = [
    "IGT", "Aristocrat", "Novomatic", "Konami", "Scientific Games", 
    "Bally", "WMS", "Merkur", "Ainsworth", "EGT"
]
TABLE_GAME_TYPES = {
    "roulette": ["European Roulette", "American Roulette", "French Roulette"],
    "blackjack": ["Classic Blackjack", "European Blackjack", "Vegas Strip Blackjack", "Atlantic City Blackjack"],
    "poker_uth": ["Ultimate Texas Hold'em", "Three Card Poker"],
    "poker_cash": ["Texas Hold'em", "Omaha", "Seven-Card Stud", "Razz"]
}
MIN_BETS = {
    "roulette": [5, 10, 20, 50],
    "blackjack": [10, 25, 50, 100],
    "poker_uth": [10, 25],
    "poker_cash": [5, 10, 25, 50]
}
MAX_BETS = {
    "roulette": [500, 1000, 2000, 5000],
    "blackjack": [1000, 2500, 5000, 10000],
    "poker_uth": [1000, 2500],
    "poker_cash": [no_limit for _ in range(4)]  # No limit for cash games
}
CHIP_VALUES = [0.5, 1, 2.5, 5, 10, 20, 50, 100, 500, 1000, 5000, 10000, 25000, 100000]

# Consumption constants
DRINK_TYPES = ["Beer", "Wine", "Cocktail", "Spirit", "Soft Drink", "Coffee", "Tea", "Water"]
DRINK_NAMES = {
    "Beer": ["Heineken", "Corona", "Stella Artois", "Budweiser", "Guinness", "Carlsberg", "Feldschlösschen", "Calanda"],
    "Wine": ["Chardonnay", "Merlot", "Cabernet Sauvignon", "Pinot Noir", "Sauvignon Blanc", "Riesling", "Champagne", "Prosecco"],
    "Cocktail": ["Martini", "Mojito", "Margarita", "Old Fashioned", "Negroni", "Daiquiri", "Manhattan", "Whiskey Sour"],
    "Spirit": ["Whiskey", "Vodka", "Gin", "Rum", "Tequila", "Brandy", "Cognac", "Scotch"],
    "Soft Drink": ["Cola", "Lemonade", "Orange Juice", "Apple Juice", "Tonic Water", "Ginger Ale", "Soda Water", "Iced Tea"],
    "Coffee": ["Espresso", "Cappuccino", "Latte", "Americano", "Macchiato", "Mocha", "Flat White", "Irish Coffee"],
    "Tea": ["Earl Grey", "English Breakfast", "Green Tea", "Chamomile", "Peppermint", "Jasmine", "Chai", "Fruit Tea"],
    "Water": ["Still Water", "Sparkling Water", "Mineral Water", "Flavored Water"]
}
FOOD_TYPES = ["Snack", "Appetizer", "Main Course", "Dessert"]
FOOD_NAMES = {
    "Snack": ["Chips", "Nuts", "Olives", "Pretzels", "Popcorn", "Crackers", "Cheese Plate", "Fruit Plate"],
    "Appetizer": ["Bruschetta", "Calamari", "Shrimp Cocktail", "Spring Rolls", "Chicken Wings", "Nachos", "Mozzarella Sticks", "Soup"],
    "Main Course": ["Steak", "Burger", "Pasta", "Pizza", "Fish & Chips", "Chicken Curry", "Caesar Salad", "Club Sandwich"],
    "Dessert": ["Cheesecake", "Chocolate Cake", "Ice Cream", "Tiramisu", "Crème Brûlée", "Apple Pie", "Fruit Salad", "Chocolate Mousse"]
}
CIGARETTE_BRANDS = ["Marlboro", "Camel", "Lucky Strike", "Winston", "Dunhill", "Parliament", "Davidoff", "Pall Mall", "Benson & Hedges", "Kent"]
CIGARETTE_VARIANTS = ["Red", "Gold", "Silver", "Blue", "Menthol", "Light", "Ultra Light", "100s", ""]

# Financial constants
TRANSACTION_TYPES = ["BUY_IN", "CASH_OUT", "CHIPS_PURCHASE", "CHIPS_REDEMPTION", "TICKET_IN", "TICKET_OUT", "JACKPOT", "HAND_PAY"]
PAYMENT_METHODS = ["CASH", "CREDIT_CARD", "DEBIT_CARD", "BANK_TRANSFER", "CHIPS", "TICKET", "COMP"]
PAYMENT_METHOD_WEIGHTS = [50, 20, 15, 5, 5, 3, 2]  # Weights for random selection

class TestDataGenerator:
    """Generator for test data for the Alpin Royal Casino Management System"""
    
    def __init__(self, output_dir, num_guests=1000, num_employees=150, num_slots=300, 
                 num_roulette=6, num_blackjack=4, num_uth=2, num_poker=4):
        """
        Initialize the test data generator.
        
        Args:
            output_dir: Directory to save the generated data
            num_guests: Number of guests to generate
            num_employees: Number of employees to generate
            num_slots: Number of slot machines to generate
            num_roulette: Number of roulette tables to generate
            num_blackjack: Number of blackjack tables to generate
            num_uth: Number of Ultimate Texas Hold'em tables to generate
            num_poker: Number of cash game poker tables to generate
        """
        self.output_dir = Path(output_dir)
        self.num_guests = num_guests
        self.num_employees = num_employees
        self.num_slots = num_slots
        self.num_roulette = num_roulette
        self.num_blackjack = num_blackjack
        self.num_uth = num_uth
        self.num_poker = num_poker
        
        # Create output directory if it doesn't exist
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.output_dir / "images" / "guests", exist_ok=True)
        os.makedirs(self.output_dir / "images" / "employees", exist_ok=True)
        os.makedirs(self.output_dir / "images" / "jackpots", exist_ok=True)
        
        # Initialize data containers
        self.guests = []
        self.employees = []
        self.slot_machines = []
        self.table_games = []
        self.gaming_sessions = []
        self.financial_transactions = []
        self.jackpots_hand_pays = []
        self.consumption_items = []
        self.player_consumptions = []
        self.cigarette_inventory = []
        self.cigarette_transactions = []
        
        # Initialize IDs
        self.next_guest_id = 10000
        self.next_employee_id = 1000
        self.next_slot_id = 1
        self.next_table_id = 1
        self.next_session_id = 1
        self.next_transaction_id = 1
        self.next_jackpot_id = 1
        self.next_consumption_item_id = 1
        self.next_player_consumption_id = 1
        self.next_cigarette_inventory_id = 1
        self.next_cigarette_transaction_id = 1
    
    def generate_all(self):
        """Generate all test data"""
        logger.info("Starting test data generation")
        
        # Generate basic data
        self.generate_employees()
        self.generate_slot_machines()
        self.generate_table_games()
        self.generate_consumption_items()
        self.generate_cigarette_inventory()
        
        # Generate guests and their activities
        self.generate_guests()
        
        # Save all data to JSON files
        self.save_all_data()
        
        logger.info("Test data generation completed")
    
    def generate_guests(self):
        """Generate guest data"""
        logger.info(f"Generating {self.num_guests} guests")
        
        for _ in tqdm(range(self.num_guests), desc="Generating guests"):
            guest_id = self.next_guest_id
            self.next_guest_id += 1
            
            # Basic guest info
            gender = random.choice(["male", "female"])
            first_name = fake.first_name_male() if gender == "male" else fake.first_name_female()
            last_name = fake.last_name()
            
            # Generate a date of birth between 21 and 80 years ago
            dob = fake.date_of_birth(minimum_age=21, maximum_age=80)
            
            # Calculate age
            today = datetime.date.today()
            age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
            
            # Generate guest data
            vip_status = random.choices(VIP_STATUSES, weights=VIP_WEIGHTS)[0]
            nationality = random.choices(NATIONALITIES, weights=NATIONALITY_WEIGHTS)[0]
            
            # Generate registration date between 1 and 5 years ago
            registration_date = fake.date_between(start_date="-5y", end_date="-1d")
            
            # Generate photo
            photo_filename = self.generate_guest_photo(guest_id, gender)
            
            guest = {
                "guest_id": guest_id,
                "casino_guest_id": f"{CASINO_GUEST_ID_PREFIX}{guest_id}",
                "first_name": first_name,
                "last_name": last_name,
                "email": fake.email(),
                "phone": fake.phone_number(),
                "address": fake.address(),
                "city": fake.city(),
                "postal_code": fake.postcode(),
                "country": fake.country(),
                "date_of_birth": dob.strftime("%Y-%m-%d"),
                "age": age,
                "gender": gender,
                "nationality": nationality,
                "id_type": random.choice(["PASSPORT", "ID_CARD", "DRIVING_LICENSE"]),
                "id_number": fake.bothify(text="?#########"),
                "vip_status": vip_status,
                "registration_date": registration_date.strftime("%Y-%m-%d"),
                "notes": fake.text(max_nb_chars=200) if random.random() < 0.3 else "",
                "photo_filename": photo_filename,
                "is_active": random.random() < 0.95  # 95% of guests are active
            }
            
            self.guests.append(guest)
            
            # Generate activities for this guest
            self.generate_guest_activities(guest)
    
    def generate_guest_photo(self, guest_id, gender):
        """Generate a photo for a guest"""
        try:
            # Use randomuser.me API to get a random photo
            gender_param = "male" if gender == "male" else "female"
            response = requests.get(f"https://randomuser.me/api/?gender={gender_param}&nat=ch,de,fr,it")
            if response.status_code == 200:
                data = response.json()
                photo_url = data["results"][0]["picture"]["large"]
                photo_response = requests.get(photo_url)
                if photo_response.status_code == 200:
                    # Save the photo
                    filename = f"guest_{guest_id}.jpg"
                    filepath = self.output_dir / "images" / "guests" / filename
                    with open(filepath, "wb") as f:
                        f.write(photo_response.content)
                    return filename
            
            # If API call fails, generate a placeholder image
            return self.generate_placeholder_image(guest_id, "guest")
        except Exception as e:
            logger.warning(f"Error generating guest photo: {e}")
            return self.generate_placeholder_image(guest_id, "guest")
    
    def generate_placeholder_image(self, entity_id, entity_type):
        """Generate a placeholder image with text"""
        try:
            # Create a blank image
            img = Image.new('RGB', (200, 200), color=(73, 109, 137))
            
            # Save the image
            filename = f"{entity_type}_{entity_id}.jpg"
            filepath = self.output_dir / "images" / f"{entity_type}s" / filename
            img.save(filepath)
            return filename
        except Exception as e:
            logger.warning(f"Error generating placeholder image: {e}")
            return None
    
    def generate_guest_activities(self, guest):
        """Generate activities for a guest"""
        # Determine number of visits (sessions) based on VIP status and registration date
        registration_date = datetime.datetime.strptime(guest["registration_date"], "%Y-%m-%d").date()
        days_registered = (datetime.date.today() - registration_date).days
        
        # Calculate base number of visits based on days registered
        base_visits = max(1, int(days_registered / 30))  # At least 1 visit per month on average
        
        # Adjust based on VIP status
        vip_multiplier = {
            "STANDARD": 0.5,
            "SILVER": 1.0,
            "GOLD": 2.0,
            "PLATINUM": 4.0
        }
        
        num_visits = int(base_visits * vip_multiplier[guest["vip_status"]] * random.uniform(0.5, 1.5))
        
        # Cap at a reasonable number
        num_visits = min(num_visits, 200)
        
        # Generate sessions
        visit_dates = sorted([fake.date_between(start_date=registration_date, end_date="today") 
                             for _ in range(num_visits)])
        
        for visit_date in visit_dates:
            self.generate_gaming_session(guest, visit_date)
    
    def generate_gaming_session(self, guest, visit_date):
        """Generate a gaming session for a guest"""
        session_id = self.next_session_id
        self.next_session_id += 1
        
        # Generate session start time (casino opens at 10:00)
        start_hour = random.randint(10, 23)
        start_minute = random.randint(0, 59)
        start_time = datetime.time(start_hour, start_minute)
        start_datetime = datetime.datetime.combine(visit_date, start_time)
        
        # Generate session duration (between 1 and 8 hours)
        duration_hours = random.uniform(1, 8)
        end_datetime = start_datetime + datetime.timedelta(hours=duration_hours)
        
        # Ensure end time is not after 6:00 AM the next day (casino closing time)
        max_end_datetime = datetime.datetime.combine(visit_date + datetime.timedelta(days=1), datetime.time(6, 0))
        end_datetime = min(end_datetime, max_end_datetime)
        
        # Recalculate actual duration
        duration_hours = (end_datetime - start_datetime).total_seconds() / 3600
        
        session = {
            "session_id": session_id,
            "guest_id": guest["guest_id"],
            "start_time": start_datetime.strftime("%Y-%m-%d %H:%M:%S"),
            "end_time": end_datetime.strftime("%Y-%m-%d %H:%M:%S"),
            "duration_hours": round(duration_hours, 2),
            "status": "COMPLETED"
        }
        
        self.gaming_sessions.append(session)
        
        # Generate activities during this session
        self.generate_session_activities(guest, session)
    
    def generate_session_activities(self, guest, session):
        """Generate activities during a gaming session"""
        # Determine guest's budget for this session based on VIP status
        base_budget = random.uniform(200, 1000)
        vip_multiplier = {
            "STANDARD": 1,
            "SILVER": 2,
            "GOLD": 5,
            "PLATINUM": 10
        }
        budget = base_budget * vip_multiplier[guest["vip_status"]] * random.uniform(0.8, 1.2)
        
        # Initial buy-in (50-100% of budget)
        initial_buy_in = budget * random.uniform(0.5, 1.0)
        self.generate_financial_transaction(
            guest["guest_id"], 
            session["session_id"], 
            "BUY_IN", 
            initial_buy_in, 
            session["start_time"]
        )
        
        # Determine number of activities during session
        session_duration = float(session["duration_hours"])
        num_activities = int(session_duration * random.uniform(1, 3))
        
        # Generate timeline of activities
        start_time = datetime.datetime.strptime(session["start_time"], "%Y-%m-%d %H:%M:%S")
        end_time = datetime.datetime.strptime(session["end_time"], "%Y-%m-%d %H:%M:%S")
        
        activity_times = sorted([start_time + (end_time - start_time) * random.random() 
                                for _ in range(num_activities)])
        
        # Current balance starts with initial buy-in
        current_balance = initial_buy_in
        
        # Generate activities
        for i, activity_time in enumerate(activity_times):
            activity_type = random.choices(
                ["game", "consumption", "financial"],
                weights=[0.6, 0.3, 0.1]
            )[0]
            
            if activity_type == "game":
                # Gaming activity (slot or table)
                game_type = random.choices(
                    ["slot", "table"],
                    weights=[0.7, 0.3]
                )[0]
                
                if game_type == "slot":
                    # Slot machine activity
                    slot = random.choice(self.slot_machines)
                    bet_amount = random.uniform(1, min(50, current_balance))
                    
                    # Determine outcome (win or lose)
                    win_probability = 0.4  # 40% chance to win
                    win = random.random() < win_probability
                    
                    if win:
                        win_multiplier = random.choices(
                            [1.5, 2, 3, 5, 10, 50, 100],
                            weights=[0.5, 0.25, 0.15, 0.05, 0.03, 0.015, 0.005]
                        )[0]
                        win_amount = bet_amount * win_multiplier
                        current_balance += win_amount - bet_amount
                        
                        # Check if this is a jackpot or hand pay
                        if win_multiplier >= 50 or win_amount >= 1200:
                            self.generate_jackpot_hand_pay(
                                guest["guest_id"],
                                session["session_id"],
                                slot["slot_id"],
                                None,
                                win_amount,
                                activity_time.strftime("%Y-%m-%d %H:%M:%S")
                            )
                    else:
                        # Loss
                        current_balance -= bet_amount
                
                else:
                    # Table game activity
                    table = random.choice(self.table_games)
                    min_bet = table["min_bet"]
                    max_bet = min(table["max_bet"], current_balance)
                    
                    if max_bet < min_bet:
                        # Not enough balance for this table
                        continue
                    
                    bet_amount = random.uniform(min_bet, max_bet)
                    
                    # Determine outcome (win or lose)
                    win_probability = 0.48  # Slightly below 50% for house edge
                    win = random.random() < win_probability
                    
                    if win:
                        win_multiplier = random.uniform(1.5, 2.5)
                        win_amount = bet_amount * win_multiplier
                        current_balance += win_amount - bet_amount
                    else:
                        # Loss
                        current_balance -= bet_amount
            
            elif activity_type == "consumption":
                # Consumption activity (drink, food, cigarette)
                consumption_type = random.choices(
                    ["drink", "food", "cigarette"],
                    weights=[0.5, 0.3, 0.2]
                )[0]
                
                if consumption_type in ["drink", "food"]:
                    # Find matching consumption items
                    matching_items = [item for item in self.consumption_items 
                                     if item["item_type"] == consumption_type.upper()]
                    
                    if matching_items:
                        item = random.choice(matching_items)
                        quantity = random.randint(1, 3)
                        
                        self.generate_player_consumption(
                            guest["guest_id"],
                            session["session_id"],
                            item["item_id"],
                            quantity,
                            activity_time.strftime("%Y-%m-%d %H:%M:%S")
                        )
                
                elif consumption_type == "cigarette":
                    # Find cigarette inventory items
                    if self.cigarette_inventory:
                        inventory_item = random.choice(self.cigarette_inventory)
                        quantity = random.randint(1, 2)  # 1 or 2 packs
                        
                        # Record cigarette transaction
                        self.generate_cigarette_transaction(
                            inventory_item["inventory_id"],
                            guest["guest_id"],
                            session["session_id"],
                            quantity,
                            activity_time.strftime("%Y-%m-%d %H:%M:%S")
                        )
            
            elif activity_type == "financial":
                # Financial transaction (additional buy-in or cash-out)
                if current_balance < 100 and random.random() < 0.8:
                    # Additional buy-in if balance is low
                    additional_amount = random.uniform(100, 500) * vip_multiplier[guest["vip_status"]]
                    self.generate_financial_transaction(
                        guest["guest_id"],
                        session["session_id"],
                        "BUY_IN",
                        additional_amount,
                        activity_time.strftime("%Y-%m-%d %H:%M:%S")
                    )
                    current_balance += additional_amount
                elif current_balance > 1000 and random.random() < 0.3:
                    # Partial cash-out if balance is high
                    cash_out_amount = current_balance * random.uniform(0.3, 0.7)
                    self.generate_financial_transaction(
                        guest["guest_id"],
                        session["session_id"],
                        "CASH_OUT",
                        cash_out_amount,
                        activity_time.strftime("%Y-%m-%d %H:%M:%S")
                    )
                    current_balance -= cash_out_amount
        
        # Final cash-out at the end of session
        if current_balance > 10:
            self.generate_financial_transaction(
                guest["guest_id"],
                session["session_id"],
                "CASH_OUT",
                current_balance,
                session["end_time"]
            )
    
    def generate_financial_transaction(self, guest_id, session_id, transaction_type, amount, timestamp):
        """Generate a financial transaction"""
        transaction_id = self.next_transaction_id
        self.next_transaction_id += 1
        
        # Determine payment method based on transaction type
        if transaction_type in ["BUY_IN", "CHIPS_PURCHASE"]:
            payment_method = random.choices(
                ["CASH", "CREDIT_CARD", "DEBIT_CARD", "BANK_TRANSFER"],
                weights=[50, 30, 15, 5]
            )[0]
        elif transaction_type in ["CASH_OUT", "CHIPS_REDEMPTION"]:
            payment_method = "CASH"
        elif transaction_type in ["TICKET_IN", "TICKET_OUT"]:
            payment_method = "TICKET"
        else:
            payment_method = random.choices(
                PAYMENT_METHODS,
                weights=PAYMENT_METHOD_WEIGHTS
            )[0]
        
        # Assign a random employee
        employee_id = random.choice(self.employees)["employee_id"] if self.employees else None
        
        transaction = {
            "transaction_id": transaction_id,
            "guest_id": guest_id,
            "session_id": session_id,
            "transaction_type": transaction_type,
            "amount": round(amount, 2),
            "payment_method": payment_method,
            "timestamp": timestamp,
            "employee_id": employee_id,
            "notes": ""
        }
        
        self.financial_transactions.append(transaction)
        return transaction
    
    def generate_jackpot_hand_pay(self, guest_id, session_id, slot_id, table_id, amount, timestamp):
        """Generate a jackpot or hand pay record"""
        jackpot_id = self.next_jackpot_id
        self.next_jackpot_id += 1
        
        # Determine if it's a jackpot or hand pay
        is_jackpot = amount >= 5000 or random.random() < 0.7
        
        # Assign a random employee
        employee_id = random.choice(self.employees)["employee_id"] if self.employees else None
        
        # Generate a photo for big wins
        photo_filename = None
        if amount >= 10000:
            photo_filename = self.generate_jackpot_photo(jackpot_id)
        
        jackpot = {
            "jackpot_id": jackpot_id,
            "guest_id": guest_id,
            "session_id": session_id,
            "slot_id": slot_id,
            "table_id": table_id,
            "amount": round(amount, 2),
            "is_jackpot": is_jackpot,
            "timestamp": timestamp,
            "employee_id": employee_id,
            "photo_filename": photo_filename,
            "notes": f"{'Jackpot' if is_jackpot else 'Hand Pay'} win on {'slot machine' if slot_id else 'table'} #{slot_id or table_id}"
        }
        
        self.jackpots_hand_pays.append(jackpot)
        
        # Also create a financial transaction for this
        self.generate_financial_transaction(
            guest_id,
            session_id,
            "JACKPOT" if is_jackpot else "HAND_PAY",
            amount,
            timestamp
        )
        
        return jackpot
    
    def generate_jackpot_photo(self, jackpot_id):
        """Generate a photo for a jackpot win"""
        try:
            # Create a placeholder image for jackpot
            return self.generate_placeholder_image(jackpot_id, "jackpot")
        except Exception as e:
            logger.warning(f"Error generating jackpot photo: {e}")
            return None
    
    def generate_player_consumption(self, guest_id, session_id, item_id, quantity, timestamp):
        """Generate a player consumption record"""
        consumption_id = self.next_player_consumption_id
        self.next_player_consumption_id += 1
        
        # Assign a random employee
        employee_id = random.choice(self.employees)["employee_id"] if self.employees else None
        
        consumption = {
            "consumption_id": consumption_id,
            "guest_id": guest_id,
            "session_id": session_id,
            "item_id": item_id,
            "quantity": quantity,
            "timestamp": timestamp,
            "employee_id": employee_id,
            "notes": ""
        }
        
        self.player_consumptions.append(consumption)
        return consumption
    
    def generate_cigarette_transaction(self, inventory_id, guest_id, session_id, quantity, timestamp):
        """Generate a cigarette transaction record"""
        transaction_id = self.next_cigarette_transaction_id
        self.next_cigarette_transaction_id += 1
        
        # Assign a random employee
        employee_id = random.choice(self.employees)["employee_id"] if self.employees else None
        
        transaction = {
            "transaction_id": transaction_id,
            "inventory_id": inventory_id,
            "transaction_type": "DISPENSED",
            "quantity": quantity,
            "guest_id": guest_id,
            "session_id": session_id,
            "timestamp": timestamp,
            "employee_id": employee_id,
            "notes": ""
        }
        
        self.cigarette_transactions.append(transaction)
        
        # Update inventory quantity
        for item in self.cigarette_inventory:
            if item["inventory_id"] == inventory_id:
                item["quantity"] = max(0, item["quantity"] - quantity)
                break
        
        return transaction
    
    def generate_employees(self):
        """Generate employee data"""
        logger.info(f"Generating {self.num_employees} employees")
        
        departments = ["Management", "Reception", "Gaming", "Bar", "Restaurant", "Security", "IT", "Maintenance", "Finance", "HR"]
        positions = {
            "Management": ["CEO", "General Manager", "Operations Manager", "Floor Manager"],
            "Reception": ["Receptionist", "Guest Relations", "VIP Host"],
            "Gaming": ["Dealer", "Croupier", "Pit Boss", "Slot Attendant", "Gaming Supervisor"],
            "Bar": ["Bartender", "Bar Manager", "Waiter", "Waitress"],
            "Restaurant": ["Chef", "Sous Chef", "Server", "Host", "Hostess"],
            "Security": ["Security Officer", "Security Manager", "Surveillance Operator"],
            "IT": ["IT Specialist", "System Administrator", "Network Engineer"],
            "Maintenance": ["Maintenance Technician", "Cleaning Staff", "Facility Manager"],
            "Finance": ["Accountant", "Cashier", "Financial Analyst"],
            "HR": ["HR Manager", "Recruiter", "Training Coordinator"]
        }
        
        for _ in tqdm(range(self.num_employees), desc="Generating employees"):
            employee_id = self.next_employee_id
            self.next_employee_id += 1
            
            # Basic employee info
            gender = random.choice(["male", "female"])
            first_name = fake.first_name_male() if gender == "male" else fake.first_name_female()
            last_name = fake.last_name()
            
            # Generate a date of birth between 20 and 65 years ago
            dob = fake.date_of_birth(minimum_age=20, maximum_age=65)
            
            # Calculate age
            today = datetime.date.today()
            age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
            
            # Generate department and position
            department = random.choice(departments)
            position = random.choice(positions[department])
            
            # Generate hire date between 1 and 10 years ago
            hire_date = fake.date_between(start_date="-10y", end_date="-1d")
            
            # Generate photo
            photo_filename = self.generate_employee_photo(employee_id, gender)
            
            employee = {
                "employee_id": employee_id,
                "first_name": first_name,
                "last_name": last_name,
                "email": f"{first_name.lower()}.{last_name.lower()}@alpinroyal.com",
                "phone": fake.phone_number(),
                "address": fake.address(),
                "date_of_birth": dob.strftime("%Y-%m-%d"),
                "age": age,
                "gender": gender,
                "department": department,
                "position": position,
                "hire_date": hire_date.strftime("%Y-%m-%d"),
                "photo_filename": photo_filename,
                "is_active": random.random() < 0.95  # 95% of employees are active
            }
            
            self.employees.append(employee)
    
    def generate_employee_photo(self, employee_id, gender):
        """Generate a photo for an employee"""
        try:
            # Use randomuser.me API to get a random photo
            gender_param = "male" if gender == "male" else "female"
            response = requests.get(f"https://randomuser.me/api/?gender={gender_param}")
            if response.status_code == 200:
                data = response.json()
                photo_url = data["results"][0]["picture"]["large"]
                photo_response = requests.get(photo_url)
                if photo_response.status_code == 200:
                    # Save the photo
                    filename = f"employee_{employee_id}.jpg"
                    filepath = self.output_dir / "images" / "employees" / filename
                    with open(filepath, "wb") as f:
                        f.write(photo_response.content)
                    return filename
            
            # If API call fails, generate a placeholder image
            return self.generate_placeholder_image(employee_id, "employee")
        except Exception as e:
            logger.warning(f"Error generating employee photo: {e}")
            return self.generate_placeholder_image(employee_id, "employee")
    
    def generate_slot_machines(self):
        """Generate slot machine data"""
        logger.info(f"Generating {self.num_slots} slot machines")
        
        for i in range(1, self.num_slots + 1):
            slot_id = self.next_slot_id
            self.next_slot_id += 1
            
            machine_type = random.choice(SLOT_MACHINE_TYPES)
            manufacturer = random.choice(SLOT_MACHINE_MANUFACTURERS)
            
            # Generate model name
            model = f"{manufacturer} {fake.word().capitalize()} {random.choice(['Pro', 'Plus', 'Elite', 'Max', 'Ultra', ''])}"
            
            # Generate denomination
            denomination = random.choice([0.01, 0.05, 0.10, 0.25, 0.50, 1.00, 5.00])
            
            # Generate location
            location = f"Floor {random.randint(1, 3)}, Section {random.choice(['A', 'B', 'C', 'D'])}, Position {random.randint(1, 20)}"
            
            slot = {
                "slot_id": slot_id,
                "machine_number": f"SM-{slot_id:04d}",
                "machine_type": machine_type,
                "manufacturer": manufacturer,
                "model": model,
                "denomination": denomination,
                "min_bet": denomination,
                "max_bet": denomination * random.choice([3, 5, 10, 20, 30]),
                "payback_percentage": round(random.uniform(0.92, 0.98), 4),
                "location": location,
                "installation_date": fake.date_between(start_date="-5y", end_date="-1m").strftime("%Y-%m-%d"),
                "last_maintenance": fake.date_between(start_date="-3m", end_date="today").strftime("%Y-%m-%d"),
                "status": random.choices(["ACTIVE", "MAINTENANCE", "OUT_OF_ORDER"], weights=[0.95, 0.03, 0.02])[0]
            }
            
            self.slot_machines.append(slot)
    
    def generate_table_games(self):
        """Generate table game data"""
        logger.info(f"Generating table games ({self.num_roulette} roulette, {self.num_blackjack} blackjack, {self.num_uth} UTH, {self.num_poker} poker)")
        
        # Generate roulette tables
        for i in range(1, self.num_roulette + 1):
            table_id = self.next_table_id
            self.next_table_id += 1
            
            game_type = random.choice(TABLE_GAME_TYPES["roulette"])
            min_bet_index = random.randint(0, len(MIN_BETS["roulette"]) - 1)
            
            table = {
                "table_id": table_id,
                "table_number": f"R{i}",
                "game_type": game_type,
                "category": "ROULETTE",
                "min_bet": MIN_BETS["roulette"][min_bet_index],
                "max_bet": MAX_BETS["roulette"][min_bet_index],
                "location": f"Floor {random.randint(1, 2)}, Roulette Section",
                "status": random.choices(["ACTIVE", "CLOSED"], weights=[0.9, 0.1])[0]
            }
            
            self.table_games.append(table)
        
        # Generate blackjack tables
        for i in range(1, self.num_blackjack + 1):
            table_id = self.next_table_id
            self.next_table_id += 1
            
            game_type = random.choice(TABLE_GAME_TYPES["blackjack"])
            min_bet_index = random.randint(0, len(MIN_BETS["blackjack"]) - 1)
            
            table = {
                "table_id": table_id,
                "table_number": f"BJ{i}",
                "game_type": game_type,
                "category": "BLACKJACK",
                "min_bet": MIN_BETS["blackjack"][min_bet_index],
                "max_bet": MAX_BETS["blackjack"][min_bet_index],
                "location": f"Floor {random.randint(1, 2)}, Blackjack Section",
                "status": random.choices(["ACTIVE", "CLOSED"], weights=[0.9, 0.1])[0]
            }
            
            self.table_games.append(table)
        
        # Generate Ultimate Texas Hold'em tables
        for i in range(1, self.num_uth + 1):
            table_id = self.next_table_id
            self.next_table_id += 1
            
            game_type = random.choice(TABLE_GAME_TYPES["poker_uth"])
            min_bet_index = random.randint(0, len(MIN_BETS["poker_uth"]) - 1)
            
            table = {
                "table_id": table_id,
                "table_number": f"UTH{i}",
                "game_type": game_type,
                "category": "POKER_UTH",
                "min_bet": MIN_BETS["poker_uth"][min_bet_index],
                "max_bet": MAX_BETS["poker_uth"][min_bet_index],
                "location": f"Floor {random.randint(1, 2)}, Poker Section",
                "status": random.choices(["ACTIVE", "CLOSED"], weights=[0.9, 0.1])[0]
            }
            
            self.table_games.append(table)
        
        # Generate cash game poker tables
        for i in range(1, self.num_poker + 1):
            table_id = self.next_table_id
            self.next_table_id += 1
            
            game_type = random.choice(TABLE_GAME_TYPES["poker_cash"])
            min_bet_index = random.randint(0, len(MIN_BETS["poker_cash"]) - 1)
            
            table = {
                "table_id": table_id,
                "table_number": f"P{i}",
                "game_type": game_type,
                "category": "POKER_CASH",
                "min_bet": MIN_BETS["poker_cash"][min_bet_index],
                "max_bet": "No Limit",
                "location": f"Floor {random.randint(1, 2)}, Poker Room",
                "status": random.choices(["ACTIVE", "CLOSED"], weights=[0.9, 0.1])[0]
            }
            
            self.table_games.append(table)
    
    def generate_consumption_items(self):
        """Generate consumption items data"""
        logger.info("Generating consumption items")
        
        # Generate drink items
        for drink_type, names in DRINK_NAMES.items():
            for name in names:
                item_id = self.next_consumption_item_id
                self.next_consumption_item_id += 1
                
                price = 0
                if drink_type == "Beer":
                    price = random.uniform(6, 10)
                elif drink_type == "Wine":
                    price = random.uniform(8, 15)
                elif drink_type == "Cocktail":
                    price = random.uniform(12, 20)
                elif drink_type == "Spirit":
                    price = random.uniform(10, 25)
                elif drink_type == "Soft Drink":
                    price = random.uniform(4, 7)
                elif drink_type == "Coffee":
                    price = random.uniform(4, 8)
                elif drink_type == "Tea":
                    price = random.uniform(4, 7)
                elif drink_type == "Water":
                    price = random.uniform(3, 6)
                
                item = {
                    "item_id": item_id,
                    "item_name": name,
                    "item_type": "DRINK",
                    "category": drink_type.upper(),
                    "price": round(price, 2),
                    "is_complimentary": False,
                    "is_active": True
                }
                
                self.consumption_items.append(item)
        
        # Generate food items
        for food_type, names in FOOD_NAMES.items():
            for name in names:
                item_id = self.next_consumption_item_id
                self.next_consumption_item_id += 1
                
                price = 0
                if food_type == "Snack":
                    price = random.uniform(5, 12)
                elif food_type == "Appetizer":
                    price = random.uniform(10, 18)
                elif food_type == "Main Course":
                    price = random.uniform(18, 35)
                elif food_type == "Dessert":
                    price = random.uniform(8, 15)
                
                item = {
                    "item_id": item_id,
                    "item_name": name,
                    "item_type": "FOOD",
                    "category": food_type.upper(),
                    "price": round(price, 2),
                    "is_complimentary": False,
                    "is_active": True
                }
                
                self.consumption_items.append(item)
        
        # Generate cigarette items for consumption tracking
        for brand in CIGARETTE_BRANDS:
            for variant in CIGARETTE_VARIANTS:
                if variant:  # Skip empty variant for some brands
                    item_id = self.next_consumption_item_id
                    self.next_consumption_item_id += 1
                    
                    price = random.uniform(9, 12)
                    
                    item = {
                        "item_id": item_id,
                        "item_name": f"{brand} {variant}".strip(),
                        "item_type": "CIGARETTE",
                        "category": "CIGARETTE",
                        "price": round(price, 2),
                        "is_complimentary": False,
                        "is_active": True
                    }
                    
                    self.consumption_items.append(item)
    
    def generate_cigarette_inventory(self):
        """Generate cigarette inventory data"""
        logger.info("Generating cigarette inventory")
        
        for brand in CIGARETTE_BRANDS:
            for variant in CIGARETTE_VARIANTS:
                if variant or random.random() < 0.3:  # Skip some empty variants
                    inventory_id = self.next_cigarette_inventory_id
                    self.next_cigarette_inventory_id += 1
                    
                    # Generate initial quantity
                    quantity = random.randint(10, 100)
                    
                    # Generate reorder level
                    reorder_level = random.randint(5, 20)
                    
                    inventory = {
                        "inventory_id": inventory_id,
                        "brand": brand,
                        "variant": variant,
                        "quantity": quantity,
                        "reorder_level": reorder_level,
                        "last_restock_date": fake.date_between(start_date="-1m", end_date="today").strftime("%Y-%m-%d"),
                        "notes": ""
                    }
                    
                    self.cigarette_inventory.append(inventory)
    
    def save_all_data(self):
        """Save all generated data to JSON files"""
        logger.info("Saving all data to JSON files")
        
        # Save guests
        self.save_json_file("guests.json", self.guests)
        
        # Save employees
        self.save_json_file("employees.json", self.employees)
        
        # Save slot machines
        self.save_json_file("slot_machines.json", self.slot_machines)
        
        # Save table games
        self.save_json_file("table_games.json", self.table_games)
        
        # Save gaming sessions
        self.save_json_file("gaming_sessions.json", self.gaming_sessions)
        
        # Save financial transactions
        self.save_json_file("financial_transactions.json", self.financial_transactions)
        
        # Save jackpots and hand pays
        self.save_json_file("jackpots_hand_pays.json", self.jackpots_hand_pays)
        
        # Save consumption items
        self.save_json_file("consumption_items.json", self.consumption_items)
        
        # Save player consumptions
        self.save_json_file("player_consumptions.json", self.player_consumptions)
        
        # Save cigarette inventory
        self.save_json_file("cigarette_inventory.json", self.cigarette_inventory)
        
        # Save cigarette transactions
        self.save_json_file("cigarette_transactions.json", self.cigarette_transactions)
    
    def save_json_file(self, filename, data):
        """Save data to a JSON file"""
        filepath = self.output_dir / filename
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.info(f"Saved {len(data)} records to {filepath}")

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Generate test data for Alpin Royal Casino Management System")
    parser.add_argument("--output-dir", type=str, default="test_data", help="Output directory for generated data")
    parser.add_argument("--num-guests", type=int, default=1000, help="Number of guests to generate")
    parser.add_argument("--num-employees", type=int, default=150, help="Number of employees to generate")
    parser.add_argument("--num-slots", type=int, default=300, help="Number of slot machines to generate")
    parser.add_argument("--num-roulette", type=int, default=6, help="Number of roulette tables to generate")
    parser.add_argument("--num-blackjack", type=int, default=4, help="Number of blackjack tables to generate")
    parser.add_argument("--num-uth", type=int, default=2, help="Number of Ultimate Texas Hold'em tables to generate")
    parser.add_argument("--num-poker", type=int, default=4, help="Number of cash game poker tables to generate")
    
    args = parser.parse_args()
    
    generator = TestDataGenerator(
        output_dir=args.output_dir,
        num_guests=args.num_guests,
        num_employees=args.num_employees,
        num_slots=args.num_slots,
        num_roulette=args.num_roulette,
        num_blackjack=args.num_blackjack,
        num_uth=args.num_uth,
        num_poker=args.num_poker
    )
    
    generator.generate_all()

if __name__ == "__main__":
    main()
