"""
Alpin Royal Casino Management System - Database Initialization and Test Data Loader
This script initializes the database and loads test data.
"""

import os
import sys
import json
import argparse
import logging
import asyncio
from pathlib import Path
from tqdm import tqdm
import datetime
import shutil

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import database utilities
from base_layer.utils.database import init_db, get_db_session
from base_layer.config.settings import get_settings

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("db_init_and_load.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("db_init_and_load")

class DatabaseInitializer:
    """Initialize database and load test data"""
    
    def __init__(self, test_data_dir, images_dir=None):
        """
        Initialize the database initializer.
        
        Args:
            test_data_dir: Directory containing test data JSON files
            images_dir: Directory to store images (if None, will use test_data_dir/images)
        """
        self.test_data_dir = Path(test_data_dir)
        self.images_dir = Path(images_dir) if images_dir else self.test_data_dir / "images"
        
        # Ensure directories exist
        if not self.test_data_dir.exists():
            raise ValueError(f"Test data directory {self.test_data_dir} does not exist")
        
        # Create images directory if it doesn't exist
        os.makedirs(self.images_dir, exist_ok=True)
        
        # Initialize settings
        self.settings = get_settings()
    
    async def init_database(self):
        """Initialize the database schema"""
        logger.info("Initializing database schema")
        
        try:
            await init_db()
            logger.info("Database schema initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing database schema: {e}")
            raise
    
    async def load_all_data(self):
        """Load all test data into the database"""
        logger.info("Loading all test data into the database")
        
        # Order matters due to foreign key constraints
        await self.load_employees()
        await self.load_slot_machines()
        await self.load_table_games()
        await self.load_consumption_items()
        await self.load_cigarette_inventory()
        await self.load_guests()
        await self.load_gaming_sessions()
        await self.load_financial_transactions()
        await self.load_jackpots_hand_pays()
        await self.load_player_consumptions()
        await self.load_cigarette_transactions()
        
        logger.info("All test data loaded successfully")
    
    async def load_employees(self):
        """Load employee data"""
        logger.info("Loading employee data")
        
        try:
            # Load JSON data
            employees_file = self.test_data_dir / "employees.json"
            if not employees_file.exists():
                logger.warning(f"Employees file {employees_file} does not exist, skipping")
                return
            
            with open(employees_file, "r", encoding="utf-8") as f:
                employees = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.player import Employee
                
                # Insert employees
                for employee_data in tqdm(employees, desc="Loading employees"):
                    # Copy image if it exists
                    if employee_data.get("photo_filename"):
                        src_path = self.test_data_dir / "images" / "employees" / employee_data["photo_filename"]
                        if src_path.exists():
                            dst_path = self.images_dir / "employees" / employee_data["photo_filename"]
                            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                            shutil.copy(src_path, dst_path)
                    
                    # Convert date strings to datetime objects
                    if "date_of_birth" in employee_data:
                        employee_data["date_of_birth"] = datetime.datetime.strptime(
                            employee_data["date_of_birth"], "%Y-%m-%d"
                        ).date()
                    
                    if "hire_date" in employee_data:
                        employee_data["hire_date"] = datetime.datetime.strptime(
                            employee_data["hire_date"], "%Y-%m-%d"
                        ).date()
                    
                    # Create employee object
                    employee = Employee(**employee_data)
                    session.add(employee)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(employees)} employees")
        except Exception as e:
            logger.error(f"Error loading employee data: {e}")
            raise
    
    async def load_slot_machines(self):
        """Load slot machine data"""
        logger.info("Loading slot machine data")
        
        try:
            # Load JSON data
            slots_file = self.test_data_dir / "slot_machines.json"
            if not slots_file.exists():
                logger.warning(f"Slot machines file {slots_file} does not exist, skipping")
                return
            
            with open(slots_file, "r", encoding="utf-8") as f:
                slots = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.gaming_session import SlotMachine
                
                # Insert slot machines
                for slot_data in tqdm(slots, desc="Loading slot machines"):
                    # Convert date strings to datetime objects
                    if "installation_date" in slot_data:
                        slot_data["installation_date"] = datetime.datetime.strptime(
                            slot_data["installation_date"], "%Y-%m-%d"
                        ).date()
                    
                    if "last_maintenance" in slot_data:
                        slot_data["last_maintenance"] = datetime.datetime.strptime(
                            slot_data["last_maintenance"], "%Y-%m-%d"
                        ).date()
                    
                    # Create slot machine object
                    slot = SlotMachine(**slot_data)
                    session.add(slot)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(slots)} slot machines")
        except Exception as e:
            logger.error(f"Error loading slot machine data: {e}")
            raise
    
    async def load_table_games(self):
        """Load table game data"""
        logger.info("Loading table game data")
        
        try:
            # Load JSON data
            tables_file = self.test_data_dir / "table_games.json"
            if not tables_file.exists():
                logger.warning(f"Table games file {tables_file} does not exist, skipping")
                return
            
            with open(tables_file, "r", encoding="utf-8") as f:
                tables = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.gaming_session import TableGame
                
                # Insert table games
                for table_data in tqdm(tables, desc="Loading table games"):
                    # Handle "No Limit" max bet
                    if table_data.get("max_bet") == "No Limit":
                        table_data["max_bet"] = 1000000  # Use a large number to represent no limit
                    
                    # Create table game object
                    table = TableGame(**table_data)
                    session.add(table)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(tables)} table games")
        except Exception as e:
            logger.error(f"Error loading table game data: {e}")
            raise
    
    async def load_consumption_items(self):
        """Load consumption item data"""
        logger.info("Loading consumption item data")
        
        try:
            # Load JSON data
            items_file = self.test_data_dir / "consumption_items.json"
            if not items_file.exists():
                logger.warning(f"Consumption items file {items_file} does not exist, skipping")
                return
            
            with open(items_file, "r", encoding="utf-8") as f:
                items = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.consumption import ConsumptionItem
                
                # Insert consumption items
                for item_data in tqdm(items, desc="Loading consumption items"):
                    # Create consumption item object
                    item = ConsumptionItem(**item_data)
                    session.add(item)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(items)} consumption items")
        except Exception as e:
            logger.error(f"Error loading consumption item data: {e}")
            raise
    
    async def load_cigarette_inventory(self):
        """Load cigarette inventory data"""
        logger.info("Loading cigarette inventory data")
        
        try:
            # Load JSON data
            inventory_file = self.test_data_dir / "cigarette_inventory.json"
            if not inventory_file.exists():
                logger.warning(f"Cigarette inventory file {inventory_file} does not exist, skipping")
                return
            
            with open(inventory_file, "r", encoding="utf-8") as f:
                inventory = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.consumption import CigaretteInventory
                
                # Insert cigarette inventory items
                for inventory_data in tqdm(inventory, desc="Loading cigarette inventory"):
                    # Convert date strings to datetime objects
                    if "last_restock_date" in inventory_data:
                        inventory_data["last_restock_date"] = datetime.datetime.strptime(
                            inventory_data["last_restock_date"], "%Y-%m-%d"
                        ).date()
                    
                    # Create cigarette inventory object
                    inventory_item = CigaretteInventory(**inventory_data)
                    session.add(inventory_item)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(inventory)} cigarette inventory items")
        except Exception as e:
            logger.error(f"Error loading cigarette inventory data: {e}")
            raise
    
    async def load_guests(self):
        """Load guest data"""
        logger.info("Loading guest data")
        
        try:
            # Load JSON data
            guests_file = self.test_data_dir / "guests.json"
            if not guests_file.exists():
                logger.warning(f"Guests file {guests_file} does not exist, skipping")
                return
            
            with open(guests_file, "r", encoding="utf-8") as f:
                guests = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.player import Player
                
                # Insert guests
                for guest_data in tqdm(guests, desc="Loading guests"):
                    # Copy image if it exists
                    if guest_data.get("photo_filename"):
                        src_path = self.test_data_dir / "images" / "guests" / guest_data["photo_filename"]
                        if src_path.exists():
                            dst_path = self.images_dir / "guests" / guest_data["photo_filename"]
                            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                            shutil.copy(src_path, dst_path)
                    
                    # Convert date strings to datetime objects
                    if "date_of_birth" in guest_data:
                        guest_data["date_of_birth"] = datetime.datetime.strptime(
                            guest_data["date_of_birth"], "%Y-%m-%d"
                        ).date()
                    
                    if "registration_date" in guest_data:
                        guest_data["registration_date"] = datetime.datetime.strptime(
                            guest_data["registration_date"], "%Y-%m-%d"
                        ).date()
                    
                    # Create guest object
                    guest = Player(**guest_data)
                    session.add(guest)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(guests)} guests")
        except Exception as e:
            logger.error(f"Error loading guest data: {e}")
            raise
    
    async def load_gaming_sessions(self):
        """Load gaming session data"""
        logger.info("Loading gaming session data")
        
        try:
            # Load JSON data
            sessions_file = self.test_data_dir / "gaming_sessions.json"
            if not sessions_file.exists():
                logger.warning(f"Gaming sessions file {sessions_file} does not exist, skipping")
                return
            
            with open(sessions_file, "r", encoding="utf-8") as f:
                sessions = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.gaming_session import GamingSession
                
                # Insert gaming sessions
                for session_data in tqdm(sessions, desc="Loading gaming sessions"):
                    # Convert datetime strings to datetime objects
                    if "start_time" in session_data:
                        session_data["start_time"] = datetime.datetime.strptime(
                            session_data["start_time"], "%Y-%m-%d %H:%M:%S"
                        )
                    
                    if "end_time" in session_data:
                        session_data["end_time"] = datetime.datetime.strptime(
                            session_data["end_time"], "%Y-%m-%d %H:%M:%S"
                        )
                    
                    # Create gaming session object
                    gaming_session = GamingSession(**session_data)
                    session.add(gaming_session)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(sessions)} gaming sessions")
        except Exception as e:
            logger.error(f"Error loading gaming session data: {e}")
            raise
    
    async def load_financial_transactions(self):
        """Load financial transaction data"""
        logger.info("Loading financial transaction data")
        
        try:
            # Load JSON data
            transactions_file = self.test_data_dir / "financial_transactions.json"
            if not transactions_file.exists():
                logger.warning(f"Financial transactions file {transactions_file} does not exist, skipping")
                return
            
            with open(transactions_file, "r", encoding="utf-8") as f:
                transactions = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.financial import FinancialTransaction
                
                # Insert financial transactions
                for transaction_data in tqdm(transactions, desc="Loading financial transactions"):
                    # Convert datetime strings to datetime objects
                    if "timestamp" in transaction_data:
                        transaction_data["timestamp"] = datetime.datetime.strptime(
                            transaction_data["timestamp"], "%Y-%m-%d %H:%M:%S"
                        )
                    
                    # Create financial transaction object
                    transaction = FinancialTransaction(**transaction_data)
                    session.add(transaction)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(transactions)} financial transactions")
        except Exception as e:
            logger.error(f"Error loading financial transaction data: {e}")
            raise
    
    async def load_jackpots_hand_pays(self):
        """Load jackpot and hand pay data"""
        logger.info("Loading jackpot and hand pay data")
        
        try:
            # Load JSON data
            jackpots_file = self.test_data_dir / "jackpots_hand_pays.json"
            if not jackpots_file.exists():
                logger.warning(f"Jackpots and hand pays file {jackpots_file} does not exist, skipping")
                return
            
            with open(jackpots_file, "r", encoding="utf-8") as f:
                jackpots = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.financial import JackpotHandPay
                
                # Insert jackpots and hand pays
                for jackpot_data in tqdm(jackpots, desc="Loading jackpots and hand pays"):
                    # Copy image if it exists
                    if jackpot_data.get("photo_filename"):
                        src_path = self.test_data_dir / "images" / "jackpots" / jackpot_data["photo_filename"]
                        if src_path.exists():
                            dst_path = self.images_dir / "jackpots" / jackpot_data["photo_filename"]
                            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                            shutil.copy(src_path, dst_path)
                    
                    # Convert datetime strings to datetime objects
                    if "timestamp" in jackpot_data:
                        jackpot_data["timestamp"] = datetime.datetime.strptime(
                            jackpot_data["timestamp"], "%Y-%m-%d %H:%M:%S"
                        )
                    
                    # Create jackpot/hand pay object
                    jackpot = JackpotHandPay(**jackpot_data)
                    session.add(jackpot)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(jackpots)} jackpots and hand pays")
        except Exception as e:
            logger.error(f"Error loading jackpot and hand pay data: {e}")
            raise
    
    async def load_player_consumptions(self):
        """Load player consumption data"""
        logger.info("Loading player consumption data")
        
        try:
            # Load JSON data
            consumptions_file = self.test_data_dir / "player_consumptions.json"
            if not consumptions_file.exists():
                logger.warning(f"Player consumptions file {consumptions_file} does not exist, skipping")
                return
            
            with open(consumptions_file, "r", encoding="utf-8") as f:
                consumptions = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.consumption import PlayerConsumption
                
                # Insert player consumptions
                for consumption_data in tqdm(consumptions, desc="Loading player consumptions"):
                    # Convert datetime strings to datetime objects
                    if "timestamp" in consumption_data:
                        consumption_data["timestamp"] = datetime.datetime.strptime(
                            consumption_data["timestamp"], "%Y-%m-%d %H:%M:%S"
                        )
                    
                    # Create player consumption object
                    consumption = PlayerConsumption(**consumption_data)
                    session.add(consumption)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(consumptions)} player consumptions")
        except Exception as e:
            logger.error(f"Error loading player consumption data: {e}")
            raise
    
    async def load_cigarette_transactions(self):
        """Load cigarette transaction data"""
        logger.info("Loading cigarette transaction data")
        
        try:
            # Load JSON data
            transactions_file = self.test_data_dir / "cigarette_transactions.json"
            if not transactions_file.exists():
                logger.warning(f"Cigarette transactions file {transactions_file} does not exist, skipping")
                return
            
            with open(transactions_file, "r", encoding="utf-8") as f:
                transactions = json.load(f)
            
            # Get database session
            async with get_db_session() as session:
                # Import here to avoid circular imports
                from modules.player_tracking.models.consumption import CigaretteTransaction
                
                # Insert cigarette transactions
                for transaction_data in tqdm(transactions, desc="Loading cigarette transactions"):
                    # Convert datetime strings to datetime objects
                    if "timestamp" in transaction_data:
                        transaction_data["timestamp"] = datetime.datetime.strptime(
                            transaction_data["timestamp"], "%Y-%m-%d %H:%M:%S"
                        )
                    
                    # Create cigarette transaction object
                    transaction = CigaretteTransaction(**transaction_data)
                    session.add(transaction)
                
                # Commit changes
                await session.commit()
            
            logger.info(f"Loaded {len(transactions)} cigarette transactions")
        except Exception as e:
            logger.error(f"Error loading cigarette transaction data: {e}")
            raise

async def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Initialize database and load test data for Alpin Royal Casino Management System")
    parser.add_argument("--test-data-dir", type=str, default="test_data", help="Directory containing test data JSON files")
    parser.add_argument("--images-dir", type=str, default=None, help="Directory to store images (if None, will use test_data_dir/images)")
    parser.add_argument("--skip-init", action="store_true", help="Skip database initialization")
    
    args = parser.parse_args()
    
    initializer = DatabaseInitializer(
        test_data_dir=args.test_data_dir,
        images_dir=args.images_dir
    )
    
    if not args.skip_init:
        await initializer.init_database()
    
    await initializer.load_all_data()

if __name__ == "__main__":
    asyncio.run(main())
