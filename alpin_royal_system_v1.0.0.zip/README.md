# Alpin Royal Casino Management System

A comprehensive casino management system with modular architecture, designed to automate and streamline casino operations with AI integration.

## System Overview

The Alpin Royal Casino Management System is designed as a modular application with a common base layer that provides core services and functionality. Individual modules plug into this base layer to provide specific business functions, including:

- Player Tracking
- Network Design and Planning
- Inventory Management
- Ticket System
- Cashdesk
- Reception
- Gaming Pit
- Slot Machines
- Employee Management
- Bar
- Hotel
- Restaurant

## Key Features

- Modular architecture for easy extension and maintenance
- Beautiful and intuitive UI for desktop and mobile
- Real-time data processing and visualization
- AI-powered analytics and automation
- Comprehensive reporting and dashboards
- Floor plan-based visualization for network and inventory management
- Integrated ticket system for technical support

## Technology Stack

- **Backend**: Python with FastAPI
- **Frontend**: React for web, React Native for mobile
- **Database**: PostgreSQL, MongoDB, Redis, Elasticsearch
- **AI Components**: TensorFlow/PyTorch, NLP capabilities
- **DevOps**: Docker, Kubernetes (optional)

## Getting Started

See the [Deployment and Maintenance Guide](/docs/deployment_maintenance_guide.md) for detailed setup instructions.

## Documentation

- [System Architecture](/docs/architecture/system_architecture.md)
- [Database Schema](/docs/architecture/database_schema.md)
- [Entity Relationship Diagram](/docs/architecture/entity_relationship_diagram.md)
- [User Guides](/docs/user_guides/)
- [API Documentation](/docs/api_docs/)
- [Deployment Guide](/docs/deployment/)
