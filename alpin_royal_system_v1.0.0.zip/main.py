"""
Alpin Royal Casino Management System - Main Entry Point
This is the main entry point for the application.
"""

import logging
from base_layer.core.app import app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
