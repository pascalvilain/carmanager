"""
Alpin Royal Casino Management System - Authentication Manager
This module handles user authentication and authorization.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel

from base_layer.config.settings import get_settings, Settings

logger = logging.getLogger(__name__)

# Authentication models
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None
    roles: List[str] = []

class User(BaseModel):
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    disabled: Optional[bool] = None
    roles: List[str] = []

class UserInDB(User):
    hashed_password: str

# Setup password context and OAuth2 scheme
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a password against a hash.
    
    Args:
        plain_password: Plain text password
        hashed_password: Hashed password
        
    Returns:
        bool: True if password matches hash
    """
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """
    Hash a password.
    
    Args:
        password: Plain text password
        
    Returns:
        str: Hashed password
    """
    return pwd_context.hash(password)

async def get_user(username: str) -> Optional[UserInDB]:
    """
    Get a user from the database.
    
    Args:
        username: Username to look up
        
    Returns:
        Optional[UserInDB]: User if found, None otherwise
    """
    # TODO: Replace with actual database lookup
    # This is a placeholder for demonstration
    fake_users_db = {
        "admin": {
            "username": "admin",
            "full_name": "Administrator",
            "email": "admin@alpinroyal.com",
            "hashed_password": get_password_hash("admin"),
            "disabled": False,
            "roles": ["admin"]
        },
        "manager": {
            "username": "manager",
            "full_name": "Casino Manager",
            "email": "manager@alpinroyal.com",
            "hashed_password": get_password_hash("manager"),
            "disabled": False,
            "roles": ["manager"]
        },
        "staff": {
            "username": "staff",
            "full_name": "Casino Staff",
            "email": "staff@alpinroyal.com",
            "hashed_password": get_password_hash("staff"),
            "disabled": False,
            "roles": ["staff"]
        }
    }
    
    if username in fake_users_db:
        user_dict = fake_users_db[username]
        return UserInDB(**user_dict)
    
    return None

async def authenticate_user(username: str, password: str) -> Optional[User]:
    """
    Authenticate a user.
    
    Args:
        username: Username
        password: Password
        
    Returns:
        Optional[User]: User if authentication successful, None otherwise
    """
    user = await get_user(username)
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    
    return user

def create_access_token(data: Dict[str, Any], settings: Settings = Depends(get_settings)) -> str:
    """
    Create a JWT access token.
    
    Args:
        data: Data to encode in the token
        settings: Application settings
        
    Returns:
        str: JWT token
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    
    encoded_jwt = jwt.encode(
        to_encode, 
        settings.JWT_SECRET_KEY, 
        algorithm=settings.JWT_ALGORITHM
    )
    
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme), settings: Settings = Depends(get_settings)) -> User:
    """
    Get the current user from a JWT token.
    
    Args:
        token: JWT token
        settings: Application settings
        
    Returns:
        User: Current user
        
    Raises:
        HTTPException: If token is invalid or user not found
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(
            token, 
            settings.JWT_SECRET_KEY, 
            algorithms=[settings.JWT_ALGORITHM]
        )
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        
        token_data = TokenData(
            username=username,
            roles=payload.get("roles", [])
        )
    except JWTError:
        raise credentials_exception
    
    user = await get_user(token_data.username)
    if user is None:
        raise credentials_exception
    
    return user

async def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    """
    Get the current active user.
    
    Args:
        current_user: Current user
        
    Returns:
        User: Current active user
        
    Raises:
        HTTPException: If user is disabled
    """
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    
    return current_user

def has_role(required_roles: List[str]):
    """
    Dependency for role-based access control.
    
    Args:
        required_roles: List of roles that are allowed
        
    Returns:
        Callable: Dependency function
    """
    async def role_checker(current_user: User = Depends(get_current_active_user)) -> User:
        for role in required_roles:
            if role in current_user.roles:
                return current_user
        
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    return role_checker
