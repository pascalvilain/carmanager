"""
Alpin Royal Casino Management System - Storage Utilities
This module provides file storage utilities using MinIO/S3.
"""

import logging
import io
from typing import Optional, List, Dict, Any, BinaryIO
from minio import Minio
from minio.error import S3Error
from fastapi import UploadFile

from base_layer.config.settings import Settings

logger = logging.getLogger(__name__)

# Global MinIO client
_minio_client: Optional[Minio] = None

async def init_storage(settings: Settings) -> None:
    """
    Initialize storage connection.
    
    Args:
        settings: Application settings
    """
    global _minio_client
    
    # Create client
    _minio_client = Minio(
        settings.MINIO_URL,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE
    )
    
    # Ensure bucket exists
    if not _minio_client.bucket_exists(settings.MINIO_BUCKET):
        _minio_client.make_bucket(settings.MINIO_BUCKET)
        logger.info(f"Created bucket: {settings.MINIO_BUCKET}")
    
    logger.info("Storage connection initialized")

async def close_storage() -> None:
    """
    Close storage connection.
    """
    global _minio_client
    _minio_client = None
    logger.info("Storage connection closed")

def get_storage_client() -> Minio:
    """
    Get the MinIO client.
    
    Returns:
        Minio: MinIO client
        
    Raises:
        RuntimeError: If storage is not initialized
    """
    global _minio_client
    
    if _minio_client is None:
        raise RuntimeError("Storage not initialized")
    
    return _minio_client

async def upload_file(
    file_path: str, 
    file_data: BinaryIO, 
    content_type: Optional[str] = None,
    metadata: Optional[Dict[str, str]] = None
) -> str:
    """
    Upload a file to storage.
    
    Args:
        file_path: Path to store the file (including filename)
        file_data: File data
        content_type: Content type of the file
        metadata: Optional metadata
        
    Returns:
        str: URL of the uploaded file
        
    Raises:
        S3Error: If upload fails
    """
    client = get_storage_client()
    from base_layer.config.settings import get_settings
    settings = get_settings()
    
    try:
        # Get file size
        file_data.seek(0, io.SEEK_END)
        file_size = file_data.tell()
        file_data.seek(0)
        
        # Upload file
        client.put_object(
            bucket_name=settings.MINIO_BUCKET,
            object_name=file_path,
            data=file_data,
            length=file_size,
            content_type=content_type,
            metadata=metadata
        )
        
        logger.info(f"Uploaded file: {file_path}")
        
        # Generate URL
        url = f"/{settings.MINIO_BUCKET}/{file_path}"
        return url
    
    except S3Error as e:
        logger.error(f"Error uploading file {file_path}: {str(e)}")
        raise

async def upload_fastapi_file(
    file: UploadFile, 
    destination_path: str,
    metadata: Optional[Dict[str, str]] = None
) -> str:
    """
    Upload a FastAPI UploadFile to storage.
    
    Args:
        file: FastAPI UploadFile
        destination_path: Path to store the file (including filename)
        metadata: Optional metadata
        
    Returns:
        str: URL of the uploaded file
        
    Raises:
        S3Error: If upload fails
    """
    file_data = await file.read()
    file_io = io.BytesIO(file_data)
    
    return await upload_file(
        file_path=destination_path,
        file_data=file_io,
        content_type=file.content_type,
        metadata=metadata
    )

async def download_file(file_path: str) -> io.BytesIO:
    """
    Download a file from storage.
    
    Args:
        file_path: Path of the file to download
        
    Returns:
        io.BytesIO: File data
        
    Raises:
        S3Error: If download fails
    """
    client = get_storage_client()
    from base_layer.config.settings import get_settings
    settings = get_settings()
    
    try:
        # Download file
        response = client.get_object(
            bucket_name=settings.MINIO_BUCKET,
            object_name=file_path
        )
        
        # Read data
        data = io.BytesIO(response.read())
        response.close()
        response.release_conn()
        
        logger.info(f"Downloaded file: {file_path}")
        
        return data
    
    except S3Error as e:
        logger.error(f"Error downloading file {file_path}: {str(e)}")
        raise

async def delete_file(file_path: str) -> None:
    """
    Delete a file from storage.
    
    Args:
        file_path: Path of the file to delete
        
    Raises:
        S3Error: If deletion fails
    """
    client = get_storage_client()
    from base_layer.config.settings import get_settings
    settings = get_settings()
    
    try:
        # Delete file
        client.remove_object(
            bucket_name=settings.MINIO_BUCKET,
            object_name=file_path
        )
        
        logger.info(f"Deleted file: {file_path}")
    
    except S3Error as e:
        logger.error(f"Error deleting file {file_path}: {str(e)}")
        raise

async def list_files(prefix: str) -> List[Dict[str, Any]]:
    """
    List files in storage with a given prefix.
    
    Args:
        prefix: Prefix to filter files
        
    Returns:
        List[Dict[str, Any]]: List of file information
        
    Raises:
        S3Error: If listing fails
    """
    client = get_storage_client()
    from base_layer.config.settings import get_settings
    settings = get_settings()
    
    try:
        # List objects
        objects = client.list_objects(
            bucket_name=settings.MINIO_BUCKET,
            prefix=prefix,
            recursive=True
        )
        
        # Convert to list of dicts
        result = []
        for obj in objects:
            result.append({
                'name': obj.object_name,
                'size': obj.size,
                'last_modified': obj.last_modified,
                'etag': obj.etag,
                'content_type': obj.content_type
            })
        
        return result
    
    except S3Error as e:
        logger.error(f"Error listing files with prefix {prefix}: {str(e)}")
        raise

async def get_file_url(file_path: str, expires: int = 3600) -> str:
    """
    Get a presigned URL for a file.
    
    Args:
        file_path: Path of the file
        expires: Expiration time in seconds
        
    Returns:
        str: Presigned URL
        
    Raises:
        S3Error: If URL generation fails
    """
    client = get_storage_client()
    from base_layer.config.settings import get_settings
    settings = get_settings()
    
    try:
        # Generate URL
        url = client.presigned_get_object(
            bucket_name=settings.MINIO_BUCKET,
            object_name=file_path,
            expires=expires
        )
        
        return url
    
    except S3Error as e:
        logger.error(f"Error generating URL for file {file_path}: {str(e)}")
        raise
