"""
Alpin Royal Casino Management System - Event Bus
This module provides an event bus for inter-module communication.
"""

import logging
import asyncio
from typing import Dict, List, Callable, Any, Awaitable, Optional
from pydantic import BaseModel

from base_layer.config.settings import Settings

logger = logging.getLogger(__name__)

class Event(BaseModel):
    """
    Event model for the event bus.
    """
    event_type: str
    data: Dict[str, Any]
    source: Optional[str] = None
    timestamp: Optional[float] = None

# Type for event handlers
EventHandler = Callable[[Event], Awaitable[None]]

class EventBus:
    """
    Event bus for inter-module communication.
    Implements a publish-subscribe pattern.
    """
    
    def __init__(self):
        """
        Initialize the event bus.
        """
        self.subscribers: Dict[str, List[EventHandler]] = {}
        self.event_history: List[Event] = []
        self.max_history_size = 1000
        logger.info("Event bus initialized")
    
    async def publish(self, event_type: str, data: Dict[str, Any], source: Optional[str] = None) -> None:
        """
        Publish an event to the event bus.
        
        Args:
            event_type: Type of the event
            data: Event data
            source: Source of the event
        """
        import time
        
        # Create event
        event = Event(
            event_type=event_type,
            data=data,
            source=source,
            timestamp=time.time()
        )
        
        # Add to history
        self.event_history.append(event)
        if len(self.event_history) > self.max_history_size:
            self.event_history.pop(0)
        
        # Notify subscribers
        if event_type in self.subscribers:
            tasks = []
            for handler in self.subscribers[event_type]:
                tasks.append(asyncio.create_task(self._call_handler(handler, event)))
            
            if tasks:
                await asyncio.gather(*tasks)
        
        logger.debug(f"Published event: {event_type} from {source}")
    
    async def _call_handler(self, handler: EventHandler, event: Event) -> None:
        """
        Call an event handler with error handling.
        
        Args:
            handler: Event handler function
            event: Event to handle
        """
        try:
            await handler(event)
        except Exception as e:
            logger.error(f"Error in event handler for {event.event_type}: {str(e)}")
    
    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        """
        Subscribe to an event type.
        
        Args:
            event_type: Type of event to subscribe to
            handler: Event handler function
        """
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        
        if handler not in self.subscribers[event_type]:
            self.subscribers[event_type].append(handler)
            logger.debug(f"Subscribed to event: {event_type}")
    
    def unsubscribe(self, event_type: str, handler: EventHandler) -> None:
        """
        Unsubscribe from an event type.
        
        Args:
            event_type: Type of event to unsubscribe from
            handler: Event handler function
        """
        if event_type in self.subscribers and handler in self.subscribers[event_type]:
            self.subscribers[event_type].remove(handler)
            logger.debug(f"Unsubscribed from event: {event_type}")
    
    def get_recent_events(self, event_type: Optional[str] = None, limit: int = 100) -> List[Event]:
        """
        Get recent events from the history.
        
        Args:
            event_type: Optional filter by event type
            limit: Maximum number of events to return
            
        Returns:
            List[Event]: List of recent events
        """
        if event_type:
            filtered_events = [e for e in self.event_history if e.event_type == event_type]
            return filtered_events[-limit:]
        else:
            return self.event_history[-limit:]

# Global event bus instance
_event_bus: Optional[EventBus] = None

async def init_event_bus(settings: Settings) -> None:
    """
    Initialize the event bus.
    
    Args:
        settings: Application settings
    """
    global _event_bus
    _event_bus = EventBus()
    logger.info("Event bus initialized")

async def close_event_bus() -> None:
    """
    Close the event bus.
    """
    global _event_bus
    _event_bus = None
    logger.info("Event bus closed")

def get_event_bus() -> EventBus:
    """
    Get the event bus instance.
    
    Returns:
        EventBus: Event bus instance
        
    Raises:
        RuntimeError: If event bus is not initialized
    """
    global _event_bus
    if _event_bus is None:
        raise RuntimeError("Event bus not initialized")
    
    return _event_bus
