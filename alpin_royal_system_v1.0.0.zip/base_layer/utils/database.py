"""
Alpin Royal Casino Management System - Database Utilities
This module provides database connection and utility functions.
"""

import logging
from typing import Optional, Dict, Any
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, AsyncEngine
from sqlalchemy.orm import sessionmaker
from motor.motor_asyncio import AsyncIOMotorClient
import redis.asyncio as redis
from elasticsearch import AsyncElasticsearch

from base_layer.config.settings import Settings

logger = logging.getLogger(__name__)

# Global database connections
_pg_engine: Optional[AsyncEngine] = None
_pg_session_factory: Optional[sessionmaker] = None
_mongo_client: Optional[AsyncIOMotorClient] = None
_redis_client: Optional[redis.Redis] = None
_es_client: Optional[AsyncElasticsearch] = None

async def init_db(settings: Settings) -> None:
    """
    Initialize database connections.
    
    Args:
        settings: Application settings
    """
    await init_postgres(settings)
    await init_mongodb(settings)
    await init_redis(settings)
    await init_elasticsearch(settings)
    
    logger.info("All database connections initialized")

async def init_postgres(settings: Settings) -> None:
    """
    Initialize PostgreSQL connection.
    
    Args:
        settings: Application settings
    """
    global _pg_engine, _pg_session_factory
    
    # Convert PostgreSQL URL to async format
    db_url = str(settings.DATABASE_URL)
    if db_url.startswith("postgresql://"):
        db_url = db_url.replace("postgresql://", "postgresql+asyncpg://")
    
    # Create engine
    _pg_engine = create_async_engine(
        db_url,
        echo=settings.DEBUG,
        future=True
    )
    
    # Create session factory
    _pg_session_factory = sessionmaker(
        _pg_engine,
        class_=AsyncSession,
        expire_on_commit=False
    )
    
    logger.info("PostgreSQL connection initialized")

async def init_mongodb(settings: Settings) -> None:
    """
    Initialize MongoDB connection.
    
    Args:
        settings: Application settings
    """
    global _mongo_client
    
    # Create client
    _mongo_client = AsyncIOMotorClient(settings.MONGODB_URL)
    
    # Test connection
    await _mongo_client.admin.command('ping')
    
    logger.info("MongoDB connection initialized")

async def init_redis(settings: Settings) -> None:
    """
    Initialize Redis connection.
    
    Args:
        settings: Application settings
    """
    global _redis_client
    
    # Create client
    _redis_client = redis.from_url(settings.REDIS_URL)
    
    # Test connection
    await _redis_client.ping()
    
    logger.info("Redis connection initialized")

async def init_elasticsearch(settings: Settings) -> None:
    """
    Initialize Elasticsearch connection.
    
    Args:
        settings: Application settings
    """
    global _es_client
    
    # Create client
    _es_client = AsyncElasticsearch([settings.ELASTICSEARCH_URL])
    
    # Test connection
    await _es_client.info()
    
    logger.info("Elasticsearch connection initialized")

async def close_db() -> None:
    """
    Close all database connections.
    """
    await close_postgres()
    await close_mongodb()
    await close_redis()
    await close_elasticsearch()
    
    logger.info("All database connections closed")

async def close_postgres() -> None:
    """
    Close PostgreSQL connection.
    """
    global _pg_engine
    
    if _pg_engine is not None:
        await _pg_engine.dispose()
        _pg_engine = None
    
    logger.info("PostgreSQL connection closed")

async def close_mongodb() -> None:
    """
    Close MongoDB connection.
    """
    global _mongo_client
    
    if _mongo_client is not None:
        _mongo_client.close()
        _mongo_client = None
    
    logger.info("MongoDB connection closed")

async def close_redis() -> None:
    """
    Close Redis connection.
    """
    global _redis_client
    
    if _redis_client is not None:
        await _redis_client.close()
        _redis_client = None
    
    logger.info("Redis connection closed")

async def close_elasticsearch() -> None:
    """
    Close Elasticsearch connection.
    """
    global _es_client
    
    if _es_client is not None:
        await _es_client.close()
        _es_client = None
    
    logger.info("Elasticsearch connection closed")

async def get_db_session() -> AsyncSession:
    """
    Get a PostgreSQL database session.
    
    Returns:
        AsyncSession: Database session
        
    Raises:
        RuntimeError: If database is not initialized
    """
    global _pg_session_factory
    
    if _pg_session_factory is None:
        raise RuntimeError("PostgreSQL not initialized")
    
    async with _pg_session_factory() as session:
        try:
            yield session
        finally:
            await session.close()

def get_mongo_db(db_name: Optional[str] = None):
    """
    Get a MongoDB database.
    
    Args:
        db_name: Database name, defaults to settings.MONGODB_DB_NAME
        
    Returns:
        Database: MongoDB database
        
    Raises:
        RuntimeError: If MongoDB is not initialized
    """
    global _mongo_client
    
    if _mongo_client is None:
        raise RuntimeError("MongoDB not initialized")
    
    from base_layer.config.settings import get_settings
    settings = get_settings()
    
    if db_name is None:
        db_name = settings.MONGODB_DB_NAME
    
    return _mongo_client[db_name]

def get_redis_client():
    """
    Get the Redis client.
    
    Returns:
        Redis: Redis client
        
    Raises:
        RuntimeError: If Redis is not initialized
    """
    global _redis_client
    
    if _redis_client is None:
        raise RuntimeError("Redis not initialized")
    
    return _redis_client

def get_elasticsearch_client():
    """
    Get the Elasticsearch client.
    
    Returns:
        AsyncElasticsearch: Elasticsearch client
        
    Raises:
        RuntimeError: If Elasticsearch is not initialized
    """
    global _es_client
    
    if _es_client is None:
        raise RuntimeError("Elasticsearch not initialized")
    
    return _es_client
