"""
Alpin Royal Casino Management System - Logger
This module provides logging utilities for the application.
"""

import logging
import sys
import os
from logging.handlers import RotatingFileHandler
from typing import Optional

from base_layer.config.settings import get_settings

def setup_logging(log_dir: Optional[str] = None) -> None:
    """
    Set up logging for the application.
    
    Args:
        log_dir: Directory to store log files, defaults to './logs'
    """
    settings = get_settings()
    
    # Set default log directory if not provided
    if log_dir is None:
        log_dir = os.path.join(os.getcwd(), 'logs')
    
    # Create log directory if it doesn't exist
    os.makedirs(log_dir, exist_ok=True)
    
    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(settings.LOG_LEVEL)
    
    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Create formatters
    console_formatter = logging.Formatter(settings.LOG_FORMAT)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(settings.LOG_LEVEL)
    root_logger.addHandler(console_handler)
    
    # Create file handler for general logs
    general_log_file = os.path.join(log_dir, 'alpin_royal.log')
    file_handler = RotatingFileHandler(
        general_log_file,
        maxBytes=10485760,  # 10 MB
        backupCount=10
    )
    file_handler.setFormatter(file_formatter)
    file_handler.setLevel(settings.LOG_LEVEL)
    root_logger.addHandler(file_handler)
    
    # Create file handler for error logs
    error_log_file = os.path.join(log_dir, 'error.log')
    error_file_handler = RotatingFileHandler(
        error_log_file,
        maxBytes=10485760,  # 10 MB
        backupCount=10
    )
    error_file_handler.setFormatter(file_formatter)
    error_file_handler.setLevel(logging.ERROR)
    root_logger.addHandler(error_file_handler)
    
    # Set specific loggers
    set_library_log_levels()
    
    logging.info(f"Logging initialized at level {settings.LOG_LEVEL}")

def set_library_log_levels() -> None:
    """
    Set log levels for third-party libraries.
    """
    # Set log levels for noisy libraries
    logging.getLogger("uvicorn").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("fastapi").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    logging.getLogger("elasticsearch").setLevel(logging.WARNING)
    logging.getLogger("minio").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
