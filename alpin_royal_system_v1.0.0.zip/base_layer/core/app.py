"""
Alpin Royal Casino Management System - Core Application
This module contains the main FastAPI application and initialization logic.
"""

import logging
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from base_layer.config.settings import get_settings, Settings
from base_layer.module_system.module_registry import ModuleRegistry
from base_layer.api.api_router import api_router
from base_layer.utils.database import init_db, close_db
from base_layer.utils.event_bus import init_event_bus, close_event_bus
from base_layer.utils.storage import init_storage, close_storage
from base_layer.utils.logger import setup_logging

logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for FastAPI application.
    Handles startup and shutdown events.
    """
    # Setup logging
    setup_logging()
    
    # Initialize components
    settings = get_settings()
    logger.info(f"Starting Alpin Royal Casino Management System in {settings.environment} mode")
    
    # Initialize databases
    await init_db(settings)
    
    # Initialize event bus
    await init_event_bus(settings)
    
    # Initialize storage
    await init_storage(settings)
    
    # Initialize module registry
    module_registry = ModuleRegistry(app, settings)
    await module_registry.initialize_modules()
    
    logger.info("Alpin Royal Casino Management System started successfully")
    
    yield
    
    # Shutdown logic
    logger.info("Shutting down Alpin Royal Casino Management System")
    
    # Shutdown modules
    await module_registry.shutdown_modules()
    
    # Close connections
    await close_storage()
    await close_event_bus()
    await close_db()
    
    logger.info("Alpin Royal Casino Management System shutdown complete")

def create_app() -> FastAPI:
    """
    Create and configure the FastAPI application.
    
    Returns:
        FastAPI: Configured FastAPI application
    """
    settings = get_settings()
    
    app = FastAPI(
        title="Alpin Royal Casino Management System",
        description="A comprehensive casino management system with modular architecture and AI integration",
        version="1.0.0",
        lifespan=lifespan
    )
    
    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include main API router
    app.include_router(api_router)
    
    return app

app = create_app()
