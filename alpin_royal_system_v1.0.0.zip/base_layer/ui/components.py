"""
Casino Management System - Common UI Components
This module provides common UI components for the Casino Management System.
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

class UIComponentRegistry:
    """
    Registry for UI components in the Casino Management System.
    Provides a way to register and retrieve UI components for both desktop and mobile interfaces.
    """
    
    def __init__(self):
        """Initialize the UI component registry."""
        self.components = {
            "desktop": {},
            "mobile": {}
        }
        self.logger = logging.getLogger("ui_components")
    
    def register_component(self, platform: str, name: str, component_data: Dict[str, Any]) -> None:
        """
        Register a UI component.
        
        Args:
            platform: The platform (desktop or mobile)
            name: The component name
            component_data: The component data
        """
        if platform not in self.components:
            raise ValueError(f"Invalid platform: {platform}")
        
        self.components[platform][name] = component_data
        self.logger.debug(f"Registered {platform} component: {name}")
    
    def get_component(self, platform: str, name: str) -> Optional[Dict[str, Any]]:
        """
        Get a UI component.
        
        Args:
            platform: The platform (desktop or mobile)
            name: The component name
            
        Returns:
            The component data or None if not found
        """
        if platform not in self.components:
            raise ValueError(f"Invalid platform: {platform}")
        
        return self.components[platform].get(name)
    
    def get_all_components(self, platform: str) -> Dict[str, Any]:
        """
        Get all UI components for a platform.
        
        Args:
            platform: The platform (desktop or mobile)
            
        Returns:
            Dictionary of all components
        """
        if platform not in self.components:
            raise ValueError(f"Invalid platform: {platform}")
        
        return self.components[platform]
    
    def load_components_from_directory(self, directory: str) -> None:
        """
        Load UI components from a directory.
        
        Args:
            directory: The directory path
        """
        dir_path = Path(directory)
        if not dir_path.exists():
            self.logger.warning(f"UI components directory does not exist: {directory}")
            return
        
        # Load desktop components
        desktop_dir = dir_path / "desktop"
        if desktop_dir.exists():
            self._load_components_from_directory(desktop_dir, "desktop")
        
        # Load mobile components
        mobile_dir = dir_path / "mobile"
        if mobile_dir.exists():
            self._load_components_from_directory(mobile_dir, "mobile")
    
    def _load_components_from_directory(self, directory: Path, platform: str) -> None:
        """
        Load UI components from a directory for a specific platform.
        
        Args:
            directory: The directory path
            platform: The platform (desktop or mobile)
        """
        for file_path in directory.glob("*.json"):
            try:
                with open(file_path, "r") as f:
                    component_data = json.load(f)
                
                component_name = file_path.stem
                self.register_component(platform, component_name, component_data)
                self.logger.debug(f"Loaded {platform} component from file: {file_path}")
                
            except Exception as e:
                self.logger.error(f"Error loading component from {file_path}: {str(e)}")

# Common UI components for desktop
DESKTOP_COMPONENTS = {
    "header": {
        "type": "header",
        "properties": {
            "logo": "/static/images/logo.png",
            "title": "Casino Management System",
            "user_menu": True,
            "notifications": True
        }
    },
    "sidebar": {
        "type": "sidebar",
        "properties": {
            "modules": [
                {"name": "Player Tracking", "icon": "user", "route": "/player-tracking"},
                {"name": "Cashdesk", "icon": "money", "route": "/cashdesk"},
                {"name": "Reception", "icon": "hotel", "route": "/reception"},
                {"name": "Gaming Pit", "icon": "cards", "route": "/gaming-pit"},
                {"name": "Slot Machines", "icon": "slots", "route": "/slots"},
                {"name": "Employee Management", "icon": "people", "route": "/employees"},
                {"name": "Bar", "icon": "drink", "route": "/bar"},
                {"name": "Hotel", "icon": "bed", "route": "/hotel"},
                {"name": "Restaurant", "icon": "food", "route": "/restaurant"}
            ],
            "collapsible": True
        }
    },
    "footer": {
        "type": "footer",
        "properties": {
            "copyright": "© 2025 Casino Management System",
            "links": [
                {"name": "Help", "url": "/help"},
                {"name": "About", "url": "/about"},
                {"name": "Contact", "url": "/contact"}
            ]
        }
    },
    "data_table": {
        "type": "data_table",
        "properties": {
            "pagination": True,
            "search": True,
            "export": True,
            "selectable": True,
            "sortable": True,
            "filterable": True
        }
    },
    "card": {
        "type": "card",
        "properties": {
            "elevation": 2,
            "header": True,
            "footer": False,
            "collapsible": False
        }
    },
    "form": {
        "type": "form",
        "properties": {
            "validation": True,
            "responsive": True,
            "auto_save": False
        }
    },
    "button": {
        "type": "button",
        "properties": {
            "variants": ["primary", "secondary", "success", "danger", "warning", "info"],
            "sizes": ["small", "medium", "large"],
            "icons": True
        }
    },
    "input": {
        "type": "input",
        "properties": {
            "types": ["text", "number", "email", "password", "date", "time", "datetime"],
            "validation": True,
            "masks": True
        }
    },
    "modal": {
        "type": "modal",
        "properties": {
            "sizes": ["small", "medium", "large", "fullscreen"],
            "draggable": True,
            "resizable": True
        }
    },
    "tabs": {
        "type": "tabs",
        "properties": {
            "variants": ["horizontal", "vertical"],
            "responsive": True
        }
    },
    "alert": {
        "type": "alert",
        "properties": {
            "variants": ["success", "info", "warning", "error"],
            "dismissible": True,
            "timeout": True
        }
    },
    "chart": {
        "type": "chart",
        "properties": {
            "types": ["bar", "line", "pie", "doughnut", "radar", "scatter"],
            "responsive": True,
            "interactive": True,
            "exportable": True
        }
    },
    "dashboard": {
        "type": "dashboard",
        "properties": {
            "layout": "grid",
            "widgets": True,
            "customizable": True,
            "responsive": True
        }
    }
}

# Common UI components for mobile
MOBILE_COMPONENTS = {
    "header": {
        "type": "header",
        "properties": {
            "logo": "/static/images/logo-small.png",
            "title": "CMS",
            "menu_button": True,
            "back_button": True
        }
    },
    "navigation": {
        "type": "navigation",
        "properties": {
            "type": "bottom",
            "items": [
                {"name": "Home", "icon": "home", "route": "/"},
                {"name": "Players", "icon": "user", "route": "/players"},
                {"name": "Activities", "icon": "activity", "route": "/activities"},
                {"name": "Scan", "icon": "qrcode", "route": "/scan"},
                {"name": "More", "icon": "more", "route": "/more"}
            ]
        }
    },
    "card": {
        "type": "card",
        "properties": {
            "elevation": 1,
            "swipeable": True,
            "actionable": True
        }
    },
    "form": {
        "type": "form",
        "properties": {
            "validation": True,
            "step_by_step": True,
            "auto_save": True
        }
    },
    "button": {
        "type": "button",
        "properties": {
            "variants": ["primary", "secondary", "success", "danger"],
            "sizes": ["small", "medium", "large", "full"],
            "icons": True,
            "floating": True
        }
    },
    "input": {
        "type": "input",
        "properties": {
            "types": ["text", "number", "date", "time", "barcode"],
            "keyboard_types": ["default", "numeric", "email", "phone"],
            "auto_complete": True
        }
    },
    "list": {
        "type": "list",
        "properties": {
            "swipeable": True,
            "pull_to_refresh": True,
            "infinite_scroll": True,
            "searchable": True
        }
    },
    "modal": {
        "type": "modal",
        "properties": {
            "position": ["bottom", "center", "full"],
            "backdrop_dismissible": True
        }
    },
    "tabs": {
        "type": "tabs",
        "properties": {
            "swipeable": True,
            "icons": True
        }
    },
    "alert": {
        "type": "alert",
        "properties": {
            "variants": ["success", "info", "warning", "error"],
            "position": ["top", "bottom"],
            "dismissible": True
        }
    },
    "scanner": {
        "type": "scanner",
        "properties": {
            "types": ["barcode", "qrcode"],
            "camera_access": True,
            "flash": True,
            "vibration": True
        }
    },
    "numpad": {
        "type": "numpad",
        "properties": {
            "large_keys": True,
            "decimal_point": True,
            "backspace": True,
            "clear": True
        }
    },
    "quick_actions": {
        "type": "quick_actions",
        "properties": {
            "grid_layout": True,
            "icons": True,
            "customizable": True
        }
    }
}

# Global UI component registry instance
ui_component_registry = UIComponentRegistry()

# Register default components
for name, component in DESKTOP_COMPONENTS.items():
    ui_component_registry.register_component("desktop", name, component)

for name, component in MOBILE_COMPONENTS.items():
    ui_component_registry.register_component("mobile", name, component)

def get_ui_component_registry() -> UIComponentRegistry:
    """
    Get the global UI component registry instance.
    
    Returns:
        The UI component registry instance
    """
    return ui_component_registry
