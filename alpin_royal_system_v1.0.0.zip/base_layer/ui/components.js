"""
Alpin Royal Casino Management System - UI Components
This module provides common UI components for the application.
"""

import React from 'react'
import { 
  Box, 
  Button, 
  Card, 
  CardContent, 
  CircularProgress, 
  Dialog, 
  DialogActions, 
  DialogContent, 
  DialogContentText, 
  DialogTitle,
  Divider,
  IconButton,
  Paper,
  Snackbar,
  TextField,
  Typography,
  useTheme
} from '@mui/material'
import { styled } from '@mui/material/styles'

// Styled components for common use

export const PageContainer = styled(Box)(({ theme }) => ({
  padding: theme.spacing(3),
  width: '100%',
  maxWidth: '1600px',
  margin: '0 auto',
}))

export const PageHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: theme.spacing(3),
}))

export const ContentCard = styled(Card)(({ theme }) => ({
  marginBottom: theme.spacing(3),
  boxShadow: theme.shadows[2],
  borderRadius: theme.shape.borderRadius,
  overflow: 'hidden',
}))

export const DashboardWidget = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[2],
}))

export const WidgetTitle = styled(Typography)(({ theme }) => ({
  fontWeight: 600,
  marginBottom: theme.spacing(1),
}))

export const FormContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(2),
  width: '100%',
}))

export const ActionBar = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'flex-end',
  gap: theme.spacing(1),
  marginTop: theme.spacing(2),
}))

export const DataGrid = styled(Box)(({ theme }) => ({
  width: '100%',
  overflowX: 'auto',
  '& table': {
    width: '100%',
    borderCollapse: 'collapse',
  },
  '& th, & td': {
    padding: theme.spacing(1.5),
    textAlign: 'left',
    borderBottom: `1px solid ${theme.palette.divider}`,
  },
  '& th': {
    fontWeight: 600,
    backgroundColor: theme.palette.background.default,
  },
}))

// React components

export const LoadingSpinner = ({ size = 40 }) => (
  <Box display="flex" justifyContent="center" alignItems="center" p={3}>
    <CircularProgress size={size} />
  </Box>
)

export const EmptyState = ({ title, description, icon, action }) => (
  <Box 
    display="flex" 
    flexDirection="column" 
    alignItems="center" 
    justifyContent="center" 
    p={4}
    textAlign="center"
  >
    {icon && <Box mb={2}>{icon}</Box>}
    <Typography variant="h6" gutterBottom>{title}</Typography>
    <Typography variant="body2" color="textSecondary" mb={3}>
      {description}
    </Typography>
    {action && action}
  </Box>
)

export const ConfirmDialog = ({ 
  open, 
  title, 
  message, 
  confirmText = 'Confirm', 
  cancelText = 'Cancel',
  onConfirm, 
  onCancel 
}) => (
  <Dialog open={open} onClose={onCancel}>
    <DialogTitle>{title}</DialogTitle>
    <DialogContent>
      <DialogContentText>{message}</DialogContentText>
    </DialogContent>
    <DialogActions>
      <Button onClick={onCancel} color="primary">
        {cancelText}
      </Button>
      <Button onClick={onConfirm} color="primary" variant="contained" autoFocus>
        {confirmText}
      </Button>
    </DialogActions>
  </Dialog>
)

export const SearchField = ({ value, onChange, placeholder = 'Search...', onClear }) => {
  return (
    <TextField
      fullWidth
      variant="outlined"
      size="small"
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      InputProps={{
        endAdornment: value ? (
          <IconButton size="small" onClick={onClear}>
            <ClearIcon fontSize="small" />
          </IconButton>
        ) : null,
      }}
    />
  )
}

// Theme and styling utilities

export const getStatusColor = (status, theme) => {
  const colors = {
    active: theme.palette.success.main,
    inactive: theme.palette.text.disabled,
    pending: theme.palette.warning.main,
    error: theme.palette.error.main,
    completed: theme.palette.success.main,
    processing: theme.palette.info.main,
  }
  
  return colors[status.toLowerCase()] || theme.palette.text.primary
}

export const StatusBadge = ({ status, label }) => {
  const theme = useTheme()
  const color = getStatusColor(status, theme)
  
  return (
    <Box
      sx={{
        display: 'inline-flex',
        alignItems: 'center',
        px: 1,
        py: 0.5,
        borderRadius: '4px',
        backgroundColor: `${color}20`,
        color: color,
        fontSize: '0.75rem',
        fontWeight: 600,
      }}
    >
      {label || status}
    </Box>
  )
}

// Mock implementation of icons for the example
const ClearIcon = () => <span>✕</span>
