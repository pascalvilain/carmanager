"""
Alpin Royal Casino Management System - Settings
This module contains the application settings and configuration.
"""

import os
from typing import List, Dict, Any, Optional
from functools import lru_cache
from pydantic import BaseSettings, PostgresDsn, AnyHttpUrl, validator

class Settings(BaseSettings):
    """
    Application settings and configuration.
    """
    # Application settings
    APP_NAME: str = "Alpin Royal Casino Management System"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    SECRET_KEY: str = "your-secret-key-here"  # Change in production
    API_PREFIX: str = "/api"
    
    # CORS settings
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:8000"]
    
    # Database settings
    DATABASE_URL: PostgresDsn = "postgresql://postgres:postgres@localhost:5432/alpin_royal"
    MONGODB_URL: str = "mongodb://localhost:27017/"
    MONGODB_DB_NAME: str = "alpin_royal"
    REDIS_URL: str = "redis://localhost:6379/0"
    ELASTICSEARCH_URL: str = "http://localhost:9200"
    
    # Storage settings
    MINIO_URL: str = "localhost:9000"
    MINIO_ACCESS_KEY: str = "minioadmin"
    MINIO_SECRET_KEY: str = "minioadmin"
    MINIO_SECURE: bool = False
    MINIO_BUCKET: str = "alpin-royal"
    
    # JWT settings
    JWT_SECRET_KEY: str = "your-jwt-secret-key-here"  # Change in production
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # Module settings
    ENABLED_MODULES: List[str] = [
        "player_tracking",
        "network_design",
        "inventory_management",
        "ticket_system"
    ]
    
    # AI settings
    AI_MODEL_PATH: str = "./models"
    NLP_MODEL_NAME: str = "en_core_web_md"
    
    # Logging settings
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Email settings
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: Optional[int] = None
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    
    class Config:
        env_file = ".env"
        case_sensitive = True

    @validator("CORS_ORIGINS", pre=True)
    def assemble_cors_origins(cls, v: str | List[str]) -> List[str] | str:
        if isinstance(v, str) and not v.startswith("["):
            return [i.strip() for i in v.split(",")]
        elif isinstance(v, (list, str)):
            return v
        raise ValueError(v)

@lru_cache()
def get_settings() -> Settings:
    """
    Get application settings with caching.
    
    Returns:
        Settings: Application settings
    """
    return Settings()
