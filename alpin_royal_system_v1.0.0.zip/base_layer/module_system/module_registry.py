"""
Alpin Royal Casino Management System - Module Registry
This module handles the registration and management of system modules.
"""

import logging
import importlib
import inspect
from typing import Dict, List, Type, Any
from fastapi import FastAPI

from base_layer.config.settings import Settings

logger = logging.getLogger(__name__)

class ModuleBase:
    """
    Base class for all modules in the system.
    All modules must inherit from this class.
    """
    
    def __init__(self, app: FastAPI, settings: Settings):
        """
        Initialize the module.
        
        Args:
            app: The FastAPI application instance
            settings: Application settings
        """
        self.app = app
        self.settings = settings
        self.name = self.__class__.__module__.split('.')[-2]  # Get module name from module path
        logger.info(f"Initializing module: {self.name}")
    
    async def initialize(self) -> None:
        """
        Initialize the module. This method is called during system startup.
        Override this method to perform module-specific initialization.
        """
        logger.info(f"Module {self.name} initialized")
    
    async def register_routes(self) -> None:
        """
        Register API routes for the module.
        Override this method to register module-specific routes.
        """
        logger.info(f"Routes registered for module {self.name}")
    
    async def register_event_handlers(self) -> None:
        """
        Register event handlers for the module.
        Override this method to register module-specific event handlers.
        """
        logger.info(f"Event handlers registered for module {self.name}")
    
    async def shutdown(self) -> None:
        """
        Shutdown the module. This method is called during system shutdown.
        Override this method to perform module-specific cleanup.
        """
        logger.info(f"Module {self.name} shutdown")


class ModuleRegistry:
    """
    Registry for all modules in the system.
    Handles module discovery, initialization, and lifecycle management.
    """
    
    def __init__(self, app: FastAPI, settings: Settings):
        """
        Initialize the module registry.
        
        Args:
            app: The FastAPI application instance
            settings: Application settings
        """
        self.app = app
        self.settings = settings
        self.modules: Dict[str, ModuleBase] = {}
        logger.info("Module registry initialized")
    
    async def discover_modules(self) -> List[Type[ModuleBase]]:
        """
        Discover available modules based on the enabled_modules setting.
        
        Returns:
            List[Type[ModuleBase]]: List of discovered module classes
        """
        discovered_modules = []
        
        for module_name in self.settings.ENABLED_MODULES:
            try:
                # Import the module
                module_path = f"modules.{module_name}.module"
                module = importlib.import_module(module_path)
                
                # Find the Module class
                for name, obj in inspect.getmembers(module):
                    if (inspect.isclass(obj) and 
                        issubclass(obj, ModuleBase) and 
                        obj != ModuleBase):
                        discovered_modules.append(obj)
                        logger.info(f"Discovered module: {module_name}")
                        break
                else:
                    logger.warning(f"No Module class found in {module_path}")
            
            except ImportError as e:
                logger.error(f"Failed to import module {module_name}: {str(e)}")
            except Exception as e:
                logger.error(f"Error discovering module {module_name}: {str(e)}")
        
        return discovered_modules
    
    async def initialize_modules(self) -> None:
        """
        Initialize all discovered modules.
        """
        # Discover modules
        module_classes = await self.discover_modules()
        
        # Initialize modules
        for module_class in module_classes:
            try:
                # Instantiate the module
                module_instance = module_class(self.app, self.settings)
                module_name = module_instance.name
                
                # Initialize the module
                await module_instance.initialize()
                
                # Register routes
                await module_instance.register_routes()
                
                # Register event handlers
                await module_instance.register_event_handlers()
                
                # Store the module instance
                self.modules[module_name] = module_instance
                
                logger.info(f"Module {module_name} initialized and registered")
            
            except Exception as e:
                logger.error(f"Error initializing module {module_class.__name__}: {str(e)}")
        
        logger.info(f"Initialized {len(self.modules)} modules")
    
    async def shutdown_modules(self) -> None:
        """
        Shutdown all modules.
        """
        for module_name, module_instance in self.modules.items():
            try:
                await module_instance.shutdown()
                logger.info(f"Module {module_name} shutdown complete")
            except Exception as e:
                logger.error(f"Error shutting down module {module_name}: {str(e)}")
        
        logger.info("All modules shutdown complete")
    
    def get_module(self, module_name: str) -> ModuleBase:
        """
        Get a module instance by name.
        
        Args:
            module_name: Name of the module
            
        Returns:
            ModuleBase: Module instance
            
        Raises:
            KeyError: If module is not found
        """
        if module_name not in self.modules:
            raise KeyError(f"Module {module_name} not found")
        
        return self.modules[module_name]
